# Versions

The kit's versions, newest first. The website's Versions page is built from this file (`setup/build_site.py`): add a version at the top, with a `## <version> · <date>` heading and one line per change.

## 3.1 · 19 Nov 2026

- Fixes "Internal error during import" in Figma for decks built with the 3.0 download from the website. Every file the kit writes now carries a preview image, like the files Figma saves.
- Built on the official template as saved from Figma on 19 Nov 2026.
- Finds the template's theme colours even when Figma renames the theme.
- When Figma refuses a deck, Kiro knows the steps: get the latest kit, refresh the template from Figma, then tell the maintainer.
- Rebuild decks made with 3.0.

## 3.0 · 18 Nov 2026

- The official Figma template, [00 Day & Night template](https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4), is the base of every build.
- 40 layouts, 12 of them new: the legacy gradient cover, the oversized-number divider, the brand-circle question, the composition overview, the current-state walkthrough with video, the laptop comparison, variants, anatomy, shortcuts and evidence, the audit collage, the gradient brief and the design-team slogan.
- Text uses the template's "Shiji /" text styles, colours come from its Slides theme, labels are Noto Sans and layers carry the template's names.
- A public edition of the kit for the website, without the team's own screenshots, recordings and internal links.

## 2.0 · 18 Nov 2026

- The Shiji Day & Night look: night slides with Night Serif titles and one Energetic Green highlight, day slides for screenshots, the aurora on the cover.
- A new skill, `presentation-brand`: the Brand Kit colours, the aurora and horizon gradients, the type, the day, night and blue themes, the rules and a visual check, all from one file of tokens.
- 28 layouts, and a Day & Night showcase file with every layout once, to open in Figma.
- Decks are `.fig` files, which Figma's file browser takes by drag and drop.
- The kit's website.

## 1.0 · 17 Nov 2026

- First version: Kiro builds the design team's presentations as native Figma Slides files, on the Product Presentation Template.
- The `presentation-designer` agent runs the whole flow (brief, story, copy, build, visual check, hand-over) and reviews decks.
- The `presentation-writer` skill: deck types (quarterly, design update, research readout), the team's voice, slide copy rules, live moments and a copy check.
- The `figma-slides-builder` skill: 27 layouts from the template and the team's decks, preview and fit report, file check, PowerPoint export.
- A library of the 20 template slides and four of the team's decks (190 slides).
