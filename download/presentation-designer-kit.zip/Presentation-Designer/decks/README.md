# Decks

One folder per deck, named in kebab case (`design-updates-q4-2026`). The presentation-designer agent creates it.

```
decks/design-updates-q4-2026/
├── brief.md          ← audience, goal, length, sources
├── outline.md        ← the story, one line per slide
├── deck.json         ← every slide's copy and notes (what the build reads)
├── img/              ← screenshots and pictures used on slides
├── Design Updates Q4 2026.fig    ← drag onto the Figma file browser
└── preview/          ← contact sheets, one PNG per slide, fit report
```

These folders are your own work: the share zip leaves them out.
