# Presentation Designer: Figma Slides with Kiro

Build the design team's presentations as **native Figma Slides files** with Kiro, on the team's official template, **"00 Day & Night template"** ([open it in Figma](https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4)). Kiro writes the story and the copy in the team's voice, then builds a Figma Slides file: night slides with Night Serif titles and one Energetic Green highlight, day slides for the screenshots, the aurora on the cover. Drag the `.fig` file onto the Figma file browser and it opens as a Slides deck that belongs to the template: text linked to its text styles, colours bound to its Slides theme, the linked Shiji logo and icons, real gradients, videos that play, auto layout text, speaker notes in presenter view, transitions set, and one named row of the slide grid per section. PowerPoint export is there for the times someone needs it.

Version 4.0 · 19 Nov 2026 · maintained by Laura Casas (Design) · every version in [CHANGELOG.md](CHANGELOG.md)

**New in 4.0:** infographics. A fourth skill, `presentation-infographics`, draws eight kinds of diagram (wheel, rings, cycle, process, user flow, timeline, hierarchy, matrix) as editable Figma layers in the template's own style: its chips, cards and gradient circle, Night Serif for the anchor, Day Sans for titles, Noto Sans for labels. Kiro proposes one in the outline whenever a slide explains a structure. Every label is checked for contrast (4.5:1). A diagram also exports as a PNG or a one-slide Figma file. Examples: `examples/infographics/Shiji infographics.fig`.

**New in 3.0:** the official Figma template is the base of every build (40 layouts, 12 of them new: the legacy gradient cover, the oversized-number divider, the brand-circle question, the composition overview, the current-state walkthrough with video, the laptop comparison, variants, anatomy, shortcuts and evidence, the audit collage, the gradient brief, the design-team slogan). Text uses the template's "Shiji /" text styles, labels are Noto Sans, layers carry the template's names.

## What is inside

| | |
|---|---|
| **Agent** `presentation-designer` | Runs the whole flow: brief, story, copy, build, visual check, hand-over. Also reviews decks. |
| **Skill** `presentation-writer` | The words: deck types (quarterly, design update, research readout), the team's voice, slide copy rules, live moments (comedic relief, quotes, questions, reveals), a copy check, starter specs, reviews. |
| **Skill** `presentation-brand` | The look: Shiji Brand Kit colours and the template's theme colours, the aurora and horizon gradients, Night Serif / Day Sans / Noto Sans and the template's text styles, the day, night and blue themes, the legacy accents, the rules and a visual check. One file of tokens drives every slide. |
| **Skill** `presentation-infographics` | The diagrams: wheel, rings, cycle, process, user flow, timeline, hierarchy and matrix as editable Figma layers, which one fits which content (Kiro proposes them without being asked), the type pairings, the contrast check on every label, PNG and one-slide Figma export. |
| **Skill** `figma-slides-builder` | The file: the template's 40 layouts, the build into a Figma Slides file, preview and fit report, file check, PowerPoint export. |
| **The official template** | `template/Day & Night template.deck`: the local copy of [00 Day & Night template](https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4), saved from Figma. Every build starts from it. |
| **Day & Night showcase** | `examples/day-night-template/Shiji Day & Night template.fig`: the template's 40 layouts rebuilt by the kit, with sample content, in the template's rows. Drag it into Figma to compare. |
| **Infographics examples** | `examples/infographics/Shiji infographics.fig`: one slide per diagram with sample data. Drag it into Figma to see and reuse them. |
| **Library** | `library/index.html`: the Day & Night layouts, the previous template and four of the team's decks (190 slides). |

## Setup (once, about 5 minutes)

1. **Open this folder on its own in Kiro** (File > Open Folder) and trust it when Kiro asks. The agent, skills and rules live in the hidden `.kiro/` folder (Finder: Cmd + Shift + . shows it). Copy the whole folder, never only the visible files.
   - To use it next to other folders in the same window instead, use File > Add Folder to Workspace.
2. **Install Google Chrome** if you do not have it. Kiro uses it to measure text and draw previews.
3. **Fonts.** Install the Shiji fonts (Shiji Day Sans Aeonik, Shiji Night Serif Reckless Neue) from the design lead. Noto Sans is free on Google Fonts. Figma has them already; the fonts only make the local preview exact.
4. **Check:** in a terminal in this folder, `python3 setup/check_setup.py`. It checks the tools and builds a short test deck. Drag `examples/smoke-test/Smoke test.fig` onto the Figma file browser: if it opens as a Slides file with the right fonts and colours, you are set.

Works on macOS with Python 3.9 or newer. If `python3` is missing, macOS offers to install it (with its command line tools) the first time you type it in a terminal. Apart from Python and Chrome, building decks needs nothing else. Optional: `brew install zstd` lets Kiro read decks saved by Figma for a review. On Windows or Linux the build works; previews and PowerPoint pictures use macOS tools.

## Making a deck

In Kiro, pick the **presentation-designer** agent (agent menu in the chat) and describe the deck:

- *"Design Updates Q4 2026 for product leadership, 40 minutes. Here are the Jira epics and the adoption numbers."*
- *"A component update on the new Panel for developers and QA. Figma file: ..., prototype: ..."*
- *"Turn these research notes into a readout for the product team. Humour is welcome."*
- *"Review this deck for tone and consistency"* (with a Figma link, or a local copy saved from Figma)

Kiro will:

1. Ask a few questions (audience, length, where the facts are) and save `brief.md`.
2. Propose the story, one line per slide (`outline.md`), and wait for your yes.
3. Write all the copy and speaker notes into `deck.json`, place a few live moments (a quote, a question to the room, maybe a meme), turn structures into infographics (a wheel, a user flow, a timeline...), and run the copy check.
4. Build `<Deck name>.fig`, look at every slide in the preview, fix what does not fit, run the brand's visual check and the file check.
5. Tell you what is left to finish in Figma.

Everything for one deck lives in `decks/<deck-name>/`: put the screenshots you want on slides in its `img/` folder. Without the agent, the four skills work the same way from the normal Kiro chat. Ask for a diagram on its own ("a PNG of our check-in flow for Confluence") and Kiro builds just that.

### Opening the deck in Figma

1. Open Figma's **file browser** (Drafts or a project page) and drag the `.fig` file onto it, or use **Import**. Not onto an open file: Figma then answers "Drop .fig or .jam files into the file browser".
2. It opens as a new Figma Slides file in Drafts. Move it to the team project.
3. Finish in Figma what a file cannot carry: live prototype embeds (the slide says where), GIFs, Figma Slides polls, object animations.

Why `.fig` and not `.deck`: Figma's file browser only takes `.fig` and `.jam` files by drag and drop. The file inside is the same Slides document Figma saves.

Need PowerPoint? From Figma: **File > Export > PowerPoint**. Or ask Kiro for a `.pptx`.

## The look

Day & Night, as the official template defines it: dark night slides by default (openers, dividers, statements, numbers, quotes), light day slides for screenshots and detail, Reviewpro Blue for one or two punctuation slides. One highlight per slide, in Energetic Green on night and Reviewpro Blue on day. Night Serif for emotion, Day Sans for information, Noto Sans for labels. Gradients are real Figma gradients (aurora, horizon, deep night); four legacy layouts keep the earlier violet glows as an accent, about one per deck. The rules and the values are in `.kiro/skills/presentation-brand/SKILL.md`; every layout is pictured in `library/index.html`.

## Folder structure

```
Presentation-Designer/
├── .kiro/
│   ├── agents/presentation-designer.md     ← the agent
│   ├── skills/presentation-writer/          ← words: deck types, voice, live moments, copy check
│   ├── skills/presentation-brand/           ← look: tokens.json, rules, visual check, brand kit
│   ├── skills/presentation-infographics/    ← diagrams: the infographic engine, pairings, contrast, PNG export
│   ├── skills/figma-slides-builder/         ← file: layouts, build, preview, checks, PowerPoint
│   └── steering/                            ← kit rules (always on) and kit maintenance (manual)
├── examples/day-night-template/             ← the template's 40 layouts rebuilt; img/internal/ stays out of the public edition
├── examples/infographics/                   ← one slide per infographic, and Shiji infographics.fig
├── examples/smoke-test/                     ← the test deck built by the setup check
├── template/                                ← the official template (saved from Figma) and its decoded/ copy
├── library/                                 ← pictures of every layout and of the team's decks, index.html
├── decks/                                   ← your decks, one folder each (local work)
└── setup/                                   ← setup check, showcase, library page, share zip
```

## Sharing and updating the kit

- **Website:** `python3 setup/build_site.py` builds `public/`, the kit's website (install steps, the look, every layout, the template deck in a browser, how the words are written) with its downloads: the public edition of the kit and the Day & Night showcase as a `.fig`. `python3 setup/publish_site.py` publishes it to https://laurapistacho.github.io/presentation-designer-kit/. The public edition (`setup/public_edition.py`) leaves out the team's own material: the pictures of the team's decks (`library/decks`, `library/slides`), the product screenshots and the screen recording of the template, and its internal links.
- **Share inside Shiji:** `python3 setup/build_kit_zip.py` checks the kit, rebuilds the Day & Night template and writes `download/presentation-designer-kit.zip`, the full kit with the team's decks, without anyone's personal decks.
- **The template changed in Figma, change the look, add a layout, new reference deck:** ask Kiro for kit maintenance; it follows `.kiro/steering/kit-maintenance.md`. The official template leads: change it in Figma first, then save a local copy into the kit.
- **Figma says "Internal error during import":** download the kit again from the website, move your `decks/` folder into it and rebuild. Still failing? In Figma, open the [official template](https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4), use **File > Save local copy**, save it over `template/Day & Night template.deck` and rebuild. Kiro knows the steps (`.kiro/steering/presentation-kit.md`, "When Figma refuses a deck").
- **Report a problem:** send the kit maintainer the output of `check_deck.py` for the deck, and say what Figma showed.
