---
inclusion: always
---

# Presentation Designer kit

This folder is the design team's kit for building **Figma Slides** presentations with Kiro, in the Shiji **Day & Night** look. Every deck is built on the official Figma Slides template, **"00 Day & Night template"**: https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4 (the source of truth for layouts, text styles and theme colours).

## What is where

| Path | What | Who changes it |
|---|---|---|
| `decks/` | One folder per deck: `brief.md`, `outline.md`, `deck.json`, `img/`, the built `.fig`, `preview/` | Anyone (your work) |
| `examples/day-night-template/` | The official template rebuilt by the kit, one slide per layout with sample content (`img/internal/` holds pictures that stay out of the public edition) | Kit maintainers |
| `examples/smoke-test/` | A short test deck the setup check builds | Kit maintainers |
| `template/Day & Night template.deck` | The local copy of the official template every build starts from (File > Save local copy in Figma) | Kit maintainers |
| `template/decoded/` | Decoded copy of the template, so computers without the zstd tool can build. Never delete it. | The setup check (on a computer with zstd) |
| `library/` | Every layout in Day & Night, the previous template and the team's real decks; `library/index.html` to browse | Kit maintainers |
| `.kiro/agents/presentation-designer.md` | The agent that runs the whole flow | Kit maintainers |
| `.kiro/skills/presentation-writer/` | The words: deck types, voice, copy, live moments, copy check, reviews | Kit maintainers |
| `.kiro/skills/presentation-brand/` | The look: tokens (colours, gradients, type, themes), rules, visual check | Kit maintainers |
| `.kiro/skills/figma-slides-builder/` | The file: layouts, build, preview, checks, PowerPoint export | Kit maintainers |
| `setup/` | Setup check, Day & Night showcase, library page, share zip, website | Kit maintainers |
| `public/` | The built website and its public downloads (`setup/build_site.py`); never edit by hand | The build |

## Rules

1. **Figma Slides first.** The deliverable is a `.fig` file: drag it onto the Figma file browser and it opens as a Slides file. (Figma's file browser refuses the `.deck` extension.) PowerPoint only when someone asks.
2. **Words, look, file.** `presentation-writer` writes `deck.json`, `presentation-brand` decides the look, `figma-slides-builder` builds the file. The `presentation-designer` agent runs all three.
3. **One folder per deck** in `decks/<deck-slug>/`, kebab case. Screenshots in `img/` inside it.
4. **Never hand-edit a built file, never set colours or sizes by hand.** Change the spec and rebuild; the look changes only in `presentation-brand/assets/tokens.json`.
5. **Facts come from the user's sources.** Missing facts become `[TBD — Requires Input: ...]`, which the copy check refuses to pass.
6. **Look before handing over:** contact sheets, fit report, the brand's visual check, `check_deck.py`.
7. **Do not change the kit while building decks.** `template/`, `library/`, `examples/`, `.kiro/` and `setup/` change only in kit maintenance (`kit-maintenance` steering file). The one exception is refreshing the template when Figma refuses a deck (below).

Run commands from this folder. Scripts need Python 3.9 or newer and Google Chrome; `python3 setup/check_setup.py` checks a computer.

## When Figma refuses a deck: "Internal error during import"

Figma's import ends with "Internal error during import" and "0 of 1 files imported". Work through these steps in order. Rebuild the deck after each one and stop at the first that imports.

1. **Get the latest kit.** Download the kit again from https://laurapistacho.github.io/presentation-designer-kit/, unzip it, and move the `decks/` folder from the old kit into the new one. Kit 3.0 wrote files that Figma refused.
2. **Refresh the template.** The official template may have changed in Figma since the kit saved its copy. Open https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4, use **File > Save local copy**, and replace `template/Day & Night template.deck` with the saved file, keeping that file name. Then run `python3 setup/check_setup.py`: it checks the template's layers and refreshes `template/decoded/`. Reading a copy saved by Figma needs the zstd tool (Mac: `brew install zstd`).
3. **Still failing, or the setup check lists missing layers:** stop retrying. Tell the kit maintainer (Laura Casas) the kit version (top of `README.md`), what Figma showed, the `check_deck.py` output for the deck, and whether step 2 helped, so the kit gets the new template for everyone. Meanwhile build the `.pptx` and import that into Figma Slides.
