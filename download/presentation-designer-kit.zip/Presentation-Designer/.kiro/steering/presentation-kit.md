---
inclusion: always
---

# Presentation Designer kit

This folder is the design team's kit for building **Figma Slides** presentations with Kiro, in the Shiji **Day & Night** look (from the original Shiji presentation skill, now the presentation-brand skill).

## What is where

| Path | What | Who changes it |
|---|---|---|
| `decks/` | One folder per deck: `brief.md`, `outline.md`, `deck.json`, `img/`, the built `.fig`, `preview/` | Anyone (your work) |
| `examples/day-night-template/` | One slide per layout with sample content; its built `Shiji Day & Night template.fig` is the team template to open in Figma | Kit maintainers |
| `examples/smoke-test/` | A short test deck the setup check builds | Kit maintainers |
| `template/Product Presentation Template.deck` | The file skeleton every build starts from (logo, icons, colour collection), saved from Figma | Kit maintainers |
| `template/decoded/` | Decoded copy of the template, so computers without the zstd tool can build. Never delete it. | The setup check (on a computer with zstd) |
| `library/` | Every layout in Day & Night, the previous template and the team's real decks; `library/index.html` to browse | Kit maintainers |
| `.kiro/agents/presentation-designer.md` | The agent that runs the whole flow | Kit maintainers |
| `.kiro/skills/presentation-writer/` | The words: deck types, voice, copy, live moments, copy check, reviews | Kit maintainers |
| `.kiro/skills/presentation-brand/` | The look: tokens (colours, gradients, type, themes), rules, visual check | Kit maintainers |
| `.kiro/skills/figma-slides-builder/` | The file: layouts, build, preview, checks, PowerPoint export | Kit maintainers |
| `setup/` | Setup check, Day & Night showcase, library page, share zip, website | Kit maintainers |
| `public/` | The built website and its public downloads (`setup/build_site.py`); never edit by hand | The build |

## Rules

1. **Figma Slides first.** The deliverable is a `.fig` file: drag it onto the Figma file browser and it opens as a Slides file. (Figma's file browser refuses the `.deck` extension.) PowerPoint only when someone asks.
2. **Words, look, file.** `presentation-writer` writes `deck.json`, `presentation-brand` decides the look, `figma-slides-builder` builds the file. The `presentation-designer` agent runs all three.
3. **One folder per deck** in `decks/<deck-slug>/`, kebab case. Screenshots in `img/` inside it.
4. **Never hand-edit a built file, never set colours or sizes by hand.** Change the spec and rebuild; the look changes only in `presentation-brand/assets/tokens.json`.
5. **Facts come from the user's sources.** Missing facts become `[TBD — Requires Input: ...]`, which the copy check refuses to pass.
6. **Look before handing over:** contact sheets, fit report, the brand's visual check, `check_deck.py`.
7. **Do not change the kit while building decks.** `template/`, `library/`, `examples/`, `.kiro/` and `setup/` change only in kit maintenance (`kit-maintenance` steering file).

Run commands from this folder. Scripts need Python 3.9 or newer and Google Chrome; `python3 setup/check_setup.py` checks a computer.
