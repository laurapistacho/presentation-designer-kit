---
inclusion: manual
name: "kit-maintenance"
description: >
  How kit maintainers update the Presentation Designer kit: the Day & Night look (brand tokens),
  a new layout, a new version of the template file, new reference decks in the library, the share zip.
---

# Maintaining the kit

Load this only when the user asks to change the kit itself. Building decks never needs it.

## The look (colours, gradients, type, themes)

1. Edit `.kiro/skills/presentation-brand/assets/tokens.json`. Layouts ask for roles ("title", "muted", "highlight") and type tokens ("display", "body"), so a change there reaches every layout. Never put a colour or a size inside `layouts.py`.
2. New colours become new variables of the "Shiji Day & Night" collection in every built file automatically. Keep the brand kit values (`presentation-brand/references/brand-kit.md`); do not invent shades.
3. Update the tables in `presentation-brand/SKILL.md` if a value or a role changed.
4. `python3 setup/build_showcase.py` rebuilds the Day & Night template (one slide per layout) and `library/index.html`. Look at `library/day-night/` before sharing.

## A new layout

1. Find the pattern in `library/` (the team's decks) and the closest layout in `.kiro/skills/figma-slides-builder/scripts/layouts.py`.
2. Add a function with the `@layout(name, default_theme, fields, about)` decorator next to the closest layout. Build it from the helpers on `S` in `build_deck.py`: `background`, `t` (text in a type token), `frame` (auto layout), `heading`, `bullets`, `pill`, `chip`, `shot` (screenshots and photos), `icon`, `dot`, `rect`, `vplace` (vertical placement after measuring), `equal_heights`, `footer`. Colours by theme role or brand token name only.
3. Add its word limits, required fields and extra fields to `LIMITS`, `REQUIRED` and `EXTRA` in `presentation-writer/scripts/lint_copy.py`.
4. Regenerate the layouts table: `python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --layouts-md`, paste it into `figma-slides-builder/references/layouts.md`, and add a line to "Picking a layout" there and to `slide-copy.md` in the writer skill.
5. Add a slide using it to `examples/day-night-template/deck.json`, run `python3 setup/build_showcase.py` and look at its picture in `library/day-night/`.

## A new version of the template file

The template is the file skeleton (document, logo and icon components, the colour collection), not the look.

1. In Figma, open the Product Presentation Template and use **File > Save local copy**.
2. Replace `template/Product Presentation Template.deck` (same file name).
3. `python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --check-template` lists every template layer the code uses that is gone (`references/template-spec.md` says what each is for).
4. For each, find the new layer with `python3 .kiro/skills/figma-slides-builder/scripts/inspect_deck.py "template/Product Presentation Template.deck" --slides N` and update the id in `build_deck.py` or `layouts.py`.
5. `python3 setup/check_setup.py` must pass. Run it on a computer with the zstd tool (`brew install zstd`): it refreshes `template/decoded/`, the decoded copy of the template that lets computers without zstd build decks. Never delete that folder.
6. `python3 setup/build_showcase.py`, and look at the pictures.

## Library: new reference decks

1. Render the deck's slide grid with the Figma MCP tool `download_figma_images` (node `0:3`): once at `pngScale` 0.1, once at 0.3 to 0.5.
2. `python3 .kiro/skills/figma-slides-builder/scripts/figma_grid_slices.py small.png big.png --out <tmp>/slides --prefix E` (next free letter).
3. Convert the contact sheets and chosen slides to JPG (`sips -s format jpeg -s formatOptions 75 in.png --out out.jpg`) into `library/decks/` (`deckE-1.jpg`...) and `library/slides/` (`E04.jpg`...).
4. Add the deck to the tables in `figma-slides-builder/references/examples.md` and, if it is a new kind of deck, to `presentation-writer/references/deck-types.md`.
5. `python3 setup/build_library_page.py` refreshes `library/index.html`.

## Sharing a new version

Website: `python3 setup/build_site.py` rebuilds `public/` (the site, the public kit zip without the team's decks, the template `.fig`). Look at it with `python3 setup/build_site.py --serve`, then publish the folder (GitHub Pages: push `public/` to the `gh-pages` branch of the site repository, with its `.nojekyll`). Before publishing, the template `.fig` must have imported into Figma once.

Full kit for the team:

`python3 setup/build_kit_zip.py` runs the setup check, rebuilds the Day & Night template and writes `download/presentation-designer-kit.zip` with everything except personal decks (`decks/*`), previews and caches. Update the version line in `README.md` first. Build the zip on a computer with zstd, so `template/decoded/` matches the template.

Scripts must run on Python 3.9, the version macOS installs with its command line tools: no `match`, no backslashes inside f-string expressions, no `X | None` annotations. Test a change with `/usr/bin/python3` as well.
