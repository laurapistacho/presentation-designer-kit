---
inclusion: manual
name: "kit-maintenance"
description: >
  How kit maintainers update the Presentation Designer kit: a new version of the official Figma template,
  the look (brand tokens, text styles, theme colours), a new layout, new reference decks in the library,
  the share zip and the public website.
---
# Maintaining the kit
Load this only when the user asks to change the kit itself. Building decks never needs it.

**The official template is the Figma Slides file "00 Day & Night template": https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4.** The design team owns it, and it leads: the kit follows the file, never the other way round. The kit keeps a local copy in `template/Day & Night template.deck`.

## A new version of the official template
When the team changes the template in Figma (a style, a colour, a layout, a component), and when a designer reports that refreshing the template fixed "Internal error during import" (`presentation-kit` steering, "When Figma refuses a deck"). Then also share the new version (below), so nobody has to refresh it by hand:
1. In Figma, open the official template and use **File > Save local copy**.
2. Replace `template/Day & Night template.deck` (same file name). Use the file exactly as Figma saved it: never strip parts of it (the preview `thumbnail.png`, images). Only `setup/public_edition.py` cleans a copy, for the website.
3. `python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --check-template` lists every template layer the code uses that is gone (`figma-slides-builder/references/template-spec.md` says what each is for). For each, find the new layer with `python3 .kiro/skills/figma-slides-builder/scripts/inspect_deck.py "template/Day & Night template.deck" --slides N` and update the id in `build_deck.py`.
4. Compare the styles and colours with the tokens: `python3 .kiro/skills/figma-slides-builder/scripts/inspect_deck.py "template/Day & Night template.deck" --styles` lists every text style and colour variable. Where a "Shiji /" style or a theme colour changed, give `presentation-brand/assets/tokens.json` the same value (`type`, `colors`). The build writes token values into the styles, so a token that differs from its style changes the style in every built deck. A renamed style goes into `text_styles`, a renamed theme colour into `theme_variables`.
5. A new layout in the template: see "A new layout" below.
6. `python3 setup/check_setup.py` must pass. Run it on a computer with the zstd tool (`brew install zstd`): it refreshes `template/decoded/`, the decoded copy of the template that lets computers without zstd build decks. Never delete that folder.
7. Rebuild and compare with Figma: `python3 setup/build_showcase.py`, then render the official template's slides with the Figma tool `download_figma_images` (file key `r03dbNAia3aYpzBjBab0c4`, one slide id per image, `pngScale` 0.5; the ids are in `examples/day-night-template` and `inspect_deck.py`) and look at both side by side.

## The look (colours, gradients, type, themes)
1. Change the style or colour in the official template first, then follow "A new version" above. Tokens alone change built decks but not the template, so the two drift.
2. Gradients, themes, spacing and radii live only in `presentation-brand/assets/tokens.json`. Layouts ask for roles ("title", "muted", "highlight") and type tokens ("display", "body"), so a change there reaches every layout. Never put a colour or a size inside `layouts.py`.
3. Every colour token is a variable in every built file: the theme roles (`theme_variables`) in "Shiji / Presentation theme", the rest in "Shiji Day & Night". Keep the brand kit values (`presentation-brand/references/brand-kit.md`); do not invent shades.
4. Update the tables in `presentation-brand/SKILL.md` if a value or a role changed.
5. `python3 setup/build_showcase.py` rebuilds the Day & Night template (one slide per layout) and `library/index.html`. Look at `library/day-night/` before sharing.

## A new layout
1. Find the slide in the official template (or the pattern in `library/`, the team's decks) and the closest layout in `.kiro/skills/figma-slides-builder/scripts/layouts.py`, which follows the template's order.
2. Add a function with the `@layout(name, default_theme, fields, about, template=...)` decorator next to the closest layout; `template` is the slide's name in the Figma template ("Comparison · Two laptop mockups"). Build it from the helpers on `S` in `build_deck.py`: `background`, `t` (text in a type token, linked to its style), `frame` (auto layout), `heading`, `bullets`, `pill`, `chip`, `shot` (screenshots and photos), `video`, `laptop`, `art` (template artwork), `icon`, `dot`, `rect`, `vplace` (vertical placement after measuring), `equal_heights`, `footer`. Colours by theme role or brand token name only. Artwork that cannot be drawn from tokens (blurred gradients, a component, a device) is copied from the template: add its layer ids to `ART` in `build_deck.py`.
3. Add its word limits, required fields and extra fields to `LIMITS`, `REQUIRED` and `EXTRA` in `presentation-writer/scripts/lint_copy.py` (and `CONTENT`, `DIVIDERS`, `LEGACY` where it belongs).
4. Regenerate the layouts table: `python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --layouts-md`, paste it into `figma-slides-builder/references/layouts.md`, and add a line to "Picking a layout" there and to `slide-copy.md` in the writer skill.
5. Add a slide using it to `examples/day-night-template/deck.json` at the template's position (with its `row`), run `python3 setup/build_showcase.py` and look at its picture in `library/day-night/`.

## Library: new reference decks
1. Render the deck's slide grid with the Figma MCP tool `download_figma_images` (node `0:3`): once at `pngScale` 0.1, once at 0.3 to 0.5.
2. `python3 .kiro/skills/figma-slides-builder/scripts/figma_grid_slices.py small.png big.png --out <tmp>/slides --prefix E` (next free letter).
3. Convert the contact sheets and chosen slides to JPG (`sips -s format jpeg -s formatOptions 75 in.png --out out.jpg`) into `library/decks/` (`deckE-1.jpg`...) and `library/slides/` (`E04.jpg`...).
4. Add the deck to the tables in `figma-slides-builder/references/examples.md` and, if it is a new kind of deck, to `presentation-writer/references/deck-types.md`.
5. `python3 setup/build_library_page.py` refreshes `library/index.html`.

## Internal and public material
The template and the showcase hold the team's own work: real product screenshots (`examples/day-night-template/img/internal/`), a screen recording, internal links. The internal kit (`build_kit_zip.py`) carries everything. The public edition (`setup/public_edition.py`, called by `build_site.py`) leaves it out: a cleaned copy of the template, the showcase with placeholders where the internal pictures were, and its pictures. New internal pictures for the showcase go into `img/internal/`; anything else in `img/` is public.

## Sharing a new version
Website (https://laurapistacho.github.io/presentation-designer-kit/, repository `laurapistacho/presentation-designer-kit`, branch `gh-pages`): `python3 setup/build_site.py` rebuilds `public/` (the site, the public kit zip, the public template `.fig`). Look at it with `python3 setup/build_site.py --serve`. Drag the new `public/download/shiji-day-and-night-template.fig` into Figma once: it must import. Then `python3 setup/publish_site.py` pushes `public/` to the site. Publishing is public: ask the kit owner before running it, every time.
Full kit for the team:
`python3 setup/build_kit_zip.py` runs the setup check, rebuilds the Day & Night template and writes `download/presentation-designer-kit.zip` with everything except personal decks (`decks/*`), previews and caches. Update the version line in `README.md` first. Build the zip on a computer with zstd, so `template/decoded/` matches the template.
Scripts must run on Python 3.9, the version macOS installs with its command line tools: no `match`, no backslashes inside f-string expressions, no `X | None` annotations. Test a change with `/usr/bin/python3` as well.
