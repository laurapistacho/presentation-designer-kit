#!/usr/bin/env python3
"""Check the words in a deck spec (deck.json) before it is built.

    python3 lint_copy.py deck.json            # report as Markdown
    python3 lint_copy.py deck.json --json     # report as JSON

Errors (exit code 1): unknown layouts, missing required fields, placeholders left in the text
([TBD — Requires Input], TBD, XX, lorem ipsum), unknown themes.
Brand rule (presentation-brand skill): one ==highlight== per slide; more is a warning.
Warnings: fields over their word limit, too many items, too many words on a slide for the deck type,
content slides without speaker notes, quotes without who said them, numbers without a source,
AI vocabulary, exclamation marks, em-dash chains, repeated words ("status status"), mixed British and
American spelling, inconsistent product names (Reviewpro, never ReviewPro), index items that do not match
the section titles, section numbers out of order, and pacing (long runs without a live moment).

The rhythm map at the end shows the deck at a glance, one line per slide.
"""
import argparse
import json
import os
import re
import sys

COMMON = {'layout', 'notes', 'skip', 'name', 'role', 'transition', 'transition_duration', 'easing', 'advance_after', 'new_row',
          'row', 'theme', 'logo', 'kicker'}
THEMES = {'day', 'night', 'blue'}

# layout -> {field: max words}; "field[]" = each list item, "field[].key" = key of each list item
LIMITS = {
    'cover': {'title': 6, 'subtitle': 6, 'kicker': 4, 'date': 4},
    'cover-navy': {'title': 8, 'subtitle': 10, 'kicker': 4, 'date': 4},
    'cover-center': {'title': 8, 'subtitle': 8, 'kicker': 4, 'date': 4},
    'index': {'title': 3, 'items[]': 4},
    'section': {'title': 6, 'number': 1},
    'section-flat': {'title': 6, 'number': 1},
    'topic': {'title': 4},
    'intro': {'title': 2, 'subtitle': 20, 'subtitle[]': 7, 'lead': 20},
    'statement': {'text': 25, 'kicker': 4, 'sub': 14},
    'question': {'title': 5, 'text': 45},
    'content': {'title': 3, 'subtitle': 5, 'lead': 15, 'body': 40, 'bullets[]': 12, 'note': 25, 'chip': 3},
    'image': {'title': 6, 'subtitle': 8, 'caption': 15, 'chip': 3},
    'picture': {'caption': 14},
    'compare': {'title': 6, 'left_label': 2, 'right_label': 2, 'left_caption': 15, 'right_caption': 15},
    'mobile': {'title': 5, 'title_light': 2, 'subtitle': 5, 'lead': 15, 'body': 40, 'body[]': 15, 'bullets[]': 12},
    'split': {'title': 6, 'subtitle': 16},
    'content-dark': {'title': 6, 'title_light': 3, 'subtitle': 6, 'body': 40, 'items[]': 14, 'bullets[]': 14},
    'content-glow': {'title': 3, 'title_light': 3, 'subtitle': 6, 'body': 45},
    'icons': {'title': 4, 'body': 40, 'highlight': 20, 'heading': 4, 'items[].title': 3, 'items[].text': 14},
    'stats': {'title': 3, 'subtitle': 5, 'lead': 15, 'bullets[]': 15, 'stats[].value': 2, 'stats[].label': 4},
    'quote-cards': {'title': 3, 'subtitle': 5, 'lead': 20, 'quotes[].text': 10, 'quotes[].who': 6},
    'quotes': {'title': 4, 'quotes[].text': 20, 'quotes[].who': 5, 'closing': 15},
    'quote': {'title': 5, 'text': 20, 'who': 6, 'footer': 12},
    'people': {'title': 4, 'people[].name': 2, 'people[].role': 4, 'people[].quote': 12, 'footer': 25},
    'circle-list': {'title': 10, 'kicker': 4, 'lead': 15, 'items[]': 12, 'items[].title': 5, 'items[].text': 12},
    'meme': {'text': 15, 'caption': 8},
    'thanks': {'title': 3, 'subtitle': 6, 'cta': 3, 'contact': 8},
    'columns': {'title': 6, 'subtitle': 8, 'columns[].title': 3, 'columns[].text': 30},
    'cover-gradient': {'title': 6, 'subtitle': 8, 'kicker': 4, 'date': 4},
    'section-number': {'title': 6, 'number': 1},
    'question-circle': {'title': 5},
    'composition': {'title': 3, 'lead': 25, 'bullets[]': 10},
    'walkthrough': {'title': 9, 'heading': 3, 'bullets[]': 9, 'caption': 15},
    'compare-laptop': {'title': 6, 'left_label': 2, 'right_label': 2, 'left_caption': 20, 'right_caption': 20},
    'variants': {'title': 3, 'bullets[]': 14, 'variants[].name': 3, 'variants[].tags[]': 2},
    'anatomy': {'title': 3, 'groups[].title': 6, 'groups[].text': 25, 'groups[].bullets[]': 10, 'columns[].label': 2},
    'showcase': {'title': 4, 'subtitle': 8, 'lead': 20, 'bullets[]': 18, 'closing': 15, 'source[].text': 9},
    'collage': {'title': 3, 'subtitle': 8, 'lead': 20, 'body': 30, 'bullets[]': 14},
    'content-gradient': {'title': 4, 'lead': 30, 'body': 35, 'bullets[]': 12},
    'slogan': {'text': 12},
}
for _lay, _lim in LIMITS.items():  # every layout takes a kicker: the small mono label above the title
    _lim.setdefault('kicker', 4)
EXTRA = {
    'content': {'image', 'image_style', 'image_fit', 'embed_url', 'link', 'split'},
    'image': {'image', 'image_style', 'image_fit'},
    'picture': {'image', 'image_fit', 'background'},
    'compare': {'left_image', 'right_image', 'image_fit'},
    'mobile': {'image', 'bullets'},
    'split': {'image', 'side', 'background'},
    'intro': {'image'},
    'statement': {'background', 'circle', 'size'},
    'question': {'icon', 'serif'},
    'stats': {'stats', 'source', 'note', 'link'},
    'quote-cards': {'quotes', 'source', 'note', 'link'},
    'quotes': {'quotes', 'source'},
    'people': {'people'},
    'icons': {'items'},
    'circle-list': {'items', 'markers', 'background', 'title_size'},
    'meme': {'image', 'image_fit', 'icon', 'serif'},
    'index': {'items', 'unnumbered'},
    'content-dark': {'items', 'bullets', 'background'},
    'content-glow': {'bullets', 'background'},
    'columns': {'columns', 'background'},
    'cover': {'background'}, 'cover-navy': {'background'}, 'thanks': {'background'}, 'index': {'items', 'unnumbered', 'background'},
    'section': {'background'}, 'quote': {'background'}, 'stats': {'stats', 'source', 'note', 'link', 'background'},
    'composition': {'bullets', 'background'},
    'walkthrough': {'video', 'poster', 'image', 'bullets'},
    'compare-laptop': {'left_image', 'right_image'},
    'variants': {'variants', 'bullets'},
    'anatomy': {'groups', 'columns'},
    'showcase': {'image', 'bullets', 'source', 'note'},
    'collage': {'images', 'bullets'},
    'content-gradient': {'bullets'},
    'people': {'people', 'footer'},
}
REQUIRED = {
    'cover': ['title'], 'cover-navy': ['title'], 'cover-center': ['title'], 'index': ['items'],
    'section': ['number', 'title'], 'section-flat': ['number', 'title'], 'topic': ['title'], 'intro': ['title'],
    'statement': ['text'], 'question': ['text'], 'content': ['title'], 'image': ['title'], 'picture': [],
    'compare': [], 'mobile': ['title'], 'split': ['title'], 'content-dark': ['title'], 'content-glow': ['title'],
    'icons': ['title', 'items'], 'stats': ['title', 'stats'], 'quote-cards': ['title', 'quotes'], 'quotes': ['quotes'],
    'quote': ['text'], 'people': ['people'], 'circle-list': ['title', 'items'], 'meme': ['text'], 'thanks': [],
    'columns': ['title', 'columns'], 'cover-gradient': ['title'], 'section-number': ['number', 'title'],
    'question-circle': ['title'], 'composition': ['title'], 'walkthrough': ['title'], 'compare-laptop': [],
    'variants': ['title'], 'anatomy': ['title'], 'showcase': ['title'], 'collage': ['title'], 'content-gradient': ['title'],
    'slogan': [],
}
NEEDS_IMAGE = {'image': ['image'], 'picture': ['image'], 'compare': ['left_image', 'right_image'], 'meme': ['image'],
               'split': ['image'], 'mobile': ['image'], 'compare-laptop': ['left_image', 'right_image'],
               'showcase': ['image'], 'collage': ['images']}
COUNTS = {('index', 'items'): (2, 6), ('content', 'bullets'): (0, 4), ('stats', 'stats'): (2, 4),
          ('stats', 'bullets'): (0, 3), ('quote-cards', 'quotes'): (2, 3), ('quotes', 'quotes'): (2, 5),
          ('people', 'people'): (1, 5), ('icons', 'items'): (2, 4), ('circle-list', 'items'): (2, 5),
          ('content-dark', 'items'): (1, 5), ('mobile', 'body'): (0, 3), ('intro', 'subtitle'): (1, 3),
          ('columns', 'columns'): (2, 3), ('quotes', 'quotes'): (2, 6), ('walkthrough', 'bullets'): (0, 6),
          ('variants', 'variants'): (1, 3), ('variants', 'bullets'): (0, 4), ('anatomy', 'groups'): (1, 3),
          ('anatomy', 'columns'): (0, 2), ('showcase', 'bullets'): (0, 4), ('collage', 'images'): (2, 8),
          ('collage', 'bullets'): (0, 6), ('composition', 'bullets'): (0, 4)}
CONTENT = {'content', 'image', 'compare', 'stats', 'quote-cards', 'icons', 'mobile', 'people', 'content-dark',
           'content-glow', 'circle-list', 'quotes', 'intro', 'columns', 'composition', 'walkthrough', 'compare-laptop',
           'variants', 'anatomy', 'showcase', 'collage', 'content-gradient'}
DIVIDERS = {'cover', 'cover-navy', 'cover-center', 'cover-gradient', 'index', 'section', 'section-flat', 'section-number',
            'topic', 'thanks', 'slogan'}
COVERS = ('cover', 'cover-navy', 'cover-center', 'cover-gradient')
SECTIONS = ('section', 'section-number')
LEGACY = {'cover-gradient', 'section-number', 'question-circle', 'content-gradient'}
SLIDE_WORDS = {'quarterly': 60, 'design-update': 80, 'research': 50, 'other': 70}
MAX_RUN = {'quarterly': 10, 'design-update': 8, 'research': 5, 'other': 8}
MAX_RELIEF = {'quarterly': 1, 'design-update': 1, 'research': 6, 'other': 2}

# Same list as the framework's .kiro/references/shared/slop-vocabulary.md (product workspace), plus
# a few slide favourites. word -> what to write instead.
SLOP = {
    'delve': 'look at, dig into', 'landscape': 'field, market (or name it)', 'tapestry': 'say what is complex',
    'realm': 'area', 'foster': 'build, grow, support', 'leverage': 'use', 'leveraging': 'using', 'utilize': 'use',
    'utilise': 'use', 'embark': 'start', 'endeavor': 'project', 'endeavour': 'project', 'paramount': 'top priority',
    'meticulous': 'careful', 'intricate': 'complex', 'pivotal': 'key', 'moreover': 'also', 'furthermore': 'also',
    'comprehensive': 'full, complete', 'harness': 'use', 'elevate': 'improve', 'elevates': 'improves',
    'robust': 'strong, reliable', 'seamless': 'smooth', 'seamlessly': 'smoothly', 'facilitate': 'help, let',
    'game-changer': 'the actual impact', 'game changer': 'the actual impact', 'cutting-edge': 'new',
    'best-in-class': 'the specific advantage', 'world-class': 'the specific advantage', 'stakeholders': 'name the people',
    'synergy': 'what combines', 'synergies': 'what combines', 'holistic': 'end-to-end', 'unlock': 'enable, open',
    'unlocks': 'enables', 'supercharge': 'speed up', 'revolutionize': 'change', 'revolutionise': 'change',
    'next-level': 'the specific gain', 'state-of-the-art': 'new', 'deep dive': 'detailed look',
    "it's worth noting": '(delete it)', 'in conclusion': '(state the conclusion)', "let's dive in": '(delete it)',
    'genuinely': '(delete it)', 'truly': '(delete it)', 'testament': 'proof',
}
# Fine alone; two or more on one slide reads as generated. "navigate" and "dynamic" are left out on
# purpose: in these decks they are literal (the navigation, Dynamic Dashboards).
CLUSTER = ['innovative', 'ecosystem', 'nuanced', 'multifaceted', 'paradigm', 'catalyst', 'transformative',
           'empower', 'empowers', 'optimize', 'optimise', 'scalable', 'effortless', 'streamline', 'streamlined']
ALLOWED_EXCLAMATIONS = ['Test the interactions!']
SPELLING = [('behaviour', 'behavior'), ('colour', 'color'), ('favour', 'favor'), ('centre', 'center'),
            ('organis', 'organiz'), ('prioritis', 'prioritiz'), ('optimis', 'optimiz'), ('recognis', 'recogniz'),
            ('analys', 'analyz'), ('standardis', 'standardiz'), ('customis', 'customiz'), ('visualis', 'visualiz'),
            ('summaris', 'summariz'), ('modernis', 'moderniz'), ('personalis', 'personaliz'), ('catalogue', 'catalog')]
TERMS = {  # preferred form: variants seen in decks or easy to slip into
    'Reviewpro': ['ReviewPro', 'Review Pro', 'REVIEWPRO', 'reviewpro'],
    'Gainsight PX': ['Gaininsight', 'GainsightPX', 'Gainsight Px', 'Gainsight px'],
    'CX': ['Cx'],
    'FigJam': ['Figjam', 'Fig Jam'],
    'Jira': ['JIRA'],
    'Figma': ['figma'],
    'Shiji': ['SHIJI', 'shiji'],
}
PLACEHOLDER = re.compile(r'\[TBD|\bTBD\b|\bXX+\b|lorem ipsum|\?\?\?', re.I)
LINK = re.compile(r'\[([^\]]+)\]\(([^)\s]+)\)')
URL = re.compile(r'https?://\S+')


def clean(text):
    text = LINK.sub(r'\1', str(text))
    text = URL.sub('', text)
    return text.replace('**', '').replace('==', '')


def words(text):
    return len(re.findall(r"[\w’'%#.,:/+-]*\w[\w’'%]*", clean(text)))


def texts_of(sp):
    """Yield (field label, text) for every piece of slide text in a spec slide."""
    for k, v in sp.items():
        if k in ('layout', 'notes', 'skip', 'name', 'role', 'image', 'left_image', 'right_image', 'embed_url',
                 'image_style', 'image_fit', 'split', 'background', 'circle', 'size', 'icon', 'serif', 'side',
                 'markers', 'title_size', 'unnumbered', 'transition', 'transition_duration', 'easing',
                 'advance_after', 'new_row', 'row', 'theme', 'logo', 'images', 'video', 'poster'):
            continue
        if isinstance(v, str):
            yield k, v
        elif isinstance(v, list):
            for i, it in enumerate(v):
                if isinstance(it, str):
                    yield f'{k}[{i + 1}]', it
                elif isinstance(it, dict):
                    for kk, vv in it.items():
                        if isinstance(vv, str) and kk not in ('image', 'icon', 'url', 'initials'):
                            yield f'{k}[{i + 1}].{kk}', vv
                        elif isinstance(vv, list) and kk not in ('images',):  # bullets of a group, tags of a variant
                            for j, x in enumerate(vv):
                                if isinstance(x, str):
                                    yield f'{k}[{i + 1}].{kk}[{j + 1}]', x
        elif isinstance(v, dict):
            for kk, vv in v.items():
                if isinstance(vv, str) and kk not in ('url',):
                    yield f'{k}.{kk}', vv


def role_of(sp):
    if sp.get('role'):
        return sp['role']
    lay = sp.get('layout')
    if lay == 'meme':
        return 'relief'
    if lay in ('quotes', 'quote', 'quote-cards'):
        return 'quote'
    if lay == 'circle-list' and sp.get('markers') == 'letters':
        return 'question'
    if lay == 'question' and sp.get('serif'):
        return 'principle' if not str(sp.get('text', '')).strip().endswith('?') else 'question'
    if lay == 'question':
        return 'question' if str(sp.get('text', '')).strip().endswith('?') else None
    if lay == 'statement':
        return 'reveal'
    if lay == 'question-circle':
        return 'question'
    if lay == 'slogan':
        return 'principle'
    return None


MARK = {'relief': 'R', 'quote': 'Q', 'question': '?', 'reveal': '!', 'breather': '~', 'principle': 'P'}


def lint(path):
    spec = json.load(open(path))
    base = os.path.dirname(os.path.abspath(path))
    deck_type = spec.get('deck_type', 'other')
    if deck_type not in SLIDE_WORDS:
        deck_type = 'other'
    issues = []

    def add(level, slide, msg):
        issues.append({'level': level, 'slide': slide, 'message': msg})

    try:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'figma-slides-builder', 'scripts'))
        import build_deck  # noqa: F401
        known_layouts = set(build_deck.LAYOUTS)
    except Exception:  # noqa: BLE001 - lint still works without the designer skill
        known_layouts = set(LIMITS)
    slides = spec.get('slides') or []
    if not slides:
        add('error', 0, 'The spec has no slides.')
    if not spec.get('file_name'):
        add('warning', 0, 'No file_name: the file will be named after the output path.')
    known_tr = {'none', 'instant', 'dissolve', 'smart-animate'} | {f'{v}-from-{d}' for v in ('slide', 'push', 'move') for d in ('left', 'right', 'top', 'bottom')}
    for n, sp in enumerate([spec] + slides):
        t = sp.get('transition')
        if t and str(t).lower() not in known_tr:
            add('warning', n, f'Unknown transition "{t}": use none, dissolve, smart-animate, slide-from-right, push-from-right or move-from-right.')
    if 'deck_type' not in spec:
        add('warning', 0, 'No deck_type (quarterly, design-update, research, other): word limits use "other".')
    all_text = []
    rows = []
    for n, sp in enumerate(slides, 1):
        lay = sp.get('layout')
        if lay not in known_layouts:
            add('error', n, f'Unknown layout "{lay}".')
            rows.append((n, str(lay), '', 0))
            continue
        lim = LIMITS.get(lay, {})
        if sp.get('theme') and sp['theme'] not in THEMES:
            add('error', n, f'Unknown theme "{sp["theme"]}": use day, night or blue.')
        highlights = sum(len(re.findall(r'==.+?==', str(text))) for _, text in texts_of(sp))
        if lay == 'statement':  # **x** is the punchline there, shown as the highlight
            highlights += len(re.findall(r'\*\*.+?\*\*', str(sp.get('text', ''))))
        if highlights > 1:
            add('warning', n, f'{highlights} highlights on one slide. The brand keeps one: the word, number or line that matters most.')
        for f in REQUIRED.get(lay, []):
            if not sp.get(f):
                add('error', n, f'{lay} needs "{f}".')
        allowed = COMMON | {k.split('[')[0] for k in lim} | EXTRA.get(lay, set())
        for k in sp:
            if k not in allowed:
                add('warning', n, f'"{k}" is not a field of {lay}; the build ignores it.')
        for f in NEEDS_IMAGE.get(lay, []):
            if not sp.get(f):
                add('warning', n, f'No {f} yet: the designer needs a picture for this {lay} slide.')
        paths = [(f, sp.get(f)) for f in ('image', 'left_image', 'right_image', 'video', 'poster') if sp.get(f)]
        paths += [(f'images[{i + 1}]', p_) for i, p_ in enumerate(sp.get('images') or []) if isinstance(p_, str)]
        for key in ('people', 'variants', 'columns'):
            for i, p_ in enumerate(sp.get(key) or []):
                if isinstance(p_, dict):
                    paths += [(f'{key}[{i + 1}].image', p_['image'])] if p_.get('image') else []
                    paths += [(f'{key}[{i + 1}].images[{j + 1}]', x) for j, x in enumerate(p_.get('images') or [])]
        missing = [f'{f} "{p_}"' for f, p_ in paths if not os.path.exists(os.path.join(base, p_))]
        if missing:
            add('warning', n, f'Not found next to the spec (the build leaves placeholders): {", ".join(missing)}.')
        # word limits
        for field, text in texts_of(sp):
            key = re.sub(r'\[\d+\]', '[]', field)
            if key not in lim and '[]' in key and key.split('[]')[0] + '[]' in lim and '.' not in key:
                key = key.split('[]')[0] + '[]'
            limit = lim.get(key)
            if lay == 'content' and key == 'title' and int(sp.get('split', 40)) >= 33:
                limit = 6
            if PLACEHOLDER.search(text):  # one error is enough; the other checks wait for the real words
                add('error', n, f'{field} still has a placeholder: "{clean(text)[:70]}"')
                continue
            w = words(text)
            if limit and w > limit:
                add('warning', n, f'{field} has {w} words (limit {limit}): "{clean(text)[:70]}"')
            for bad, instead in SLOP.items():
                if re.search(r'\b' + re.escape(bad) + r'\b', text, re.I):
                    add('warning', n, f'{field}: "{bad}" sounds generated; try {instead}.')
            t = clean(text)
            if '!' in t and not any(a in text for a in ALLOWED_EXCLAMATIONS):
                add('warning', n, f'{field}: exclamation mark. Let the content make the point.')
            if t.count('—') >= 2 or (field == 'title' and '—' in t):
                add('warning', n, f'{field}: em dashes in a {"title" if field == "title" else "chain"}; use a colon, a full stop or a new line.')
            dup = re.search(r'\b(\w{2,})\s+\1\b', t, re.I)
            if dup and not dup.group(1).isdigit():
                add('warning', n, f'{field}: repeated word "{dup.group(0)}".')
            all_text.append((n, field, t))
        # counts
        for (l2, f), (lo, hi) in COUNTS.items():
            if l2 == lay and isinstance(sp.get(f), list):
                c = len(sp[f])
                if c < lo or c > hi:
                    add('warning', n, f'{f}: {c} items (this layout holds {lo} to {hi}).')
        # proof checks
        if lay == 'stats':
            for st in sp.get('stats') or []:
                if PLACEHOLDER.search(str(st.get('value', ''))):
                    continue
                if not re.search(r'\d', str(st.get('value', ''))):
                    add('warning', n, f'stat "{st.get("value")}" has no number.')
                if len(str(st.get('value', ''))) > 7:
                    add('warning', n, f'stat value "{st.get("value")}" is long; keep values to 7 characters ("12,480", "~60%").')
            if not sp.get('source'):
                add('warning', n, 'Numbers without a source: add "source" with the report or dashboard they come from.')
        if lay in ('quotes', 'quote-cards'):
            for q in sp.get('quotes') or []:
                if not q.get('who'):
                    add('warning', n, f'Quote without who said it: "{str(q.get("text", ""))[:50]}"')
        if lay == 'quote' and not sp.get('who'):
            add('warning', n, 'Quote without who said it.')
        if lay in CONTENT and not str(sp.get('notes', '')).strip():
            add('warning', n, 'No speaker notes. Write what the presenter says that the slide does not show.')
        nw = words(sp.get('notes', '')) if sp.get('notes') else 0
        if nw > 180:
            add('warning', n, f'Speaker notes have {nw} words; keep them under 180 so they can be read at a glance.')
        if sp.get('notes') and PLACEHOLDER.search(str(sp['notes'])):
            add('error', n, 'Speaker notes still have a placeholder.')
        slide_text = ' '.join(clean(t) for f, t in texts_of(sp)).lower()
        hits = sorted({c for c in CLUSTER if re.search(r'\b' + c + r'\b', slide_text)})
        if len(hits) >= 2:
            add('warning', n, f'{", ".join(hits)} on one slide reads as generated; keep one, make the rest concrete.')
        sw = sum(words(t) for f, t in texts_of(sp))
        if lay not in DIVIDERS and sw > SLIDE_WORDS[deck_type]:
            add('warning', n, f'{sw} words on the slide; a {deck_type} slide should stay under {SLIDE_WORDS[deck_type]}. Cut, or split into two slides.')
        rows.append((n, lay, role_of(sp) or '', sw))

    # deck-level checks
    if slides and slides[0].get('layout') not in COVERS:
        add('warning', 1, 'The deck does not open with a cover layout.')
    if slides and slides[-1].get('layout') != 'thanks':
        add('warning', len(slides), 'The deck does not end with the thanks slide.')
    # Quarterlies and story decks number their sections once (index = section titles). Design updates
    # restart 01 Benchmark / 02 Current / 03 New for every topic, so these checks skip them.
    index = next((s for s in slides if s.get('layout') == 'index'), None)
    sections = [(i, s) for i, s in enumerate(slides, 1) if s.get('layout') in SECTIONS] if deck_type != 'design-update' else []
    if index and any(PLACEHOLDER.search(str(x)) for x in index.get('items') or []):
        index = None
    if index and sections:
        items = [re.sub(r'^\s*\d+[.)]\s*', '', clean(x)).strip() for x in index.get('items') or []]
        titles = [clean(s.get('title', '')).replace('\n', ' ').strip() for _, s in sections]
        norm = lambda x: re.sub(r'[^a-z0-9]+', ' ', x.lower()).strip()  # noqa: E731
        if len(items) != len(titles):
            add('warning', 0, f'The index lists {len(items)} topics but the deck has {len(titles)} section dividers.')
        for a, b in zip(items, titles):
            if norm(a) != norm(b):
                add('warning', 0, f'Index says "{a}" but the section divider says "{b}". Use the same words.')
            elif re.sub(r'\s+', ' ', a) != re.sub(r'\s+', ' ', b):
                add('warning', 0, f'Index writes "{a}", the divider writes "{b}": same words, different capitals.')
    nums = [str(s.get('number', '')) for _, s in sections]
    expect = [f'{i:02d}' for i in range(1, len(nums) + 1)]
    if nums and nums != expect and len(set(nums)) == len(nums):
        add('warning', 0, f'Section numbers run {", ".join(nums)}; expected {", ".join(expect)}.')
    if len(set(nums)) != len(nums):
        add('warning', 0, f'Section numbers repeat: {", ".join(nums)}.')
    legacy = [i for i, s in enumerate(slides, 1) if s.get('layout') in LEGACY]
    if len(legacy) > 2:
        add('warning', 0, f'{len(legacy)} slides in the legacy look (slides {", ".join(map(str, legacy))}): the blurred '
                          'gradients and the brand circle work as an accent, about one per deck.')
    joined = ' '.join(t for _, _, t in all_text)
    for uk, us in SPELLING:
        if re.search(r'\b' + uk, joined, re.I) and re.search(r'\b' + us, joined, re.I):
            add('warning', 0, f'Mixed spelling: both "{uk}..." and "{us}..." appear. Pick one.')
    for good, variants in TERMS.items():
        for v in variants:
            hits = sorted({n for n, _, t in all_text if re.search(r'(?<![\w./@-])' + re.escape(v) + r'(?![\w./-])', t)})
            if hits:
                add('warning', 0, f'Write "{good}", not "{v}" (slide {", ".join(map(str, hits))}).')
    # rhythm
    run, longest, start, best_start = 0, 0, 1, 1
    relief = 0
    questions = 0
    for n, lay, role, _ in rows:
        if role == 'relief':
            relief += 1
        if role == 'question':
            questions += 1
        if role or lay in DIVIDERS:
            run = 0
            start = n + 1
            continue
        run += 1
        if run > longest:
            longest, best_start = run, start
    if longest > MAX_RUN[deck_type]:
        add('warning', 0, f'Slides {best_start} to {best_start + longest - 1}: {longest} content slides in a row with no live moment. '
                          f'A {deck_type} deck needs one every {MAX_RUN[deck_type]} slides at most (quote, question, statement, comedic relief).')
    if relief > MAX_RELIEF[deck_type]:
        add('warning', 0, f'{relief} comedic-relief slides; a {deck_type} deck takes {MAX_RELIEF[deck_type]} at most.')
    if deck_type == 'research' and questions == 0:
        add('warning', 0, 'A research readout with no question to the room. Add a poll or a show of hands before the findings.')
    return spec, issues, rows, deck_type


def report_md(path, spec, issues, rows, deck_type):
    errs = [i for i in issues if i['level'] == 'error']
    warns = [i for i in issues if i['level'] == 'warning']
    out = [f"# Copy check: {spec.get('file_name', os.path.basename(path))}", '',
           f'{len(rows)} slides · deck type {deck_type} · {len(errs)} errors · {len(warns)} warnings', '']
    for title, group in (('Errors', errs), ('Warnings', warns)):
        if group:
            out.append(f'## {title}')
            for i in sorted(group, key=lambda x: x['slide']):
                where = f"Slide {i['slide']}" if i['slide'] else 'Deck'
                out.append(f"- {where}: {i['message']}")
            out.append('')
    out.append('## Rhythm map')
    out.append('R comedic relief · Q quote · ? question · ! statement or reveal · ~ breather · P principle')
    out.append('```')
    for n, lay, role, w in rows:
        out.append(f'{n:>3}  {MARK.get(role, " ")}  {lay:<13} {w:>3} words')
    out.append('```')
    return '\n'.join(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('spec')
    ap.add_argument('--json', action='store_true')
    a = ap.parse_args()
    spec, issues, rows, deck_type = lint(a.spec)
    if a.json:
        print(json.dumps({'deck_type': deck_type, 'slides': len(rows), 'issues': issues,
                          'rhythm': [{'slide': n, 'layout': l, 'role': r, 'words': w} for n, l, r, w in rows]},
                         indent=1, ensure_ascii=False))
    else:
        print(report_md(a.spec, spec, issues, rows, deck_type))
    sys.exit(1 if any(i['level'] == 'error' for i in issues) else 0)


if __name__ == '__main__':
    main()
