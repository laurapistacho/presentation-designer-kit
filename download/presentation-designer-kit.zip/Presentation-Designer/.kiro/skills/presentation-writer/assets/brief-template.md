# Brief: <deck name>

| | |
|---|---|
| Deck type | quarterly · design-update · research · other |
| Date and slot | <date>, <minutes> minutes, <presenters> |
| Room | <who is there, how technical, how senior> |
| They leave knowing | <one sentence> |
| They decide or do | <the ask, or "nothing: inform only"> |
| Humour | welcome · light · none |
| External audience | no · yes (remove customer names and internal tools) |

## Sources
- <Jira keys, Confluence pages, survey results, dashboards, Figma links, quotes>

## Must include
- <projects, numbers, people to thank>

## Open questions
- [TBD — Requires Input: ...]
