# Deck types

Three kinds of deck carry most of the team's work. The outlines below come from the real decks (Figma links and slide pictures in figma-slides-builder `references/examples.md`). Slide ids like C19 point at those pictures.

| | Quarterly | Design update | Research readout |
|---|---|---|---|
| Example | Design Updates Q2 2026 (D, 40 slides), Q3 2026 (C, 50 slides) | UX & UI Updates · Product Monthly (A, 39 slides); Settings + Expandable component update (PowerPoint, 42 slides) | UX Research & Mobile Initiative (B, 61 slides) |
| Audience | Leadership, PMs, CS leads, other teams | PMs, developers, QA, designers, CS | Product, design, CS and leadership together |
| They leave knowing | What design delivered, what it changed, what is next | How a component works now and why | What users really do, and what we should do about it |
| Breadth | Many projects, one to four slides each | One or two components, in depth | One question, followed to the end |
| Density | Low: one idea per slide, few specs | Medium to high: states, sizes, rules, Jira keys | Low: one finding per slide |
| Words per slide | under 60 | under 80 | under 50 |
| Proof | Adoption, satisfaction, quotes, launch dates | Audit counts, benchmarks, current versus new, prototypes | Survey numbers, behaviour data, quotes, personas |
| Live moments | 2 to 4 in the deck, at most one meme | one per topic, at most one meme | one every 3 to 5 slides |
| `deck_type` | `quarterly` | `design-update` | `research` |

## Quarterly: "Design Updates · Q3 2026"

Summarised for stakeholders. It reuses the best slides of the monthly and component decks (C05 to C11 are A08, A10, A12, A15 to A17 and A20) and adds outcomes, the other work streams and next quarter.

Structure (C and D):

1. Cover "Design Updates", subtitle the quarter.
2. Index with the five sections.
3. **01 Design Projects.** A topic divider per project ("New Settings", "Components"). Per project: why (one slide), what others do or the consensus statement, current, new, live prototype. Then the outcome: "It worked" with adoption numbers (C19) and with satisfaction and quotes (C20), and what improves next (C21).
4. **02 CX Collaboration.** How design and CS worked together (C24: Identify, Align, Design, Validate), then the solution slides (CX FAB problem, Knowledge Hub).
5. **03 UX Research.** Personas, research tools, mobile findings, bugs found.
6. **04 Product projects.** Topic divider per product (Dynamic Dashboards, Actionable Insights, Corporate Dashboards); one to four slides each: benchmark, components, prototype, status.
7. **05 Next steps.** Future DESIGN initiatives (C45: four projects for next quarter), then one slide per upcoming project with what has been done, what will be delivered, what happens after (C46).
8. Closing principle: "Design with proof, build with purpose, grow without friction" (C49, D39).
9. Thank you ✨, subtitle the team.

Write it for someone who missed every monthly update. Lead with the outcome ("It worked", "Launches for everyone on 13 October"), keep pixel values and component internals for the design update, and close each project with its status or date.

## Design update: "UX & UI Updates · Product Monthly"

Technical and precise. One or two components or features, followed from the problem to the behaviour. The audience will build, test or support it.

Structure (A, and the "Settings + Expandable" component update whose PowerPoint export has full speaker notes):

1. Cover "UX & UI Updates", subtitle "Product Monthly".
2. Index with the one or two topics.
3. Topic intro with an illustration: the name and a one-line definition ("A composition update: consistency, findability and layout improvements, plus two new features, anchor navigation and search", A03).
4. Why this initiative (A04): the entry point and today's pain, in two short paragraphs. Optionally the continuation statement (A05: "This is the natural next step after the global navigation redesign").
5. Audit overview (A06): what the audit found, as a list with counts.
6. **01 Benchmark**: what others do (A08, A09) and the industry consensus statement (A10).
7. **02 Current design** (A12): annotated screenshot and the list of issues.
8. **03 New design** (A14 to A19): the new screen, then one slide per state or behaviour, with chips naming the state (Default, Active, No results). Sizes and rules where they matter ("Collapsed (56px): icons only, tooltips on hover").
9. Live prototype (A20): "Test the interactions!" and the link.
10. When there is feedback: the quotes (A23, A25), the recurring request as a statement (A24) and "From feedback to fixes" with Jira keys (A26).
11. Repeat 3 to 10 for the second topic.
12. Thank you ✨.

Write it for the developer who builds it next sprint: name every state, size and rule; link the prototype, the Jira tickets and the Confluence or Storybook page. The speaker notes in the component update deck are the model ("We audited 31 pages across 8 modules. What we found: 5 different action layouts, 4 different breadcrumb behaviors...").

## Research readout: "UX Research & Mobile Initiative"

A story with the audience inside it. The room is asked, teased, made to laugh, and then shown the data.

Structure (B), five acts:

1. **01 Where we were.** The problem in the room's own experience: a meme with a question (B03), the challenge today (B05), a show of hands (B06), "Who are you?" (B07).
2. **02 So we decided to find out.** The method in plain words: the system (B10), the timeline (B11), the journey of activities with counts (B12), a meme about the data (B13, B14), what the system gives us (B15). Then a poll: "What do you THINK is the #1 issue?" (B16).
3. **03 What we found.** The reveal (B17: "The answer is... all of them. But not equally."), a tease and its proof (B19 → B20), one finding per slide (B22 to B26), the human cost (B31: "45 minutes · Logged out 10 times · Unable to complete flow"), and the bridge "But who are these users?" (B32).
4. **04 Synthetic Personas** (or whatever the research produced). Meet them (B33), one slide per key persona (B34, B35), how they are used (B42), then a check-in: "Questions about the findings before we move on?" (B43).
5. **05 So, where does this leave us?** The reframe (B44: "Not a full app redesign. A controlled evolution based on the value from data."), why it matters (B45), a hero quote with its number (B46), the twist (B47), the opportunity areas (B48), proposed projects, the process per role (B53 to B56), what we have now (B58), success metrics (B59), impact (B60).
6. Thank you ✨.

Write it as a story: tension first, data second, recommendation last. Every number gets a human face (a quote, a persona, a flow) and every human story gets a number.

## Other decks

- **Huddle or internal session** ("Design Customer Success Huddle"): `cover-navy`, a short index, `content-dark` slides for agreements and next steps. Under 15 slides.
- **Kickoff or challenge brief** ("Design Challenge", template slides 11 and 12): `content-dark` and `content-glow` with the scenario, what to deliver and the timing.
- **Roadmap** ("2026 Roadmap / Q2 Achievements"): `cover-center`, then the quarterly structure with dates on every project.

For an HTML kickoff briefing generated from a PRD, the product workspace has the `kickoff-briefing` skill instead.
