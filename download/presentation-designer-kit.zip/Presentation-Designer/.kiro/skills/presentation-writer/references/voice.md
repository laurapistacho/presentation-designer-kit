# Voice, tone and usage

## The team's voice

What the best slides in the team's decks have in common (slide ids point at figma-slides-builder `references/examples.md`):

- **Concrete beats abstract.** "Today it's a single long scroll of nine stacked sections" (A04), not "the current experience is suboptimal".
- **Contrast carries the point.** "Every serious product agrees: sidebar to orient, search to jump. We're the only one still scrolling." (A10). "We assumed... / We now know..." (B37). Use a contrast where it is the point of the slide, once or twice per deck. Everywhere, it turns into a tic.
- **Numbers have a face.** "45 minutes · Logged out 10 times · Unable to complete flow" (B31). "~30 mentions, the top navigation-specific request in the survey" (A24).
- **Honest.** "Note: there might be some elements that are not perfect since this is AI generated" under every AI-built prototype. "Context: isolated detractors, the majority is switching and moving on without issues" (A26).
- **"We" for the team, roles for people.** "We audited 31 pages across 8 modules." Users are users, or the persona's name; customers are a role and a company ("Revenue manager, city hotel group").
- **Short.** One idea per line. A headline that needs a comma is usually two slides.

## Tone per deck type

| | Quarterly | Design update | Research readout |
|---|---|---|---|
| Sounds like | A confident summary for people who were not in the room | A precise walkthrough for people who will build it | A story the room is part of |
| Lead with | The outcome: "It worked", "Live for everyone on October 13" | The behaviour: "Collapsed (56px): icons only, tooltips on hover" | The question: "Who are you?" |
| Verbs | delivered, launched, measured, next | shows, opens, collapses, replaces, keeps | assumed, found, means, should |
| Detail | Results, dates, owners; no pixel values | States, sizes, rules, Jira keys, links | One finding per slide, the number and the human behind it |
| Humour | One light moment at most | One per topic at most | Welcome, every few slides |

### Rewrites by deck type

| Draft | Quarterly | Design update | Research |
|---|---|---|---|
| "We improved the navigation." | "The new navigation is live: ~60% of users switched." | "Side Bar: expandable. Collapsed 56px, expanded 220px, preference saved across sessions." | "Users told us the icons don't explain themselves. ~30 of them." |
| "There are issues with Settings." | "Settings was one long scroll. Now it has search and a sidebar." | "Current Settings: one flat scroll, no search, 'Account Administration' is a 13-item catch-all." | "How long does it take you to find a setting? (Hands up if more than a minute.)" |
| "Mobile usage is important." | "Mobile is a leadership tool: 62.7% of mobile users are managers." | "Mobile parity: which components need a mobile version, and which are out of scope." | "Mobile is a leadership tool (now)." |

## Fixes from the team's own decks

Real lines from the example decks, and what to write instead. Use them to calibrate a review.

| Slide | As written | Better | Why |
|---|---|---|---|
| A04 | "Settings it's the entry point for every product Reputation, Surveys..." | "Settings is the entry point for every product: Reputation, Surveys..." | "it's" means "it is"; the list needs a colon |
| A16 | "Real-time search, now you can find any setting without knowing where it lives" | "Real-time search: find any setting without knowing where it lives." | Comma splice |
| A19 | "...sections sit directly on the page, one step closer to reach a modernized a look that felt dated and heavy" | "...sections sit directly on the page. It replaces a look that felt dated and heavy." | Two sentences merged; doubled article |
| C36 | "Planned to launch on October 2026" | "Planned to launch in October 2026" | "on" a date, "in" a month |
| C45 | "These projects eliminate accumulated debt... Replacing them with a scalable system..." | "...accumulated debt... We replace it with one system that every future feature builds on." | Fragment |
| C02 / D02 | Index "Cx Collaboration", divider "CX Collaboration" | "CX Collaboration" in both | Same name everywhere |
| C02 / C37 | Index "Product Projects", divider "Product projects" | One capitalisation | Same name everywhere |
| D26 | "Gaininsight PX" | "Gainsight PX" | Product name |
| PPTX file | "Settings + Ezpandable" | "Settings + Expandable" | Typo in the file name people search for |
| A08 | "What are the others doing" | "What others do" or "What are others doing?" | Either a statement or a question |

`scripts/lint_copy.py` catches several of these (product names, mixed spellings, index versus dividers, repeated words). Grammar and sense need a human read.

## Usage

### Spelling and grammar
- **US English**, as in most of the team's slides: behavior, color, prioritize, standardize, organize, modernized. The check flags decks that mix "behaviour" and "behavior".
- Sentence case for headlines and labels: "From feedback to fixes", "Why this initiative?". Product, feature and component names keep their capitals: Side Bar, Knowledge Hub, Dynamic Dashboards, Page Headers.
- Questions end with a question mark; headlines do not end with a full stop. Statements and reveals may ("The answer is... all of them.").
- No exclamation marks, except the team's fixed "Test the interactions!" on prototype slides.
- Capitals for emphasis once per deck at most ("What do you THINK is the #1 issue?", "Future DESIGN initiatives"). Bold does the job everywhere else.

### Names (house style)
| Write | Not |
|---|---|
| Reviewpro (lowercase p: the company dropped the capital P; module names follow it, Reviewpro Reputation) | ReviewPro, Review Pro, REVIEWPRO. Package names, URLs and file names keep their spelling (`@reviewpro/ui-components`) |
| Shiji | SHIJI |
| Gainsight PX | Gaininsight, GainsightPX |
| CX (customer experience), UX, UI | Cx |
| Figma, FigJam, Figma Slides | figma, Figjam |
| Jira, Confluence, Storybook | JIRA |
| Side Bar, Knowledge Hub, CX FAB, Page Headers, Dynamic Dashboards | lower-case or renamed variants |
| Digital Stay, Daylight PMS, Guest Communications | |

### Numbers
- Thousands with a comma: 12,480. Percent without a space: 62.7%. Approximate with a tilde: ~60%, ~30 mentions.
- Ranges with an en dash and no spaces: 39–42%, 2–5 min, July–September 2026.
- Ratings as "4.30 / 5". Pixel values as "56px". Changes as "182px to 119px (34% less)".
- Round for quarterlies (~60%), keep the decimal for research when it matters (62.7%).
- Every number has a source the presenter can name; the slide says it in a `source` line or the notes do.

### Dates
- "October 13", "Q3 2026", "July–September 2026". No ordinal suffixes ("July 13", not "July 13th").
- Future dates are commitments: write them only when the team has agreed them.

### Punctuation
- Em dashes only in attributions ("— Revenue manager, city hotel group") and link labels ("Satisfaction Survey — Confluence"). Elsewhere a colon or a full stop.
- Curly quotes in quotes; the quote layouts add them, so do not type them inside `text`.
- "·" separates items in a one-line list ("45 minutes · Logged out 10 times · Unable to complete flow").
- Ellipsis for a spoken pause in reveals only ("The answer is...").

### Words
Avoid the generated-sounding words the framework bans (`.kiro/references/shared/slop-vocabulary.md` in the product workspace): leverage, robust, seamless, unlock, elevate, holistic, synergy, stakeholders, game-changer and the rest; the check lists them with replacements. Two or more of innovative, ecosystem, scalable, effortless, transformative, empower, optimize, streamline on one slide also reads as generated. Write what the thing does instead.

### Audience care
- Customer and hotel names are fine inside Shiji. For partners, customers or external events, replace them with a role and a segment ("Regional Director, luxury chain").
- No user names, emails or IDs on slides. Screenshots: use test accounts or blur real data.
- Internal tools and Jira keys are fine for the team and stakeholders; drop them for external audiences.
