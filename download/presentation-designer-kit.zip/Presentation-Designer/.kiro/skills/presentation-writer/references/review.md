# Reviewing a deck

## 1. Get the words

| You have | Do |
|---|---|
| A `deck.json` | `lint_copy.py deck.json` and `.kiro/skills/figma-slides-builder/scripts/deck_text.py deck.json` |
| A Figma Slides file the user can save | Ask for **File > Save local copy**, then `deck_text.py <file>` (needs the zstd tool: `brew install zstd`). Without it: **File > Export > PowerPoint** and `deck_text.py file.pptx` |
| A PowerPoint file | `deck_text.py file.pptx` |
| Only a Figma link | Render the slides (figma-slides-builder SKILL.md, "Reading other Figma Slides files") and read the pictures. Say in the review that the text was read from images. |

`deck_text.py` lists each slide's text top to bottom, marks the headline, counts the words and shows the speaker notes.

## 2. Decide the yardstick

Deck type and audience (`deck-types.md`). A density that is right for a design update is wrong for a quarterly.

## 3. Read in this order

1. **Story.** Does the deck answer, in order: why this matters, what we did, what it changed, what is next or what we ask? Is the ask on a slide, not only in the presenter's head? Does each section open with a divider that the index names in the same words?
2. **Slides.** One point per slide. Does the headline (or lead) say it? Anything that could be a second slide? Anything that is not needed?
3. **Proof.** Every claim backed by a number, a quote or a screenshot; every number with a source; every quote attributed.
4. **Sentences.** Grammar, sense, length, parallel bullets, no fragments that hide the subject.
5. **Usage.** Names, spelling, numbers, dates (`voice.md`). The check catches some; read for the rest.
6. **Tone.** Right register for the room; no generated-sounding words; no in-jokes the audience will not get.
7. **Rhythm.** Longest run without a live moment; where a question, a quote or a breather would help (`rhythm.md`).
8. **Notes.** Do content slides have speaker notes that add to the slide instead of repeating it?

## 4. Write `copy-review.md`

Lead with where things stand, then the fixes as a table the author can work through. Quote the current text exactly and give the replacement in full.

```markdown
# Copy review: Design Updates Q3 2026

| | |
|---|---|
| Deck type | Quarterly, 50 slides, about 45 minutes |
| Verdict | Ready after the must-fix items; the story holds |
| Must fix | 6 (typos, inconsistent names, one unsourced number) |
| Should fix | 9 (long slides, unclear headlines) |
| Could | 4 (rhythm, punch-ups) |

## Must fix
| Slide | Issue | Now | Suggested |
|---|---|---|---|
| 2, 23 | Same section, two spellings | "Cx Collaboration" / "CX Collaboration" | "CX Collaboration" |
| 36 | Preposition | "Planned to launch on October 2026" | "Planned to launch in October 2026" |

## Should fix
...

## Could
| Slides | Idea |
|---|---|
| 12–22 | Eleven content slides in a row. A quote slide after 19 ("It worked") would give the numbers a voice. |
```

Severity:
- **Must fix**: wrong or unsourced facts, typos, wrong names, inconsistent section names, grammar that changes the meaning, private data on a slide for the wrong audience.
- **Should fix**: slides over the word limit, headlines that do not say the point, bullets that are not parallel, missing notes on key slides.
- **Could**: rhythm, stronger openings and endings, a better quote, a live moment.

Keep the review proportionate: for a 50-slide deck, the 10 to 20 fixes that matter, not every comma.

## 5. Apply

- If the deck has a `deck.json`, offer to apply the fixes there and rebuild with figma-slides-builder.
- If the deck lives in Figma, the author applies them in Figma: the skill cannot write into an existing Figma file. For a larger rewrite, offer to rebuild it as a new deck from a spec (`deck_text.py` output is a good start).
