# Rhythm: live moments that keep the room awake

A run of content slides at the same pace loses the room. Live moments break the run, create a little tension, and make the next point land. The research deck (B) does this every three to five slides; the quarterlies (C, D) use a few strong ones. Slide ids point at figma-slides-builder `references/examples.md` and its images.

Mark each live moment in the spec with `"role"`. The copy check prints a rhythm map from it and warns when a run is too long.

| `role` | Moment | Layouts |
|---|---|---|
| `relief` | Comedic relief: a meme or a funny picture | `meme`, `split`, `picture` |
| `quote` | The quoter: customer voice | `quotes`, `quote`, `quote-cards` |
| `question` | A question to the room: show of hands, poll, check-in | `question`, `question-circle`, `circle-list` (letters), `statement` |
| `reveal` | The answer, the twist, the punchline | `statement`, `quote` |
| `breather` | A pause after a dense run | `topic`, `statement`, `split` |
| `principle` | A line to remember | `slogan` (the team slogan), `question` with `serif: true` |

## How many, where

| | Quarterly | Design update | Research readout |
|---|---|---|---|
| Longest run of content slides | 10 | 8 | 5 |
| Comedic relief | 0 or 1 | 0 or 1 | up to 6 (B has 6 in 61 slides) |
| Quotes | 1 to 2 slides, after the results | when feedback exists, after the new design | 2 to 4, attached to findings |
| Questions to the room | optional, 1 | optional | 2 to 3 (opening, before findings, check-in) |
| Principle | 1, before thank you | optional | optional |

The look carries rhythm too (presentation-brand skill): most live moments are **night** slides (statement, quote, stats, section) and most content is **day** (screenshots). A run of day slides broken by a night moment reads like the deck is breathing. If a stretch has eight day slides in a row, a night statement or quote usually belongs there.

Place them:
- **Opening** (first three content slides): a question or a meme that names the problem from the room's side.
- **Before a reveal**: a question or poll, so the answer has something to land on.
- **After a dense stretch** (benchmarks, specs, data): relief or a breather.
- **After a claim**: the quoter proves it with real words.
- **Before a decision or the next steps**: the strongest quote or number.
- **The end**: a principle, then thank you.

## Comedic relief (the meme)

The meme says what the room is feeling about the problem, and the line next to it turns the feeling into the question of the section.

How the team does it:
- B03: grumpy cat, "Should I follow the data or my instincts?", and next to it "How many times have you made a product decision based on assumptions?"
- B07: a confused face, "Who are you?", next to "This is what we were asking ourselves about our mobile users."
- B09: Office Space, "Yeah... I'm gonna need more data", right after the method slide.
- B13 / B14: "Data, data everywhere" and the conspiracy-board meme, "Here's what it felt like connecting all the data".

Rules:
- The joke points at us or at the situation. Never at users, customers, colleagues or another team.
- Recognisable formats and short text: up to 8 words on the meme itself.
- One meme does one job. If it needs explaining, cut it.
- Not with external executives, customers, or on sensitive topics (incidents, people changes).
- You write the concept; the user supplies or approves the image. Put the brief in the notes: "Meme: Office Space, Lumbergh. Top: 'Yeah... I'm gonna need more'. Bottom: 'data'." Set `image` to the file name it will have (`img/meme-more-data.png`); the build leaves a placeholder until the file exists.
- Speaker note: "Pause. Let it land." Then the next slide carries the point.

Spec:
```json
{"layout": "meme", "role": "relief", "image": "img/meme-instincts.png", "icon": "question",
 "text": "How many times have you made a product decision based on assumptions?",
 "notes": "Pause for the laugh. Then: be honest, most of us. That's where this project started."}
```

## The quoter (customer voice)

Real words of real users, chosen to prove one point.

- A quotes slide (A23, A25): 3 to 6 short quotes in a grid of cards, each with the hotel or role under it, a closing line that says what they add up to, the survey link.
- A hero quote (B46): one quote in serif, who said it, and the number that explains it ("39–42% of users don't use mobile at all").
- Quote cards next to results (C20): two or three quotes beside the satisfaction score.
- After the quotes, a statement that names the pattern (A24: "The #1 request: let users see the menu labels, not just icons. ~30 mentions...").

Rules: verbatim, attributed, short, from the user's sources only (`voice.md`, Quotes). Speaker note: read one quote aloud, in full.

```json
{"layout": "quote", "role": "quote", "title": "The Awareness Gap",
 "text": "Please share how I get and install the mobile app.", "who": "Admin",
 "footer": "39–42% of users don't use mobile at all.",
 "notes": "This came from a support ticket. It sounds small. Then look at the number under it."}
```

## Questions to the room

- **Show of hands** (B06): "🎤 Who here has used our mobile app in the last month?" Closed, answerable in five seconds, asked to everyone.
- **Poll** (B16): "What do you THINK is the #1 issue with our mobile app?" with A to D answers (`circle-list`, `markers: "letters"`). For live voting, note "Designer: replace with a Figma Slides poll".
- **Check-in** (B43): "Questions about the findings before we move on?" before the recommendations.
- **Rhetorical set-up** (B32): "But who are these users?" opens the next act.

Write the question so the next slide answers it. Speaker note: say how long to wait ("Give it five seconds, count the hands").

## Reveals

- **The answer** (B17, after the poll): "The answer is...\n**all of them.**\nBut not equally."
- **Tease, then proof** (B19 → B20): "What do Suicide Squad, Sex and the City, and Bad Boys II have in common?" (film posters), then the ratings gap and "The more you use it, the worse it feels."
- **The twist** (B47): "⚠ And a third factor: key accounts use features that aren't the top requests in surveys..."
- **The reframe** (B44): "Not a full app redesign.\nA controlled evolution based on the value from data."

The reveal works only if the slide before it set it up. Keep the reveal to one sentence and one bold turn.

## Breathers and principles

- A topic divider or a short statement after five or more dense slides.
- An aphorism mid-deck (B21: "Don't look at what people say, look at what they do. Actions speak louder than words.").
- The closing principle (C49, D39): "Design with proof, build with purpose, grow without friction." Use the team's line, or one written for this deck in the same three-beat shape, at most once.
