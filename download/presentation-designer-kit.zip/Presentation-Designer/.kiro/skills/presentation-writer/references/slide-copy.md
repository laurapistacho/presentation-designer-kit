# Writing slide copy

Field names below are the deck spec fields (figma-slides-builder `references/deck-spec.md` and `references/layouts.md`). Word limits per field and layout are enforced by `scripts/lint_copy.py`.

## Headline (`title`)

- On proof, statement and research slides the headline **is the point**: "It worked", "The #1 request: let users see the menu labels, not just icons", "Mobile is a leadership tool (now)".
- On walkthrough slides of a design update the headline is the **name of the thing** ("Search", "Side Bar", "Panel"), because the subtitle and the chip say which aspect and which state. Keep these names identical from slide to slide.
- Two lines are fine on dividers and covers. Break them on purpose with `\n` so each line reads as a unit ("New\nSettings", "Who are\nthese users?").
- Short enough to read in two seconds: 3 words in the narrow `content` column, 6 with `split: 33`.

## Subtitle (`subtitle`)

The aspect or the frame, 2 to 5 words: "Expandable/Collapse", "The problem today", "Integrated into the navigation", "Live prototype", "Adoption", "Satisfaction", "What is going to improve".

## Lead (`lead`)

One sentence that makes the slide's claim in plain words: "An expandable sidebar that lets users switch between icon-only and full-label modes." Up to 15 words. If you cannot write it, the slide has no point yet.

## Bullets (`bullets`, `items`)

- 2 to 4 per slide. Five is a list for a document, not a slide.
- Parallel: all start the same way (all nouns, or all verbs).
- Bold lead-in, colon, detail: "**Live filtering**: cards filter instantly across all sections". The bold part should still make sense on its own.
- Fragments without full stops, or full sentences with them. One style per slide.
- Specs belong in design updates: "Collapsed (56px): icons only, tooltips on hover".

## Body (`body`)

A short paragraph when the slide needs a why: two sentences, under 40 words. The "Why this initiative?" pattern works well: what it is, then what is wrong today.

## Numbers (`stats`, numbers in text)

- One number per card, the label in 1 to 4 words under it: "~60%" / "adoption".
- The story sits next to the numbers (`lead`, `bullets`): what changed and why it matters.
- Always a `source` with the report, dashboard or survey, as a link when there is one.
- If a number is not in the sources, write `[TBD — Requires Input: adoption rate after reminder phase]`.

## Quotes (`quotes`, `quote`)

- Verbatim. Cut with "..." only when the meaning stays.
- Short: up to 10 words for cards, 20 for a quotes slide, 20 for a hero quote. Pick the line that makes the point, not the nicest one.
- Attribution: role and company for cards ("Revenue manager (city hotel)"), company or role on quote slides ("Resort group", "Admin").
- Original language kept when it is short and readable ("Más ágil, más visual y atractivo"); the translation in the notes.
- Three quotes that say the same thing prove a pattern. Three that say different things prove nothing; add the number instead.

## Links (`link`, `source`, `[text](url)`)

- The words say what opens: "Satisfaction Survey — Confluence", "Deployment Plan", "Gainsight PX Mapper". Never "click here", never a bare URL.
- Exception: prototype URLs (figma.site) are shown so people can type them.

## On-slide notes (`note`)

Caveats in small text at the bottom of the column: "Note: there might be some elements that are not perfect since this is AI generated." One line.

## Speaker notes (`notes`)

The presenter's script, in spoken language. Figma Slides shows it in presenter view and it carries over to PowerPoint.

- 40 to 120 words on content slides; one line on dividers or none.
- First sentence: the point of the slide, said differently from the headline.
- Then what to show or do ("Type 'tax' in the search and watch the cards filter").
- Then the bridge to the next slide ("So we asked: who is actually using it?").
- Numbers the way they are said ("almost seventy percent").
- Build tasks last, starting with "Designer:" ("Designer: insert the Settings prototype embed").
- No slide numbers inside notes.

A model from the team's component update (slide "Audit Overview"):

> We audited 31 pages across 8 modules. What we found: 5 different action layouts, 4 different breadcrumb behaviors, filters mixed with actions, view modifiers treated inconsistently, and overflow menus with no clear rules.

## What each layout wants from the words

| Layout | The words should |
|---|---|
| `cover`, `cover-navy`, `cover-center`, `cover-gradient` | Name the deck and the period; nothing else. The kicker names the series ("Product monthly"), the highlight goes on the period (`Design Updates\n==Q4 2026==`), `date` sits at the bottom. `cover-center` and `cover-gradient` set two lines in two typefaces: the series on line 1, the period on line 2 ("2026 Roadmap\nQ2 Achievements") |
| `index` | Use exactly the section titles of the dividers |
| `section`, `section-flat`, `section-number` | 2 to 4 words, or a short sentence in a story deck ("So we decided to find out"). `section-number` fits two short lines under the giant number ("Research Process &\nMobile Initiative") |
| `topic` | Two short lines; line 1 is set in serif, so put the softer word there ("New / Settings", "Mobile / updates") |
| `intro`, `composition` | Name and one-line definition of the component or project ("A composition update: consistency, findability and layout improvements") |
| `question` | A real question, or a "why" with two short paragraphs |
| `question-circle` | A set-up question of two short lines ("Who are\nthese users?"); the answer is the next slide |
| `statement` | One sentence with a turn; bold the turn (it shows as the highlight) |
| `content`, `image`, `compare`, `compare-laptop`, `mobile` | Kicker = the feature, title = the claim, at most four supporting lines; captions say what changed, in one sentence each |
| `walkthrough` | The title states the problem of the current state ("Current settings page is one long, flat scroll"); the bullets are the issues, one per line, parallel |
| `variants` | One bullet per variant family ("Desktop first, vertical. Two sizes."); chip names and tags in 1 or 2 words |
| `anatomy` | Up to three questions as group titles (what has been done, what will be delivered, what happens after) with short answers; the chips name the parts |
| `showcase` | Subtitle = the idea in one line (in the highlight colour), lead = who it is for, bullets = how it works, closing = the evidence; sources as links |
| `collage` | Subtitle = what the audit shows; "Found:" and the findings, one per line |
| `stats`, `quote-cards` | The claim on the left, the proof on the right, the source at the bottom |
| `quotes`, `quote` | Real words of real people, and the line that says why they matter |
| `icons` | Why the projects exist (left), what each one does in 10 words (right) |
| `circle-list` | A question or theme in the circle, short parallel answers on the right |
| `people` | Name, role, the one sentence that makes the person real |
| `meme`, `split`, `picture` | See `rhythm.md` |
| `content-dark`, `content-glow`, `content-gradient` | Text-only: a title, a frame and a short list or paragraph |
| `columns` | Two or three parallel findings or principles: a 1 to 3 word heading each, one or two sentences under it |
| `slogan` | Nothing to write: it is the design-team slogan, "Design with proof, build with purpose, grow without friction", word for word |
| `thanks` | "Thank you" (or a closing line), the team name, an optional button (`cta`: "Questions?") |

## Kicker and highlight

- **Kicker:** the topic in 1 to 4 words, above the title ("Settings", "Adoption", "Industry consensus"). It orients; the title makes the point. Do not repeat the title in it.
- **Highlight:** `==...==` on the one word, number or line that matters most. One per slide, and not on every slide: covers, numbers and closing lines earn it most. On day slides it is Reviewpro Blue, on night slides Energetic Green.
