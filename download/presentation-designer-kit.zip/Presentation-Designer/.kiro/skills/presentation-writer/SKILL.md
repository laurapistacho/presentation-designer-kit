---
name: presentation-writer
description: Writes and reviews the words of Shiji product and design presentations for Figma Slides - story, headlines, bullets, numbers, quotes and speaker notes - in the right tone for the deck type (quarterly for stakeholders, design and component updates, research readouts). Adds live moments that keep the room awake - comedic relief (memes), the quoter (customer voice), audience questions, reveals - and checks tone, usage and consistency. Produces the deck spec that figma-slides-builder turns into a Figma Slides file in the Day & Night look of presentation-brand. Use when asked to write, outline, structure, review, proofread, shorten or punch up a deck, check its tone, write speaker notes, add humour, memes or quotes, or prepare a quarterly, design update or research presentation.
---

# Presentation writer

Writes the words of a deck and checks the words of existing decks. The look belongs to the **presentation-brand** skill and the file to the **figma-slides-builder** skill: this skill hands the builder a deck spec (`deck.json`) and the builder makes the Figma Slides file.

| You get | File |
|---|---|
| The brief: audience, goal, length, sources | `brief.md` |
| The story, one line per slide | `outline.md` |
| The deck spec with all copy and speaker notes | `deck.json` |
| A review of an existing deck | `copy-review.md` |

Files go in `decks/<deck-slug>/` in the kit folder (the same folder the builder builds in). Paths in this skill are relative to the kit folder.

## Pick the mode

| The user asks | Mode |
|---|---|
| "Write / outline / prepare the Q4 deck", "turn these notes into slides" | **Write** (all steps below) |
| "Review / proofread / check the tone of this deck" | **Review** (`references/review.md`) |
| "Make it more fun", "add memes", "add quotes", "it's boring" | **Punch up**: the rhythm pass only (`references/rhythm.md`) |
| "Write the speaker notes" | **Notes** only (`references/slide-copy.md`, Speaker notes) |

## Write

1. **Brief.** Settle these before writing, three questions at a time at most, and save the answers in `brief.md`:
   - Deck type: quarterly, design update (monthly or component), research readout, or other (huddle, kickoff, challenge). `references/deck-types.md` describes each.
   - Who is in the room and what they should know, decide or do afterwards.
   - Slot length and presenters. The team's decks run 40 to 60 slides because dividers and visuals take seconds; budget about one minute per content slide.
   - Sources for every fact: Jira keys, Confluence pages, survey results, Gainsight PX numbers, Figma links, quotes. Read what the user gives you. If the facts live in Jira or Confluence and those tools are not available, ask the user to paste them.
   - Whether humour is welcome with this audience.
2. **Outline.** Use the structure for the deck type. Write `outline.md`: one line per slide with the layout, the headline and the point it makes. For decks over ten slides show the outline and get a yes before writing the copy.
3. **Copy.** Write `deck.json` following `references/slide-copy.md` and `references/voice.md`, with the layouts and fields from figma-slides-builder (`.kiro/skills/figma-slides-builder/references/layouts.md`, or `build_deck.py --layouts`). Speaker notes on every content slide. Give titles a `kicker` (the topic in 1 to 4 words) and mark the one word, number or line that matters most with `==highlight==`, one per slide (presentation-brand, rule 2). Start from a skeleton in `.kiro/skills/presentation-writer/assets/skeletons/` when it helps. Set `transition` (the team's decks read well with `dissolve`) and leave `grid` at `sections`. Leave the colours to the layouts; use `"theme"` only when a slide needs the other side of Day & Night.
4. **Rhythm pass.** Read `references/rhythm.md` and place the live moments the deck type calls for: comedic relief, the quoter, questions to the room, reveals, breathers. Mark them with `"role"` in the spec. For memes, write the concept and the caption; the user supplies the image.
5. **Check.** `python3 .kiro/skills/presentation-writer/scripts/lint_copy.py decks/<slug>/deck.json`. Fix every error (an error means unknown layout, missing field or a placeholder left in). Read every warning and fix it or say why it stays. Two rounds at most, then tell the user what is left.
6. **Build.** Hand over to figma-slides-builder (its SKILL.md, Workflow step 3). Its fit report names slides where text does not fit; cut words there (do not shrink fonts) and rebuild.

When you report back: where the files are, the slide count, the open `[TBD — Requires Input]` items with who can answer them, and the images the designer still needs.

## Ground rules

- **Nothing invented.** Every number, quote, date, Jira key and name comes from the user's sources. When something is missing, write `[TBD — Requires Input: what is missing]`; the check refuses to pass it, so it cannot ship by accident.
- **Quotes are verbatim.** Keep the original language when it is short and put the translation in the speaker notes or in small text. Attribute by role and company ("Revenue manager, city hotel group"). Remove customer names for any audience outside Shiji.
- **One slide, one point.** If a slide needs "and" in its headline, it is two slides.
- **The audience's words.** Outcomes for stakeholders, specs for builders, stories for research. Same facts, different slides.
- **Humour serves the point.** A meme that does not move the argument forward is cut. Never joke about customers, colleagues or users' competence.

## Tools

- `.kiro/skills/presentation-writer/scripts/lint_copy.py deck.json` checks word limits per layout and deck type, placeholders, missing notes and sources, AI vocabulary, exclamation marks, em-dash chains, repeated words, mixed spelling, product-name usage, index versus section titles, section numbering and pacing, unknown themes, more than one highlight per slide, and prints a rhythm map of the deck.
- `.kiro/skills/figma-slides-builder/scripts/deck_text.py` turns a Figma Slides file (Figma: File > Save local copy; reading it needs the zstd tool, see the builder skill), a `.pptx` or a `deck.json` into Markdown, slide by slide, with word counts and notes. Use it to review existing decks.
- `.kiro/skills/figma-slides-builder/scripts/figma_grid_slices.py` gives one picture per slide from a Figma Slides link (see the builder skill) when you need to see a deck you cannot open.

## References

- `references/deck-types.md`: quarterly, design update, research readout and other decks; audience, structure and density for each, taken from the team's real decks.
- `references/voice.md`: tone per deck type, the team's voice, rewrite examples, usage and glossary.
- `references/slide-copy.md`: how to write headlines, subtitles, leads, bullets, numbers, quotes, links and speaker notes, and what each layout wants.
- `references/rhythm.md`: the live moments (comedic relief, the quoter, questions, reveals, breathers), when to use them, how to write them.
- `references/review.md`: how to review an existing deck and the format of `copy-review.md`.
