# Figma Slides compatibility

## Opening a built file in Figma

1. Open Figma (desktop app or browser) and go to the **file browser** (Home, Drafts or a project page). Not an open file: dropped onto a canvas, Figma answers "Drop .fig or .jam files into the file browser".
2. Drag the `.fig` file onto the file browser window, or use **Import** and pick the file.
3. It opens as a new Figma Slides file in Drafts. Move it into the team project.
4. First open: if Figma reports missing fonts, the Figma organisation lacks Shiji Day Sans Aeonik or Shiji Night Serif Reckless Neue. Noto Sans is a Google font that Figma has built in. Ask the design lead for the Shiji font files (they are licensed, so the kit does not ship them).

Then finish in Figma: insert live prototypes and polls where the notes say "Designer:", replace still images with GIFs, check the presenter notes.

**Why `.fig`:** Figma's file browser imports `.fig` and `.jam` files by drag and drop and rejects other extensions, `.deck` included ("Files failed to import... Drop .fig or .jam files into the file browser"). The file inside says it is a Slides document (the `fig-deck` header), and the file browser accepts it under the `.fig` name: the template's own `canvas.fig`, taken out of the `.deck`, imported this way. So the build writes the Slides file Figma would save, named `.fig`.

## What the file is

A zip archive, the same thing Figma writes with **File > Save local copy**:

| Part | What it holds |
|---|---|
| `canvas.fig` | The document: an 8-byte header (`fig-deck` for Slides), a version number, then two compressed chunks. Chunk 1 is the schema (raw deflate), chunk 2 the layers (zstd in current Figma, raw deflate in older files). The encoding is Figma's "kiwi" binary format, and the schema travels inside the file. |
| `images/<sha1>` | Every image fill, named by the SHA-1 of its bytes. |
| `meta.json` | File name, export date, background colour. |
| `thumbnail.png` | Small preview for the file browser. Figma regenerates it. |

`scripts/figdeck.py` decodes and re-encodes this format with the schema from the file. `python3 scripts/figdeck.py selftest <file>` confirms that an unmodified file re-encodes to the identical bytes. With the `zstd` command line tool installed, the layers chunk is read and written with real zstd compression. Without it, the build still writes zstd, as a frame of uncompressed blocks (a valid zstd stream, just larger), and reads the template from `template/decoded/`, its decoded copy. Only reading other files saved by Figma needs the tool.

## What the build writes

- The file skeleton comes from the official template (`template/Day & Night template.deck`, a local copy of https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4): the Slides document and its theme, the linked logo and icon components, the text styles and the colour collections. Each new slide starts from a template slide, so it sits in the team's Slides theme.
- **Text is linked to the template's text styles** (`Shiji / Labels / Kicker`, `Shiji / Headings / Slide title`, `Shiji / Body / Body 28`...), so a designer can change a style once in Figma and every slide follows. The tokens and the styles hold the same values.
- **Colours are variables**: fills bind to the role names of the Slides theme ("Shiji / Presentation theme": `Accent/Mint`, `Background/Night`, `Surface/Ice`...) and, for the other brand colours, to the "Shiji Day & Night" palette.
- Each slide is drawn new: a background layer (locked, named `Background / (aurora)` and so on) with native linear and radial gradients, then text, rectangles, circles, pictures and the logo instance. The legacy and component layouts also copy their artwork from the template (the violet gradients, the brand circle, the wireframe, the laptop, the flag button).
- Layers carry the template's names: `Brand / Shiji logo · linked`, `Icon / Question · linked`, `Media / Screenshot · replace image fill`, `Media / Component demo · insert example`.
- Text columns, lists, cards, chips and buttons are **auto layout frames**, so Figma reflows them when someone edits the words.
- The build measures every text block in Chrome first, so boxes and frames already fit when the file opens.
- Speaker notes are stored in Figma's notes format (bold heading lines and bullet lists, as in the template) and show in presenter view.
- Videos (`walkthrough`) are real Figma Slides video layers: they play when presenting.
- Layers are stored in id order, as Figma does. Slides are grouped into named rows of the slide grid, one per section by default (`grid` and `row` in the spec).
- The template's 40 slides, and the stale copies of pasted slides Figma keeps on its internal page, are removed.

`scripts/check_deck.py` verifies the result: it decodes and re-encodes identically, every parent exists, ids are unique, every instance has its component, every colour variable and text style reference resolves, text runs and lines match the text, every image is in the archive, slides are 1920 x 1080 inside rows of the grid.

## Figma Slides facts that shape the layouts

From Figma's plugin documentation for Slides (developers.figma.com, "Working in Slides"):

- A slide is a `SLIDE` node, fixed at 1920 x 1080, inside a `SLIDE_ROW`, inside the `SLIDE_GRID`.
- Interactive elements (`POLL`, `EMBED`, `FACEPILE`, `ALIGNMENT`, `YOUTUBE`) cannot be created from outside Figma. The build leaves placeholders for them.
- A slide's transition is stored as its on-click link to the next slide (type, duration, easing), and auto-advance as an "after delay" link. The build writes these from `transition`, `transition_duration`, `easing` and `advance_after`.
- The build uses frames, rectangles, ellipses, text, images, videos, the template's components and exact copies of the template's own artwork layers, which Figma already reads in the template.

## Reading a Slides file from a link

The Figma REST API answers "File type not supported by this endpoint" for the layers of a Slides file, but it renders images. The slide grid is node `0:3` in every Slides file, so `download_figma_images` with `nodeId: "0:3"` returns the whole deck. `scripts/figma_grid_slices.py` cuts it into slides (see SKILL.md). For text and layers, ask for **File > Save local copy** and read the file with `scripts/deck_text.py` or `scripts/inspect_deck.py`.

## PowerPoint

| Route | When | Result |
|---|---|---|
| Figma: File > Export > PowerPoint | The deck lives in Figma | Figma's own conversion |
| `deck_to_pptx.py` | No Figma round trip, or Figma is not available | Text, rectangles, circles, screenshots and notes editable; gradient backgrounds, logo and icons as pictures |
| Figma Slides import of a `.pptx` | Someone sends a PowerPoint deck | Figma converts it to a Slides file; rebuild it in the kit for the Day & Night look |

PowerPoint files reference the fonts by name. On a computer without the Shiji fonts and Noto Sans, PowerPoint substitutes them; send the PDF export for read-only sharing. Videos become their poster frame.
