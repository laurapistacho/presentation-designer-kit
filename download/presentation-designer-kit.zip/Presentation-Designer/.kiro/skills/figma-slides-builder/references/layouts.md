# Layouts

The 40 layouts of the official Figma template, "00 Day & Night template" (https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4), in the template's order. Each one is a function in `scripts/layouts.py` that draws on an empty 1920 x 1080 slide: colours, gradients and type come from the **presentation-brand** skill (`assets/tokens.json`), text is linked to the template's text styles, and the legacy and component layouts copy their artwork from the template file (`references/template-spec.md`). A layout never hard-codes a colour or a size. Each layout has a default theme (night, day or blue); `"theme"` on a slide switches it where the layout supports both.

The last eight rows are the infographics of the presentation-infographics skill (wheel to matrix): diagrams drawn as editable Figma layers. Their fields, limits and type pairings are in `.kiro/skills/presentation-infographics/SKILL.md`; each has an example slide in `examples/infographics/deck.json`.

Text fields accept `**bold**`, `==highlight==` (one per slide: Energetic Green on night and blue, Reviewpro Blue on day), `[link text](https://url)` and `\n` for a new line. Every layout takes a `kicker`: the small label above the title, 1 to 4 words. Word limits live in the writer's copy check (`presentation-writer/scripts/lint_copy.py`), which runs before every build.

The ids in the old notes (A04, C19...) point at the team's real decks in `library/` (see `examples.md`): the layout of the same name rebuilds that pattern.

<!-- The table below is generated: python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --layouts-md -->
| Layout | In the Figma template | Default theme | What it is | Fields |
|---|---|---|---|---|
| `cover` | Cover · Aurora | night | Opening slide on the aurora: logo top centre, centred Night Serif title with one green highlight, subtitle and date. | kicker, title (==x== marks the green line), subtitle, date |
| `cover-navy` | Cover · Horizon | night | Left-aligned opening slide on the night horizon (day light at the top fading into night), logo top left. | kicker, title, subtitle, date |
| `cover-center` | Cover · Split typography | blue | Centred opening slide on Reviewpro Blue: a Day Sans line over a Night Serif line (2026 Roadmap / Q2 Achievements). | kicker, title (line 1 in Day Sans, line 2 in Night Serif), subtitle, date |
| `cover-gradient` | Cover · Legacy gradient | night | Legacy look: centred two-line title on Brand Navy with the violet glow of the previous template rising from the bottom left. Use on purpose, about one per deck. | kicker, title (line 1 in Day Sans Black, line 2 in Night Serif), subtitle, date |
| `index` | Agenda · Four topics | night | Agenda: Night Serif title on the left, numbered topics on the right with hairlines between them. | title (default "Agenda"), kicker, items[] (up to 8) |
| `section` | Divider · Dark numbered | night | Section divider on deep night: Energetic Green section number in Night Serif, title under it. Starts a new row of the slide grid. | number ("01"), title, kicker, background (deep|night|horizon|aurora|blue) |
| `section-flat` | Divider · Blue numbered | blue | Section divider on Reviewpro Blue: big white number on the left, title beside it. Starts a new row of the slide grid. | number, title, kicker |
| `section-number` | Divider · Oversized number | night | Legacy look: a giant faded number behind a Day Sans title on Link Blue with a violet edge. Starts a new row of the slide grid. Use on purpose, about one per deck. | number ("01"), title |
| `topic` | Project opener · Mixed typography | night | Sub-topic divider: two-line title in a soft blue glow inside a thin ring (New / Settings). | title (line 1 Night Serif, line 2 Day Sans), kicker |
| `question-circle` | Question · Brand circle | night | Legacy look: a question in two typefaces inside the Shiji brand circle on Brand Navy (Who are / these users?). | title (line 1 Night Serif, line 2 Day Sans Black), kicker |
| `composition` | Component · Composition overview | night | A component or page in one line, next to a tilted product wireframe on deep night (a composition update). | kicker, title, lead, bullets[] |
| `image` | Product · Large screenshot | day | Title on top, one big screenshot or diagram on the stage below (flows, journeys). | kicker, title, subtitle, image, caption, chip, image_fit |
| `walkthrough` | Component · Current-state walkthrough | day | The current state, shown: a screen recording (or a screenshot) on Blue 5 with the issues listed beside it. | kicker, title, video | image, poster, heading, bullets[], caption |
| `compare` | Comparison · Two screenshots | day | Current versus new: two screenshots side by side, an outline chip on the old one, an Energetic Green chip on the new one. | kicker, title, left_label, right_label, left_image, right_image, left_caption, right_caption |
| `compare-laptop` | Comparison · Two laptop mockups | day | Current versus new on two laptops: each screenshot fills a laptop screen, chips above, captions below. | kicker, title, left_label, right_label, left_image, right_image, left_caption, right_caption |
| `mobile` | Product · Mobile mockup | day | A phone on a soft circle at the right showing the screenshot; title and text on the left. | kicker, title, title_light, subtitle, body, bullets[], image (phone screen, about 9 x 19.5) |
| `variants` | Product · Variants & showcase | day | A component's variants: a short list on the left, each variant on the light-blue stage with its name, its tags and a demo slot (a screenshot, or an empty slot to paste the component into). | kicker, title, bullets[], variants[{name, tags[], image}] (1-3) |
| `content` | Product · Text & screenshot | day | The workhorse: text column centred in the white panel on the left, the screenshot on a soft stage on the right. With embed_url it becomes a live prototype slide. | kicker, title, subtitle, lead, body, bullets[], note, link{text,url}, image | embed_url, chip, split (33|40|50), image_fit (fit|fill) |
| `anatomy` | Component · Anatomy & delivery | day | What was done, what comes, what follows: question-and-answer groups on the left; labelled screenshots of the parts (cells, rows) on the stage. | kicker, title, groups[{title, bullets[] | text}] (1-3), columns[{label, image | images[], width}] (1-2) |
| `showcase` | Component · Shortcuts & evidence | day | A feature argued with evidence on Daylight Blue 60: the case on the left (a line in the highlight colour, the facts, a closing line), the picture and its sources on the right. | kicker, title, subtitle, lead, bullets[], closing, image, source (one or a list of {text,url}) |
| `collage` | Component · Audit collage | day | An audit in pictures: the findings on the left, a two-column collage of screenshot crops on the stage. | kicker, title, subtitle, lead, body, bullets[], images[] (2-8) |
| `intro` | Product · Feature spotlight | day | Topic intro on day: title and a one-line definition on the left, a big illustration on the stage at the right. | kicker, title, subtitle (a line or a list of lines, in the highlight colour), lead, image (illustration) |
| `circle-list` | Poll · Four options | night | A big circle on the left holding the title, a list on the right: polls (A/B/C/D), opportunity areas, checklists. | kicker, title (inside the circle), lead, items[], markers (none|letters|check|numbers), background (night|day|blue) |
| `content-dark` | Plan · Three deliverables | night | Text-only on night: heading and a paragraph on the left, a numbered list (or green-dot bullets) on the right. | kicker, title, title_light, subtitle, body, items[] (numbered), bullets[] |
| `content-glow` | Brief · Scenario | night | Text-only on the night horizon: a heading, a subtitle line and a paragraph (scenarios, briefs). | kicker, title, title_light, subtitle, body, bullets[] |
| `content-gradient` | Brief · Gradient scenario | night | Legacy look: a scenario or brief in white on the violet field of the previous template, fading to white at the bottom right. Use on purpose, about one per deck. | kicker, title, lead, body, bullets[] |
| `quote-cards` | Quotes · Three testimonials | night | Text on the left, two or three short user quotes as glass cards on the right. | kicker, title, subtitle, lead, quotes[{text,who}] (2-3), source{text,url} |
| `quotes` | Quotes · Four cards | day | Voice of the customer: short quotes in a grid of two or three columns, the hotel or role under each. | kicker, title, quotes[{text,who}] (2-6), closing, source{text,url} |
| `icons` | Roadmap · Four initiatives | day | A light panel on the left with the why; up to four icon items on the right (key projects, principles). Icons: integrations, space, settings, question, flag. | kicker, title, body, highlight, heading, items[{icon,title,text}] (up to 4) |
| `people` | People · Four personas | day | A row of people or personas: round photo (or initials), name, role and a one-line quote. | kicker, title, people[{image,name,role,quote}] (up to 5), footer |
| `columns` | Findings · Three columns | night | Two or three columns, each with a highlighted heading (the two-column slide of the original brand deck). | kicker, title, subtitle, columns[{title, text | bullets[]}] (2-3) |
| `stats` | Metrics · Three values | night | Proof in numbers: Night Serif figures with a hairline above each, the first one in Energetic Green. | kicker, title, subtitle, lead, bullets[], stats[{value,label}] (2-4), source{text,url} |
| `quote` | Quote · Hero | night | One hero quote on deep night: a big green quote mark, the quote in Night Serif, who said it. | kicker (or title), text, who, footer |
| `statement` | Statement · Full width | night | One sentence in Night Serif, centred, with the punchline in the highlight colour. | kicker, text (==x== or **x** for the punchline), sub, background (night|deep|blue|aurora|day) |
| `slogan` | Design-team slogan | day | The design-team slogan in Night Serif under the round flag button. Keep the wording as it is. | text (default: the design-team slogan) |
| `question` | Question · Context | day | A question to the room on a quiet day background: round icon, Night Serif question, a short line under it. | kicker, icon (question|settings|integrations|space|flag), title, text, serif (bool) |
| `split` | Visual · Split image & text | night | Half and half: a title on a colour half, a full-bleed picture on the other half. | kicker, title, subtitle, image, side (right|left), background (night|blue|day|daylight) |
| `picture` | Visual · Full bleed | night | One picture across the whole slide (a meme, a photo, a finished visual), with an optional caption chip. | image, image_fit (fill|fit), background, caption |
| `meme` | Visual · Image & punchline | day | Comedic relief: the meme framed on the left, the punchline on the right. | image, text, icon, serif (default true), caption |
| `thanks` | Closing · Thank you | night | Closing slide on the aurora: big Night Serif title, subtitle, an Energetic Green button and a contact line. | title (default "Thank you"), subtitle, cta (button text), contact |
| `wheel` | Infographic · Wheel (kit) | night | Infographic: one thing in the centre (Night Serif) and its parts around it as chips, joined by dotted spokes. | kicker, title, lead, center, items[] (3-10: text, color, highlight), palette (products) |
| `rings` | Infographic · Rings (kit) | night | Infographic: layers or scopes inside each other, the inner one stacked in the middle, the others on their ring. | kicker, title, lead, rings[] inner to outer (2-4: label, items[] up to 4: text, color, highlight, outline) |
| `cycle` | Infographic · Cycle (kit) | night | Infographic: a loop of numbered cards around the gradient circle, joined by arrows. | kicker, title, lead, center, steps[] (3-8: text, highlight) |
| `process` | Infographic · Process (kit) | night | Infographic: steps in order, left to right: a numbered circle, a title and a line of text each. | kicker, title, subtitle, steps[] (2-6: text, sub, highlight) |
| `userflow` | Infographic · User flow (kit) | night | Infographic: screens, decisions and their paths, left to right; a branch starts a row below. | kicker, title, subtitle, nodes[] (id, text, kind: start | screen | decision | end, label), links[] (from, to, label) |
| `timeline` | Infographic · Timeline (kit) | night | Infographic: dated moments on a line, phases above it, a Today chip; years and versions in Night Serif. | kicker, title, subtitle, events[] (2-8: date, text, sub, highlight), phases[] (title, from, to), today |
| `hierarchy` | Infographic · Hierarchy (kit) | night | Infographic: a tree from one item down: cards under it, each with its own chips. | kicker, title, subtitle, root (text, sub, children[] up to 6, each with children[] up to 5) |
| `matrix` | Infographic · Matrix (kit) | night | Infographic: two axes and four quadrant cards with up to four chips in each. | kicker, title, lead, quadrants[4] (title, items[] up to 4, highlight), x_axis, y_axis (label, low, high) |

## Picking a layout

- A slide that explains a structure (parts of a whole, layers, a loop, steps, screens and decisions, dates, reporting lines, two criteria) takes an infographic: `wheel`, `rings`, `cycle`, `process`, `userflow`, `timeline`, `hierarchy` or `matrix`. Propose it in the outline without being asked; the user can say no.

- **Open and close:** `cover` (aurora, centred) for most decks, `cover-navy` (horizon, left) for huddles and internal sessions, `cover-center` (blue) for roadmaps, `cover-gradient` (the legacy violet glow) when the deck continues the look of the earlier quarterlies. Close with `thanks`.
- **Structure:** `index` once, after the cover. `section` for each part (night, green number); `section-flat` (blue) for sub-parts in design updates; `section-number` (legacy, the giant faded number) for a research chapter. `topic` opens a project or component inside a section; `composition` opens a component with a picture of its structure. Section layouts start a new row in Figma's slide grid.
- **Show the work:** `content` is the workhorse (text left, screenshot on the stage right; `split` 33, 40 or 50 sets the text column; `embed_url` makes a live prototype slide). `image` for one big flow or diagram, `walkthrough` for the current state with a screen recording and its issues, `compare` for current versus new, `compare-laptop` for the same on two laptops, `mobile` for a phone screen, `variants` for a component's variants with an empty slot to paste each into, `anatomy` for what was done, what comes and what follows next to the parts, `showcase` for a feature argued with evidence and sources, `collage` for an audit in screenshot crops, `intro` before the details of a component.
- **Make the point:** `statement` (one sentence), `question` (to the room), `question-circle` (a set-up question in the brand circle), `quote` (one voice), `stats` (numbers), `columns` (two or three findings side by side), `icons` (up to four initiatives), `slogan` (the design-team slogan, word for word).
- **Voices and people:** `quote-cards` (story left, quotes right), `quotes` (a grid of short quotes), `people` (personas or a team).
- **Text only:** `content-dark` (numbered list or green-dot bullets), `content-glow` (a scenario or brief on the horizon), `content-gradient` (the same on the legacy violet field).
- **Pictures and relief:** `split` (title next to a photo), `picture` (full bleed), `meme` (the punchline next to the picture), `circle-list` (polls with A, B, C, checklists).
- **The legacy look** (`cover-gradient`, `section-number`, `question-circle`, `content-gradient`) comes from the earlier template and is kept in the official one on purpose: use it as an accent, about one per deck. The copy check warns at three.

## Examples

```json
{"layout": "cover", "kicker": "Product monthly", "title": "Design Updates\n==Q4 2026==", "subtitle": "UX & UI Design · Reviewpro", "date": "November 2026"}
{"layout": "section", "number": "01", "title": "Design projects"}
{"layout": "content", "kicker": "Settings", "title": "Search that finds it", "lead": "Find any setting without knowing where it lives.",
 "bullets": ["**Live filtering** across all sections", "Highlighted matches", "Match-count badges"],
 "image": "img/settings-search.png", "chip": "New", "link": {"text": "Open the prototype", "url": "https://www.figma.com/proto/..."}}
{"layout": "walkthrough", "kicker": "Settings", "title": "Current settings page is one long, flat scroll",
 "video": "img/settings-today.mov", "heading": "Issues", "bullets": ["One long scroll with no navigation", "No search to find settings"]}
{"layout": "compare-laptop", "kicker": "Comparison", "title": "Current versus new", "left_image": "img/current.png", "right_image": "img/new.png",
 "left_caption": "Badges only show the newest notifications.", "right_caption": "Totals beside every badge."}
{"layout": "variants", "kicker": "Component", "title": "Variants", "bullets": ["Desktop first, horizontal. Three sizes."],
 "variants": [{"name": "Horizontal tab", "tags": ["Desktop", "Large"], "image": "img/tabs-large.png"}]}
{"layout": "anatomy", "kicker": "Component", "title": "Tables",
 "groups": [{"title": "What has been done?", "bullets": ["Audits and benchmark"]}, {"title": "What will be delivered?", "bullets": ["Documentation of the new foundations"]}],
 "columns": [{"label": "Cells", "width": 220, "images": ["img/cell-1.png", "img/cell-2.png"]}, {"label": "Rows", "width": 768, "image": "img/rows.png"}]}
{"layout": "showcase", "kicker": "Component", "title": "Keyboard shortcuts", "subtitle": "A productivity layer for power users",
 "bullets": ["Go to section: G + key", "Command bar: ⌘K to search and jump"], "image": "img/keys.png",
 "source": [{"text": "Keyboard shortcuts: UX research and proposal", "url": "https://..."}]}
{"layout": "collage", "kicker": "Settings", "title": "Audit overview", "subtitle": "Where the current page breaks down",
 "bullets": ["Duplicate entries", "AI features scattered"], "images": ["img/audit-1.png", "img/audit-2.png", "img/audit-3.png"]}
{"layout": "stats", "kicker": "Adoption", "title": "It worked", "stats": [{"value": "~60%", "label": "adoption"}, {"value": "12,480", "label": "users exposed"}],
 "source": {"text": "Rollout summary", "url": "https://..."}}
{"layout": "statement", "text": "Every serious product agrees:\n**sidebar to orient, search to jump.**"}
{"layout": "slogan"}
{"layout": "thanks", "title": "Thank you", "subtitle": "UX/UI Design", "cta": "Questions?"}
```

`examples/day-night-template/deck.json` in the kit folder rebuilds the official template, one slide per layout in the template's order; its built file and pictures are the reference for how each one looks.

## When nothing fits

Use the closest layout and put the change in the notes as "Designer: ...". Never hand-edit a built file: every change goes through the spec and `build_deck.py`. A new layout is a new function in `scripts/layouts.py` (maintainers: `kit-maintenance` steering file).
