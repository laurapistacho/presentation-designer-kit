# Layouts

Every layout is a function in `scripts/layouts.py`. It draws on an empty 1920 x 1080 slide in the Day & Night look: colours, gradients and type come from the **presentation-brand** skill (`assets/tokens.json`), so a layout never hard-codes a colour or a size. Each layout has a default theme (night, day or blue); `"theme"` on a slide switches it where the layout supports both.

Text fields accept `**bold**`, `==highlight==` (one per slide: Energetic Green on night and blue, Reviewpro Blue on day), `[link text](https://url)` and `\n` for a new line. Every layout takes a `kicker`: the small mono label above the title, 1 to 4 words. Word limits live in the writer's copy check (`presentation-writer/scripts/lint_copy.py`), which runs before every build.

The ids in the old notes (A04, C19...) point at the team's real decks in `library/` (see `examples.md`): the layout of the same name rebuilds that pattern in the new look.

<!-- The table below is generated: python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --layouts-md -->
| Layout | Default theme | What it is | Fields |
|---|---|---|---|
| `cover` | night | Opening slide on the aurora: logo top centre, centred Night Serif title with one green highlight, subtitle and date. | kicker, title (==x== marks the green line), subtitle, date |
| `cover-navy` | night | Left-aligned opening slide on the night horizon (day light at the top fading into night), logo top left. | kicker, title, subtitle, date |
| `cover-center` | blue | Centred opening slide on Reviewpro Blue: a Day Sans line over a Night Serif line (2026 Roadmap / Q2 Achievements). | kicker, title (line 1 in Day Sans, line 2 in Night Serif), subtitle, date |
| `thanks` | night | Closing slide on the aurora: big Night Serif title, subtitle, an Energetic Green button and a contact line. | title (default "Thank you"), subtitle, cta (button text), contact |
| `index` | night | Agenda: Night Serif title on the left, numbered topics on the right with hairlines between them. | title (default "Agenda"), kicker, items[] (up to 8) |
| `section` | night | Section divider on deep night: Energetic Green section number in Night Serif, title under it. Starts a new row of the slide grid. | number ("01"), title, kicker, background (deep|night|horizon|aurora|blue) |
| `section-flat` | blue | Section divider on Reviewpro Blue: big white number on the left, title beside it. Starts a new row of the slide grid. | number, title, kicker |
| `topic` | night | Sub-topic divider: two-line title in a soft blue glow inside a thin ring (New / Settings). | title (line 1 Night Serif, line 2 Day Sans), kicker |
| `statement` | night | One sentence in Night Serif, centred, with the punchline in the highlight colour. | kicker, text (==x== or **x** for the punchline), sub, background (night|deep|blue|aurora|day) |
| `question` | day | A question to the room on a quiet day background: round icon, Night Serif question, a short line under it. | kicker, icon (question|settings|integrations|space), title, text, serif (bool) |
| `quote` | night | One hero quote on deep night: a big green quote mark, the quote in Night Serif, who said it. | kicker (or title), text, who, footer |
| `stats` | night | Proof in numbers: Night Serif figures with a hairline above each, the first one in Energetic Green. | kicker, title, subtitle, lead, bullets[], stats[{value,label}] (2-4), source{text,url} |
| `content` | day | The workhorse: text column on the left, the screenshot on a soft stage on the right. With embed_url it becomes a live prototype slide. | kicker, title, subtitle, lead, body, bullets[], note, link{text,url}, image | embed_url, chip, split (33|40|50), image_fit (fit|fill) |
| `image` | day | Title on top, one big screenshot or diagram on the stage below (flows, journeys). | kicker, title, subtitle, image, caption, chip, image_fit |
| `compare` | day | Current versus new: two screenshots side by side, an outline chip on the old one, an Energetic Green chip on the new one. | kicker, title, left_label, right_label, left_image, right_image, left_caption, right_caption |
| `content-dark` | night | Text-only on night: heading and a paragraph on the left, a numbered list (or green-dot bullets) on the right. | kicker, title, title_light, subtitle, body, items[] (numbered), bullets[] |
| `content-glow` | night | Text-only on the night horizon: a heading, a subtitle line and a paragraph (scenarios, briefs). | kicker, title, title_light, subtitle, body, bullets[] |
| `columns` | night | Two or three columns, each with a highlighted heading (the two-column slide of the original brand deck). | kicker, title, subtitle, columns[{title, text | bullets[]}] (2-3) |
| `icons` | day | Night panel on the left with the why; up to four icon items on the right (key projects, principles). Icons: integrations, space, settings, question. | kicker, title, body, highlight, heading, items[{icon,title,text}] (up to 4) |
| `intro` | day | Topic intro on day: title and a one-line definition on the left, a big illustration on the stage at the right. | kicker, title, subtitle (a line or a list of lines, in the highlight colour), lead, image (illustration) |
| `mobile` | day | A phone on a soft circle at the right showing the screenshot; title and text on the left. | kicker, title, title_light, subtitle, body, bullets[], image (phone screen, about 9 x 19.5) |
| `split` | night | Half and half: a title on a colour half, a full-bleed picture on the other half. | kicker, title, subtitle, image, side (right|left), background (night|blue|day|daylight) |
| `picture` | night | One picture across the whole slide (a meme, a photo, a finished visual), with an optional caption chip. | image, image_fit (fill|fit), background, caption |
| `meme` | day | Comedic relief: the meme framed on the left, the punchline on the right. | image, text, icon, serif (default true), caption |
| `quote-cards` | night | Text on the left, two or three short user quotes as glass cards on the right. | kicker, title, subtitle, lead, quotes[{text,who}] (2-3), source{text,url} |
| `quotes` | day | Voice of the customer: short quotes in a grid of two or three columns, the hotel or role under each. | kicker, title, quotes[{text,who}] (2-6), closing, source{text,url} |
| `people` | day | A row of people or personas: round photo (or initials), name, role and a one-line quote. | kicker, title, people[{image,name,role,quote}] (up to 5), footer |
| `circle-list` | night | A big circle on the left holding the title, a list on the right: polls (A/B/C/D), opportunity areas, checklists. | kicker, title (inside the circle), lead, items[], markers (none|letters|check|numbers), background (night|day|blue) |

## Picking a layout

- **Open and close:** `cover` (aurora, centred) for most decks, `cover-navy` (horizon, left) for huddles and internal sessions, `cover-center` (blue) for roadmaps. Close with `thanks`.
- **Structure:** `index` once, after the cover. `section` for each part (night, green number); `section-flat` (blue) for sub-parts in design updates. `topic` opens a project or component inside a section. Section layouts start a new row in Figma's slide grid.
- **Show the work:** `content` is the workhorse (text left, screenshot on the stage right; `split` 33, 40 or 50 sets the text column; `embed_url` makes a live prototype slide). `image` for one big flow or diagram, `compare` for current versus new, `mobile` for a phone screen, `intro` before the details of a component.
- **Make the point:** `statement` (one sentence), `question` (to the room), `quote` (one voice), `stats` (numbers), `columns` (two or three findings side by side), `icons` (up to four initiatives).
- **Voices and people:** `quote-cards` (story left, quotes right), `quotes` (a grid of short quotes), `people` (personas or a team).
- **Text only:** `content-dark` (numbered list or green-dot bullets), `content-glow` (a scenario or brief on the horizon).
- **Pictures and relief:** `split` (title next to a photo), `picture` (full bleed), `meme` (the punchline next to the picture), `circle-list` (polls with A, B, C, checklists).

## Examples

```json
{"layout": "cover", "kicker": "Product monthly", "title": "Design Updates\n==Q4 2026==", "subtitle": "UX & UI Design · ReviewPro", "date": "November 2026"}
{"layout": "section", "number": "01", "title": "Design projects"}
{"layout": "content", "kicker": "Settings", "title": "Search that finds it", "lead": "Find any setting without knowing where it lives.",
 "bullets": ["**Live filtering** across all sections", "Highlighted matches", "Match-count badges"],
 "image": "img/settings-search.png", "chip": "New", "link": {"text": "Open the prototype", "url": "https://www.figma.com/proto/..."}}
{"layout": "compare", "title": "Current versus new", "left_image": "img/current.png", "right_image": "img/new.png",
 "left_caption": "Today: four cards, equal weight.", "right_caption": "New: the score first."}
{"layout": "stats", "kicker": "Adoption", "title": "It worked", "stats": [{"value": "~60%", "label": "adoption"}, {"value": "12,480", "label": "users exposed"}],
 "source": {"text": "Rollout summary", "url": "https://..."}}
{"layout": "statement", "text": "Every serious product agrees:\n**sidebar to orient, search to jump.**"}
{"layout": "columns", "title": "What we learned", "columns": [{"title": "Orientation", "text": "..."}, {"title": "Search", "text": "..."}]}
{"layout": "thanks", "title": "Thank ==you==", "subtitle": "UX/UI Design", "cta": "Questions?"}
```

`examples/day-night-template/deck.json` in the kit folder uses every layout once; its built file and pictures are the reference for how each one looks.

## When nothing fits

Use the closest layout and put the change in the notes as "Designer: ...". Never hand-edit a built file: every change goes through the spec and `build_deck.py`. A new layout is a new function in `scripts/layouts.py` (maintainers: `kit-maintenance` steering file).
