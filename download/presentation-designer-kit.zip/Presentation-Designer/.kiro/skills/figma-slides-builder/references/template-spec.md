# The template file: what the build takes from it

Source: Figma Slides file `Q43PlPzdfGtoPMZOjttDxH` ("Product Presentation Template"), saved locally as `template/Product Presentation Template.deck` in the kit (exported 17 Nov 2026). Values below were read from that file with `scripts/inspect_deck.py`.

Since the Day & Night redesign the template is the **file skeleton**, not the look. The look comes from the presentation-brand skill (`assets/tokens.json`). Pictures of the old template slides stay in `library/template/` for comparison.

## What the build takes

| From the template | Id | Used for |
|---|---|---|
| The Slides document, its slide grid and first slide row | `0:0`, `0:3` | Every file: the build fills the grid with new slides and removes the 20 old ones |
| Slide 14 | `2002:2370` | The base copied for every new slide (then emptied) |
| Local colour collection "Product Presentations" | `1:123` | Renamed **Shiji Day & Night**; its 13 variables are re-valued to the brand kit and 6 brand colours are added (`build_deck.py`, `REUSE_VARIABLE`) |
| `Shiji` logo instances, white and dark | `2013:277`, `2038:246` | The logo on every slide, 91 x 48 px |
| The template's own instance of each icon: question, integrations, space, settings | `2002:2385`, `2038:257`, `2038:264`, `2038:271` (components `2040:378`, `2038:205`, `2038:207`, `2038:209`) | Icons in white, centred on round buttons (`question`, `icons`, `meme`). Each icon is a copy of the instance that already uses it, scaled like Figma's scale tool does (scale factor plus the cached sizes and outlines inside). Never re-point an instance at another component, and never resize one by its box alone: Figma then keeps the icon at its old size, off centre. |
| A plain text layer | `2002:2391` | Copied for every text layer, then set in the brand type |
| An auto layout frame | `2013:156` | Copied for every column, list row, card, chip and button |
| A rectangle and the circle's ellipse | `2038:240`, `1:63` | Backgrounds, stages, screenshots, hairlines, dots, rings |

`python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --check-template` confirms every id the code uses is still in the file (59 ids today).

## What the build ignores

- The old slides, their blurred gradient ellipses and their fonts (Lato, Noto Sans, Inter).
- The template's text styles and its Slides theme. The theme is linked to a team library ("Product Presentations", key `ea519b22…`); editing it in the file would fight the library. Text gets its type on the layer instead.
- The template's other colour collections (Shiji 2024, Shiji 2025, ReviewPro product tokens, spacing, radius). They stay in the file, unused.

## A new version of the template

See the `kit-maintenance` steering file: save it from Figma, replace the file, run `--check-template`, refresh `template/decoded/` with the setup check, rebuild the Day & Night showcase.
