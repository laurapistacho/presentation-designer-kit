# The template file: what the build takes from it

**The official template is the Figma Slides file "00 Day & Night template": https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4** (file key `r03dbNAia3aYpzBjBab0c4`). The design team owns it. It is the source of truth for every Shiji slide: the layouts, the Slides theme (colours and text styles), the linked logo and icons, the layer names. The kit keeps a local copy of it, saved with **File > Save local copy** (18 Nov 2026): `template/Day & Night template.deck`.

The kit's look is this template. The presentation-brand skill's `assets/tokens.json` holds the same values as numbers (colours, type, gradients), so the builder can draw any slide in the look; its "text_styles" and "theme_variables" sections map each token to the style or colour of this file, and every token matches the template's style exactly (a build never changes the template's styles). Values below were read from the file with `scripts/inspect_deck.py`.

## The 40 slides, in six rows

Each slide is one layout of the kit (`references/layouts.md` has the table; the slide names in the Figma file are the "In the Figma template" column).

| Row in the slide grid | Slides | Kit layouts |
|---|---|---|
| 01 · Covers & agenda | 1 to 5 | `cover`, `cover-navy`, `cover-center`, `cover-gradient`, `index` |
| 02 · Dividers & key messages | 6 to 11 | `section`, `section-flat`, `section-number`, `topic`, `question-circle`, `composition` |
| 03 · Product & comparisons | 12 to 22 | `image`, `walkthrough`, `compare`, `compare-laptop`, `mobile`, `variants`, `content`, `anatomy`, `showcase`, `collage`, `intro` |
| 04 · Research & evidence | 23 to 32 | `circle-list`, `content-dark`, `content-glow`, `content-gradient`, `quote-cards`, `quotes`, `icons`, `people`, `columns`, `stats` |
| 05 · Plans & briefs | 33 to 36 | `quote`, `statement`, `slogan`, `question` |
| 07 · Visuals & closing | 37 to 40 | `split`, `picture`, `meme`, `thanks` |

## What the build takes

| From the template | Id | Used for |
|---|---|---|
| The Slides document, its slide grid and first row | `0:0`, `0:3` | Every file. The build removes the 40 template slides (and the stale copies of pasted slides Figma keeps on its internal page) and fills the grid with the new ones, one row per section, each row named |
| Slide 12, "Product · Large screenshot" | `2041:196` | The base of every new slide (copied empty). It carries the template's Slides theme, so each slide sits in the team theme |
| Colour collection "Shiji / Presentation theme" | `2038:290` | The Slides theme colours: fills bind to its role names (`Accent/Mint`, `Background/Night`, `Surface/Ice`...), re-valued from the tokens (tokens.json "theme_variables") |
| Colour collection "Shiji Day & Night" | `1:123` | The full brand palette as variables, re-valued from the tokens; the colours it lacks are added. Fills without a theme role bind here (Twilight, Moonlight, Blue 3...) |
| Text styles "Shiji / ..." | (by name) | Every text layer is linked to the style of its type token (tokens.json "text_styles"): `Shiji / Labels / Kicker`, `Shiji / Headings / Slide title`, `Shiji / Body / Body 28`... |
| The linked Shiji logo, white and Logo Blue | `2041:20`, `2041:214` | The logo on every slide, 91 x 48 px, named `Brand / Shiji logo · linked` |
| The template's own instance of each icon: question, integrations, space, settings, flag | `2041:153`, `2041:624`, `2041:611`, `2041:617`, `2051:4933` | Icons in white, centred on round buttons. Each icon is a copy of the instance that already uses it, scaled like Figma's scale tool does. Never re-point an instance at another component, and never resize one by its box alone |
| A plain text layer, an auto layout frame, a rectangle, an ellipse | `2041:195`, `2041:208`, `2041:211`, `2041:251` | Copied for every text layer, column, card, chip, button, stage, screenshot, dot and ring |
| The video layer of slide 13 | `2051:5009` | Copied for a `video` (format, playback settings); its recording is replaced |
| Artwork (`build_deck.ART`) | `2047:147`, `2047:156` + `2047:158`, `2047:163`, `2051:4954`, `2047:213`, `2047:167`, `2051:4931` | Copied as they are: the legacy gradient of slide 4, the number gradient of slide 8, the brand circle of slide 10, the wireframe of slide 11, the laptop of slide 15, the scenario gradient of slide 26, the round flag button of slide 35 |

`python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --check-template` confirms every id the code uses is still in the file (42 ids today).

## Layer names

The build names layers the way the template does, so designers find their way in Figma:

| Name | Layer |
|---|---|
| `Background / (aurora)`, `Background / (night)`... | The locked full-bleed gradient of a slide |
| `Brand / Shiji logo · linked` | The logo instance (linked to the library: never detach it) |
| `Icon / Question · linked` | An icon instance |
| `Media / Screenshot · replace image fill` | A picture: select it and replace its image fill |
| `Media / Component demo · insert example` | An empty slot to paste a component into |
| `Media / Walkthrough video · replace video` | A video |
| `Artwork / ...` | Template artwork (gradients, brand circle, wireframe) |
| `Kicker`, `Title`, `Subtitle`, `Lead`, `Body`, `Bullets`, `Item 1`... | The text and the auto layout frames that hold it |

## What the build ignores

- The template's sample words and pictures: every slide is drawn new from the spec.
- The "Legacy /", "Compatibility /" and "Variants /" text styles nobody links to, and the other colour collections (from pasted slides and libraries). They stay in the file.
- The second Slides theme (`2040:330`, the previous Product Presentations theme). It stays in the file, unused.

## The public edition

The template carries the team's own material: real product screenshots, a screen recording, internal links and stale slides. `setup/public_edition.py` writes a cleaned copy for the website and its download: the same skeleton (theme, styles, components, the layers above), without the template slides' content. The internal kit keeps the full file.

## A new version of the template

See the `kit-maintenance` steering file: in Figma, open the official template and use File > Save local copy, replace the file, run `--check-template`, refresh `template/decoded/` with the setup check, rebuild the showcase.
