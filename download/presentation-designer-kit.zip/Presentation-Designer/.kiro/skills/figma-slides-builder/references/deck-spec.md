# Deck spec (`deck.json`)

The spec is the hand-off between the words (presentation-writer) and the build (`build_deck.py`). One JSON file, one object per slide, in presentation order. Image paths are relative to the spec file. The look is not in the spec: it comes from the layouts and the presentation-brand tokens.

```json
{
  "file_name": "Design Updates Q4 2026",
  "deck_type": "quarterly",
  "audience": "Product leadership, PMs, CS leads",
  "transition": "dissolve",
  "slides": [
    {"layout": "cover", "kicker": "Product monthly", "title": "Design Updates\n==Q4 2026==", "subtitle": "UX & UI Design",
     "notes": "Welcome. Twenty minutes, five sections, one ask at the end."},
    {"layout": "index", "items": ["Design Projects", "CX Collaboration", "UX Research", "Product Projects", "Next steps"]},
    {"layout": "section", "number": "01", "title": "Design Projects"},
    {"layout": "content", "kicker": "Settings", "title": "Search that finds it",
     "lead": "Find any setting without knowing where it lives.",
     "bullets": ["**Live filtering** across all sections", "**Highlighted matches** in every card"],
     "image": "img/search-active.png", "chip": "New",
     "notes": "Type 'tax' and watch the cards filter. This is the first time Settings has search."},
    {"layout": "thanks", "title": "Thank ==you==", "subtitle": "UX/UI Design", "cta": "Questions?"}
  ]
}
```

## Top-level fields

| Field | Required | Meaning |
|---|---|---|
| `file_name` | yes | Name the file gets in Figma and PowerPoint. |
| `deck_type` | recommended | `quarterly`, `design-update`, `research` or `other`. The writer's copy check uses it for word limits and pacing. |
| `audience` | recommended | Who is in the room. Read by people, not by the build. |
| `transition` | optional | Transition for every slide: `none` (default), `dissolve`, `smart-animate`, `slide-from-right`, `push-from-right`, `move-from-right` (and `-left`, `-top`, `-bottom`). A slide's own `transition` wins. |
| `transition_duration`, `easing` | optional | Seconds (default 0.4) and `ease-out` (default), `ease-in`, `ease-in-out`, `linear`, `gentle`. |
| `advance_after` | optional | Seconds before Figma moves on by itself (kiosk loops). Per slide too. |
| `grid` | optional | `sections` (default): a new row of the slide grid at every `section` or `section-flat` slide. `single`: one long row. `new_row: true` on any slide starts a row there. |
| `slides` | yes | List of slides. Each needs `layout`; the other fields depend on the layout (`layouts.md`, or `build_deck.py --layouts`). |

## Fields every slide can have

| Field | Meaning |
|---|---|
| `kicker` | The small mono label above the title, 1 to 4 words ("Settings", "Adoption"). Uppercase in the slide; write it in normal case. |
| `theme` | `day`, `night` or `blue`, to switch the layout's default where it makes sense (a night `content` slide, a day `columns` slide). |
| `background` | On covers, dividers, statements and text-only slides: `aurora`, `horizon`, `deep`, `night`, `blue`, `day`, `daylight` (the brand skill describes each). |
| `logo` | `false` hides the footer logo on that slide. |
| `notes` | Speaker notes (below). |
| `skip`, `name`, `role`, `transition`, `new_row` | Skip the slide, name it in the grid, mark a live moment (presentation-writer `references/rhythm.md`), its own transition, a new grid row. |

## Text formatting

- `==highlight==` for the one word, number or line that matters most on the slide: Energetic Green on night and blue slides, Reviewpro Blue on day slides. One per slide; the copy check warns at two.
- `**bold**` for words that carry the point in body text and bullets. One bold phrase per paragraph at most. In a `statement`, `**...**` marks the punchline and shows as the highlight.
- `[link text](https://...)` for links. The words say where the link goes ("Satisfaction Survey — Confluence"), never "click here".
- `\n` starts a new line. In titles a new line is a deliberate break: use it to balance two lines, or to put the highlight on its own line.
- Lists (`bullets`, `items`) are JSON arrays. One item per bullet, no bullet characters in the text.
- Emoji only where the team uses them (✅ in checklists). Not in titles: Night Serif has no emoji, Figma swaps in another font.

## Images

- PNG or JPG. Screenshots at 2x of the real size, cropped to what the slide talks about. They are shown whole, at their own ratio, on the stage.
- Keep images next to the spec in `img/`. Name them after what they show (`search-no-results.png`).
- `image_fit: "fill"` crops to fill the box (photos); the default shows the whole image (screenshots).
- Phone screens for `mobile`: portrait, about 9 x 19.5 (390 x 844 at 1x).
- `people` without an `image` get round initials on a blue gradient.
- GIFs become a still frame in the file. Add the animated GIF in Figma afterwards.

## Speaker notes

`notes` on every content slide. Plain sentences, the way the presenter will say them. They show in Figma Slides presenter view and carry over to PowerPoint. Things the designer must finish in Figma go at the end, starting with `Designer:` ("Designer: insert the Settings prototype embed").

## Things the build cannot create

Figma Slides interactive elements (polls, alignment scales, live prototype embeds, YouTube, facepiles) only exist inside Figma. For a live prototype use `embed_url` on a `content` slide: the build leaves a placeholder card with the link. For a poll use `circle-list` with `markers: "letters"` and note "Designer: replace with a Figma Slides poll" if the team wants live voting.
