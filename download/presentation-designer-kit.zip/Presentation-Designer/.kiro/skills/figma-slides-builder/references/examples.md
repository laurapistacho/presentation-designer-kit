# Visual library: the team's real decks

Four Figma Slides decks built by the design team, captured on 17 Nov 2026 from their Figma links (rendered with the Figma API, slide grid node `0:3`). Slide ids below (A04, C19...) match the file names in `library/slides/` (a selection) and the numbered contact sheets in `library/decks/` (every slide, 16 per sheet). Paths are relative to the kit folder; `library/index.html` shows everything in a browser. Open the images before matching a look.

| Deck | Title | Type | Slides | Figma | Contact sheets |
|---|---|---|---|---|---|
| A | UX & UI Updates · Product Monthly | Design and component update | 39 | `figma.com/slides/PmOV26l9XFQu9ndIz8igTa` | `deckA-1..3.jpg` |
| B | UX Research & Mobile Initiative · Shiji Guest Solutions | Research readout | 61 | `figma.com/slides/Zh3rYHndnzD76hBC0OaRXP` | `deckB-1..4.jpg` |
| C | Design Updates · Q3 2026 | Quarterly | 50 | `figma.com/slides/tcIYHEBS1DGtWJnTQcmZ4Z` | `deckC-1..4.jpg` |
| D | Design Updates · Q2 2026 | Quarterly | 40 | `figma.com/slides/uoOcpvKGl68lykWrWvOja3` | `deckD-1..3.jpg` |


The story structure of each deck type is in the presentation-writer skill (`references/deck-types.md`). This file is about the patterns: which slides the team uses and which layout rebuilds each one.

**These pictures show the previous template's look** (blurred purple glows, Lato body text). Use them for structure and content patterns, not for colours or type: the layouts redraw every pattern in the look of the official template, "00 Day & Night template" (https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4). Four of its layouts keep the legacy look on purpose, as an accent (`cover-gradient`, `section-number`, `question-circle`, `content-gradient`). `library/day-night/` and the first section of `library/index.html` show every layout, one slide each.

## What every deck shares

- Opens on the gradient cover (A01, C01, D01) or navy with glow (B01). Title in Day Sans Black, a short subtitle bottom left, white logo top left.
- An index on the gradient (A02, C02, D02), then numbered section dividers with a giant faded number: on the gradient (B02, C03, D03) or flat twilight blue (A07, A11, A13).
- Topic dividers inside a section: navy with a big blue circle and a two-word title, first word in Night Serif, second in Day Sans (C04 "New Settings", C12 "Components", C28, C31, C33, C38, C42, D13, D16, D20).
- Content slides are white with a light-blue panel on the right (about three quarters of the width) holding screenshots, and a narrow text column on the left: Day Sans Bold title in twilight blue, a small bold subtitle, a lead sentence, short bullets, a note at the bottom. Logo bottom right.
- Closes with a principle in Night Serif on white (C49, D39: "Design with proof, build with purpose, grow without friction") and "Thank you ✨" on blue with the glow (A39, B61, C50, D40).

## Patterns, where they appear, and the layout that rebuilds them

| Pattern | Examples | Layout | Notes |
|---|---|---|---|
| Gradient cover | A01, C01, D01 | `cover`, or `cover-gradient` to keep the earlier look | Subtitle = quarter or "Product Monthly". |
| Navy cover with glow | B01, B04 | `cover-navy` | B04 reuses it mid-deck as a chapter opener ("From assumptions → Measurable insights"). |
| Index | A02, C02, D02 | `index` | 2 to 5 topics, numbered. |
| Section divider | B02, B08, C03, C23, C27, D03 | `section`, or `section-number` for the giant faded number | Number plus 2 to 5 words; research deck uses a sentence ("So we decided to find out"). |
| Flat section divider | A07, A11, A13, A27 | `section-flat` | Benchmark / Current design / New design inside a component story. |
| Topic divider | C04, C12, D13, D20 | `topic` | Night Serif line 1, Day Sans line 2. |
| Topic intro with illustration | A03, A21, A34 | `intro`, or `composition` on night with the tilted wireframe | White, a big tilted line illustration of the component on the right, a one-line definition on the left. |
| Why this initiative | A04, A22, D21 | `question` | Round icon, title, two short paragraphs. A22 adds a bordered fact box with rollout numbers. |
| Industry consensus / big statement | A05, A10, A24, C06, B17, B44 | `statement` | Kicker, one sentence, **bold** punchline. Blue with navy circle (A10, A24) or navy (B17, B44). |
| Component with a screenshot | A06, A16 to A19, C13 to C16, D04, D06 | `content` | Chips above the screenshot name the state: Default, Active, No results, CURRENT, NEW, Old, New. |
| Several states side by side | A15, A28, C21 | `variants`, or `content` with one combined image | A name chip and tag chips above each state. |
| Annotated current design | A12, C07 | `walkthrough` (a screen recording or a screenshot, issues beside it) | Screenshot left, issues listed on the right. |
| Component anatomy and plan | C21 (Tables) | `anatomy` | What has been done, what will be delivered, what happens after; cells and rows pictured. |
| Live prototype | A20, A31, A38, C11, C17, C22, C41 | `content` with `embed_url` | "Live prototype · Test the interactions!" plus "Note: there might be some elements that are not perfect since this is AI generated" and the figma.site link. |
| Current versus new | D07 | `compare`, or `compare-laptop` on two laptops | D07 states the gain under it: "182px to 119px (34% less chrome)". |
| Benchmark collage | A08, A09, C05, C39 | `collage`, or `content` / `image` | Competitor screenshots on the panel, the list of tools in the column. |
| Proof with numbers | C19, A22 | `stats` | Big numbers in cards, source link under them. |
| Proof with quotes | C20 | `quote-cards` | Role and company under each quote; original language kept, translation in small text. |
| Voice of the customer | A23, A25 | `quotes` | Blue, navy circle, quotes with the hotel name in bold, closing line, link to the survey. |
| Hero quote | B46 | `quote` | Night Serif quote, who said it, the number that explains it. |
| Users' quotes in serif | B25 | `quotes` or `quote` | Purple gradient, right-aligned serif quotes with roles. |
| From feedback to fixes | A26 | `content` (text) or build in Figma | Bordered boxes: the request, what CS reported (with their Jira keys), what shipped, context line. |
| Icon grid | C24, C45, D28, D37, B36, B42, B60 | `icons` | Four steps or projects, round blue icon buttons. |
| Circle with list | B05, B10, B16, B37, B45, B48, D14, D15 | `circle-list` | Title in the circle, list on the right. B16 is a poll (A/B/C/D), B48 and D15 use coloured dots per area. |
| Checklist | B58 | `circle-list` with `markers: "check"`, `background: "white"` | |
| Text on navy | B53 to B56, B59 | `content-dark` | Bold role plus light subtitle in the title ("Product Management Mobile Product Review"), numbered points. |
| Text on gradient | B15, B52 | `content-glow`, or `content-gradient` for the violet field | |
| Personas row | B33, D17 | `people` | Photo, name, role, one-line quote, status band at the bottom. |
| Persona detail | B34, B35 | `split` | Emoji-marked bullets on the light half, a portrait on the other. |
| Phone screens | B49 to B51, C32, D35 | `mobile`, or `image` with several phones | C32 labels each bug with a blue chip under the phone. |
| Timeline | B11 | `picture` or `image` (build the Gantt in Figma, export it) | Months across, milestones down, outputs on the right. |
| Flow / sankey | B30, B31 | `image` | B31 adds the human cost: "45 minutes · Logged out 10 times · Unable to complete flow". |
| Keyboard shortcut visual | C48 | `showcase` (the case, the keys, the sources) | |
| Principle | C49, D39 | `slogan` (the flag button and the slogan, word for word) | |
| Thank you | A39, B61, C50, D40 | `thanks` | Subtitle = team name. |

## Live moments (comedic relief, questions, reveals)

The research deck (B) is the reference for keeping a room awake: one live moment every three to five slides. When and how to write them is in the presentation-writer skill (`references/rhythm.md`).

| Moment | Examples | Layout |
|---|---|---|
| Meme with a question | B03 (cat: "Should I follow the data or my instincts?" + "How many times have you made a product decision based on assumptions?") | `meme` |
| Meme with one line | B07 ("This is what we were asking ourselves about our mobile users." + "Who are you?"), B14 ("Here's what it felt like connecting all the data") | `split` |
| Full-bleed meme | B09 ("Yeah... I'm gonna need more data"), B13 ("Data, data everywhere") | `picture` |
| Show of hands | B06 ("🎤 Who here has used our mobile app in the last month?") | `question` with `serif: true` |
| Poll, then reveal | B16 (A/B/C/D) → B17 ("The answer is... all of them. But not equally.") | `circle-list` (letters) → `statement` |
| Tease, then proof | B19 (three film posters: "What do Suicide Squad, Sex and the City, and Bad Boys II have in common?") → B20 (Perception vs. Reality Gap ratings) | `split` or `image` → `stats` or `image` |
| Aphorism | B21 ("Don't look at what people say, look at what they do.") | `question` with `serif: true` |
| Set-up question | B32 ("But who are these users?") | `question-circle` |
| Check-in | B43 ("Questions about the findings before we move on?") | `statement` |
| Twist | B47 ("⚠ And a third factor: key accounts...") | `statement` |

## Details worth copying

- Chips: small rounded labels in blue (`#2463EB`) or ice (`#D5ECFF`) with 14 to 20 px uppercase or title-case text, always above the screenshot they label.
- Links are underlined words in the text colour ("Deployment Plan", "Confluence Analysis", "Gainsight PX Mapper", "Satisfaction Survey – Confluence"), never bare URLs, except the figma.site link under a live prototype.
- Notes and sources sit at the bottom of the text column in 20 px Noto Sans: "Note: ...", "Source: ...".
- Emoji mark list items in the research deck (📊 ✗ 🔴 🟠 🟡 🟢) and subtitles in the template (🔍 🍽). They are rarely used in quarterlies.
- Customer names: the decks quote hotels by name. Fine inside Shiji; remove them for any external audience.
