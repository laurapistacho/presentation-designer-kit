---
name: figma-slides-builder
description: Builds Shiji product and design presentations as native Figma Slides files (.fig, opened by dragging into the Figma file browser) in the Day & Night look of the presentation-brand skill - 28 layouts, aurora and horizon gradients as real Figma gradients, brand colours as variables, speaker notes, transitions and grid rows per section. Previews and fit-checks every slide, checks the file, and exports PowerPoint (.pptx) when someone needs it. Use when asked for a presentation, slides, a deck, Figma Slides, "build the deck", a quarterly, design update or research deck, component update slides, or to turn a deck spec or outline into slides. Pair with presentation-writer for the words and presentation-brand for the look.
---

# Figma Slides builder

Builds decks the design team opens in **Figma Slides** and keeps editing. The look (colours, gradients, type, themes) comes from the **presentation-brand** skill: `assets/tokens.json` there is read on every build, so the brand has one source. The words come from the **presentation-writer** skill as a deck spec (`deck.json`). Figma Slides is the target; PowerPoint is a by-product.

| Output | File | Use it for |
|---|---|---|
| Figma Slides | `<Name>.fig` | The deliverable. Drag it into the Figma file browser and it opens as a Slides file. |
| Preview | `preview/` | Your check before handing over: one PNG per slide, contact sheets, fit report, a browser version. |
| PowerPoint | `<Name>.pptx` | Only when asked, for people outside Figma. |

**Write `.fig`, not `.deck`.** Figma's file browser imports `.fig` and `.jam` files by drag and drop and refuses the `.deck` extension ("Drop .fig or .jam files into the file browser"). The content is the same Figma Slides file; the `.fig` name is what gets it through the door.

## Where things are

All paths are relative to the kit folder (the folder that holds `.kiro/`, `template/`, `library/` and `decks/`). Scripts need Python 3.9+ and Google Chrome (Chrome measures text and draws the preview). `setup/check_setup.py` checks a computer.

| Path | What |
|---|---|
| `.kiro/skills/presentation-brand/assets/tokens.json` | The look: colours, gradients, type scale, themes. |
| `.kiro/skills/figma-slides-builder/scripts/layouts.py` | The 28 layouts. |
| `template/Product Presentation Template.deck` | The file skeleton every build starts from: Slides document, the Shiji logo component, icons, the colour collection (renamed and re-valued to the brand). Its old slides are not used. |
| `examples/day-night-template/` | One slide per layout with sample content; its built `.fig` is the team's template to import into Figma. |
| `decks/<deck-slug>/` | One folder per deck: `deck.json`, `img/` with screenshots, the built `.fig`, `preview/`. |
| `library/index.html` | Every layout, then the previous template and four of the team's decks. |

## Workflow

1. **One folder per deck:** `decks/<deck-slug>/` (kebab case: `design-updates-q4-2026`). Screenshots in `decks/<deck-slug>/img/`, at 2x.
2. **Get the spec.** The writer's `deck.json`, or write one with `references/deck-spec.md` and `references/layouts.md`. List the layouts: `python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --layouts`.
3. **Build with a preview:**
   ```
   python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py decks/<slug>/deck.json --out "decks/<slug>/<File name>.fig" --preview decks/<slug>/preview
   ```
4. **Look before you hand over.** Open `preview/contact-sheet*.png` (read the images) and read the `fit_issues` and `warnings` the build prints (also in `preview/report.json`). They name the slide, the layer and the problem: text taller than its box or than its space, past the slide edge, into the bottom margin, over the logo, overlapping text. Fix by cutting words, splitting the slide or picking a roomier layout (`"split": 50` widens the text column of `content`). Rebuild. Stop after two rounds and tell the user what is still tight. Then run the brand skill's visual check.
5. **File check:** `python3 .kiro/skills/figma-slides-builder/scripts/check_deck.py "decks/<slug>/<File name>.fig"` must report no errors. If it does, do not hand the file over: report them.
6. **Hand over with the import steps** (`references/figma-slides.md`):
   - Drag the `.fig` file into the **Figma file browser** (the Drafts or a project page, not an open file), or use **Import** there. It opens as a new Figma Slides file; move it to the team project.
   - Then, in Figma: insert live prototypes where a slide says "Live prototype", swap still images for GIFs, add polls where the notes say so, check presenter notes.
7. **PowerPoint, only when asked.** Once the deck is in Figma, **File > Export > PowerPoint** is the first choice. Without a Figma round trip:
   ```
   python3 .kiro/skills/figma-slides-builder/scripts/deck_to_pptx.py "decks/<slug>/<File name>.fig" "decks/<slug>/<File name>.pptx" --preview=decks/<slug>/pptx-preview
   ```
   Text, shapes, photos and notes stay editable; gradients become pictures. Check the preview like step 4.

Report back with the paths of the `.fig` (and `.pptx`), the slide count, fit issues left, and what the designer still has to do in Figma.

## What the build writes

| Feature | In `deck.json` | In Figma |
|---|---|---|
| Day & Night look | per layout; `"theme": "day" \| "night" \| "blue"` to switch a slide | Native gradients, brand colours as variables ("Shiji Day & Night" collection), auto layout frames for text columns, lists, cards and buttons |
| Highlight | `==word==` in any text, one per slide | A green (night) or Reviewpro Blue (day) text run |
| Speaker notes | `notes` on any slide | Presenter view, and the PowerPoint export |
| Transitions | `transition` for the deck or per slide: `none` (default), `dissolve`, `smart-animate`, `slide-from-right`, `push-from-right`, `move-from-right` and the other directions; `transition_duration` (seconds), `easing` (`ease-out`, `ease-in`, `ease-in-out`, `linear`, `gentle`) | Slide > Transition |
| Auto-advance | `advance_after` (seconds) | Transition timing "After delay" |
| Grid rows | `grid`: `sections` (default: a new row at every `section` and `section-flat`) or `single`; `new_row: true` forces a break | The rows of the slide grid |
| Skipped slides, names | `skip: true`, `name` | Slide > Skip slide, the grid label |

Not possible from a file (Figma creates them only in the editor): polls, alignment scales, live prototype embeds, YouTube, facepiles, object animations. The build leaves a placeholder and the notes say what to insert.

## Layouts

`references/layouts.md` lists all 28 with their default theme and fields, and how to pick. Short version: covers (`cover`, `cover-navy`, `cover-center`) and `thanks`; structure (`index`, `section`, `section-flat`, `topic`); work (`content`, `image`, `compare`, `mobile`, `intro`); points (`statement`, `question`, `quote`, `stats`, `columns`, `icons`); voices (`quote-cards`, `quotes`, `people`); text only (`content-dark`, `content-glow`); pictures and relief (`split`, `picture`, `meme`, `circle-list`).

When nothing fits, use the closest layout and put the change in the notes as "Designer: ...". Never hand-edit a built file: every change goes through the spec and `build_deck.py`.

## Reading other Figma Slides files

Figma's API cannot read the layers of a Slides file, but it renders it, and the slide grid is node `0:3` in every Slides file:

1. `download_figma_images` with `nodeId: "0:3"`, `pngScale: 0.1` (small, to find the slides).
2. Again with `pngScale` 0.3 to 0.5 (big, for the pictures; Figma caps renders at about 32 megapixels).
3. `python3 .kiro/skills/figma-slides-builder/scripts/figma_grid_slices.py small.png big.png --out <folder> --prefix A` gives one PNG per slide and contact sheets.

For the words, ask for **File > Save local copy** in Figma and run `scripts/deck_text.py <file>` (it also reads `.pptx` and `deck.json`). Never claim to have read a Figma file you could not open.

## Troubleshooting

| Problem | What to do |
|---|---|
| Figma says "Drop .fig or .jam files into the file browser" | The file was a `.deck`, or it was dropped onto an open file. Use the `.fig`, and drop it on the file browser (Drafts or a project). |
| Figma refuses the `.fig` | Run `check_deck.py` and send the result to the kit maintainer. Meanwhile build the `.pptx` and import it into Figma Slides. |
| "Google Chrome was not found" | Install Chrome, or set `CHROME=/path/to/chrome`. |
| "This file was saved by Figma with zstd compression" | Reading a deck saved by Figma (for a review) needs the zstd tool: `brew install zstd`. Without it, export the deck from Figma as PowerPoint and run `deck_text.py` on the `.pptx`. Building does not need the tool. If the template itself fails to read, `template/decoded/` is missing or older than the template: see the `kit-maintenance` steering file. |
| Preview fonts look wrong | The fonts are not installed and the web fallback was blocked. Figma is unaffected. `setup/check_setup.py` lists what is missing. |
| Text slightly off in Figma | The preview approximates Figma's text layout. Text columns are auto layout frames, so Figma reflows them; shorten the copy if a block runs long. |
| A template layer is missing | The template file changed. `build_deck.py --check-template` lists the ids; see the `kit-maintenance` steering file. |

## Checklist before delivering

- [ ] Built with `build_deck.py` into `decks/<slug>/` as a `.fig`, no hand edits.
- [ ] Contact sheets looked at; every fit issue and warning fixed or reported; the brand skill's visual check done.
- [ ] `check_deck.py` reports no errors.
- [ ] Every number and quote comes from the user's sources; no `[TBD — Requires Input]` left, or each one flagged to the user.
- [ ] Speaker notes on content slides; what to finish in Figma is in the notes.
- [ ] Import steps and the Figma to-do list given to the user.
