---
name: figma-slides-builder
description: Builds Shiji product and design presentations as native Figma Slides files (.fig, opened by dragging into the Figma file browser) from the official Figma Slides template "00 Day & Night template" - its 40 layouts, text linked to its text styles, colours bound to its Slides theme, the linked logo and icons, real gradients, videos, speaker notes, transitions and named grid rows per section. Previews and fit-checks every slide, checks the file, and exports PowerPoint (.pptx) when someone needs it. Use when asked for a presentation, slides, a deck, Figma Slides, "build the deck", a quarterly, design update or research deck, component update slides, or to turn a deck spec or outline into slides. Pair with presentation-writer for the words and presentation-brand for the look.
---

# Figma Slides builder

Builds decks the design team opens in **Figma Slides** and keeps editing. Every deck is built on the **official template, "00 Day & Night template"** (https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4, saved locally in `template/`): its 40 layouts, its text styles, its theme colours, its linked logo and icons. The look as numbers (colours, gradients, type) comes from the **presentation-brand** skill's `assets/tokens.json`, which matches the template's styles exactly. The words come from the **presentation-writer** skill as a deck spec (`deck.json`). Figma Slides is the target; PowerPoint is a by-product.

| Output | File | Use it for |
|---|---|---|
| Figma Slides | `<Name>.fig` | The deliverable. Drag it into the Figma file browser and it opens as a Slides file. |
| Preview | `preview/` | Your check before handing over: one PNG per slide, contact sheets, fit report, a browser version. |
| PowerPoint | `<Name>.pptx` | Only when asked, for people outside Figma. |

**Write `.fig`, not `.deck`.** Figma's file browser imports `.fig` and `.jam` files by drag and drop and refuses the `.deck` extension ("Drop .fig or .jam files into the file browser"). The content is the same Figma Slides file; the `.fig` name is what gets it through the door.

## Where things are

All paths are relative to the kit folder (the folder that holds `.kiro/`, `template/`, `library/` and `decks/`). Scripts need Python 3.9+ and Google Chrome (Chrome measures text and draws the preview). `setup/check_setup.py` checks a computer.

| Path | What |
|---|---|
| `.kiro/skills/presentation-brand/assets/tokens.json` | The look: colours, gradients, type scale, themes. |
| `.kiro/skills/figma-slides-builder/scripts/layouts.py` | The 40 layouts, in the template's order. |
| `template/Day & Night template.deck` | The official template, saved from Figma: Slides theme, text styles, colour collections, the linked logo and icons, and the artwork the legacy and component layouts copy. Its slides are not copied into decks. `references/template-spec.md` lists what the build takes. |
| `examples/day-night-template/` | The official template rebuilt by the kit, one slide per layout with sample content; its built `.fig` imports into Figma. |
| `decks/<deck-slug>/` | One folder per deck: `deck.json`, `img/` with screenshots, the built `.fig`, `preview/`. |
| `library/index.html` | Every layout, then the previous template and four of the team's decks. |

## Workflow

1. **One folder per deck:** `decks/<deck-slug>/` (kebab case: `design-updates-q4-2026`). Screenshots in `decks/<deck-slug>/img/`, at 2x.
2. **Get the spec.** The writer's `deck.json`, or write one with `references/deck-spec.md` and `references/layouts.md`. List the layouts: `python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py --layouts`.
3. **Build with a preview:**
   ```
   python3 .kiro/skills/figma-slides-builder/scripts/build_deck.py decks/<slug>/deck.json --out "decks/<slug>/<File name>.fig" --preview decks/<slug>/preview
   ```
4. **Look before you hand over.** Open `preview/contact-sheet*.png` (read the images) and read the `fit_issues` and `warnings` the build prints (also in `preview/report.json`). They name the slide, the layer and the problem: text taller than its box or than its space, past the slide edge, into the bottom margin, over the logo, overlapping text. Fix by cutting words, splitting the slide or picking a roomier layout (`"split": 50` widens the text column of `content`). Rebuild. Stop after two rounds and tell the user what is still tight. Then run the brand skill's visual check.
5. **File check:** `python3 .kiro/skills/figma-slides-builder/scripts/check_deck.py "decks/<slug>/<File name>.fig"` must report no errors. If it does, do not hand the file over: report them.
6. **Hand over with the import steps** (`references/figma-slides.md`):
   - Drag the `.fig` file into the **Figma file browser** (the Drafts or a project page, not an open file), or use **Import** there. It opens as a new Figma Slides file; move it to the team project.
   - Then, in Figma: insert live prototypes where a slide says "Live prototype", swap still images for GIFs, add polls where the notes say so, check presenter notes.
7. **PowerPoint, only when asked.** Once the deck is in Figma, **File > Export > PowerPoint** is the first choice. Without a Figma round trip:
   ```
   python3 .kiro/skills/figma-slides-builder/scripts/deck_to_pptx.py "decks/<slug>/<File name>.fig" "decks/<slug>/<File name>.pptx" --preview=decks/<slug>/pptx-preview
   ```
   Text, shapes, photos and notes stay editable; gradients become pictures. Check the preview like step 4.

Report back with the paths of the `.fig` (and `.pptx`), the slide count, fit issues left, and what the designer still has to do in Figma.

## What the build writes

| Feature | In `deck.json` | In Figma |
|---|---|---|
| Day & Night look | per layout; `"theme": "day" \| "night" \| "blue"` to switch a slide | Native gradients, colours bound to the Slides theme ("Shiji / Presentation theme") and the "Shiji Day & Night" palette, auto layout frames for text columns, lists, cards and buttons |
| Text styles | per type token | Every text layer linked to the template's style ("Shiji / Headings / Slide title"...) |
| Layer names | automatic | The template's names: `Brand / Shiji logo · linked`, `Media / Screenshot · replace image fill`... |
| Videos | `video` (and `poster`) on `walkthrough` | A Figma Slides video that plays when presenting |
| Highlight | `==word==` in any text, one per slide | A green (night) or Reviewpro Blue (day) text run |
| Speaker notes | `notes` on any slide | Presenter view, and the PowerPoint export |
| Transitions | `transition` for the deck or per slide: `none` (default), `dissolve`, `smart-animate`, `slide-from-right`, `push-from-right`, `move-from-right` and the other directions; `transition_duration` (seconds), `easing` (`ease-out`, `ease-in`, `ease-in-out`, `linear`, `gentle`) | Slide > Transition |
| Auto-advance | `advance_after` (seconds) | Transition timing "After delay" |
| Grid rows | `grid`: `sections` (default: a new row at every section divider, named after it) or `single`; `row: "03 · Product & comparisons"` starts a named row; `new_row: true` forces a break | The named rows of the slide grid |
| Skipped slides, names | `skip: true`, `name` | Slide > Skip slide, the grid label |

Not possible from a file (Figma creates them only in the editor): polls, alignment scales, live prototype embeds, YouTube, facepiles, object animations. The build leaves a placeholder and the notes say what to insert.

## Layouts

`references/layouts.md` lists all 40 with their slide in the Figma template, default theme and fields, and how to pick. Short version: covers (`cover`, `cover-navy`, `cover-center`, `cover-gradient`) and `thanks`; structure (`index`, `section`, `section-flat`, `section-number`, `topic`, `composition`); work (`content`, `image`, `walkthrough`, `compare`, `compare-laptop`, `mobile`, `variants`, `anatomy`, `showcase`, `collage`, `intro`); points (`statement`, `question`, `question-circle`, `quote`, `stats`, `columns`, `icons`, `slogan`); voices (`quote-cards`, `quotes`, `people`); text only (`content-dark`, `content-glow`, `content-gradient`); pictures and relief (`split`, `picture`, `meme`, `circle-list`). The legacy look (`cover-gradient`, `section-number`, `question-circle`, `content-gradient`) is an accent: about one per deck.

When nothing fits, use the closest layout and put the change in the notes as "Designer: ...". Never hand-edit a built file: every change goes through the spec and `build_deck.py`.

## Reading other Figma Slides files

Figma's API cannot read the layers of a Slides file, but it renders it, and the slide grid is node `0:3` in every Slides file:

1. `download_figma_images` with `nodeId: "0:3"`, `pngScale: 0.1` (small, to find the slides).
2. Again with `pngScale` 0.3 to 0.5 (big, for the pictures; Figma caps renders at about 32 megapixels).
3. `python3 .kiro/skills/figma-slides-builder/scripts/figma_grid_slices.py small.png big.png --out <folder> --prefix A` gives one PNG per slide and contact sheets.

When the layer ids are known (from a local copy), render single slides instead: `download_figma_images` with each slide's id at `pngScale` 0.5. That is how the official template is compared with the kit's rebuild of it.

For the words, ask for **File > Save local copy** in Figma and run `scripts/deck_text.py <file>` (it also reads `.pptx` and `deck.json`). Never claim to have read a Figma file you could not open.

## Troubleshooting

| Problem | What to do |
|---|---|
| Figma says "Drop .fig or .jam files into the file browser" | The file was a `.deck`, or it was dropped onto an open file. Use the `.fig`, and drop it on the file browser (Drafts or a project). |
| Figma refuses the `.fig` | Run `check_deck.py` and send the result to the kit maintainer. Meanwhile build the `.pptx` and import it into Figma Slides. |
| "Google Chrome was not found" | Install Chrome, or set `CHROME=/path/to/chrome`. |
| "This file was saved by Figma with zstd compression" | Reading a deck saved by Figma (for a review) needs the zstd tool: `brew install zstd`. Without it, export the deck from Figma as PowerPoint and run `deck_text.py` on the `.pptx`. Building does not need the tool. If the template itself fails to read, `template/decoded/` is missing or older than the template: see the `kit-maintenance` steering file. |
| Preview fonts look wrong | The fonts are not installed and the web fallback was blocked. Figma is unaffected. `setup/check_setup.py` lists what is missing. |
| Text slightly off in Figma | The preview approximates Figma's text layout. Text columns are auto layout frames, so Figma reflows them; shorten the copy if a block runs long. |
| A template layer is missing | The template file changed. `build_deck.py --check-template` lists the ids; see the `kit-maintenance` steering file. |
| "Text style ... is not in the template" | Someone renamed a style in the Figma template. Rename it back, or update `text_styles` in the brand tokens (`kit-maintenance`). The text is built unlinked meanwhile. |
| The build lists `text_without_style` | Text in a size the template has no style for (a custom `size`). It looks right, but is not linked to a style. |

## Checklist before delivering

- [ ] Built with `build_deck.py` into `decks/<slug>/` as a `.fig`, no hand edits.
- [ ] Contact sheets looked at; every fit issue and warning fixed or reported; the brand skill's visual check done.
- [ ] `check_deck.py` reports no errors.
- [ ] Every number and quote comes from the user's sources; no `[TBD — Requires Input]` left, or each one flagged to the user.
- [ ] Speaker notes on content slides; what to finish in Figma is in the notes.
- [ ] Import steps and the Figma to-do list given to the user.
