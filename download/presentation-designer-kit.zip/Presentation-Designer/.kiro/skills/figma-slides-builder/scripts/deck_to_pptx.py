#!/usr/bin/env python3
"""Convert a Figma Slides file (.fig or .deck) into a PowerPoint `.pptx` file.

    python3 deck_to_pptx.py deck.fig out.pptx

What stays editable in PowerPoint: every text box (fonts, sizes, colours, bullets, links), plain
rectangles and circles, screenshots and photos, speaker notes. What becomes a picture: gradients,
blurred glows, the Shiji logo, icons and other vector artwork (PowerPoint cannot draw them the way
Figma does). Pictures are rendered with headless Chrome, so Chrome must be installed.

Fonts are referenced by name (Shiji Day Sans Aeonik, Shiji Night Serif Reckless Neue, Lato, Noto
Sans). PowerPoint shows them correctly on computers that have the fonts installed.

When the deck lives in Figma already, Figma's own File > Export > PowerPoint is the first choice.
Use this script when there is no Figma round trip (for example a deck built by build_deck.py).
"""
import html
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from xml.sax.saxutils import escape

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import figdeck  # noqa: E402
import render_deck as R  # noqa: E402

EMU = 6350  # 1920 px = 12,192,000 EMU (13.333 in)
SW, SH = 1920 * EMU, 1080 * EMU

# Figma family + style -> PowerPoint typeface + bold flag (desktop family names of the font files).
TYPEFACES = {
    'Shiji Day Sans Aeonik': {'Regular': ('Shiji Day Sans Aeonik', False), 'Bold': ('Shiji Day Sans Aeonik', True),
                              'Black': ('Shiji Day Sans Aeonik Black', False), 'Medium': ('Shiji Day Sans Aeonik Medium', False),
                              'Light': ('Shiji Day Sans Aeonik Light', False), 'SemiBold': ('Shiji Day Sans Aeonik SemiBold', False),
                              'Thin': ('Shiji Day Sans Aeonik Thin', False), 'Air': ('Shiji Day Sans Aeonik Air', False)},
    'Lato': {'Regular': ('Lato', False), 'Bold': ('Lato', True), 'Black': ('Lato Black', False), 'Light': ('Lato Light', False),
             'Thin': ('Lato Thin', False)},
    'Noto Sans': {'Regular': ('Noto Sans', False), 'Medium': ('Noto Sans Medium', False), 'Bold': ('Noto Sans', True)},
    'Shiji Night Serif Reckless Neue': {'Regular': ('Shiji Night Serif Reckless Neue', False),
                                        'Heavy': ('Shiji Night Serif Reckless Neue', True),
                                        'Bold': ('Shiji Night Serif Reckless Neue', True)},
}


def typeface(font_name):
    fam = (font_name or {}).get('family', 'Lato')
    style = (font_name or {}).get('style', 'Regular')
    italic = 'Italic' in style
    base = style.replace('Italic', '').strip() or 'Regular'
    t = TYPEFACES.get(fam, {}).get(base)
    if t:
        return t[0], t[1], italic
    return fam, base in ('Bold', 'Black', 'Heavy', 'ExtraBold', 'SemiBold'), italic


def emu(px):
    return int(round(px * EMU))


def hex6(c):
    return '%02X%02X%02X' % tuple(max(0, min(255, round(c.get(k, 0) * 255))) for k in 'rgb')


def is_axis_aligned(m):
    return abs(m[1]) < 1e-4 and abs(m[3]) < 1e-4 and m[0] > 0 and m[4] > 0


# --------------------------------------------------------------------------- classify the tree
class Item:
    def __init__(self, kind, node, m, opacity, ctx=None):
        self.kind, self.node, self.m, self.opacity, self.ctx = kind, node, m, opacity, ctx


def solid_only(paints):
    vis = [p for p in paints or [] if p.get('visible', True)]
    return all(p.get('type') == 'SOLID' for p in vis), vis


def walk(d, n, parent_m, parent_op, items):
    if not n.get('visible', True):
        return
    t = n.get('type')
    m = R.mul(parent_m, R.mat(n.get('transform')))
    op = parent_op * n.get('opacity', 1.0)
    effects = [e for e in n.get('effects') or [] if e.get('visible', True)]
    blur = any(e.get('type') in ('FOREGROUND_BLUR', 'BACKGROUND_BLUR') for e in effects)
    if t == 'TEXT':
        items.append(Item('text' if is_axis_aligned(m) else 'raster', n, m, op))
        return
    if t in ('INSTANCE', 'VECTOR', 'SHAPE_WITH_TEXT', 'CONNECTOR', 'LINE', 'STAR', 'REGULAR_POLYGON', 'BOOLEAN_OPERATION'):
        items.append(Item('raster', n, m, op))
        return
    fills_ok, fills = solid_only(n.get('fillPaints'))
    images = [p for p in fills if p.get('type') == 'IMAGE']
    if t in ('RECTANGLE', 'ROUNDED_RECTANGLE', 'ELLIPSE'):
        if blur or not is_axis_aligned(m) or n.get('dashPattern'):  # dashed and dotted outlines: a picture
            items.append(Item('raster', n, m, op))
        elif images and len(fills) == len(images) and t != 'ELLIPSE':
            items.append(Item('picture', n, m, op))
        elif images or not fills_ok:
            items.append(Item('raster', n, m, op))
        else:
            items.append(Item('shape', n, m, op))
        return
    if t in ('FRAME', 'GROUP', 'SECTION', 'MODULE', 'SYMBOL'):
        if fills:
            if fills_ok and is_axis_aligned(m) and not blur:
                items.append(Item('shape', n, m, op))
            else:
                items.append(Item('raster-self', n, m, op))
        for c in d.children(n):
            walk(d, c, m, op, items)
        return
    items.append(Item('raster', n, m, op))


# --------------------------------------------------------------------------- text
def text_xml(d, r, n, m, op, rels, bg=None):
    td = n.get('textData') or {}
    chars = td.get('characters', '')
    ids = td.get('characterStyleIDs') or []
    table = {o['styleID']: o for o in td.get('styleOverrideTable') or []}
    base = dict(n)
    st = r.d_style(n.get('styleIdForText'))
    if st:
        base.update({k: st[k] for k in R.TEXT_STYLE_KEYS if k in st})
    merged = {}
    for sid, o in table.items():
        p = {}
        st2 = r.d_style(o.get('styleIdForText'))
        if st2:
            p.update({k: st2[k] for k in R.TEXT_STYLE_KEYS if k in st2})
        p.update({k: v for k, v in o.items() if k not in ('styleID', 'styleIdForText')})
        merged[sid] = p

    def get(sid, k, dflt=None):
        o = merged.get(sid)
        if o and k in o:
            return o[k]
        return base.get(k, dflt)

    x, y = m[2], m[5]
    w, h = n['size']['x'] * m[0], n['size']['y'] * m[4]
    resize = n.get('textAutoResize', 'NONE')
    anchor = {'TOP': 't', 'CENTER': 'ctr', 'BOTTOM': 'b'}.get(n.get('textAlignVertical', 'TOP'), 't')
    algn = {'LEFT': 'l', 'CENTER': 'ctr', 'RIGHT': 'r', 'JUSTIFIED': 'just'}.get(n.get('textAlignHorizontal', 'LEFT'), 'l')
    wrap = 'none' if resize == 'WIDTH_AND_HEIGHT' else 'square'
    if resize == 'WIDTH_AND_HEIGHT':  # PowerPoint measures a little wider than Figma: give auto-width boxes room
        extra = w * 0.12 + 8
        align_ = n.get('textAlignHorizontal', 'LEFT')
        x -= {'CENTER': extra / 2, 'RIGHT': extra}.get(align_, 0)
        w += extra
    lines = td.get('lines') or []
    paras, start = [], 0
    for i, ch in enumerate(chars + '\n'):
        if ch == '\n':
            paras.append((start, i))
            start = i + 1
    out = []
    ord_n = None  # running number of the ordered list in this box
    literal = False
    for pi, (a, b) in enumerate(paras):
        info = lines[pi] if pi < len(lines) else {}
        lt = info.get('lineType', 'PLAIN')
        sid0 = ids[a] if a < len(ids) else 0
        size0 = get(sid0, 'fontSize', 24.0)
        lh = R.figma_line_height(get(sid0, 'lineHeight'), size0, get(sid0, 'fontName'))
        ppr = f'<a:pPr algn="{algn}"'
        bullet = '<a:buNone/>'
        prefix = ''
        if lt in ('UNORDERED_LIST', 'ORDERED_LIST'):
            ind = emu(size0 * 1.25)
            ppr += f' marL="{ind}" indent="-{ind}"'
            if lt == 'UNORDERED_LIST':
                bullet = '<a:buFont typeface="Arial"/><a:buChar char="•"/>'
                ord_n = None
            else:
                if ord_n is None:
                    ord_n = info.get('listStartOffset', 0) or 0
                    # A list that continues from another text box: Keynote, Quick Look and Google Slides
                    # ignore startAt, so write the numbers as text there.
                    literal = ord_n > 0
                ord_n += 1
                if literal:
                    prefix = f'{ord_n}.\t'
                else:
                    bullet = f'<a:buFont typeface="+mj-lt"/><a:buAutoNum type="arabicPeriod" startAt="{ord_n if ord_n == 1 else 1}"/>'
        else:
            ord_n = None
        ppr += '>'
        if lh:
            ppr += f'<a:lnSpc><a:spcPts val="{int(round(lh * 50))}"/></a:lnSpc>'  # px -> 1/100 pt
        para_sp = base.get('paragraphSpacing') or 0
        if para_sp and pi < len(paras) - 1:
            ppr += f'<a:spcAft><a:spcPts val="{int(round(para_sp * 0.5 * 100))}"/></a:spcAft>'
        ppr += bullet + '</a:pPr>'
        runs = []
        if prefix:
            runs.append(run_xml(get, ids[a] if a < len(ids) else 0, prefix, op, rels, bg))
        k = a
        while k < b:
            sid = ids[k] if k < len(ids) else 0
            j = k
            while j < b and (ids[j] if j < len(ids) else 0) == sid:
                j += 1
            runs.append(run_xml(get, sid, chars[k:j], op, rels, bg))
            k = j
        end_size = int(round(size0 * 0.5 * 100))
        out.append(f'<a:p>{ppr}{"".join(runs)}<a:endParaRPr lang="en-US" sz="{end_size}" dirty="0"/></a:p>')
    body = (f'<p:txBody><a:bodyPr wrap="{wrap}" lIns="0" tIns="0" rIns="0" bIns="0" rtlCol="0" anchor="{anchor}">'
            f'<a:noAutofit/></a:bodyPr><a:lstStyle/>{"".join(out)}</p:txBody>')
    return x, y, max(w, 1), max(h, 1), body


def run_xml(get, sid, text, op, rels, bg=None):
    size = get(sid, 'fontSize', 24.0)
    face, bold, italic = typeface(get(sid, 'fontName'))
    attrs = f'lang="en-US" sz="{int(round(size * 0.5 * 100))}"'
    if bold:
        attrs += ' b="1"'
    if italic:
        attrs += ' i="1"'
    ls = get(sid, 'letterSpacing') or {}
    if ls.get('value'):
        v = ls['value'] * size / 100.0 if ls.get('units') == 'PERCENT' else ls['value']
        attrs += f' spc="{int(round(v * 0.5 * 100))}"'
    deco = get(sid, 'textDecoration', 'NONE')
    if deco == 'UNDERLINE':
        attrs += ' u="sng"'
    elif deco == 'STRIKETHROUGH':
        attrs += ' strike="sngStrike"'
    if get(sid, 'textCase', 'ORIGINAL') == 'UPPER':
        attrs += ' cap="all"'
    fill = ''
    fills = [p for p in get(sid, 'fillPaints') or [] if p.get('visible', True)]
    if fills:
        p = fills[-1]
        c = p.get('color') or (p.get('stops') or [{}])[0].get('color') or {'r': 0, 'g': 0, 'b': 0, 'a': 1}
        alpha = c.get('a', 1.0) * p.get('opacity', 1.0) * op
        if alpha < 0.999 and bg:
            # Faded text (the giant section numbers): mix with the slide colour instead of using
            # transparency, which several viewers ignore.
            c = {k: c.get(k, 0) * alpha + bg[k] * (1 - alpha) for k in 'rgb'}
            alpha = 1.0
        fill = f'<a:solidFill><a:srgbClr val="{hex6(c)}">' + (f'<a:alpha val="{int(alpha * 100000)}"/>' if alpha < 0.999 else '') + '</a:srgbClr></a:solidFill>'
    link = ''
    hl = get(sid, 'hyperlink')
    if hl and hl.get('url'):
        rid = rels.add('http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink', hl['url'], external=True)
        link = f'<a:hlinkClick r:id="{rid}"/>'
    fonts = f'<a:latin typeface="{escape(face)}"/><a:ea typeface="{escape(face)}"/><a:cs typeface="{escape(face)}"/>'
    rpr = f'<a:rPr {attrs} dirty="0">{fill}{fonts}{link}</a:rPr>'
    pieces = text.split('\u2028')  # Figma soft line break -> PowerPoint line break
    return f'<a:br>{rpr}</a:br>'.join(f'<a:r>{rpr}<a:t>{escape(t)}</a:t></a:r>' for t in pieces)


# --------------------------------------------------------------------------- package
class Rels:
    def __init__(self):
        self.items = []

    def add(self, typ, target, external=False):
        for rid, t, tg, ext in self.items:
            if t == typ and tg == target:
                return rid
        rid = f'rId{len(self.items) + 1}'
        self.items.append((rid, typ, target, external))
        return rid

    def xml(self):
        rows = ''.join(f'<Relationship Id="{rid}" Type="{t}" Target="{escape(tg)}"' + (' TargetMode="External"' if ext else '') + '/>'
                       for rid, t, tg, ext in self.items)
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                f'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{rows}</Relationships>')


NS = ('xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
      'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"')
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'

THEME = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Shiji Product Presentation"><a:themeElements>
<a:clrScheme name="Shiji"><a:dk1><a:srgbClr val="111111"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="172256"/></a:dk2><a:lt2><a:srgbClr val="F1F9FF"/></a:lt2>
<a:accent1><a:srgbClr val="1F3A8A"/></a:accent1><a:accent2><a:srgbClr val="2463EB"/></a:accent2><a:accent3><a:srgbClr val="172256"/></a:accent3><a:accent4><a:srgbClr val="92C5FD"/></a:accent4>
<a:accent5><a:srgbClr val="D5ECFF"/></a:accent5><a:accent6><a:srgbClr val="0FFFAB"/></a:accent6><a:hlink><a:srgbClr val="2463EB"/></a:hlink><a:folHlink><a:srgbClr val="1F3A8A"/></a:folHlink></a:clrScheme>
<a:fontScheme name="Shiji"><a:majorFont><a:latin typeface="Shiji Day Sans Aeonik"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Lato"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>
<a:fmtScheme name="Office"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst>
<a:lnStyleLst><a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="12700"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln><a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst>
<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>
<a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme>
</a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>"""

MASTER = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldMaster {NS}><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>
<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>
<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>
<p:txStyles><p:titleStyle><a:lvl1pPr><a:defRPr sz="4400"><a:latin typeface="+mj-lt"/></a:defRPr></a:lvl1pPr></p:titleStyle><p:bodyStyle><a:lvl1pPr><a:defRPr sz="2400"><a:latin typeface="+mn-lt"/></a:defRPr></a:lvl1pPr></p:bodyStyle><p:otherStyle><a:lvl1pPr><a:defRPr sz="1800"/></a:lvl1pPr></p:otherStyle></p:txStyles></p:sldMaster>"""

LAYOUT = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sldLayout {NS} preserve="1"><p:cSld name="Blank"><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"""

NOTES_MASTER = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:notesMaster {NS}><p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>
<p:sp><p:nvSpPr><p:cNvPr id="2" name="Slide Image Placeholder 1"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldImg" idx="2"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="381000" y="685800"/><a:ext cx="6096000" cy="3429000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:sp>
<p:sp><p:nvSpPr><p:cNvPr id="3" name="Notes Placeholder 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" sz="quarter" idx="3"/></p:nvPr></p:nvSpPr><p:spPr><a:xfrm><a:off x="685800" y="4343400"/><a:ext cx="5486400" cy="4114800"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="en-US"/></a:p></p:txBody></p:sp>
</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:notesStyle><a:lvl1pPr marL="0" algn="l" defTabSz="914400" rtl="0" eaLnBrk="1" latinLnBrk="0" hangingPunct="1"><a:defRPr sz="1200" kern="1200"><a:solidFill><a:schemeClr val="tx1"/></a:solidFill><a:latin typeface="+mn-lt"/><a:ea typeface="+mn-ea"/><a:cs typeface="+mn-cs"/></a:defRPr></a:lvl1pPr></p:notesStyle></p:notesMaster>"""


def notes_xml(text, slide_no):
    paras = ''.join(f'<a:p><a:r><a:rPr lang="en-US" dirty="0"/><a:t>{escape(line)}</a:t></a:r></a:p>' if line else '<a:p><a:endParaRPr lang="en-US"/></a:p>'
                    for line in text.split('\n'))
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:notes {NS}><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>'
            f'<p:sp><p:nvSpPr><p:cNvPr id="2" name="Slide Image Placeholder 1"/><p:cNvSpPr><a:spLocks noGrp="1" noRot="1" noChangeAspect="1"/></p:cNvSpPr><p:nvPr><p:ph type="sldImg"/></p:nvPr></p:nvSpPr><p:spPr/></p:sp>'
            f'<p:sp><p:nvSpPr><p:cNvPr id="3" name="Notes Placeholder 2"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="body" idx="1"/></p:nvPr></p:nvSpPr><p:spPr/>'
            f'<p:txBody><a:bodyPr/><a:lstStyle/>{paras}</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>')


# --------------------------------------------------------------------------- rasters
def render_plates(d, r, jobs, work):
    """jobs: list of (key, [Item]) -> {key: png path}. One transparent 1920x1080 image per job."""
    out = {}
    per = 3  # three full-size plates per screenshot keeps Chrome's capture reliable
    for k in range(0, len(jobs), per):
        chunk = jobs[k:k + per]
        cells = []
        for key, items in chunk:
            bgc = 'transparent'
            if isinstance(items, tuple):
                items, bgc = items
            parts = []
            for it in items:
                outer = it.opacity / max(1e-6, it.node.get('opacity', 1.0))
                if it.kind == 'raster-self':
                    one = r.node_html(strip_children(it.node), None, f'p{key}', transform_override=it.m)
                else:
                    one = r.node_html(it.node, it.ctx, f'p{key}', transform_override=it.m)
                parts.append(f'<div style="position:absolute;inset:0;opacity:{outer:.4f}">{one}</div>' if outer < 0.999 else one)
            cells.append(f'<div class="cell"><section class="slide" style="background:{bgc}">{"".join(parts)}</section></div>')
        page = os.path.join(work, f'plates{k}.html')
        open(page, 'w').write(f'<!doctype html><html><head><meta charset="utf-8">{R.FONT_HEAD}<style>{R.PAGE_CSS}'
                              f'html,body{{background:transparent}}.cell{{width:1920px;height:1080px;overflow:hidden;position:relative;margin-left:1px}}</style></head>'
                              f'<body>{"".join(cells)}</body></html>')
        png = os.path.join(work, f'plates{k}.png')
        R.chrome(['--virtual-time-budget=15000', '--default-background-color=00000000', f'--window-size=1921,{1080 * len(chunk) + 1}',
                  f'--screenshot={png}', 'file://' + page])
        for j, (key, _) in enumerate(chunk):
            out[key] = (png, j * 1080)
    return out


def strip_children(node):
    node = dict(node)
    node['guid'] = None  # renderer only follows children of nodes with a guid
    return node


def trim_box(items):
    xs, ys = [], []
    for it in items:
        n = it.node
        w, h = (n.get('size') or {}).get('x', 0), (n.get('size') or {}).get('y', 0)
        pad = 0
        for e in n.get('effects') or []:
            if e.get('visible', True):
                pad = max(pad, e.get('radius', 0) * 1.5 + abs((e.get('offset') or {}).get('y', 0)))
        for (px, py) in ((0, 0), (w, 0), (0, h), (w, h)):
            X, Y = R.apply(it.m, px, py)
            xs += [X - pad, X + pad]
            ys += [Y - pad, Y + pad]
    x0, y0 = max(0, int(min(xs)) - 2), max(0, int(min(ys)) - 2)
    x1, y1 = min(1920, int(max(xs)) + 3), min(1080, int(max(ys)) + 3)
    return x0, y0, max(1, x1 - x0), max(1, y1 - y0)


# --------------------------------------------------------------------------- convert
def convert(deck_path, out_path):
    d = figdeck.Deck(deck_path)
    work = tempfile.mkdtemp(prefix='deck2pptx_')
    r = R.Renderer(d, image_dir=os.path.join(work, 'images'), image_url_prefix='file://' + os.path.join(work, 'images') + '/')
    slides = d.slides()
    media = {}
    files = {}
    plate_jobs, plans = [], []
    for si, s in enumerate(slides, 1):
        items = []
        for c in d.children(s):
            walk(d, c, [1, 0, 0, 0, 1, 0], 1.0, items)
        groups, cur = [], []
        for it in items:
            if it.kind.startswith('raster'):
                cur.append(it)
            else:
                if cur:
                    groups.append(('plate', cur))
                    cur = []
                groups.append(('item', it))
        if cur:
            groups.append(('plate', cur))
        bg_needs_plate = not solid_only(s.get('fillPaints'))[0]
        if bg_needs_plate:
            plate_jobs.append((f'{si}_bg', [Item('raster-self', s, [1, 0, 0, 0, 1, 0], 1.0)]))
        ok_bg, bg_fills = solid_only(s.get('fillPaints'))
        for gi, (kind, g) in enumerate(groups):
            if kind == 'plate':
                if gi == 0 and not bg_needs_plate and trim_box(g) == (0, 0, 1920, 1080):
                    color_ = '#' + hex6(bg_fills[-1]['color']) if bg_fills else '#FFFFFF'
                    plate_jobs.append((f'{si}_{gi}', (g, color_)))  # opaque: background baked in, saved as JPEG
                else:
                    plate_jobs.append((f'{si}_{gi}', g))
        plans.append((s, groups, bg_needs_plate))
    plates = render_plates(d, r, plate_jobs, work) if plate_jobs else {}

    def add_media(rels, path, ext):
        data = open(path, 'rb').read()
        name = media.get(data)
        if not name:
            name = f'image{len(media) + 1}.{ext}'
            media[data] = name
            files[f'ppt/media/{name}'] = data
        return rels.add(f'{REL}/image', f'../media/{name}')

    slide_entries = []
    for si, (s, groups, bg_plate) in enumerate(plans, 1):
        rels = Rels()
        rels.add(f'{REL}/slideLayout', '../slideLayouts/slideLayout1.xml')
        shapes = []
        sid = [2]

        def next_id():
            sid[0] += 1
            return sid[0]

        bg = '<p:bg><p:bgPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>'
        ok, fills = solid_only(s.get('fillPaints'))
        slide_bg = fills[-1]['color'] if ok and fills else {'r': 1, 'g': 1, 'b': 1}
        if ok and fills:
            bg = f'<p:bg><p:bgPr><a:solidFill><a:srgbClr val="{hex6(fills[-1]["color"])}"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>'
        if bg_plate:
            big, row = plates[f'{si}_bg']
            dst = os.path.join(work, f'plate_{si}_bg.png')
            R.crop(big, dst, 1, row, 1920, 1080)
            rid = add_media(rels, dst, 'png')
            shapes.append(pic_xml(next_id(), 'Background', rid, 0, 0, 1920, 1080))
        for gi, (kind, g) in enumerate(groups):
            if kind == 'plate':
                key = f'{si}_{gi}'
                x, y, w, h = trim_box(g)
                big, row = plates[key]
                cropped = os.path.join(work, f'plate_{key}.png')
                R.crop(big, cropped, 1 + x, row + y, w, h)
                ext = 'png'
                if gi == 0 and (x, y, w, h) == (0, 0, 1920, 1080) and not bg_plate:
                    jpg = cropped[:-4] + '.jpg'
                    subprocess.run(['sips', '-s', 'format', 'jpeg', '-s', 'formatOptions', '85', cropped, '--out', jpg], capture_output=True)
                    if os.path.exists(jpg):
                        cropped, ext = jpg, 'jpg'
                name = ', '.join(sorted(set(it.node.get('name', '') for it in g)))[:60]
                rid = add_media(rels, cropped, ext)
                shapes.append(pic_xml(next_id(), f'Artwork: {name}', rid, x, y, w, h))
                continue
            it = g
            n = it.node
            if it.kind == 'text':
                x, y, w, h, body = text_xml(d, r, n, it.m, it.opacity, rels, slide_bg)
                shapes.append(f'<p:sp><p:nvSpPr><p:cNvPr id="{next_id()}" name="{escape(n.get("name", "Text"))[:80]}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
                              f'<p:spPr><a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>{body}</p:sp>')
            elif it.kind == 'shape':
                shapes.append(shape_xml(next_id(), n, it.m, it.opacity))
            elif it.kind == 'picture':
                shapes.append(picture_fill_xml(next_id(), n, it.m, r, rels, add_media, work))
        notes = R.notes_text(s)
        if notes:
            rels.add(f'{REL}/notesSlide', f'../notesSlides/notesSlide{si}.xml')
            files[f'ppt/notesSlides/notesSlide{si}.xml'] = notes_xml(notes, si).encode()
            nrels = Rels()
            nrels.add(f'{REL}/notesMaster', '../notesMasters/notesMaster1.xml')
            nrels.add(f'{REL}/slide', f'../slides/slide{si}.xml')
            files[f'ppt/notesSlides/_rels/notesSlide{si}.xml.rels'] = nrels.xml().encode()
        xml = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld {NS}><p:cSld name="{escape(str(s.get("name", si)))}">{bg}<p:spTree>'
               f'<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
               f'{"".join(shapes)}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>')
        trans = pptx_transition(s)
        if trans:
            xml = xml.replace('</p:clrMapOvr></p:sld>', '</p:clrMapOvr>' + trans + '</p:sld>', 1)
        if s.get('isSkippedSlide'):
            xml = xml.replace('<p:sld ', '<p:sld show="0" ', 1)
        files[f'ppt/slides/slide{si}.xml'] = xml.encode()
        files[f'ppt/slides/_rels/slide{si}.xml.rels'] = rels.xml().encode()
        slide_entries.append(si)
    title = d.meta.get('file_name', 'Presentation')
    write_package(out_path, files, slide_entries, title, any('notesSlides' in k for k in files))
    shutil.rmtree(work, ignore_errors=True)
    convert.last = (files, slide_entries, title)
    return out_path


def preview(out_dir, size=960):
    """PNG of every slide as PowerPoint draws it, through macOS Quick Look (needs PowerPoint or Keynote installed)."""
    files, slides, title = convert.last
    os.makedirs(out_dir, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix='pptxql_')
    singles = []
    for i in slides:
        keep = {k: v for k, v in files.items() if not re.match(r'ppt/(slides|notesSlides)/(_rels/)?(slide|notesSlide)\d+\.xml(\.rels)?$', k)
                or re.search(rf'(slide|notesSlide){i}\.xml', k)}
        one = os.path.join(tmp, f'{i:02d}.pptx')
        write_package(one, keep, [i], title, False)
        singles.append(one)
    subprocess.run(['qlmanage', '-t', '-s', str(size), '-o', tmp] + singles, capture_output=True, timeout=600)
    pngs = []
    for one in singles:
        src = one + '.png'
        if os.path.exists(src):
            dst = os.path.join(out_dir, os.path.basename(one)[:-5] + '.png')
            shutil.move(src, dst)
            pngs.append(dst)
    shutil.rmtree(tmp, ignore_errors=True)
    return pngs


def pptx_transition(slide):
    """Figma Slides keeps the transition on the slide's link to the next slide; PowerPoint keeps it on the
    slide it leads to. Both mean "how this slide leaves", so the same slide carries it here."""
    for pi in slide.get('prototypeInteractions') or []:
        for a in pi.get('actions') or []:
            t = a.get('transitionType', 'INSTANT_TRANSITION')
            if t == 'INSTANT_TRANSITION':
                return ''
            d = a.get('transitionDuration', 0.4) or 0.4
            spd = 'fast' if d < 0.5 else 'med' if d < 1.0 else 'slow'
            direction = {'LEFT': 'r', 'RIGHT': 'l', 'TOP': 'd', 'BOTTOM': 'u'}.get(t.rsplit('_', 1)[-1], 'l')
            if t.startswith('PUSH_FROM'):
                body = f'<p:push dir="{direction}"/>'
            elif t.startswith(('SLIDE_FROM', 'MOVE_FROM')):
                body = f'<p:cover dir="{direction}"/>'
            else:  # dissolve, smart animate and the rest
                body = '<p:fade/>'
            auto = ''
            if (pi.get('event') or {}).get('interactionType') == 'AFTER_TIMEOUT':
                auto = f' advTm="{int((pi["event"].get("transitionTimeout") or 0) * 1000)}"'
            return f'<p:transition spd="{spd}"{auto}>{body}</p:transition>'
    return ''


def pic_xml(pid, name, rid, x, y, w, h, src_rect=''):
    return (f'<p:pic><p:nvPicPr><p:cNvPr id="{pid}" name="{escape(name)}"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>'
            f'<p:blipFill><a:blip r:embed="{rid}"/>{src_rect}<a:stretch><a:fillRect/></a:stretch></p:blipFill>'
            f'<p:spPr><a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>')


def shape_xml(pid, n, m, op):
    x, y = m[2], m[5]
    w, h = n['size']['x'] * m[0], n['size']['y'] * m[4]
    t = n.get('type')
    if t == 'ELLIPSE':
        geom = '<a:prstGeom prst="ellipse"><a:avLst/></a:prstGeom>'
    else:
        rad = n.get('cornerRadius', 0) or 0
        if rad > 0:
            adj = int(min(50000, rad / max(1, min(w, h)) * 100000))
            geom = f'<a:prstGeom prst="roundRect"><a:avLst><a:gd name="adj" fmla="val {adj}"/></a:avLst></a:prstGeom>'
        else:
            geom = '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom>'
    ok, fills = solid_only(n.get('fillPaints'))
    fill = '<a:noFill/>'
    if fills:
        p = fills[-1]
        alpha = p['color'].get('a', 1.0) * p.get('opacity', 1.0) * op
        fill = f'<a:solidFill><a:srgbClr val="{hex6(p["color"])}">' + (f'<a:alpha val="{int(alpha * 100000)}"/>' if alpha < 0.999 else '') + '</a:srgbClr></a:solidFill>'
    line = '<a:ln><a:noFill/></a:ln>'
    strokes = [p for p in n.get('strokePaints') or [] if p.get('visible', True) and p.get('type') == 'SOLID']
    if strokes and (n.get('strokeWeight') or 0) > 0:
        line = f'<a:ln w="{emu(n["strokeWeight"])}"><a:solidFill><a:srgbClr val="{hex6(strokes[-1]["color"])}"/></a:solidFill></a:ln>'
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{pid}" name="{escape(n.get("name", "Shape"))[:80]}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm>{geom}{fill}{line}</p:spPr></p:sp>')


def picture_fill_xml(pid, n, m, r, rels, add_media, work):
    p = [q for q in n.get('fillPaints') or [] if q.get('visible', True) and q.get('type') == 'IMAGE'][-1]
    h_ = figdeck.image_hash_hex(p.get('image') or {})
    data = r.d.images.get(h_)
    x, y = m[2], m[5]
    w, h = n['size']['x'] * m[0], n['size']['y'] * m[4]
    if not data:
        return shape_xml(pid, n, m, 1.0)
    ext = 'png' if data[:4] == b'\x89PNG' else 'jpg'
    path = os.path.join(work, f'img_{h_}.{ext}')
    open(path, 'wb').write(data)
    rid = add_media(rels, path, ext)
    iw, ih = p.get('originalImageWidth') or 1, p.get('originalImageHeight') or 1
    mode = p.get('imageScaleMode', 'FILL')
    src = ''
    if mode == 'FIT':
        k = min(w / iw, h / ih)
        nw, nh = iw * k, ih * k
        x, y, w, h = x + (w - nw) / 2, y + (h - nh) / 2, nw, nh
    elif mode in ('FILL', 'CROP', 'STRETCH'):
        k = max(w / iw, h / ih)
        cw, ch = w / k, h / k
        lr = (iw - cw) / 2 / iw * 100000
        tb = (ih - ch) / 2 / ih * 100000
        if lr > 1 or tb > 1:
            src = f'<a:srcRect l="{int(lr)}" t="{int(tb)}" r="{int(lr)}" b="{int(tb)}"/>'
    return pic_xml(pid, n.get('name', 'Image'), rid, x, y, w, h, src)


def write_package(out, files, slides, title, has_notes):
    ct = ['<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
          '<Default Extension="xml" ContentType="application/xml"/>', '<Default Extension="png" ContentType="image/png"/>',
          '<Default Extension="jpg" ContentType="image/jpeg"/>',
          '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>',
          '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>',
          '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>',
          '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>',
          '<Override PartName="/ppt/theme/theme2.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>',
          '<Override PartName="/ppt/notesMasters/notesMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.notesMaster+xml"/>',
          '<Override PartName="/ppt/presProps.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presProps+xml"/>',
          '<Override PartName="/ppt/viewProps.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.viewProps+xml"/>',
          '<Override PartName="/ppt/tableStyles.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.tableStyles+xml"/>',
          '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
          '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>']
    for i in slides:
        ct.append(f'<Override PartName="/ppt/slides/slide{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>')
        if f'ppt/notesSlides/notesSlide{i}.xml' in files:
            ct.append(f'<Override PartName="/ppt/notesSlides/notesSlide{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.notesSlide+xml"/>')
    pres_rels = Rels()
    pres_rels.add(f'{REL}/slideMaster', 'slideMasters/slideMaster1.xml')
    pres_rels.add(f'{REL}/notesMaster', 'notesMasters/notesMaster1.xml')
    slide_ids = []
    for i in slides:
        rid = pres_rels.add(f'{REL}/slide', f'slides/slide{i}.xml')
        slide_ids.append(f'<p:sldId id="{255 + i}" r:id="{rid}"/>')
    pres_rels.add(f'{REL}/theme', 'theme/theme1.xml')
    pres_rels.add(f'{REL}/presProps', 'presProps.xml')
    pres_rels.add(f'{REL}/viewProps', 'viewProps.xml')
    pres_rels.add(f'{REL}/tableStyles', 'tableStyles.xml')
    pres = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation {NS} saveSubsetFonts="1">'
            f'<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:notesMasterIdLst><p:notesMasterId r:id="rId2"/></p:notesMasterIdLst>'
            f'<p:sldIdLst>{"".join(slide_ids)}</p:sldIdLst><p:sldSz cx="{SW}" cy="{SH}"/><p:notesSz cx="6858000" cy="9144000"/>'
            f'<p:defaultTextStyle><a:lvl1pPr><a:defRPr lang="en-US"/></a:lvl1pPr></p:defaultTextStyle></p:presentation>')
    m_rels = Rels()
    m_rels.add(f'{REL}/slideLayout', '../slideLayouts/slideLayout1.xml')
    m_rels.add(f'{REL}/theme', '../theme/theme1.xml')
    l_rels = Rels()
    l_rels.add(f'{REL}/slideMaster', '../slideMasters/slideMaster1.xml')
    n_rels = Rels()
    n_rels.add(f'{REL}/theme', '../theme/theme2.xml')
    root = Rels()
    root.add(f'{REL}/officeDocument', 'ppt/presentation.xml')
    root.add('http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties', 'docProps/core.xml')
    root.add(f'{REL}/extended-properties', 'docProps/app.xml')
    now = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
            f'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>{escape(title)}</dc:title><dc:creator>Shiji Design</dc:creator>'
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">{now}</dcterms:modified></cp:coreProperties>')
    app = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
           f'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>Microsoft Office PowerPoint</Application><Slides>{len(slides)}</Slides><PresentationFormat>Widescreen</PresentationFormat></Properties>')
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' + ''.join(ct) + '</Types>')
        z.writestr('_rels/.rels', root.xml())
        z.writestr('docProps/core.xml', core)
        z.writestr('docProps/app.xml', app)
        z.writestr('ppt/presentation.xml', pres)
        z.writestr('ppt/_rels/presentation.xml.rels', pres_rels.xml())
        z.writestr('ppt/presProps.xml', f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentationPr {NS}/>')
        z.writestr('ppt/viewProps.xml', f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:viewPr {NS}><p:normalViewPr><p:restoredLeft sz="15620"/><p:restoredTop sz="94660"/></p:normalViewPr><p:gridSpacing cx="76200" cy="76200"/></p:viewPr>')
        z.writestr('ppt/tableStyles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:tblStyleLst xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" def="{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"/>')
        z.writestr('ppt/theme/theme1.xml', THEME)
        z.writestr('ppt/theme/theme2.xml', THEME)
        z.writestr('ppt/slideMasters/slideMaster1.xml', MASTER)
        z.writestr('ppt/slideMasters/_rels/slideMaster1.xml.rels', m_rels.xml())
        z.writestr('ppt/slideLayouts/slideLayout1.xml', LAYOUT)
        z.writestr('ppt/slideLayouts/_rels/slideLayout1.xml.rels', l_rels.xml())
        z.writestr('ppt/notesMasters/notesMaster1.xml', NOTES_MASTER)
        z.writestr('ppt/notesMasters/_rels/notesMaster1.xml.rels', n_rels.xml())
        for name, data in files.items():
            z.writestr(name, data)


def check_pptx(path):
    """Package-level check: XML parses, every relationship target exists, every part has a content type."""
    import posixpath
    import xml.dom.minidom as md
    errors = []
    z = zipfile.ZipFile(path)
    names = set(z.namelist())
    ct = md.parseString(z.read('[Content_Types].xml'))
    defaults = {e.getAttribute('Extension').lower() for e in ct.getElementsByTagName('Default')}
    overrides = {e.getAttribute('PartName').lstrip('/') for e in ct.getElementsByTagName('Override')}
    for n in names:
        if n.endswith('/'):
            continue
        if n.endswith('.xml') or n.endswith('.rels'):
            try:
                md.parseString(z.read(n))
            except Exception as e:  # noqa: BLE001
                errors.append(f'{n}: not valid XML ({e})')
        if n != '[Content_Types].xml' and n not in overrides and n.rsplit('.', 1)[-1].lower() not in defaults:
            errors.append(f'{n}: no content type')
    for n in names:
        if not n.endswith('.rels'):
            continue
        base = posixpath.dirname(posixpath.dirname(n))
        for rel in md.parseString(z.read(n)).getElementsByTagName('Relationship'):
            if rel.getAttribute('TargetMode') == 'External':
                continue
            target = posixpath.normpath(posixpath.join(base, rel.getAttribute('Target')))
            if target not in names:
                errors.append(f'{n}: {rel.getAttribute("Id")} points at missing {target}')
    slides = sorted(n for n in names if re.match(r'ppt/slides/slide\d+\.xml$', n))
    return {'file': os.path.abspath(path), 'slides': len(slides), 'parts': len(names), 'errors': errors}


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--check':
        import json
        r = check_pptx(sys.argv[2])
        print(json.dumps(r, indent=1))
        sys.exit(1 if r['errors'] else 0)
    args = [a for a in sys.argv[1:] if not a.startswith('--preview=')]
    pv = [a.split('=', 1)[1] for a in sys.argv[1:] if a.startswith('--preview=')]
    if len(args) != 2:
        print(__doc__)
        print('Options: --check file.pptx | --preview=DIR (PNG per slide via Quick Look)')
        sys.exit(2)
    out = convert(args[0], args[1])
    r = check_pptx(out)
    if pv:
        shots = preview(pv[0])
        R.contact_sheet(shots, os.path.join(pv[0], 'contact-sheet.png')) if shots and len(shots) <= 16 else None
        r['preview'] = f'{len(shots)} slides in {os.path.abspath(pv[0])}'
    import json
    print(json.dumps(r, indent=1))
