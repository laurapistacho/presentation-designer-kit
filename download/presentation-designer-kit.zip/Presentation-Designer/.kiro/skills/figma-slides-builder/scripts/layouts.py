"""Shiji Day & Night slide layouts (registered in build_deck.LAYOUTS on import).

Every layout draws on an empty 1920 x 1080 slide with the primitives of build_deck.S, in the colours,
gradients and type of the presentation-brand skill (assets/tokens.json). Night is the default for
openers, dividers and big moments; day for screenshots and dense content; blue for punctuation.
A slide can switch with "theme": "day" | "night" | "blue".
"""
from build_deck import LAYOUTS, SLIDE_H, SLIDE_W, TOKENS, LOGO_W, layout  # noqa: F401

SPACE = TOKENS['space']
M = SPACE['margin_x']                  # 128: side margin
TOP = SPACE['margin_top']              # 104: top of the content band
FOOT = SPACE['footer_y']               # 992: logo and footnotes
LIMIT = FOOT - 48                      # 944: content ends above the footer
W = SLIDE_W - 2 * M                    # 1664: content width
GAP = SPACE['gutter']                  # 64

LEGACY_BACKGROUND = {'navy': 'night', 'glow': 'aurora', 'blue': 'blue', 'cloud': 'daylight', 'ice': 'daylight',
                     'white': 'day', 'mist': 'daylight'}


def bg_theme(name, default):
    """Spec background (new or old names) -> (background token, theme)."""
    name = LEGACY_BACKGROUND.get(name, name) if name else default
    theme = {'blue': 'blue', 'day': 'day', 'daylight': 'day'}.get(name, 'night')
    return name, theme


def items_of(sp, *keys):
    for k in keys:
        if sp.get(k):
            return sp[k]
    return []


def link_of(sp):
    link = sp.get('link')
    if not link:
        return None, None
    if isinstance(link, dict):
        return link.get('text') or 'Open', link.get('url')
    return 'Open', link


def content_column(s, sp, x, w, title_kind='title', bullets_key='bullets', gap=40, align='LEFT'):
    """Heading, lead, body, bullets and a link button stacked in one auto-layout column."""
    col = s.frame(x, 0, w, 10, 'VERTICAL', gap=gap, name='Content',
                  cross={'LEFT': 'MIN', 'CENTER': 'CENTER'}[align])
    s.heading(sp, w, col, title_kind=title_kind, align=align)
    if sp.get('lead'):
        s.t(sp['lead'], 'lead', w=w, color='text', parent=col, align=align, name='Lead')
    if sp.get('body'):
        s.t(sp['body'], 'body', w=w, color='muted' if sp.get('lead') else 'text', parent=col, align=align, name='Body')
    if sp.get(bullets_key):
        s.bullets(sp[bullets_key], w, col)
    text, url = link_of(sp)
    if url:
        s.pill(f'{text}  ↗', col, url=url, name='Link button')
    return col


def visual(s, sp, x, y, w, h):
    """Chip, then the screenshot (or a prototype placeholder) inside the box."""
    chip = sp.get('chip')
    if chip:
        y, h = y + 64, h - 64
    if sp.get('image'):
        node = s.shot(sp['image'], x, y, w, h, fit='cover' if sp.get('image_fit') == 'fill' else 'contain')
        if chip:
            t = node['transform']
            s.chip(chip, None, t['m02'], t['m12'] - 60,
                   variant='new' if str(chip).strip().lower() in ('new', 'nuevo') else 'default')
        return node
    if chip:
        s.chip(chip, None, x, y - 60, variant='default')
    if sp.get('embed_url'):
        box = s.rect(x, y, w, h, fill='surface', radius=TOKENS['radius']['card'], stroke='border', stroke_w=2)
        box['name'] = 'Live prototype (insert the Figma embed here)'
        g = s.frame(x, 0, w, 10, 'VERTICAL', gap=20, cross='CENTER', name='Prototype note')
        s.t('Live prototype', 'kicker', w=w, color='kicker', align='CENTER', parent=g)
        s.t('Insert the Figma embed here', 'subtitle', w=w, color='muted', align='CENTER', parent=g)
        s.pill('Open the prototype  ↗', g, url=sp['embed_url'], name='Prototype link')
        s.vplace(g, y, y + h, 'center')
        return box
    return None


# --------------------------------------------------------------------------- openers and closers
@layout('cover', 'night', 'kicker, title (==x== marks the green line), subtitle, date',
        'Opening slide on the aurora: logo top centre, centred Night Serif title with one green highlight, subtitle and date.')
def l_cover(s, sp):
    s.background(sp.get('background') or 'aurora')
    s.brand_logo((SLIDE_W - LOGO_W) / 2, 88, 'white')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=40, cross='CENTER', name='Title block')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
    s.t(sp.get('title', ''), 'display', w=1560, color='title', align='CENTER', parent=col, name='Title')
    if sp.get('subtitle'):
        s.t(sp['subtitle'], 'subtitle', w=1200, color='muted', align='CENTER', parent=col, name='Subtitle')
    s.vplace(col, 200, 900)
    if sp.get('date'):
        s.t(sp['date'], 'label', M, FOOT, W, color='muted', align='CENTER', name='Date')


@layout('cover-navy', 'night', 'kicker, title, subtitle, date',
        'Left-aligned opening slide on the night horizon (day light at the top fading into night), logo top left.')
def l_cover_navy(s, sp):
    s.background(sp.get('background') or 'horizon')
    s.brand_logo(M, 88, 'white')
    col = s.frame(M, 0, 1440, 10, 'VERTICAL', gap=36, name='Title block')
    bar = s.rect(0, 0, 120, 6, fill='green', radius=3, parent=col)
    bar['name'] = 'Accent'
    s.heading(sp, 1440, col, title_kind='display', subtitle='', gap=28)
    if sp.get('subtitle'):
        s.t(sp['subtitle'], 'subtitle', w=1100, color='muted', parent=col, name='Subtitle')
    s.vplace(col, 220, 920)
    if sp.get('date'):
        s.t(sp['date'], 'label', M, FOOT, 900, color='muted', name='Date')


@layout('cover-center', 'blue', 'kicker, title (line 1 in Day Sans, line 2 in Night Serif), subtitle, date',
        'Centred opening slide on Reviewpro Blue: a Day Sans line over a Night Serif line (2026 Roadmap / Q2 Achievements).')
def l_cover_center(s, sp):
    s.background('blue')
    s.brand_logo((SLIDE_W - LOGO_W) / 2, 88, 'white')
    lines = str(sp.get('title', '')).split('\n')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=8, cross='CENTER', name='Title block')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
        s.frame(0, 0, 10, 28, 'NONE', parent=col, name='Space')
    s.t(lines[0], 'title', w=1560, color='title', align='CENTER', parent=col, size=96, name='Title line 1')
    if len(lines) > 1:
        s.t('\n'.join(lines[1:]), 'display', w=1560, color='title', align='CENTER', parent=col, name='Title line 2')
    if sp.get('subtitle'):
        s.frame(0, 0, 10, 32, 'NONE', parent=col, name='Space')
        s.t(sp['subtitle'], 'subtitle', w=1200, color='muted', align='CENTER', parent=col, name='Subtitle')
    s.vplace(col, 200, 900)
    if sp.get('date'):
        s.t(sp['date'], 'label', M, FOOT, W, color='muted', align='CENTER', name='Date')


@layout('thanks', 'night', 'title (default "Thank you"), subtitle, cta (button text), contact',
        'Closing slide on the aurora: big Night Serif title, subtitle, an Energetic Green button and a contact line.')
def l_thanks(s, sp):
    s.background(sp.get('background') or 'aurora')
    s.brand_logo((SLIDE_W - LOGO_W) / 2, 88, 'white')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=40, cross='CENTER', name='Title block')
    s.t(sp.get('title') or 'Thank you', 'display', w=1560, color='title', align='CENTER', parent=col, size=136,
        name='Title')
    if sp.get('subtitle'):
        s.t(sp['subtitle'], 'subtitle', w=1200, color='muted', align='CENTER', parent=col, name='Subtitle')
    if sp.get('cta'):
        s.pill(sp['cta'], col, kind='heading', pad=(18, 40), name='Button')
    s.vplace(col, 200, 900)
    if sp.get('contact'):
        s.t(sp['contact'], 'label', M, FOOT, W, color='muted', align='CENTER', name='Contact')


# --------------------------------------------------------------------------- structure
@layout('index', 'night', 'title (default "Agenda"), kicker, items[] (up to 8)',
        'Agenda: Night Serif title on the left, numbered topics on the right with hairlines between them.')
def l_index(s, sp):
    s.background(sp.get('background') or 'night')
    left = s.frame(M, 0, 600, 10, 'VERTICAL', gap=24, name='Heading')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=600, color='kicker', parent=left, name='Kicker')
    s.t(sp.get('title') or 'Agenda', 'display-s', w=600, color='title', parent=left, name='Title')
    s.vplace(left, TOP, LIMIT)
    items = (sp.get('items') or [])[:8]
    x0 = 860
    w = SLIDE_W - M - x0
    lst = s.frame(x0, 0, w, 10, 'VERTICAL', gap=0, name='Topics')
    size = 44 if len(items) <= 5 else 36
    for i, it in enumerate(items):
        line = s.rect(0, 0, w, 1.5, fill='border', parent=lst)
        line['name'] = 'Hairline'
        row = s.frame(0, 0, w, 10, 'HORIZONTAL', gap=32, pad=(26, 0), parent=lst, hug_main=False, hug_cross=True,
                      cross='CENTER', name=f'Topic {i + 1}')
        s.t(f'{i + 1:02d}', 'kicker', w=64, color='kicker', parent=row, size=26, name='Number')
        tx = s.t(it, 'lead', w=w - 96, color='title', parent=row, size=size, name='Topic')
        tx['stackChildPrimaryGrow'] = 1.0
    if items:
        line = s.rect(0, 0, w, 1.5, fill='border', parent=lst)
        line['name'] = 'Hairline'
    s.vplace(lst, TOP, LIMIT)
    s.footer(sp)


@layout('section', 'night', 'number ("01"), title, kicker, background (deep|night|horizon|aurora|blue)',
        'Section divider on deep night: Energetic Green section number in Night Serif, title under it. Starts a new row of the slide grid.')
def l_section(s, sp):
    bg, th = bg_theme(sp.get('background'), 'deep')
    s.theme(th)
    s.background(bg)
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=16, cross='CENTER', name='Divider')
    s.t(sp.get('kicker') or 'Section', 'kicker', w=W, color='muted', align='CENTER', parent=col, name='Kicker')
    if sp.get('number'):
        s.t(str(sp['number']), 'number', w=W, color='highlight', align='CENTER', parent=col, name='Number')
    s.t(sp.get('title', ''), 'title', w=1400, color='title', align='CENTER', parent=col, size=72, name='Title')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('section-flat', 'blue', 'number, title, kicker',
        'Section divider on Reviewpro Blue: big white number on the left, title beside it. Starts a new row of the slide grid.')
def l_section_flat(s, sp):
    s.background('blue')
    row = s.frame(M, 0, W, 10, 'HORIZONTAL', gap=72, hug_main=False, hug_cross=True, cross='CENTER', name='Divider')
    if sp.get('number'):
        s.t(str(sp['number']), 'number', w=440, color='title', parent=row, size=280, name='Number')
    right = s.frame(0, 0, W - 512, 10, 'VERTICAL', gap=20, parent=row, name='Heading')
    right['stackChildPrimaryGrow'] = 1.0
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W - 512, color='kicker', parent=right, name='Kicker')
    s.t(sp.get('title', ''), 'display-s', w=W - 512, color='title', parent=right, name='Title')
    s.vplace(row, TOP, LIMIT)
    s.footer(sp)


@layout('topic', 'night', 'title (line 1 Night Serif, line 2 Day Sans), kicker',
        'Sub-topic divider: two-line title in a soft blue glow inside a thin ring (New / Settings).')
def l_topic(s, sp):
    s.background('night-plain')
    glow = s.rect(0, 0, SLIDE_W, SLIDE_H, fill=None)
    from build_deck import paints
    glow['fillPaints'] = paints([{'type': 'radial', 'at': [0.5, 0.5], 'size': [0.34, 0.6],
                                  'stops': [['blue-3', 0.42, 0], ['blue-3', 0, 1]]}], SLIDE_W, SLIDE_H)
    glow['name'] = 'Glow'
    glow['locked'] = True
    d = 800
    s.dot((SLIDE_W - d) / 2, (SLIDE_H - d) / 2, d, None, stroke='border', stroke_w=2, name='Ring')
    lines = str(sp.get('title', '')).split('\n')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=4, cross='CENTER', name='Title block')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
        s.frame(0, 0, 10, 20, 'NONE', parent=col, name='Space')
    s.t(lines[0], 'statement', w=640, color='title', align='CENTER', parent=col, size=96, name='Title line 1')
    if len(lines) > 1:
        s.t('\n'.join(lines[1:]), 'title', w=640, color='title', align='CENTER', parent=col, size=96, name='Title line 2')
    s.vplace(col, 0, SLIDE_H)


# --------------------------------------------------------------------------- big moments
@layout('statement', 'night', 'kicker, text (==x== or **x** for the punchline), sub, background (night|deep|blue|aurora|day)',
        'One sentence in Night Serif, centred, with the punchline in the highlight colour.')
def l_statement(s, sp):
    bg, th = bg_theme(sp.get('background'), 'night')
    s.theme(th)
    s.background(bg)
    text = str(sp.get('text', '')).replace('**', '==')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=40, cross='CENTER', name='Statement')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
    s.t(text, 'statement', w=1480, color='title', align='CENTER', parent=col, name='Statement')
    if sp.get('sub'):
        s.t(sp['sub'], 'subtitle', w=1200, color='muted', align='CENTER', parent=col, name='Sub')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('question', 'day', 'kicker, icon (question|settings|integrations|space), title, text, serif (bool)',
        'A question to the room on a quiet day background: round icon, Night Serif question, a short line under it.')
def l_question(s, sp):
    s.background('daylight' if s.th['name'] == 'day' else None)
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=36, cross='CENTER', name='Question')
    s.icon(sp.get('icon', 'question'), 0, 0, 96, fill='highlight' if s.th['name'] == 'day' else 'reviewpro', parent=col)
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
    s.t(sp.get('title', ''), 'display-s', w=1400, color='title', align='CENTER', parent=col, name='Question')
    if sp.get('text'):
        s.t(sp['text'], 'quote-s' if sp.get('serif') else 'lead', w=1100, color='muted', align='CENTER', parent=col,
            name='Text')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('quote', 'night', 'kicker (or title), text, who, footer',
        'One hero quote on deep night: a big green quote mark, the quote in Night Serif, who said it.')
def l_quote(s, sp):
    s.background(sp.get('background') or 'deep')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=28, cross='CENTER', name='Quote')
    label = sp.get('kicker') or sp.get('title')
    if label:
        s.t(label, 'kicker', w=W, color='muted', align='CENTER', parent=col, name='Kicker')
    s.t('“', 'display', w=200, color='highlight', align='CENTER', parent=col, size=200, line=170, name='Quote mark')
    s.t(str(sp.get('text', '')).strip('“”"'), 'quote', w=1440, color='title', align='CENTER', parent=col, name='Quote')
    if sp.get('who'):
        s.t(sp['who'], 'label', w=W, color='muted', align='CENTER', parent=col, name='Who')
    if sp.get('footer'):
        s.t(sp['footer'], 'footnote', w=1200, color='muted', align='CENTER', parent=col, name='Footer')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('stats', 'night', 'kicker, title, subtitle, lead, bullets[], stats[{value,label}] (2-4), source{text,url}',
        'Proof in numbers: Night Serif figures with a hairline above each, the first one in Energetic Green.')
def l_stats(s, sp):
    s.background(sp.get('background') or 'night')
    stats = (sp.get('stats') or [])[:4]
    side = bool(sp.get('lead') or sp.get('bullets'))
    if side:
        col = content_column(s, sp, M, 640)
        s.vplace(col, TOP, LIMIT)
        x0, w = 880, SLIDE_W - M - 880
        grid = s.frame(x0, 0, w, 10, 'VERTICAL', gap=56, name='Numbers')
        cols = 2 if len(stats) > 2 else 1
        cw = (w - 56 * (cols - 1)) / cols
        for r in range(0, len(stats), cols):
            row = s.frame(0, 0, w, 10, 'HORIZONTAL', gap=56, parent=grid, hug_main=False, hug_cross=True, name='Row')
            for j, st in enumerate(stats[r:r + cols]):
                stat_cell(s, st, cw, row, first=(r + j == 0), kind='stat-s')
        s.vplace(grid, TOP, LIMIT)
    else:
        head = s.heading(sp, W, None)
        s.place(head, M, TOP)
        n = max(1, len(stats))
        cw = (W - 56 * (n - 1)) / n
        row = s.frame(M, 0, W, 10, 'HORIZONTAL', gap=56, hug_main=False, hug_cross=True, name='Numbers')
        for j, st in enumerate(stats):
            stat_cell(s, st, cw, row, first=(j == 0), kind='stat' if n <= 3 else 'stat-s')
        s.vplace(row, 330, LIMIT - 40)
    s.footer(sp)


def stat_cell(s, st, w, parent, first=False, kind='stat'):
    cell = s.frame(0, 0, w, 10, 'VERTICAL', gap=20, parent=parent, name='Number')
    line = s.rect(0, 0, w, 2, fill='highlight' if first else 'border', parent=cell)
    line['name'] = 'Hairline'
    s.frame(0, 0, 10, 8, 'NONE', parent=cell, name='Space')
    s.t(str(st.get('value', '')), kind, w=w, color='highlight' if first else 'title', parent=cell, name='Value')
    if st.get('label'):
        s.t(st['label'], 'small', w=w, color='muted', parent=cell, name='Label')
    return cell


# --------------------------------------------------------------------------- content
@layout('content', 'day', 'kicker, title, subtitle, lead, body, bullets[], note, link{text,url}, image | embed_url, chip, split (33|40|50), image_fit (fit|fill)',
        'The workhorse: text column on the left, the screenshot on a soft stage on the right. With embed_url it becomes a live prototype slide.')
def l_content(s, sp):
    s.background(None)
    split = int(sp.get('split', 40))
    px = round(SLIDE_W * {25: 33, 33: 33, 40: 40, 50: 50}.get(split, 40) / 100)
    stage = s.rect(px, 0, SLIDE_W - px, SLIDE_H, fill='stage')
    stage['name'] = 'Stage'
    col = content_column(s, sp, M, px - M - GAP)
    s.vplace(col, TOP, LIMIT)
    visual(s, sp, px + 80, 120, SLIDE_W - px - 160, 800)
    s.footer(sp, note=sp.get('note'))


@layout('image', 'day', 'kicker, title, subtitle, image, caption, chip, image_fit',
        'Title on top, one big screenshot or diagram on the stage below (flows, journeys).')
def l_image(s, sp):
    s.background(None)
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0)
    stage = s.rect(0, top - 24, SLIDE_W, SLIDE_H - top + 24, fill='stage')
    stage['name'] = 'Stage'
    bottom = LIMIT - (56 if sp.get('caption') else 0)
    visual(s, sp, M, top + 24, W, bottom - top - 24)
    if sp.get('caption'):
        s.t(sp['caption'], 'caption', M, bottom + 20, W, color='muted', align='CENTER', name='Caption')
    s.footer(sp)


@layout('compare', 'day', 'kicker, title, left_label, right_label, left_image, right_image, left_caption, right_caption',
        'Current versus new: two screenshots side by side, an outline chip on the old one, an Energetic Green chip on the new one.')
def l_compare(s, sp):
    s.background(None)
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0)
    cw = (W - GAP) / 2
    for i, side in enumerate(('left', 'right')):
        x = M + i * (cw + GAP)
        s.chip(sp.get(f'{side}_label') or ('Current' if i == 0 else 'New'), None, x, top,
               variant='current' if i == 0 else 'new')
        cap = sp.get(f'{side}_caption')
        box_h = LIMIT - (top + 64) - (72 if cap else 0)
        s.shot(sp.get(f'{side}_image'), x, top + 64, cw, box_h, valign='top', name=f'{side.title()} screenshot')
        if cap:
            s.t(cap, 'small', x, LIMIT - 52, cw, color='muted', name=f'{side.title()} caption')
    s.footer(sp)


@layout('content-dark', 'night', 'kicker, title, title_light, subtitle, body, items[] (numbered), bullets[]',
        'Text-only on night: heading and a paragraph on the left, a numbered list (or green-dot bullets) on the right.')
def l_content_dark(s, sp):
    s.background(sp.get('background') or 'night')
    items = items_of(sp, 'items')
    bullets = items_of(sp, 'bullets')
    if items or bullets:
        col = content_column(s, sp, M, 680, bullets_key='_none')
        s.vplace(col, TOP, LIMIT)
        lst = s.bullets(items or bullets, SLIDE_W - M - 900, None, kind='lead' if len(items or bullets) <= 4 else 'body',
                        marker='number' if items else 'dot', color='text', gap=36)
        s.place(lst, 900, 0)
        s.vplace(lst, TOP, LIMIT)
    else:
        col = content_column(s, sp, M, 1200)
        s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('content-glow', 'night', 'kicker, title, title_light, subtitle, body, bullets[]',
        'Text-only on the night horizon: a heading, a subtitle line and a paragraph (scenarios, briefs).')
def l_content_glow(s, sp):
    s.background(sp.get('background') or 'horizon')
    col = content_column(s, sp, M, 1180)
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('columns', 'night', 'kicker, title, subtitle, columns[{title, text | bullets[]}] (2-3)',
        'Two or three columns, each with a highlighted heading (the two-column slide of the original brand deck).')
def l_columns(s, sp):
    s.background(sp.get('background') or ('night' if s.th['name'] == 'night' else None))
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    cols = (sp.get('columns') or [])[:3]
    n = max(1, len(cols))
    cw = (W - GAP * (n - 1)) / n
    row = s.frame(M, 0, W, 10, 'HORIZONTAL', gap=GAP, hug_main=False, hug_cross=True, name='Columns')
    for c in cols:
        cell = s.frame(0, 0, cw, 10, 'VERTICAL', gap=24, parent=row, name='Column')
        line = s.rect(0, 0, 48, 4, fill='highlight', radius=2, parent=cell)
        line['name'] = 'Accent'
        s.t(c.get('title', ''), 'heading', w=cw, color='highlight', parent=cell, name='Heading')
        if c.get('text'):
            s.t(c['text'], 'body', w=cw, color='text', parent=cell, name='Text')
        if c.get('bullets'):
            s.bullets(c['bullets'], cw, cell, kind='small')
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0) + 40
    s.vplace(row, top, LIMIT)
    s.footer(sp)


@layout('icons', 'day', 'kicker, title, body, highlight, heading, items[{icon,title,text}] (up to 4)',
        'Night panel on the left with the why; up to four icon items on the right (key projects, principles). Icons: integrations, space, settings, question.')
def l_icons(s, sp):
    s.background(None)
    pw = 720
    panel = s.rect(0, 0, pw, SLIDE_H, fill='midnight')
    panel['name'] = 'Panel'
    day = s.th
    s.theme('night')
    col = s.frame(M, 0, pw - M - GAP, 10, 'VERTICAL', gap=36, name='Why')
    s.heading(sp, pw - M - GAP, col, subtitle='')
    if sp.get('body'):
        s.t(sp['body'], 'body', w=pw - M - GAP, color='text', parent=col, name='Body')
    if sp.get('highlight'):
        s.t(sp['highlight'], 'heading', w=pw - M - GAP, color='highlight', parent=col, size=28, name='Highlight')
    s.vplace(col, TOP, LIMIT)
    s.th = day
    x0 = pw + 96
    w = SLIDE_W - M - x0
    right = s.frame(x0, 0, w, 10, 'VERTICAL', gap=56, name='Items')
    if sp.get('heading'):
        s.t(sp['heading'], 'heading', w=w, color='title', parent=right, name='Heading')
    items = (sp.get('items') or [])[:4]
    cw = (w - 56) / 2
    for r in range(0, len(items), 2):
        row = s.frame(0, 0, w, 10, 'HORIZONTAL', gap=56, parent=right, hug_main=False, hug_cross=True, name='Row')
        for it in items[r:r + 2]:
            cell = s.frame(0, 0, cw, 10, 'VERTICAL', gap=16, parent=row, name='Item')
            s.icon(it.get('icon', 'settings'), 0, 0, 72, fill='highlight', parent=cell)
            s.frame(0, 0, 10, 4, 'NONE', parent=cell, name='Space')
            s.t(it.get('title', ''), 'heading', w=cw, color='title', parent=cell, size=28, name='Title')
            if it.get('text'):
                s.t(it['text'], 'small', w=cw, color='muted', parent=cell, name='Text')
    s.vplace(right, TOP, LIMIT)
    s.footer(sp)


@layout('intro', 'day', 'kicker, title, subtitle (a line or a list of lines, in the highlight colour), lead, image (illustration)',
        'Topic intro on day: title and a one-line definition on the left, a big illustration on the stage at the right.')
def l_intro(s, sp):
    s.background(None)
    px = 1000
    stage = s.rect(px, 0, SLIDE_W - px, SLIDE_H, fill='stage')
    stage['name'] = 'Stage'
    w = px - M - GAP
    col = s.frame(M, 0, w, 10, 'VERTICAL', gap=36, name='Content')
    s.heading(sp, w, col, title_kind='display-s', subtitle='')
    sub = sp.get('subtitle')
    if sub:
        s.t('\n'.join(sub) if isinstance(sub, list) else sub, 'subtitle', w=w, color='highlight', parent=col,
            name='Subtitle')
    if sp.get('lead'):
        s.t(sp['lead'], 'lead', w=w, color='muted', parent=col, name='Lead')
    s.vplace(col, TOP, LIMIT)
    s.shot(sp.get('image'), px + 80, 120, SLIDE_W - px - 160, 800, frame=False, drop=False, radius=0,
           placeholder='Illustration')
    s.footer(sp)


@layout('mobile', 'day', 'kicker, title, title_light, subtitle, body, bullets[], image (phone screen, about 9 x 19.5)',
        'A phone on a soft circle at the right showing the screenshot; title and text on the left.')
def l_mobile(s, sp):
    s.background(None)
    cx = 1390
    s.dot(cx - 430, SLIDE_H / 2 - 430, 860, 'stage', name='Circle')
    col = content_column(s, sp, M, 760)
    s.vplace(col, TOP, LIMIT)
    pw, ph = 392, 812
    x, y = cx - pw / 2, (SLIDE_H - ph) / 2
    body = s.rect(x, y, pw, ph, fill='midnight', radius=64)
    body['name'] = 'Phone'
    from build_deck import shadow
    body['effects'] = [shadow('day')]
    s.shot(sp.get('image'), x + 14, y + 14, pw - 28, ph - 28, fit='cover', radius=52, frame=False, drop=False,
           name='Phone screen', placeholder='Phone screen')
    notch = s.rect(cx - 56, y + 30, 112, 30, fill='midnight', radius=15)
    notch['name'] = 'Notch'
    s.footer(sp)


@layout('split', 'night', 'kicker, title, subtitle, image, side (right|left), background (night|blue|day|daylight)',
        'Half and half: a title on a colour half, a full-bleed picture on the other half.')
def l_split(s, sp):
    bg, th = bg_theme(sp.get('background'), 'night')
    s.theme(th)
    s.background(bg)
    half = SLIDE_W / 2
    img_x = 0 if sp.get('side') == 'left' else half
    s.shot(sp.get('image'), img_x, 0, half, SLIDE_H, fit='cover', radius=0, frame=False, drop=False,
           name='Picture', placeholder='Picture')
    tx = half + M if img_x == 0 else M
    w = half - M - GAP
    col = s.frame(tx, 0, w, 10, 'VERTICAL', gap=28, name='Content')
    s.heading(sp, w, col, title_kind='display-s')
    s.vplace(col, TOP, LIMIT)


@layout('picture', 'night', 'image, image_fit (fill|fit), background, caption',
        'One picture across the whole slide (a meme, a photo, a finished visual), with an optional caption chip.')
def l_picture(s, sp):
    bg, th = bg_theme(sp.get('background'), 'night-plain')
    s.theme(th)
    s.background(bg)
    fit = 'contain' if sp.get('image_fit') == 'fit' else 'cover'
    s.shot(sp.get('image'), 0, 0, SLIDE_W, SLIDE_H, fit=fit, radius=0, frame=False, drop=False, name='Picture',
           placeholder='Picture')
    if sp.get('caption'):
        s.pill(sp['caption'], None, M, FOOT - 24, fill=['night', 0.72], color='white', kind='caption', pad=(12, 24),
               name='Caption')


@layout('meme', 'day', 'image, text, icon, serif (default true), caption',
        'Comedic relief: the meme framed on the left, the punchline on the right.')
def l_meme(s, sp):
    s.background('daylight' if s.th['name'] == 'day' else None)
    s.shot(sp.get('image'), M, 120, 1060, 800, radius=24, name='Meme', placeholder='Meme')
    x0 = M + 1060 + GAP
    w = SLIDE_W - M - x0
    col = s.frame(x0, 0, w, 10, 'VERTICAL', gap=28, name='Punchline')
    if sp.get('icon'):
        s.icon(sp['icon'], 0, 0, 72, fill='highlight', parent=col)
    s.t(sp.get('text', ''), 'quote' if sp.get('serif', True) else 'title-s', w=w, color='title', parent=col,
        size=52 if sp.get('serif', True) else None, name='Punchline')
    if sp.get('caption'):
        s.t(sp['caption'], 'caption', w=w, color='muted', parent=col, name='Caption')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


# --------------------------------------------------------------------------- voices and people
@layout('quote-cards', 'night', 'kicker, title, subtitle, lead, quotes[{text,who}] (2-3), source{text,url}',
        'Text on the left, two or three short user quotes as glass cards on the right.')
def l_quote_cards(s, sp):
    s.background(sp.get('background') or 'night')
    col = content_column(s, sp, M, 640)
    s.vplace(col, TOP, LIMIT)
    x0 = 880
    w = SLIDE_W - M - x0
    cards = s.frame(x0, 0, w, 10, 'VERTICAL', gap=24, name='Quotes')
    for q in (sp.get('quotes') or [])[:3]:
        card = s.frame(0, 0, w, 10, 'VERTICAL', gap=20, pad=(36, 44), parent=cards, fill='surface', stroke='border',
                       radius=TOKENS['radius']['card'], name='Quote card')
        s.t(str(q.get('text', '')).strip('“”"'), 'quote-s', w=w - 88, color='title', parent=card, name='Quote')
        if q.get('who'):
            s.t(q['who'], 'label', w=w - 88, color='highlight', parent=card, name='Who')
    s.vplace(cards, TOP, LIMIT)
    s.footer(sp)


@layout('quotes', 'day', 'kicker, title, quotes[{text,who}] (2-6), closing, source{text,url}',
        'Voice of the customer: short quotes in a grid of two or three columns, the hotel or role under each.')
def l_quotes(s, sp):
    s.background('daylight' if s.th['name'] == 'day' else None)
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    quotes = (sp.get('quotes') or [])[:6]
    cols = 2 if len(quotes) in (2, 4) else 3
    cw = (W - 48 * (cols - 1)) / cols
    grid = s.frame(M, 0, W, 10, 'VERTICAL', gap=48, name='Quotes')
    for r in range(0, len(quotes), cols):
        row = s.frame(0, 0, W, 10, 'HORIZONTAL', gap=48, parent=grid, hug_main=False, hug_cross=True, name='Row')
        for q in quotes[r:r + cols]:
            cell = s.frame(0, 0, cw, 10, 'VERTICAL', gap=16, pad=(32, 36), parent=row,
                           fill='white' if s.th['name'] == 'day' else 'surface', stroke='border',
                           radius=TOKENS['radius']['card'], name='Quote')
            s.t('“', 'display', w=80, color='highlight', parent=cell, size=88, line=56, name='Quote mark')
            s.t(str(q.get('text', '')).strip('“”"'), 'quote-s', w=cw - 72, color='title', parent=cell,
                size=32 if len(quotes) > 3 else 36, name='Quote')
            if q.get('who'):
                s.t(q['who'], 'label', w=cw - 72, color='muted', parent=cell, name='Who')
        s.equal_heights(row)
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0)
    bottom = LIMIT - (80 if sp.get('closing') else 0)
    s.vplace(grid, top, bottom)
    if sp.get('closing'):
        s.t(sp['closing'], 'heading', M, LIMIT - 44, W, color='title', name='Closing')
    s.footer(sp)


@layout('people', 'day', 'kicker, title, people[{image,name,role,quote}] (up to 5), footer',
        'A row of people or personas: round photo (or initials), name, role and a one-line quote.')
def l_people(s, sp):
    s.background(None)
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    people = (sp.get('people') or [])[:5]
    n = max(1, len(people))
    cw = (W - 32 * (n - 1)) / n
    row = s.frame(M, 0, W, 10, 'HORIZONTAL', gap=32, hug_main=False, hug_cross=True, name='People')
    for p in people:
        card = s.frame(0, 0, cw, 10, 'VERTICAL', gap=16, pad=(40, 28), parent=row, fill='stage',
                       radius=TOKENS['radius']['card'], cross='CENTER', name=p.get('name') or 'Person')
        avatar(s, p, 168, card)
        s.frame(0, 0, 10, 4, 'NONE', parent=card, name='Space')
        s.t(p.get('name', ''), 'heading', w=cw - 56, color='title', align='CENTER', parent=card, size=28, name='Name')
        if p.get('role'):
            s.t(p['role'], 'label', w=cw - 56, color='highlight', align='CENTER', parent=card, name='Role')
        if p.get('quote'):
            s.t(str(p['quote']).strip('“”"'), 'quote-s', w=cw - 56, color='muted', align='CENTER', parent=card, size=24,
                name='Quote')
    s.equal_heights(row)
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0)
    s.vplace(row, top, LIMIT)
    s.footer(sp, note=sp.get('footer'))


def avatar(s, p, d, parent):
    full = s.image_file(p.get('image'))
    if full:
        node = s.dot(0, 0, d, None, parent=parent, name='Photo')
        paint, _ = s.b.image_paint(full, 'FILL')
        node['fillPaints'] = [paint]
        return node
    from build_deck import gradient
    f = s.frame(0, 0, d, d, 'HORIZONTAL', parent=parent, radius=d / 2, align='CENTER', cross='CENTER',
                hug_main=False, name='Initials')
    f['fillPaints'] = [gradient({'type': 'linear', 'angle': 135, 'stops': [['reviewpro', 1, 0], ['meridian', 1, 1]]}, d, d)]
    initials = ''.join(w[0] for w in str(p.get('name', '?')).split()[:2]).upper() or '?'
    s.t(initials, 'stat-s', w=d, color='white', align='CENTER', parent=f, size=64, name='Initials')
    return f


@layout('circle-list', 'night', 'kicker, title (inside the circle), lead, items[], markers (none|letters|check|numbers), background (night|day|blue)',
        'A big circle on the left holding the title, a list on the right: polls (A/B/C/D), opportunity areas, checklists.')
def l_circle_list(s, sp):
    bg, th = bg_theme(sp.get('background'), 'night')
    s.theme(th)
    s.background(bg)
    d = 760
    cx, cy = 96, (SLIDE_H - d) / 2
    from build_deck import gradient
    circle = s.dot(cx, cy, d, None, name='Circle')
    fill = {'night': [['twilight', 1, 0], ['reviewpro', 1, 1]], 'day': [['reviewpro', 1, 0], ['blue-3', 1, 1]],
            'blue': [['twilight', 1, 0], ['midnight', 1, 1]]}[s.th['name']]
    circle['fillPaints'] = [gradient({'type': 'linear', 'angle': 160, 'stops': fill}, d, d)]
    inner = s.frame(cx + 100, 0, d - 200, 10, 'VERTICAL', gap=16, cross='CENTER', name='Title')
    s.t(sp.get('title', ''), 'display-s', w=d - 200, color='white', align='CENTER', parent=inner, size=72, name='Title')
    s.vplace(inner, cy, cy + d)
    x0 = cx + d + 112
    w = SLIDE_W - M - x0
    col = s.frame(x0, 0, w, 10, 'VERTICAL', gap=40, name='List')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=w, color='kicker', parent=col, name='Kicker')
    if sp.get('lead'):
        s.t(sp['lead'], 'lead', w=w, color='muted', parent=col, name='Lead')
    marker = {'letters': 'letter', 'check': 'check', 'numbers': 'number', 'none': 'none'}.get(sp.get('markers', 'none'), 'dot')
    if sp.get('markers') is None:
        marker = 'dot'
    s.bullets(sp.get('items') or [], w, col, kind='lead', marker=marker, color='title', gap=32)
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)
