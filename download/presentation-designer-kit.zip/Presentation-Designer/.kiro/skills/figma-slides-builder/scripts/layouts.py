"""Shiji Day & Night slide layouts (registered in build_deck.LAYOUTS on import).

The 40 layouts of the official Figma Slides template "00 Day & Night template"
(https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4), in the template's order. Each one draws on an
empty 1920 x 1080 slide with the primitives of build_deck.S, in the colours, gradients and type of
the presentation-brand skill (assets/tokens.json); the legacy and component layouts also copy their
artwork from the template (build_deck.ART). The `template` name of each layout is the name of its
slide in the Figma template. Night is the default for openers, dividers and big moments; day for
screenshots and dense content; blue for punctuation. A slide can switch with "theme".
"""
from build_deck import LAYOUTS, SLIDE_H, SLIDE_W, TOKENS, LOGO_W, layout  # noqa: F401

SPACE = TOKENS['space']
M = SPACE['margin_x']                  # 128: side margin
PM = SPACE.get('panel_margin', 96)     # 96: margin inside a text panel next to a stage
TOP = SPACE['margin_top']              # 104: top of the content band
FOOT = SPACE['footer_y']               # 992: logo and footnotes
LIMIT = FOOT - 48                      # 944: content ends above the footer
W = SLIDE_W - 2 * M                    # 1664: content width
GAP = SPACE['gutter']                  # 64
SLOGAN = TOKENS.get('slogan', 'Design with proof, build with purpose, grow without friction')

LEGACY_BACKGROUND = {'navy': 'night', 'glow': 'aurora', 'blue': 'blue', 'cloud': 'daylight', 'ice': 'ice',
                     'white': 'day', 'mist': 'daylight'}


def bg_theme(name, default):
    """Spec background (new or old names) -> (background token, theme)."""
    name = LEGACY_BACKGROUND.get(name, name) if name else default
    theme = {'blue': 'blue', 'day': 'day', 'daylight': 'day', 'ice': 'day', 'pale': 'day'}.get(name, 'night')
    return name, theme


def items_of(sp, *keys):
    for k in keys:
        if sp.get(k):
            return sp[k]
    return []


def link_of(sp):
    link = sp.get('link')
    if not link:
        return None, None
    if isinstance(link, dict):
        return link.get('text') or 'Open', link.get('url')
    return 'Open', link


def content_column(s, sp, x, w, title_kind='title', bullets_key='bullets', gap=40, align='LEFT', lead_color=None):
    """Heading, lead, body, bullets and a link button stacked in one auto-layout column."""
    col = s.frame(x, 0, w, 10, 'VERTICAL', gap=gap, name='Content',
                  cross={'LEFT': 'MIN', 'CENTER': 'CENTER'}[align])
    s.heading(sp, w, col, title_kind=title_kind, align=align)
    if sp.get('lead'):
        s.t(sp['lead'], 'lead', w=w, color=lead_color or 'text', parent=col, align=align, name='Lead')
    if sp.get('body'):
        s.t(sp['body'], 'body', w=w, color='muted' if sp.get('lead') else 'text', parent=col, align=align, name='Body')
    if sp.get(bullets_key):
        s.bullets(sp[bullets_key], w, col)
    text, url = link_of(sp)
    if url:
        s.pill(f'{text}  ↗', col, url=url, name='Link button')
    return col


def visual(s, sp, x, y, w, h):
    """Chip, then the screenshot (or a prototype placeholder) inside the box."""
    chip = sp.get('chip')
    if chip:
        y, h = y + 64, h - 64
    if sp.get('image'):
        node = s.shot(sp['image'], x, y, w, h, fit='cover' if sp.get('image_fit') == 'fill' else 'contain')
        if chip:
            t = node['transform']
            s.chip(chip, None, t['m02'], t['m12'] - 60,
                   variant='new' if str(chip).strip().lower() in ('new', 'nuevo') else 'default')
        return node
    if chip:
        s.chip(chip, None, x, y - 60, variant='default')
    if sp.get('embed_url'):
        box = s.rect(x, y, w, h, fill='surface', radius=TOKENS['radius']['card'], stroke='border', stroke_w=2)
        box['name'] = 'Media / Live prototype · insert the Figma embed here'
        g = s.frame(x, 0, w, 10, 'VERTICAL', gap=20, cross='CENTER', name='Prototype note')
        s.t('Live prototype', 'kicker', w=w, color='kicker', align='CENTER', parent=g)
        s.t('Insert the Figma embed here', 'subtitle', w=w, color='muted', align='CENTER', parent=g)
        s.pill('Open the prototype  ↗', g, url=sp['embed_url'], name='Prototype link')
        s.vplace(g, y, y + h, 'center')
        return box
    return None


def two_line_title(s, sp, col, first, second, w, color='title', align='CENTER'):
    """A title in two type tokens: line 1 in `first`, the rest in `second` (the legacy title pairs)."""
    lines = str(sp.get('title', '')).split('\n')
    s.t(lines[0], first, w=w, color=color, align=align, parent=col, name='Title line 1')
    if len(lines) > 1:
        s.t('\n'.join(lines[1:]), second, w=w, color=color, align=align, parent=col, name='Title line 2')


def image_size_of(s, path):
    """(width, height) of an image next to the spec, or None."""
    full = s.image_file(path)
    if not full:
        return None
    import build_deck
    try:
        return build_deck.image_size(open(full, 'rb').read())
    except ValueError:
        return None


# =========================================================================== 01 · Covers & agenda
@layout('cover', 'night', 'kicker, title (==x== marks the green line), subtitle, date',
        'Opening slide on the aurora: logo top centre, centred Night Serif title with one green highlight, subtitle and date.',
        template='Cover · Aurora')
def l_cover(s, sp):
    s.background(sp.get('background') or 'aurora')
    s.brand_logo((SLIDE_W - LOGO_W) / 2, 88, 'white')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=40, cross='CENTER', name='Title block')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
    s.t(sp.get('title', ''), 'display', w=1560, color='title', align='CENTER', parent=col, name='Title')
    if sp.get('subtitle'):
        s.t(sp['subtitle'], 'subtitle', w=1200, color='muted', align='CENTER', parent=col, name='Subtitle')
    s.vplace(col, 200, 900)
    if sp.get('date'):
        s.t(sp['date'], 'label', M, FOOT, W, color='muted', align='CENTER', name='Date')


@layout('cover-navy', 'night', 'kicker, title, subtitle, date',
        'Left-aligned opening slide on the night horizon (day light at the top fading into night), logo top left.',
        template='Cover · Horizon')
def l_cover_navy(s, sp):
    s.background(sp.get('background') or 'horizon')
    s.brand_logo(M, 88, 'white')
    col = s.frame(M, 0, 1440, 10, 'VERTICAL', gap=36, name='Title block')
    bar = s.rect(0, 0, 120, 6, fill='green', radius=3, parent=col)
    bar['name'] = 'Accent'
    s.heading(sp, 1440, col, title_kind='display', subtitle='', gap=28)
    if sp.get('subtitle'):
        s.t(sp['subtitle'], 'subtitle', w=1100, color='muted', parent=col, name='Subtitle')
    s.vplace(col, 220, 920)
    if sp.get('date'):
        s.t(sp['date'], 'label', M, FOOT, 900, color='muted', name='Date')


@layout('cover-center', 'blue', 'kicker, title (line 1 in Day Sans, line 2 in Night Serif), subtitle, date',
        'Centred opening slide on Reviewpro Blue: a Day Sans line over a Night Serif line (2026 Roadmap / Q2 Achievements).',
        template='Cover · Split typography')
def l_cover_center(s, sp):
    s.background('blue')
    s.brand_logo((SLIDE_W - LOGO_W) / 2, 88, 'white')
    lines = str(sp.get('title', '')).split('\n')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=8, cross='CENTER', name='Title block')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
        s.frame(0, 0, 10, 28, 'NONE', parent=col, name='Space')
    s.t(lines[0], 'title', w=1560, color='title', align='CENTER', parent=col, size=96, name='Title line 1')
    if len(lines) > 1:
        s.t('\n'.join(lines[1:]), 'display', w=1560, color='title', align='CENTER', parent=col, name='Title line 2')
    if sp.get('subtitle'):
        s.frame(0, 0, 10, 32, 'NONE', parent=col, name='Space')
        s.t(sp['subtitle'], 'subtitle', w=1200, color='muted', align='CENTER', parent=col, name='Subtitle')
    s.vplace(col, 200, 900)
    if sp.get('date'):
        s.t(sp['date'], 'label', M, FOOT, W, color='muted', align='CENTER', name='Date')


@layout('cover-gradient', 'night', 'kicker, title (line 1 in Day Sans Black, line 2 in Night Serif), subtitle, date',
        'Legacy look: centred two-line title on Brand Navy with the violet glow of the previous template rising from the bottom left. Use on purpose, about one per deck.',
        template='Cover · Legacy gradient')
def l_cover_gradient(s, sp):
    s.background('brand-navy')
    s.art('legacy-gradient')
    s.brand_logo((SLIDE_W - LOGO_W) / 2, 80, 'white')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=0, cross='CENTER', name='Title block')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
        s.frame(0, 0, 10, 24, 'NONE', parent=col, name='Space')
    two_line_title(s, sp, col, 'header', 'display-xl', 1400)
    if sp.get('subtitle'):
        s.frame(0, 0, 10, 32, 'NONE', parent=col, name='Space')
        s.t(sp['subtitle'], 'subtitle', w=1200, color='muted', align='CENTER', parent=col, name='Subtitle')
    s.vplace(col, 0, SLIDE_H)
    if sp.get('date'):
        s.t(sp['date'], 'label', M, FOOT, W, color='muted', align='CENTER', name='Date')


@layout('index', 'night', 'title (default "Agenda"), kicker, items[] (up to 8)',
        'Agenda: Night Serif title on the left, numbered topics on the right with hairlines between them.',
        template='Agenda · Four topics')
def l_index(s, sp):
    s.background(sp.get('background') or 'night')
    left = s.frame(M, 0, 600, 10, 'VERTICAL', gap=24, name='Heading')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=600, color='kicker', parent=left, name='Kicker')
    s.t(sp.get('title') or 'Agenda', 'display-s', w=600, color='title', parent=left, name='Title')
    s.vplace(left, TOP, LIMIT)
    items = (sp.get('items') or [])[:8]
    x0 = 860
    w = SLIDE_W - M - x0
    lst = s.frame(x0, 0, w, 10, 'VERTICAL', gap=0, name='Topics')
    size = 44 if len(items) <= 5 else 36
    for i, it in enumerate(items):
        line = s.rect(0, 0, w, 1.5, fill='border', parent=lst)
        line['name'] = 'Hairline'
        row = s.frame(0, 0, w, 10, 'HORIZONTAL', gap=32, pad=(26, 0), parent=lst, hug_main=False, hug_cross=True,
                      cross='CENTER', name=f'Topic {i + 1}')
        s.t(f'{i + 1:02d}', 'kicker', w=64, color='kicker', parent=row, size=26, name='Number')
        tx = s.t(it, 'lead', w=w - 96, color='title', parent=row, size=size, name='Topic')
        tx['stackChildPrimaryGrow'] = 1.0
    if items:
        line = s.rect(0, 0, w, 1.5, fill='border', parent=lst)
        line['name'] = 'Hairline'
    s.vplace(lst, TOP, LIMIT)
    s.footer(sp)


# =========================================================================== 02 · Dividers & key messages
@layout('section', 'night', 'number ("01"), title, kicker, background (deep|night|horizon|aurora|blue)',
        'Section divider on deep night: Energetic Green section number in Night Serif, title under it. Starts a new row of the slide grid.',
        template='Divider · Dark numbered')
def l_section(s, sp):
    bg, th = bg_theme(sp.get('background'), 'deep')
    s.theme(th)
    s.background(bg)
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=16, cross='CENTER', name='Divider')
    s.t(sp.get('kicker') or 'Section', 'kicker', w=W, color='muted', align='CENTER', parent=col, name='Kicker')
    if sp.get('number'):
        s.t(str(sp['number']), 'number', w=W, color='highlight', align='CENTER', parent=col, name='Number')
    s.t(sp.get('title', ''), 'title', w=1400, color='title', align='CENTER', parent=col, size=72, name='Title')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('section-flat', 'blue', 'number, title, kicker',
        'Section divider on Reviewpro Blue: big white number on the left, title beside it. Starts a new row of the slide grid.',
        template='Divider · Blue numbered')
def l_section_flat(s, sp):
    s.background('blue')
    row = s.frame(M, 0, W, 10, 'HORIZONTAL', gap=72, hug_main=False, hug_cross=True, cross='CENTER', name='Divider')
    if sp.get('number'):
        s.t(str(sp['number']), 'number', w=440, color='title', parent=row, size=280, name='Number')
    right = s.frame(0, 0, W - 512, 10, 'VERTICAL', gap=20, parent=row, name='Heading')
    right['stackChildPrimaryGrow'] = 1.0
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W - 512, color='kicker', parent=right, name='Kicker')
    s.t(sp.get('title', ''), 'display-s', w=W - 512, color='title', parent=right, name='Title')
    s.vplace(row, TOP, LIMIT)
    s.footer(sp)


@layout('section-number', 'night', 'number ("01"), title',
        'Legacy look: a giant faded number behind a Day Sans title on Link Blue with a violet edge. Starts a new row of the slide grid. Use on purpose, about one per deck.',
        template='Divider · Oversized number')
def l_section_number(s, sp):
    s.background('link-blue')
    s.art('number-gradient')
    if sp.get('number'):
        num = s.t(str(sp['number']), 'metric', 0, 0, SLIDE_W, color='white', align='CENTER', name='Number')
        num['opacity'] = 0.1
        s.vplace(num, 0, SLIDE_H)
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=16, cross='CENTER', name='Divider')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
    s.t(sp.get('title', ''), 'title-l', w=1000, color='white', align='CENTER', parent=col, name='Title')
    s.vplace(col, 96, SLIDE_H)
    s.footer(sp)


@layout('topic', 'night', 'title (line 1 Night Serif, line 2 Day Sans), kicker',
        'Sub-topic divider: two-line title in a soft blue glow inside a thin ring (New / Settings).',
        template='Project opener · Mixed typography')
def l_topic(s, sp):
    s.background('night-plain')
    glow = s.rect(0, 0, SLIDE_W, SLIDE_H, fill=None)
    from build_deck import paints
    glow['fillPaints'] = paints([{'type': 'radial', 'at': [0.5, 0.5], 'size': [0.34, 0.6],
                                  'stops': [['blue-3', 0.42, 0], ['blue-3', 0, 1]]}], SLIDE_W, SLIDE_H)
    glow['name'] = 'Background / Glow'
    glow['locked'] = True
    d = 800
    s.dot((SLIDE_W - d) / 2, (SLIDE_H - d) / 2, d, None, stroke='border', stroke_w=2, name='Ring')
    lines = str(sp.get('title', '')).split('\n')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=4, cross='CENTER', name='Title block')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
        s.frame(0, 0, 10, 20, 'NONE', parent=col, name='Space')
    s.t(lines[0], 'statement', w=640, color='title', align='CENTER', parent=col, size=96, name='Title line 1')
    if len(lines) > 1:
        s.t('\n'.join(lines[1:]), 'title', w=640, color='title', align='CENTER', parent=col, size=96, name='Title line 2')
    s.vplace(col, 0, SLIDE_H)
    s.footer(sp)


@layout('question-circle', 'night', 'title (line 1 Night Serif, line 2 Day Sans Black), kicker',
        'Legacy look: a question in two typefaces inside the Shiji brand circle on Brand Navy (Who are / these users?).',
        template='Question · Brand circle')
def l_question_circle(s, sp):
    s.background('brand-navy')
    s.art('brand-circle')
    col = s.frame(560, 0, 800, 10, 'VERTICAL', gap=0, cross='CENTER', name='Title block')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=800, color='kicker', align='CENTER', parent=col, name='Kicker')
        s.frame(0, 0, 10, 16, 'NONE', parent=col, name='Space')
    two_line_title(s, sp, col, 'display-xl', 'header', 800)
    s.vplace(col, 0, SLIDE_H)
    s.footer(sp)


@layout('composition', 'night', 'kicker, title, lead, bullets[]',
        'A component or page in one line, next to a tilted product wireframe on deep night (a composition update).',
        template='Component · Composition overview')
def l_composition(s, sp):
    s.background(sp.get('background') or 'deep')
    s.art('wireframe')
    col = s.frame(M, 0, 656, 10, 'VERTICAL', gap=24, name='Content')
    s.heading(sp, 656, col, subtitle='')
    if sp.get('lead'):
        s.t(sp['lead'], 'lead', w=656, color='muted', parent=col, name='Lead')
    if sp.get('bullets'):
        s.bullets(sp['bullets'], 656, col, color='text')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


# =========================================================================== 03 · Product & comparisons
@layout('image', 'day', 'kicker, title, subtitle, image, caption, chip, image_fit',
        'Title on top, one big screenshot or diagram on the stage below (flows, journeys).',
        template='Product · Large screenshot')
def l_image(s, sp):
    s.background(None)
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0)
    stage = s.rect(0, top - 24, SLIDE_W, SLIDE_H - top + 24, fill='stage')
    stage['name'] = 'Stage'
    bottom = LIMIT - (56 if sp.get('caption') else 0)
    visual(s, sp, M, top + 24, W, bottom - top - 24)
    if sp.get('caption'):
        s.t(sp['caption'], 'caption', M, bottom + 20, W, color='muted', align='CENTER', name='Caption')
    s.footer(sp)


@layout('walkthrough', 'day', 'kicker, title, video | image, poster, heading, bullets[], caption',
        'The current state, shown: a screen recording (or a screenshot) on Blue 5 with the issues listed beside it.',
        template='Component · Current-state walkthrough')
def l_walkthrough(s, sp):
    s.background('pale')
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    x, y, bw, bh = M, 328, 1120, 619
    if sp.get('video'):
        s.video(sp['video'], x, y, bw, bh, poster=sp.get('poster'), name='Walkthrough video')
    else:
        s.shot(sp.get('image'), x, y, bw, bh, valign='top', halign='left', name='Walkthrough screenshot')
    x0 = 1312
    w = SLIDE_W - M - x0
    col = s.frame(x0, y, w, 10, 'VERTICAL', gap=20, name='Notes')
    if sp.get('heading'):
        s.t(sp['heading'], 'heading', w=w, color='title', parent=col, name='Heading')
    if sp.get('bullets'):
        s.bullets(sp['bullets'], w, col, gap=16)
    if sp.get('caption'):
        s.t(sp['caption'], 'caption', M, y + bh + 20, bw, color='muted', name='Caption')
    s.footer(sp)


@layout('compare', 'day', 'kicker, title, left_label, right_label, left_image, right_image, left_caption, right_caption',
        'Current versus new: two screenshots side by side, an outline chip on the old one, an Energetic Green chip on the new one.',
        template='Comparison · Two screenshots')
def l_compare(s, sp):
    s.background(None)
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0)
    cw = (W - GAP) / 2
    for i, side in enumerate(('left', 'right')):
        x = M + i * (cw + GAP)
        s.chip(sp.get(f'{side}_label') or ('Current' if i == 0 else 'New'), None, x, top,
               variant='current' if i == 0 else 'new')
        cap = sp.get(f'{side}_caption')
        box_h = LIMIT - (top + 64) - (72 if cap else 0)
        s.shot(sp.get(f'{side}_image'), x, top + 64, cw, box_h, valign='top', name=f'{side.title()} screenshot')
        if cap:
            s.t(cap, 'small', x, LIMIT - 52, cw, color='muted', name=f'{side.title()} caption')
    s.footer(sp)


@layout('compare-laptop', 'day', 'kicker, title, left_label, right_label, left_image, right_image, left_caption, right_caption',
        'Current versus new on two laptops: each screenshot fills a laptop screen, chips above, captions below.',
        template='Comparison · Two laptop mockups')
def l_compare_laptop(s, sp):
    s.background(None)
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    for i, side in enumerate(('left', 'right')):
        x = M + i * 864
        s.chip(sp.get(f'{side}_label') or ('Current' if i == 0 else 'New'), None, x, 304,
               variant='current' if i == 0 else 'new')
        s.laptop(sp.get(f'{side}_image'), x, 368, name=f'{"Current" if i == 0 else "New"} screenshot')
        if sp.get(f'{side}_caption'):
            s.t(sp[f'{side}_caption'], 'caption-l', x, 893, 807, color='text', name=f'{side.title()} caption')
    s.footer(sp)


@layout('mobile', 'day', 'kicker, title, title_light, subtitle, body, bullets[], image (phone screen, about 9 x 19.5)',
        'A phone on a soft circle at the right showing the screenshot; title and text on the left.',
        template='Product · Mobile mockup')
def l_mobile(s, sp):
    s.background(None)
    cx = 1390
    s.dot(cx - 430, SLIDE_H / 2 - 430, 860, 'stage', name='Circle')
    col = content_column(s, sp, M, 760)
    s.vplace(col, TOP, LIMIT)
    pw, ph = 392, 812
    x, y = cx - pw / 2, (SLIDE_H - ph) / 2
    body = s.rect(x, y, pw, ph, fill='midnight', radius=64)
    body['name'] = 'Phone'
    from build_deck import shadow
    body['effects'] = [shadow('day')]
    s.shot(sp.get('image'), x + 14, y + 14, pw - 28, ph - 28, fit='cover', radius=52, frame=False, drop=False,
           name='Phone screen', placeholder='Phone screen')
    notch = s.rect(cx - 56, y + 30, 112, 30, fill='midnight', radius=15)
    notch['name'] = 'Notch'
    s.footer(sp)


@layout('variants', 'day', 'kicker, title, bullets[], variants[{name, tags[], image}] (1-3)',
        'A component\'s variants: a short list on the left, each variant on the light-blue stage with its name, its tags and a demo slot (a screenshot, or an empty slot to paste the component into).',
        template='Product · Variants & showcase')
def l_variants(s, sp):
    s.background(None)
    px = 486
    stage = s.rect(px, 0, SLIDE_W - px, SLIDE_H, fill='light-blue', opacity=0.2)
    stage['name'] = 'Stage'
    stage['locked'] = True
    w = px - 2 * 60
    col = s.frame(60, TOP, w, 10, 'VERTICAL', gap=78, name='Content')
    s.heading(sp, w, col, subtitle='')
    if sp.get('bullets'):
        s.bullets(sp['bullets'], w, col, kind='caption-l', gap=24)
    variants = (sp.get('variants') or [{}])[:3]
    n = len(variants)
    x0, inner = px + 93, SLIDE_W - px - 2 * 93
    slot_w = 512 if n <= 2 else (inner - 2 * 48) / 3
    gap = 64 if n <= 2 else 48
    for i, v in enumerate(variants):
        x = x0 + i * (slot_w + gap)
        if v.get('name'):
            s.chip(v['name'], None, x, 304, variant='dark')
        tags = s.frame(x, 361, slot_w, 41, 'HORIZONTAL', gap=12, hug_main=True, hug_cross=True, name='Tags')
        for tag in v.get('tags') or []:
            s.chip(tag, tags, variant='light')
        if v.get('image'):
            s.shot(v['image'], x, 426, slot_w, 371, name=f"{v.get('name') or 'Component'} demo")
        else:
            slot = s.rect(x, 426, slot_w, 371, fill='white', radius=16)
            slot['name'] = 'Media / Component demo · insert example'
    s.footer(sp)


@layout('content', 'day', 'kicker, title, subtitle, lead, body, bullets[], note, link{text,url}, image | embed_url, chip, split (33|40|50), image_fit (fit|fill)',
        'The workhorse: text column centred in the white panel on the left, the screenshot on a soft stage on the right. With embed_url it becomes a live prototype slide.',
        template='Product · Text & screenshot')
def l_content(s, sp):
    s.background(None)
    split = int(sp.get('split', 40))
    px = round(SLIDE_W * {25: 33, 33: 33, 40: 40, 50: 50}.get(split, 40) / 100)
    stage = s.rect(px, 0, SLIDE_W - px, SLIDE_H, fill='stage')
    stage['name'] = 'Stage'
    w = px - 2 * PM
    col = content_column(s, sp, PM, w)
    s.vplace(col, TOP, LIMIT)
    visual(s, sp, px + 80, 120, SLIDE_W - px - 160, 800)
    s.footer(sp, note=sp.get('note'), x=PM, w=w)


@layout('anatomy', 'day', 'kicker, title, groups[{title, bullets[] | text}] (1-3), columns[{label, image | images[], width}] (1-2)',
        'What was done, what comes, what follows: question-and-answer groups on the left; labelled screenshots of the parts (cells, rows) on the stage.',
        template='Component · Anatomy & delivery')
def l_anatomy(s, sp):
    s.background(None)
    px = 704
    stage = s.rect(px, 0, SLIDE_W - px, SLIDE_H, fill='stage')
    stage['name'] = 'Stage'
    stage['locked'] = True
    w = px - M - 48
    col = s.frame(M, TOP, w, 10, 'VERTICAL', gap=48, name='Content')
    s.heading(sp, w, col, subtitle='')
    groups = s.frame(0, 0, w, 10, 'VERTICAL', gap=32, parent=col, name='Groups')
    for g in (sp.get('groups') or [])[:3]:
        box = s.frame(0, 0, w, 10, 'VERTICAL', gap=16, parent=groups, name='Group')
        if g.get('title'):
            s.t(g['title'], 'heading', w=w, color='title', parent=box, name='Question')
        if g.get('text'):
            s.t(g['text'], 'body', w=w, color='text', parent=box, name='Answer')
        if g.get('bullets'):
            s.bullets(g['bullets'], w, box, gap=16)
    columns = (sp.get('columns') or [])[:2]
    if columns:
        x0, inner, cgap = px + 96, SLIDE_W - px - 96 - 80, 52
        weights = [float(c.get('width') or 1) for c in columns]
        widths = [(inner - cgap * (len(columns) - 1)) * wt / sum(weights) for wt in weights]
        x = x0
        for c, cw in zip(columns, widths):
            if c.get('label'):
                s.chip(c['label'], None, x, 228, variant='new')
            imgs = c.get('images') or [c.get('image')]  # no picture yet: one placeholder for the column
            y, bottom = 288, LIMIT
            room = (bottom - y - 24 * (len(imgs) - 1)) / max(1, len(imgs))
            for k, img in enumerate(imgs):
                dims = image_size_of(s, img)
                h = min(room, cw * dims[1] / dims[0]) if dims else room
                node = s.shot(img, x, y, cw, h, valign='top', name=f"{c.get('label') or 'Part'} {k + 1}")
                y = node['transform']['m12'] + node['size']['y'] + 24
            x += cw + cgap
    s.footer(sp)


@layout('showcase', 'day', 'kicker, title, subtitle, lead, bullets[], closing, image, source (one or a list of {text,url})',
        'A feature argued with evidence on Daylight Blue 60: the case on the left (a line in the highlight colour, the facts, a closing line), the picture and its sources on the right.',
        template='Component · Shortcuts & evidence')
def l_showcase(s, sp):
    s.background('ice')
    head = s.heading(sp, 1664, None, subtitle='')
    s.place(head, M, TOP)
    w = 650
    col = s.frame(M, 280, w, 10, 'VERTICAL', gap=40, name='Content')
    if sp.get('subtitle'):
        s.t(sp['subtitle'], 'lead', w=w, color='highlight', parent=col, name='Subtitle')
    if sp.get('lead'):
        s.t(sp['lead'], 'lead', w=w, color='text', parent=col, name='Lead')
    if sp.get('bullets'):
        s.bullets(sp['bullets'], w, col, gap=16)
    if sp.get('closing'):
        s.t(sp['closing'], 'body', w=w, color='text', parent=col, name='Closing')
    s.shot(sp.get('image'), 912, 280, 880, 460, frame=False, drop=False, name='Showcase')
    if sp.get('source'):  # one link per line under the picture
        items = sp['source'] if isinstance(sp['source'], list) else [sp['source']]
        from build_deck import source_text
        s.t('\n'.join(['Source:'] + [source_text(it, '') for it in items]), 'small', 976, 792, 816, color='text',
            name='Source')
    s.footer(sp, note=sp.get('note') or '')


@layout('collage', 'day', 'kicker, title, subtitle, lead, body, bullets[], images[] (2-8)',
        'An audit in pictures: the findings on the left, a two-column collage of screenshot crops on the stage.',
        template='Component · Audit collage')
def l_collage(s, sp):
    s.background(None)
    px = 768
    stage = s.rect(px, 0, SLIDE_W - px, SLIDE_H, fill='stage')
    stage['name'] = 'Stage'
    stage['locked'] = True
    w = px - M - 64
    col = s.frame(M, TOP, w, 10, 'VERTICAL', gap=56, name='Content')
    s.heading(sp, w, col, subtitle='')
    body = s.frame(0, 0, w, 10, 'VERTICAL', gap=24, parent=col, name='Findings')
    if sp.get('subtitle'):
        s.t(sp['subtitle'], 'lead', w=w, color='highlight', parent=body, name='Subtitle')
    if sp.get('lead'):
        s.t(sp['lead'], 'lead', w=w, color='text', parent=body, name='Lead')
    if sp.get('body'):
        s.t(sp['body'], 'body', w=w, color='text', parent=body, name='Body')
    if sp.get('bullets'):
        s.bullets(sp['bullets'], w, body, gap=12)
    imgs = (sp.get('images') or [])[:8]
    if imgs:
        cw, gap, top, bottom = 448.0, 40.0, 304.0, float(LIMIT)
        dims = [image_size_of(s, p) or (16, 9) for p in imgs]
        k = 1.0
        for _ in range(8):  # masonry in two columns, shrunk until both fit above the footer
            heights = [cw * k * d[1] / d[0] for d in dims]
            cols, place = [0.0, 0.0], []
            for h in heights:
                c = 0 if cols[0] <= cols[1] else 1
                place.append((c, cols[c]))
                cols[c] += h + gap
            if max(cols) - gap <= bottom - top or k < 0.4:
                break
            k *= (bottom - top) / (max(cols) - gap)
        colw = cw * k
        x0 = px + (SLIDE_W - px - 2 * colw - 48) / 2
        for p, (c, y), h in zip(imgs, place, heights):
            s.shot(p, x0 + c * (colw + 48), top + y, colw, h, radius=8, name='Evidence')
    s.footer(sp)


@layout('intro', 'day', 'kicker, title, subtitle (a line or a list of lines, in the highlight colour), lead, image (illustration)',
        'Topic intro on day: title and a one-line definition on the left, a big illustration on the stage at the right.',
        template='Product · Feature spotlight')
def l_intro(s, sp):
    s.background(None)
    px = 1000
    stage = s.rect(px, 0, SLIDE_W - px, SLIDE_H, fill='stage')
    stage['name'] = 'Stage'
    w = px - M - GAP
    col = s.frame(M, 0, w, 10, 'VERTICAL', gap=36, name='Content')
    s.heading(sp, w, col, title_kind='display-s', subtitle='')
    sub = sp.get('subtitle')
    if sub:
        s.t('\n'.join(sub) if isinstance(sub, list) else sub, 'subtitle', w=w, color='highlight', parent=col,
            name='Subtitle')
    if sp.get('lead'):
        s.t(sp['lead'], 'lead', w=w, color='muted', parent=col, name='Lead')
    s.vplace(col, TOP, LIMIT)
    s.shot(sp.get('image'), px + 80, 120, SLIDE_W - px - 160, 800, frame=False, drop=False, radius=0,
           name='Illustration', placeholder='Illustration')
    s.footer(sp)


# =========================================================================== 04 · Research & evidence
@layout('circle-list', 'night', 'kicker, title (inside the circle), lead, items[], markers (none|letters|check|numbers), background (night|day|blue)',
        'A big circle on the left holding the title, a list on the right: polls (A/B/C/D), opportunity areas, checklists.',
        template='Poll · Four options')
def l_circle_list(s, sp):
    bg, th = bg_theme(sp.get('background'), 'night')
    s.theme(th)
    s.background(bg)
    d = 760
    cx, cy = 96, (SLIDE_H - d) / 2
    from build_deck import gradient
    circle = s.dot(cx, cy, d, None, name='Circle')
    fill = {'night': [['twilight', 1, 0], ['reviewpro', 1, 1]], 'day': [['reviewpro', 1, 0], ['blue-3', 1, 1]],
            'blue': [['twilight', 1, 0], ['midnight', 1, 1]]}[s.th['name']]
    circle['fillPaints'] = [gradient({'type': 'linear', 'angle': 160, 'stops': fill}, d, d)]
    inner = s.frame(cx + 100, 0, d - 200, 10, 'VERTICAL', gap=16, cross='CENTER', name='Title')
    s.t(sp.get('title', ''), 'display-s', w=d - 200, color='white', align='CENTER', parent=inner, size=72, name='Title')
    s.vplace(inner, cy, cy + d)
    x0 = cx + d + 112
    w = SLIDE_W - M - x0
    col = s.frame(x0, 0, w, 10, 'VERTICAL', gap=40, name='List')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=w, color='kicker', parent=col, name='Kicker')
    if sp.get('lead'):
        s.t(sp['lead'], 'lead', w=w, color='muted', parent=col, name='Lead')
    marker = {'letters': 'letter', 'check': 'check', 'numbers': 'number', 'none': 'none'}.get(sp.get('markers', 'none'), 'dot')
    if sp.get('markers') is None:
        marker = 'dot'
    s.bullets(sp.get('items') or [], w, col, kind='lead', marker=marker, color='title', gap=32)
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('content-dark', 'night', 'kicker, title, title_light, subtitle, body, items[] (numbered), bullets[]',
        'Text-only on night: heading and a paragraph on the left, a numbered list (or green-dot bullets) on the right.',
        template='Plan · Three deliverables')
def l_content_dark(s, sp):
    s.background(sp.get('background') or 'night')
    items = items_of(sp, 'items')
    bullets = items_of(sp, 'bullets')
    if items or bullets:
        col = content_column(s, sp, M, 680, bullets_key='_none')
        s.vplace(col, TOP, LIMIT)
        lst = s.bullets(items or bullets, SLIDE_W - M - 900, None, kind='lead' if len(items or bullets) <= 4 else 'body',
                        marker='number' if items else 'dot', color='text', gap=36)
        s.place(lst, 900, 0)
        s.vplace(lst, TOP, LIMIT)
    else:
        col = content_column(s, sp, M, 1200)
        s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('content-glow', 'night', 'kicker, title, title_light, subtitle, body, bullets[]',
        'Text-only on the night horizon: a heading, a subtitle line and a paragraph (scenarios, briefs).',
        template='Brief · Scenario')
def l_content_glow(s, sp):
    s.background(sp.get('background') or 'horizon')
    col = content_column(s, sp, M, 1180)
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('content-gradient', 'night', 'kicker, title, lead, body, bullets[]',
        'Legacy look: a scenario or brief in white on the violet field of the previous template, fading to white at the bottom right. Use on purpose, about one per deck.',
        template='Brief · Gradient scenario')
def l_content_gradient(s, sp):
    s.background('day')
    s.art('scenario-gradient')
    col = s.frame(M, 0, 831, 10, 'VERTICAL', gap=40, name='Content')
    s.heading(sp, 831, col, subtitle='')
    for key in ('lead', 'body'):  # both paragraphs in the lead size, as in the template
        if sp.get(key):
            s.t(sp[key], 'lead', w=831, color='title', parent=col, name=key.title())
    if sp.get('bullets'):
        s.bullets(sp['bullets'], 831, col, color='title')
    s.vplace(col, 220, LIMIT, 'top')
    s.footer(sp, logo=False)
    if sp.get('logo', True) is not False:
        s.logo(SLIDE_W - M - LOGO_W, FOOT, white=False)  # the field fades to white behind the logo


@layout('quote-cards', 'night', 'kicker, title, subtitle, lead, quotes[{text,who}] (2-3), source{text,url}',
        'Text on the left, two or three short user quotes as glass cards on the right.',
        template='Quotes · Three testimonials')
def l_quote_cards(s, sp):
    s.background(sp.get('background') or 'night')
    col = content_column(s, sp, M, 640)
    s.vplace(col, TOP, LIMIT)
    x0 = 880
    w = SLIDE_W - M - x0
    cards = s.frame(x0, 0, w, 10, 'VERTICAL', gap=24, name='Quotes')
    for q in (sp.get('quotes') or [])[:3]:
        card = s.frame(0, 0, w, 10, 'VERTICAL', gap=20, pad=(36, 44), parent=cards, fill='surface', stroke='border',
                       radius=TOKENS['radius']['card'], name='Quote card')
        s.t(str(q.get('text', '')).strip('“”"'), 'quote-s', w=w - 88, color='title', parent=card, name='Quote')
        if q.get('who'):
            s.t(q['who'], 'label', w=w - 88, color='highlight', parent=card, name='Who')
    s.vplace(cards, TOP, LIMIT)
    s.footer(sp)


@layout('quotes', 'day', 'kicker, title, quotes[{text,who}] (2-6), closing, source{text,url}',
        'Voice of the customer: short quotes in a grid of two or three columns, the hotel or role under each.',
        template='Quotes · Four cards')
def l_quotes(s, sp):
    s.background('daylight' if s.th['name'] == 'day' else None)
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    quotes = (sp.get('quotes') or [])[:6]
    cols = 2 if len(quotes) in (2, 4) else 3
    cw = (W - 48 * (cols - 1)) / cols
    grid = s.frame(M, 0, W, 10, 'VERTICAL', gap=48, name='Quotes')
    for r in range(0, len(quotes), cols):
        row = s.frame(0, 0, W, 10, 'HORIZONTAL', gap=48, parent=grid, hug_main=False, hug_cross=True, name='Row')
        for q in quotes[r:r + cols]:
            cell = s.frame(0, 0, cw, 10, 'VERTICAL', gap=16, pad=(32, 36), parent=row,
                           fill='white' if s.th['name'] == 'day' else 'surface', stroke='border',
                           radius=TOKENS['radius']['card'], name='Quote')
            s.t('“', 'display', w=80, color='highlight', parent=cell, size=88, line=56, name='Quote mark')
            s.t(str(q.get('text', '')).strip('“”"'), 'quote-s', w=cw - 72, color='title', parent=cell,
                size=32 if len(quotes) > 3 else 36, name='Quote')
            if q.get('who'):
                s.t(q['who'], 'label', w=cw - 72, color='muted', parent=cell, name='Who')
        s.equal_heights(row)
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0)
    bottom = LIMIT - (80 if sp.get('closing') else 0)
    s.vplace(grid, top, bottom)
    if sp.get('closing'):
        s.t(sp['closing'], 'heading', M, LIMIT - 44, W, color='title', name='Closing')
    s.footer(sp)


@layout('icons', 'day', 'kicker, title, body, highlight, heading, items[{icon,title,text}] (up to 4)',
        'A light panel on the left with the why; up to four icon items on the right (key projects, principles). Icons: integrations, space, settings, question, flag.',
        template='Roadmap · Four initiatives')
def l_icons(s, sp):
    s.background(None)
    pw = 720
    panel = s.rect(0, 0, pw, SLIDE_H, fill='stage')
    panel['name'] = 'Panel'
    col = s.frame(M, 0, pw - M - GAP, 10, 'VERTICAL', gap=36, name='Why')
    s.heading(sp, pw - M - GAP, col, subtitle='')
    if sp.get('body'):
        s.t(sp['body'], 'body', w=pw - M - GAP, color='text', parent=col, name='Body')
    if sp.get('highlight'):
        s.t(sp['highlight'], 'heading', w=pw - M - GAP, color='highlight', parent=col, size=28, name='Highlight')
    s.vplace(col, TOP, LIMIT)
    x0 = pw + 96
    w = SLIDE_W - M - x0
    right = s.frame(x0, 0, w, 10, 'VERTICAL', gap=56, name='Items')
    if sp.get('heading'):
        s.t(sp['heading'], 'heading', w=w, color='title', parent=right, name='Heading')
    items = (sp.get('items') or [])[:4]
    cw = (w - 56) / 2
    for r in range(0, len(items), 2):
        row = s.frame(0, 0, w, 10, 'HORIZONTAL', gap=56, parent=right, hug_main=False, hug_cross=True, name='Row')
        for it in items[r:r + 2]:
            cell = s.frame(0, 0, cw, 10, 'VERTICAL', gap=16, parent=row, name='Item')
            s.icon(it.get('icon', 'settings'), 0, 0, 72, fill='highlight', parent=cell)
            s.frame(0, 0, 10, 4, 'NONE', parent=cell, name='Space')
            s.t(it.get('title', ''), 'heading', w=cw, color='title', parent=cell, size=28, name='Title')
            if it.get('text'):
                s.t(it['text'], 'small', w=cw, color='muted', parent=cell, name='Text')
    s.vplace(right, TOP, LIMIT)
    s.footer(sp)


@layout('people', 'day', 'kicker, title, people[{image,name,role,quote}] (up to 5), footer',
        'A row of people or personas: round photo (or initials), name, role and a one-line quote.',
        template='People · Four personas')
def l_people(s, sp):
    s.background(None)
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    people = (sp.get('people') or [])[:5]
    n = max(1, len(people))
    cw = (W - 32 * (n - 1)) / n
    row = s.frame(M, 0, W, 10, 'HORIZONTAL', gap=32, hug_main=False, hug_cross=True, name='People')
    for p in people:
        card = s.frame(0, 0, cw, 10, 'VERTICAL', gap=16, pad=(40, 28), parent=row, fill='stage',
                       radius=TOKENS['radius']['card'], cross='CENTER', name=p.get('name') or 'Person')
        avatar(s, p, 168, card)
        s.frame(0, 0, 10, 4, 'NONE', parent=card, name='Space')
        s.t(p.get('name', ''), 'heading', w=cw - 56, color='title', align='CENTER', parent=card, size=28, name='Name')
        if p.get('role'):
            s.t(p['role'], 'label', w=cw - 56, color='highlight', align='CENTER', parent=card, name='Role')
        if p.get('quote'):
            s.t(str(p['quote']).strip('“”"'), 'quote-s', w=cw - 56, color='muted', align='CENTER', parent=card, size=24,
                name='Quote')
    s.equal_heights(row)
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0)
    s.vplace(row, top, LIMIT)
    s.footer(sp, note=sp.get('footer'))


def avatar(s, p, d, parent):
    full = s.image_file(p.get('image'))
    if full:
        node = s.dot(0, 0, d, None, parent=parent, name='Media / Photo · replace image fill')
        paint, _ = s.b.image_paint(full, 'FILL')
        node['fillPaints'] = [paint]
        return node
    from build_deck import gradient
    f = s.frame(0, 0, d, d, 'HORIZONTAL', parent=parent, radius=d / 2, align='CENTER', cross='CENTER',
                hug_main=False, name='Initials')
    f['fillPaints'] = [gradient({'type': 'linear', 'angle': 135, 'stops': [['reviewpro', 1, 0], ['meridian', 1, 1]]}, d, d)]
    initials = p.get('initials') or ''.join(w[0] for w in str(p.get('name', '?')).split()[:2]).upper() or '?'
    s.t(initials, 'stat-s', w=d, color='white', align='CENTER', parent=f, size=64, name='Initials')
    return f


@layout('columns', 'night', 'kicker, title, subtitle, columns[{title, text | bullets[]}] (2-3)',
        'Two or three columns, each with a highlighted heading (the two-column slide of the original brand deck).',
        template='Findings · Three columns')
def l_columns(s, sp):
    s.background(sp.get('background') or ('night' if s.th['name'] == 'night' else None))
    head = s.heading(sp, W, None)
    s.place(head, M, TOP)
    cols = (sp.get('columns') or [])[:3]
    n = max(1, len(cols))
    cw = (W - GAP * (n - 1)) / n
    row = s.frame(M, 0, W, 10, 'HORIZONTAL', gap=GAP, hug_main=False, hug_cross=True, name='Columns')
    for c in cols:
        cell = s.frame(0, 0, cw, 10, 'VERTICAL', gap=24, parent=row, name='Column')
        line = s.rect(0, 0, 48, 4, fill='highlight', radius=2, parent=cell)
        line['name'] = 'Accent'
        s.t(c.get('title', ''), 'heading', w=cw, color='highlight', parent=cell, name='Heading')
        if c.get('text'):
            s.t(c['text'], 'body', w=cw, color='text', parent=cell, name='Text')
        if c.get('bullets'):
            s.bullets(c['bullets'], cw, cell, kind='small')
    top = TOP + (210 if sp.get('subtitle') else 150) + (50 if sp.get('kicker') else 0) + 40
    s.vplace(row, top, LIMIT)
    s.footer(sp)


@layout('stats', 'night', 'kicker, title, subtitle, lead, bullets[], stats[{value,label}] (2-4), source{text,url}',
        'Proof in numbers: Night Serif figures with a hairline above each, the first one in Energetic Green.',
        template='Metrics · Three values')
def l_stats(s, sp):
    s.background(sp.get('background') or 'night')
    stats = (sp.get('stats') or [])[:4]
    side = bool(sp.get('lead') or sp.get('bullets'))
    if side:
        col = content_column(s, sp, M, 640)
        s.vplace(col, TOP, LIMIT)
        x0, w = 880, SLIDE_W - M - 880
        grid = s.frame(x0, 0, w, 10, 'VERTICAL', gap=56, name='Numbers')
        cols = 2 if len(stats) > 2 else 1
        cw = (w - 56 * (cols - 1)) / cols
        for r in range(0, len(stats), cols):
            row = s.frame(0, 0, w, 10, 'HORIZONTAL', gap=56, parent=grid, hug_main=False, hug_cross=True, name='Row')
            for j, st in enumerate(stats[r:r + cols]):
                stat_cell(s, st, cw, row, first=(r + j == 0), kind='stat-s')
        s.vplace(grid, TOP, LIMIT)
    else:
        head = s.heading(sp, W, None)
        s.place(head, M, TOP)
        n = max(1, len(stats))
        cw = (W - 56 * (n - 1)) / n
        row = s.frame(M, 0, W, 10, 'HORIZONTAL', gap=56, hug_main=False, hug_cross=True, name='Numbers')
        for j, st in enumerate(stats):
            stat_cell(s, st, cw, row, first=(j == 0), kind='stat' if n <= 3 else 'stat-s')
        s.vplace(row, 330, LIMIT - 40)
    s.footer(sp)


def stat_cell(s, st, w, parent, first=False, kind='stat'):
    cell = s.frame(0, 0, w, 10, 'VERTICAL', gap=20, parent=parent, name='Number')
    line = s.rect(0, 0, w, 2, fill='highlight' if first else 'border', parent=cell)
    line['name'] = 'Hairline'
    s.frame(0, 0, 10, 8, 'NONE', parent=cell, name='Space')
    s.t(str(st.get('value', '')), kind, w=w, color='highlight' if first else 'title', parent=cell, name='Value')
    if st.get('label'):
        s.t(st['label'], 'small', w=w, color='muted', parent=cell, name='Label')
    return cell


# =========================================================================== 05 · Plans & briefs (key moments)
@layout('quote', 'night', 'kicker (or title), text, who, footer',
        'One hero quote on deep night: a big green quote mark, the quote in Night Serif, who said it.',
        template='Quote · Hero')
def l_quote(s, sp):
    s.background(sp.get('background') or 'deep')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=28, cross='CENTER', name='Quote')
    label = sp.get('kicker') or sp.get('title')
    if label:
        s.t(label, 'kicker', w=W, color='muted', align='CENTER', parent=col, name='Kicker')
    s.t('“', 'display', w=200, color='highlight', align='CENTER', parent=col, size=200, line=170, name='Quote mark')
    s.t(str(sp.get('text', '')).strip('“”"'), 'quote', w=1440, color='title', align='CENTER', parent=col, name='Quote')
    if sp.get('who'):
        s.t(sp['who'], 'label', w=W, color='muted', align='CENTER', parent=col, name='Who')
    if sp.get('footer'):
        s.t(sp['footer'], 'footnote', w=1200, color='muted', align='CENTER', parent=col, name='Footer')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('statement', 'night', 'kicker, text (==x== or **x** for the punchline), sub, background (night|deep|blue|aurora|day)',
        'One sentence in Night Serif, centred, with the punchline in the highlight colour.',
        template='Statement · Full width')
def l_statement(s, sp):
    bg, th = bg_theme(sp.get('background'), 'night')
    s.theme(th)
    s.background(bg)
    text = str(sp.get('text', '')).replace('**', '==')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=40, cross='CENTER', name='Statement')
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
    s.t(text, 'statement', w=1480, color='title', align='CENTER', parent=col, name='Statement')
    if sp.get('sub'):
        s.t(sp['sub'], 'subtitle', w=1200, color='muted', align='CENTER', parent=col, name='Sub')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('slogan', 'day', 'text (default: the design-team slogan)',
        'The design-team slogan in Night Serif under the round flag button. Keep the wording as it is.',
        template='Design-team slogan')
def l_slogan(s, sp):
    s.background(None)
    col = s.frame(573, 0, 774, 10, 'VERTICAL', gap=24, cross='CENTER', name='Content')
    s.art('flag-button', parent=col)
    s.t(sp.get('text') or SLOGAN, 'slogan', w=774, color='ink', align='CENTER', parent=col, name='Slogan')
    s.vplace(col, 0, SLIDE_H)
    s.footer(sp)


@layout('question', 'day', 'kicker, icon (question|settings|integrations|space|flag), title, text, serif (bool)',
        'A question to the room on a quiet day background: round icon, Night Serif question, a short line under it.',
        template='Question · Context')
def l_question(s, sp):
    s.background('daylight' if s.th['name'] == 'day' else None)
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=36, cross='CENTER', name='Question')
    s.icon(sp.get('icon', 'question'), 0, 0, 96, fill='highlight' if s.th['name'] == 'day' else 'reviewpro', parent=col)
    if sp.get('kicker'):
        s.t(sp['kicker'], 'kicker', w=W, color='kicker', align='CENTER', parent=col, name='Kicker')
    s.t(sp.get('title', ''), 'display-s', w=1400, color='title', align='CENTER', parent=col, name='Question')
    if sp.get('text'):
        s.t(sp['text'], 'quote-s' if sp.get('serif') else 'lead', w=1100, color='muted', align='CENTER', parent=col,
            name='Text')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


# =========================================================================== 07 · Visuals & closing
@layout('split', 'night', 'kicker, title, subtitle, image, side (right|left), background (night|blue|day|daylight)',
        'Half and half: a title on a colour half, a full-bleed picture on the other half.',
        template='Visual · Split image & text')
def l_split(s, sp):
    bg, th = bg_theme(sp.get('background'), 'night')
    s.theme(th)
    s.background(bg)
    half = SLIDE_W / 2
    img_x = 0 if sp.get('side') == 'left' else half
    s.shot(sp.get('image'), img_x, 0, half, SLIDE_H, fit='cover', radius=0, frame=False, drop=False,
           name='Picture', placeholder='Picture')
    tx = half + M if img_x == 0 else M
    w = half - M - GAP
    col = s.frame(tx, 0, w, 10, 'VERTICAL', gap=28, name='Content')
    s.heading(sp, w, col, title_kind='display-s')
    s.vplace(col, TOP, LIMIT)
    if sp.get('logo', True) is not False:  # over the picture on the right: white
        s.logo(SLIDE_W - M - LOGO_W, FOOT, white=img_x > 0 or s.tc('logo') == 'white')


@layout('picture', 'night', 'image, image_fit (fill|fit), background, caption',
        'One picture across the whole slide (a meme, a photo, a finished visual), with an optional caption chip.',
        template='Visual · Full bleed')
def l_picture(s, sp):
    bg, th = bg_theme(sp.get('background'), 'night-plain')
    s.theme(th)
    s.background(bg)
    fit = 'contain' if sp.get('image_fit') == 'fit' else 'cover'
    s.shot(sp.get('image'), 0, 0, SLIDE_W, SLIDE_H, fit=fit, radius=0, frame=False, drop=False, name='Picture',
           placeholder='Picture')
    if sp.get('caption'):
        s.pill(sp['caption'], None, M, FOOT - 24, fill=['night', 0.72], color='white', kind='caption', pad=(12, 24),
               name='Caption')


@layout('meme', 'day', 'image, text, icon, serif (default true), caption',
        'Comedic relief: the meme framed on the left, the punchline on the right.',
        template='Visual · Image & punchline')
def l_meme(s, sp):
    s.background('daylight' if s.th['name'] == 'day' else None)
    s.shot(sp.get('image'), M, 120, 1060, 800, radius=24, name='Meme', placeholder='Meme')
    x0 = M + 1060 + GAP
    w = SLIDE_W - M - x0
    col = s.frame(x0, 0, w, 10, 'VERTICAL', gap=28, name='Punchline')
    if sp.get('icon'):
        s.icon(sp['icon'], 0, 0, 72, fill='highlight', parent=col)
    s.t(sp.get('text', ''), 'quote' if sp.get('serif', True) else 'title-s', w=w, color='title', parent=col,
        size=52 if sp.get('serif', True) else None, name='Punchline')
    if sp.get('caption'):
        s.t(sp['caption'], 'caption', w=w, color='muted', parent=col, name='Caption')
    s.vplace(col, TOP, LIMIT)
    s.footer(sp)


@layout('thanks', 'night', 'title (default "Thank you"), subtitle, cta (button text), contact',
        'Closing slide on the aurora: big Night Serif title, subtitle, an Energetic Green button and a contact line.',
        template='Closing · Thank you')
def l_thanks(s, sp):
    s.background(sp.get('background') or 'aurora')
    s.brand_logo((SLIDE_W - LOGO_W) / 2, 88, 'white')
    col = s.frame(M, 0, W, 10, 'VERTICAL', gap=40, cross='CENTER', name='Title block')
    s.t(sp.get('title') or 'Thank you', 'display', w=1560, color='title', align='CENTER', parent=col, size=136,
        name='Title')
    if sp.get('subtitle'):
        s.t(sp['subtitle'], 'subtitle', w=1200, color='muted', align='CENTER', parent=col, name='Subtitle')
    if sp.get('cta'):
        s.pill(sp['cta'], col, kind='heading', pad=(18, 40), name='Button')
    s.vplace(col, 200, 900)
    if sp.get('contact'):
        s.t(sp['contact'], 'label', M, FOOT, W, color='muted', align='CENTER', name='Contact')
