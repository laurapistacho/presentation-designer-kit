#!/usr/bin/env python3
"""Build a Figma Slides file from a deck spec (JSON) in the Shiji Day & Night design.

    python3 build_deck.py deck.json --out "Design Updates Q4.fig"
    python3 build_deck.py deck.json --out out.fig --preview preview/ --pptx out.pptx
    python3 build_deck.py --layouts            # every layout and its fields

The look comes from the presentation-brand skill (assets/tokens.json): colours, gradients, type
scale and the day, night and blue themes. The file skeleton (pages, the Shiji logo component,
icons, colour variables) comes from the Product Presentation Template, so the result opens in Figma
Slides as a normal Slides file with the brand colours as local variables ("Shiji Day & Night").

Write the output as `.fig`: Figma's file browser imports .fig files by drag and drop (it refuses the
.deck extension). The content is the same Slides file either way.

Text in the spec supports **bold**, ==highlight== (Energetic Green on night slides, Reviewpro Blue
on day slides), [link text](https://url) and line breaks ("\\n"). Image paths are relative to the spec.
"""
import argparse
import copy
import hashlib
import html
import json
import math
import os
import re
import struct
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
if __name__ == '__main__':  # layouts.py imports this module by name: let it find this copy, not a second one
    sys.modules.setdefault('build_deck', sys.modules['__main__'])
import figdeck  # noqa: E402
import render_deck  # noqa: E402

# The kit root is four levels up: <kit>/.kiro/skills/figma-slides-builder/scripts/
KIT_ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..', '..'))
TEMPLATE = os.environ.get('PRESENTATION_TEMPLATE') or os.path.join(KIT_ROOT, 'template', 'Product Presentation Template.deck')
TOKENS_FILE = os.environ.get('PRESENTATION_TOKENS') or os.path.join(
    KIT_ROOT, '.kiro', 'skills', 'presentation-brand', 'assets', 'tokens.json')
with open(TOKENS_FILE, encoding='utf-8') as _tokens:
    TOKENS = json.load(_tokens)
NO_STYLE = {'guid': {'sessionID': 4294967295, 'localID': 4294967295}}
SLIDE_W, SLIDE_H, SLIDE_GAP = 1920, 1080, 240

# Template slides (1-based order in the template) -> SLIDE node id.
T = {1: '2038:126', 2: '2013:121', 3: '2040:322', 4: '1:119', 5: '2013:268', 6: '1:146', 7: '1:160', 8: '2002:2389',
     9: '2038:159', 10: '2038:137', 11: '2013:185', 12: '2013:150', 13: '2002:3166', 14: '2002:2370', 15: '2002:2394',
     16: '2038:239', 17: '2002:3095', 18: '2002:3037', 19: '2:4570', 20: '2013:171'}

# Brand colours become the local colour variables of every file ("Shiji Day & Night" collection).
# The template's own local collection is renamed and re-valued; its variables are reused by these ids,
# and the colours it lacks are added to it.
VARIABLE_SET = '1:123'
REUSE_VARIABLE = {'white': '1:124', 'night': '1:125', 'twilight': '1:126', 'reviewpro': '1:149', 'midnight': '1:181',
                  'moonlight': '2:1745', 'blue-3': '2:3915', 'green': '2002:2368', 'meridian': '2002:2369',
                  'daylight-60': '2002:2435', 'blue-5': '2002:2436', 'daylight': '2002:2437', 'daylight-30': '2002:2438'}
# token -> (hex, variable id); the ids of added variables are filled in by Builder.brand_variables().
PALETTE = {k: (v['hex'], REUSE_VARIABLE.get(k)) for k, v in TOKENS['colors'].items()}

# Template text styles used for new text.
STYLES = {'Header': '2038:169', 'Header Night': '2038:168', 'H2': '2038:171', 'H2 Lato': '2038:172',
          'H3 Lato': '2038:173', 'H4': '2038:170', 'Body': '2038:167', 'Quote': '2038:174',
          'Body 3': '2002:2397', 'Note': '2002:3097', 'Body 2': '2002:2374'}

POSTSCRIPT = {'Lato': 'Lato-{}', 'Shiji Day Sans Aeonik': 'ShijiDaySansAeonik-{}', 'Noto Sans': 'NotoSans-{}',
              'Shiji Night Serif Reckless Neue': 'ShijiNightSerifRecklessNeue-{}', 'Noto Sans Mono': 'NotoSansMono-{}'}
BOLDER = {'Thin': 'Bold', 'Air': 'Bold', 'Light': 'Bold', 'Regular': 'Bold', 'Book': 'Bold', 'Medium': 'Bold',
          'SemiBold': 'Bold', 'Bold': 'Black', 'Black': 'Black', 'Heavy': 'Heavy'}


def bolder(family, style):
    """The bold style of a family for **bold** runs (Reckless Neue has Regular and Heavy only)."""
    return (TOKENS.get('bold', {}).get(family) or {}).get(style) or BOLDER.get(style, 'Bold')

ICONS = {'integrations': '2038:205', 'space': '2038:207', 'settings': '2038:209', 'question': '2040:378'}
# The template's own instance of each icon: copied, then scaled; never re-pointed at another component.
ICON_INSTANCES = {'question': '2002:2385', 'integrations': '2038:257', 'space': '2038:264', 'settings': '2038:271'}

# Template layers the Day & Night layouts copy: a plain text layer, an auto-layout frame, the base slide.
TEXT_PROTO, FRAME_PROTO, BASE_SLIDE = '2002:2391', '2013:156', 14
LOGO_W, LOGO_H = 91, 48

# Figma Slides stores a slide's transition as an on-click link from that slide to the next one
# (every template slide carries one). Spec names -> Figma transition and easing names.
TRANSITIONS = {'none': 'INSTANT_TRANSITION', 'instant': 'INSTANT_TRANSITION', 'dissolve': 'DISSOLVE',
               'smart-animate': 'SMART_ANIMATE', 'slide-from-right': 'SLIDE_FROM_RIGHT',
               'slide-from-left': 'SLIDE_FROM_LEFT', 'slide-from-bottom': 'SLIDE_FROM_BOTTOM',
               'slide-from-top': 'SLIDE_FROM_TOP', 'push-from-right': 'PUSH_FROM_RIGHT',
               'push-from-left': 'PUSH_FROM_LEFT', 'move-from-right': 'MOVE_FROM_RIGHT',
               'move-from-left': 'MOVE_FROM_LEFT'}
EASINGS = {'ease-out': 'OUT_CUBIC', 'ease-in': 'IN_CUBIC', 'ease-in-out': 'INOUT_CUBIC', 'linear': 'LINEAR',
           'gentle': 'GENTLE_SPRING'}
ROW_BREAK_LAYOUTS = ('section', 'section-flat')


# --------------------------------------------------------------------------- small helpers
def color(value):
    """'#RRGGBB', a brand colour name ('midnight', 'blue-5') or {'r','g','b'} -> (rgba dict, variable id or None)."""
    if isinstance(value, dict):
        return value, None
    var = None
    key = str(value).strip().lower().replace(' ', '-').replace('_', '-')
    if key in PALETTE:
        value, var = PALETTE[key]
    h = str(value).lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    if not re.fullmatch(r'[0-9a-fA-F]{6}', h):
        raise ValueError(f'Unknown colour "{value}". Use a brand colour name ({", ".join(TOKENS["colors"])}) or #RRGGBB.')
    c = {'r': int(h[0:2], 16) / 255, 'g': int(h[2:4], 16) / 255, 'b': int(h[4:6], 16) / 255, 'a': 1.0}
    return c, var


def solid(value, opacity=1.0):
    if isinstance(value, (list, tuple)):  # ['white', 0.12]: a colour with its opacity
        value, opacity = value[0], float(value[1]) * opacity
    c, var = color(value)
    p = {'type': 'SOLID', 'color': c, 'opacity': opacity, 'visible': True, 'blendMode': 'NORMAL'}
    if var:
        p['colorVar'] = {'value': {'alias': {'guid': figdeck.guid(var)}}, 'dataType': 'ALIAS', 'resolvedDataType': 'COLOR'}
    return p


def _inverse(m):
    a, b, c, d, e, f = m
    det = a * e - b * d
    return [e / det, -b / det, (b * f - c * e) / det, -d / det, a / det, (c * d - a * f) / det]


def gradient(spec, w, h):
    """A token gradient ({'type': 'linear', 'angle': 135, 'stops': [[colour, alpha, position]]} or
    {'type': 'radial', 'at': [x, y], 'size': [rx, ry], ...}, CSS semantics) -> a Figma gradient paint for a w x h box."""
    stops = []
    for col, alpha, pos in spec['stops']:
        c, _ = color(col)
        stops.append({'color': dict(c, a=float(alpha)), 'position': float(pos)})
    if spec['type'] == 'linear':
        th = math.radians(float(spec.get('angle', 180)))
        dx, dy = math.sin(th), -math.cos(th)  # CSS: 0deg points up, 90deg points right
        length = abs(w * dx) + abs(h * dy)
        sx, sy = (w / 2 - dx * length / 2) / w, (h / 2 - dy * length / 2) / h
        ex, ey = (w / 2 + dx * length / 2) / w, (h / 2 + dy * length / 2) / h
        vx, vy = -dy * length / w, dx * length / h  # any perpendicular keeps the matrix invertible
        gi = [ex - sx, vx, sx - 0.5 * vx, ey - sy, vy, sy - 0.5 * vy]
        kind = 'GRADIENT_LINEAR'
    else:
        cx, cy = spec['at']
        rx, ry = spec['size']
        gi = [2 * rx, 0.0, cx - rx, 0.0, 2 * ry, cy - ry]
        kind = 'GRADIENT_RADIAL'
    t = _inverse(gi)
    return {'type': kind, 'opacity': float(spec.get('opacity', 1.0)), 'visible': True, 'blendMode': 'NORMAL',
            'stops': stops,
            'stopsVar': [{'color': s['color'], 'position': s['position'],
                          'colorVar': {'value': {'colorValue': s['color']}, 'dataType': 'COLOR', 'resolvedDataType': 'COLOR'}}
                         for s in stops],
            'transform': {'m00': t[0], 'm01': t[1], 'm02': t[2], 'm10': t[3], 'm11': t[4], 'm12': t[5]}}


def paints(layers, w, h):
    """Background token (a list of solid / linear / radial layers, bottom first) -> Figma paints."""
    out = []
    for layer in layers:
        if layer['type'] == 'solid':
            out.append(solid(layer['color'], float(layer.get('opacity', 1.0))))
        else:
            out.append(gradient(layer, w, h))
    return out


def shadow(name):
    s = TOKENS['shadows'][name]
    c, _ = color(s['color'][0])
    return {'type': 'DROP_SHADOW', 'offset': {'x': float(s['x']), 'y': float(s['y'])}, 'radius': float(s['blur']),
            'visible': True, 'blendMode': 'NORMAL', 'spread': float(s.get('spread', 0)), 'showShadowBehindNode': False,
            'color': dict(c, a=float(s['color'][1]))}


def font(family, style):
    ps = POSTSCRIPT.get(family)
    return {'family': family, 'style': style, 'postscript': ps.format(style.replace(' ', '')) if ps else ''}


def image_size(data):
    if data[:8] == b'\x89PNG\r\n\x1a\n':
        return struct.unpack('>II', data[16:24])
    if data[:3] == b'GIF':
        return struct.unpack('<HH', data[6:10])
    if data[:2] == b'\xff\xd8':
        i = 2
        while i < len(data):
            if data[i] != 0xFF:
                i += 1
                continue
            marker = data[i + 1]
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                h, w = struct.unpack('>HH', data[i + 5:i + 9])
                return w, h
            seg = struct.unpack('>H', data[i + 2:i + 4])[0]
            i += 2 + seg
    raise ValueError('Unsupported image (use PNG or JPG)')


INLINE = re.compile(r'\*\*(.+?)\*\*|\[([^\]]+)\]\(([^)\s]+)\)|==(.+?)==')


def parse_runs(text):
    """'a **b** [c](u) ==d==' -> [('a ', {}), ('b', {'bold': True}), ('c', {'url': 'u'}), ('d', {'hl': True})]."""
    out, pos = [], 0
    for m in INLINE.finditer(text):
        if m.start() > pos:
            out.append((text[pos:m.start()], {}))
        if m.group(1) is not None:
            out.append((m.group(1), {'bold': True}))
        elif m.group(4) is not None:
            out.append((m.group(4), {'hl': True}))
        else:
            out.append((m.group(2), {'url': m.group(3)}))
        pos = m.end()
    if pos < len(text):
        out.append((text[pos:], {}))
    return out or [('', {})]


def paragraphs(value, list_type=None):
    """Spec text -> paragraphs [{'runs': [...], 'list': None|'bullet'|'number'}]."""
    if value is None:
        return []
    items = value if isinstance(value, list) else str(value).split('\n')
    out = []
    for it in items:
        if isinstance(it, dict):
            out.append({'runs': parse_runs(str(it.get('text', ''))), 'list': it.get('list', list_type)})
        else:
            for line in str(it).split('\n'):
                out.append({'runs': parse_runs(line), 'list': list_type})
    return out


def plain(value):
    return '\n'.join(''.join(t for t, _ in p['runs']) for p in paragraphs(value))


def curly(text):
    """The text in curly quotes, without the quote marks the writer may have typed already."""
    return '“' + str(text or '').strip('“”"') + '”'


PATH_ARGS = {1: 2, 2: 2, 3: 4, 4: 6}  # Figma outline blobs: M/L x y, Q x1 y1 x y, C x1 y1 x2 y2 x y; 0 closes


def scale_path_blob(data, k):
    """The same outline, every coordinate multiplied by k."""
    data = bytes(data)
    out, i = bytearray(), 0
    while i < len(data):
        cmd = data[i]
        out.append(cmd)
        i += 1
        n = PATH_ARGS.get(cmd)
        if n is None:  # 0 (close) or anything unknown: copy as is
            continue
        vals = struct.unpack_from('<%df' % n, data, i)
        out += struct.pack('<%df' % n, *(v * k for v in vals))
        i += 4 * n
    return bytes(out)


def lexical_notes(text):
    paras = []
    for line in (text or '').split('\n'):
        if line.strip():
            paras.append({'children': [{'detail': 0, 'format': 0, 'mode': 'normal', 'style': '', 'text': line,
                                        'type': 'text', 'version': 1}],
                          'direction': 'ltr', 'format': '', 'indent': 0, 'type': 'paragraph', 'version': 1,
                          'textFormat': 0, 'textStyle': ''})
        else:
            paras.append({'children': [], 'direction': None, 'format': '', 'textFormat': None, 'indent': 0,
                          'type': 'paragraph', 'version': 1, 'textStyle': ''})
    return json.dumps({'root': {'children': paras, 'direction': 'ltr', 'format': '', 'indent': 0, 'type': 'root',
                                'version': 1}}, separators=(',', ':'), ensure_ascii=False)


# --------------------------------------------------------------------------- the builder
class Builder:
    def __init__(self, template=TEMPLATE, base_dir='.'):
        self.d = figdeck.Deck(template)
        self.base_dir = base_dir
        self.tpl = dict(self.d.nodes)  # untouched template nodes by id
        self.session = self.d.max_session() + 1
        self.local = 0
        row = self.d.slide_rows()[0]
        self.row = row
        self.template_roots = [figdeck.gid(c) for c in self.d.children(row)]
        self.new_slides = []
        self.slide_specs = []
        self.touched_text = []
        self.auto_frames = []
        self.warnings = []
        self.deck_spec = {}
        self.brand_variables()

    # ------------------------------------------------------------------ brand colours
    def brand_variables(self):
        """Turn the template's local colour collection into the brand palette: rename it, re-value the
        variables it has, add the missing colours, so designers find every brand colour as a variable."""
        vset = self.d.nodes.get(VARIABLE_SET)
        if vset is None:
            self.warnings.append('The template has no local colour collection; colours are not linked to variables.')
            for k in PALETTE:
                PALETTE[k] = (PALETTE[k][0], None)
            return
        vset['name'] = TOKENS.get('name', 'Shiji Day & Night')
        mode = vset['variableSetModes'][0]['id']
        proto = self.d.nodes[REUSE_VARIABLE['midnight']]
        order = figdeck.positions(len(TOKENS['colors']))
        for (key, c), pos in zip(TOKENS['colors'].items(), order):
            gid_ = REUSE_VARIABLE.get(key)
            node = self.d.nodes.get(gid_) if gid_ else None
            if node is None:
                node = copy.deepcopy(proto)
                node['guid'] = self.new_guid()
                holder = self.d.nodes[figdeck.gid(proto['parentIndex']['guid'])]
                node['parentIndex'] = {'guid': copy.deepcopy(holder['guid']), 'position': self.next_position(holder)}
                self.add(node)
            rgb, _ = color(c['hex'])
            node['name'] = c['name']
            node['sortPosition'] = pos
            node['variableDataValues'] = {'entries': [{'modeID': copy.deepcopy(mode), 'variableData': {
                'value': {'colorValue': rgb}, 'dataType': 'COLOR', 'resolvedDataType': 'COLOR'}}]}
            node.pop('description', None)
            if c.get('role'):
                node['description'] = c['role']
            PALETTE[key] = (c['hex'], figdeck.gid(node))
        self.tpl = dict(self.d.nodes)

    # ------------------------------------------------------------------ ids / tree edits
    def new_guid(self):
        self.local += 1
        return {'sessionID': self.session, 'localID': self.local}

    def scale_instance(self, inst, width):
        """Scale a component instance to `width`, as Figma's scale tool does: the instance size, its
        uniform scale factor, and the cached sizes, positions and outlines of the layers inside."""
        k = float(width) / inst['size']['x']
        sd = inst['symbolData']
        sd['uniformScaleFactor'] = (sd.get('uniformScaleFactor') or 1.0) * k
        inst['size'] = {'x': inst['size']['x'] * k, 'y': inst['size']['y'] * k}
        blobs = self.d.message.setdefault('blobs', [])
        for e in inst.get('derivedSymbolData') or []:
            if 'size' in e:
                e['size'] = {'x': e['size']['x'] * k, 'y': e['size']['y'] * k}
            t = e.get('transform')
            if t:
                t['m02'], t['m12'] = t.get('m02', 0.0) * k, t.get('m12', 0.0) * k
            for key in ('fillGeometry', 'strokeGeometry'):
                for g in e.get(key) or []:
                    i = g.get('commandsBlob')
                    if i is not None and i < len(blobs):
                        blobs.append({'bytes': scale_path_blob(blobs[i]['bytes'], k)})
                        g['commandsBlob'] = len(blobs) - 1
        return inst

    def new_node(self, proto_gid, parent, position=None):
        """Copy one template layer (without its children) under `parent`."""
        c = copy.deepcopy(self.tpl[proto_gid])
        c['guid'] = self.new_guid()
        for k in ('prototypeInteractions', 'derivedSymbolData', 'stackChildAlignSelf', 'stackChildPrimaryGrow',
                  'stackPositioning'):
            c.pop(k, None)
        c['opacity'] = 1.0  # the prototype layers may be faded in the template (the big "01" is at 10%)
        c['visible'] = True
        if 'autoRename' in c:
            c['autoRename'] = False  # keep the layer names the builder gives
        c['parentIndex'] = {'guid': copy.deepcopy(parent['guid']), 'position': position or self.next_position(parent)}
        self.add(c)
        return c

    def add(self, node):
        self.d.message['nodeChanges'].append(node)
        self.d.nodes[figdeck.gid(node)] = node
        p = node.get('parentIndex')
        if p:
            self.d.kids.setdefault(figdeck.gid(p['guid']), []).append(node)
            self.d.kids[figdeck.gid(p['guid'])].sort(key=lambda n: n['parentIndex'].get('position', ''))

    def tpl_children(self, gid):
        return [n for n in self.d.message['nodeChanges'] if n.get('parentIndex') and figdeck.gid(n['parentIndex']['guid']) == gid]

    def clone(self, src_gid, parent, position=None, mapping=None):
        """Deep-copy a template subtree under `parent`. Returns {template id: new node}."""
        mapping = {} if mapping is None else mapping
        src = self.tpl[src_gid]
        order = []

        def collect(n):
            order.append(n)
            for c in sorted(self.tpl_children_cached(figdeck.gid(n)), key=lambda x: x['parentIndex'].get('position', '')):
                collect(c)
        collect(src)
        for n in order:
            mapping[figdeck.gid(n)] = None
        guids = {figdeck.gid(n): self.new_guid() for n in order}
        for n in order:
            c = copy.deepcopy(n)
            c['guid'] = guids[figdeck.gid(n)]
            c.pop('prototypeInteractions', None)
            if n is src:
                c['parentIndex'] = {'guid': copy.deepcopy(parent['guid']), 'position': position or self.next_position(parent)}
            else:
                pg = figdeck.gid(n['parentIndex']['guid'])
                c['parentIndex'] = {'guid': copy.deepcopy(guids[pg]), 'position': n['parentIndex'].get('position', '!')}
            for k in ('connectorStart', 'connectorEnd'):
                ep = c.get(k, {}).get('endpointNodeID')
                if ep and figdeck.gid(ep) in guids:
                    c[k]['endpointNodeID'] = copy.deepcopy(guids[figdeck.gid(ep)])
            mapping[figdeck.gid(n)] = c
            self.add(c)
        return mapping

    def tpl_children_cached(self, gid):
        if not hasattr(self, '_tpl_kids'):
            self._tpl_kids = {}
            for n in self.tpl.values():
                p = n.get('parentIndex')
                if p:
                    self._tpl_kids.setdefault(figdeck.gid(p['guid']), []).append(n)
        return self._tpl_kids.get(gid, [])

    def next_position(self, parent):
        sibs = self.d.kids.get(figdeck.gid(parent), [])
        if not sibs:
            return 'U'
        return max(s['parentIndex'].get('position', '') for s in sibs) + 'U'

    def delete(self, node):
        if node is None:
            return
        doomed = set(figdeck.gid(n) for n, _ in self.d.walk(node))
        self.d.message['nodeChanges'] = [n for n in self.d.message['nodeChanges'] if figdeck.gid(n) not in doomed]
        for g in doomed:
            self.d.nodes.pop(g, None)
        p = node.get('parentIndex')
        if p:
            k = figdeck.gid(p['guid'])
            self.d.kids[k] = [c for c in self.d.kids.get(k, []) if figdeck.gid(c) not in doomed]
        self.touched_text = [t for t in self.touched_text if figdeck.gid(t) not in doomed]

    # ------------------------------------------------------------------ slides
    def start_slide(self, template_no, spec):
        src = T[template_no]
        m = self.clone(src, self.row, position='~')
        slide = m[src]
        slide['name'] = str(spec.get('name') or len(self.new_slides) + 1)
        slide.pop('slideSpeakerNotes', None)
        if spec.get('notes'):
            slide['slideSpeakerNotes'] = lexical_notes(spec['notes'])
        if spec.get('skip'):
            slide['isSkippedSlide'] = True
        self.new_slides.append(slide)
        self.slide_specs.append(spec)
        return S(self, slide, m)

    def rows(self):
        """Slides grouped into slide-grid rows: a new row at every section divider, like the team's decks."""
        mode = self.deck_spec.get('grid', 'sections')
        groups = []
        for slide, spec in zip(self.new_slides, self.slide_specs):
            starts = spec.get('new_row') or (mode == 'sections' and spec.get('layout') in ROW_BREAK_LAYOUTS)
            if not groups or (starts and groups[-1]):
                groups.append([])
            groups[-1].append(slide)
        return groups

    def transition(self, spec):
        name = str(spec.get('transition', self.deck_spec.get('transition', 'none'))).lower()
        kind = TRANSITIONS.get(name)
        if kind is None:
            self.warnings.append(f'Unknown transition "{name}". Use one of: {", ".join(TRANSITIONS)}')
            kind = 'INSTANT_TRANSITION'
        instant = kind == 'INSTANT_TRANSITION'
        duration = 0.0 if instant else float(spec.get('transition_duration', self.deck_spec.get('transition_duration', 0.4)))
        easing = 'IN_CUBIC' if instant else EASINGS.get(str(spec.get('easing', self.deck_spec.get('easing', 'ease-out'))), 'OUT_CUBIC')
        delay = spec.get('advance_after', self.deck_spec.get('advance_after'))
        return kind, duration, easing, delay

    def link_slides(self):
        """Give every slide but the last the on-click link to the next slide, with its transition."""
        for i, (slide, spec) in enumerate(zip(self.new_slides, self.slide_specs)):
            slide.pop('prototypeInteractions', None)
            if i == len(self.new_slides) - 1:
                continue
            kind, duration, easing, delay = self.transition(spec)
            event = {'interactionType': 'AFTER_TIMEOUT', 'transitionTimeout': float(delay)} if delay else \
                {'interactionType': 'ON_CLICK', 'transitionTimeout': 0.0}
            slide['prototypeInteractions'] = [{
                'id': self.new_guid(), 'event': event,
                'actions': [{'transitionNodeID': copy.deepcopy(self.new_slides[i + 1]['guid']), 'transitionType': kind,
                             'transitionDuration': duration, 'easingType': easing, 'connectionType': 'INTERNAL_NODE',
                             'navigationType': 'NAVIGATE', 'transitionResetVideoPosition': True}],
                'isDeleted': False, 'stateManagementVersion': 1}]

    def finish(self):
        # drop the template's own slides, order the new ones, size the row and grid
        for g in self.template_roots:
            n = self.d.nodes.get(g)
            if n:
                self.delete(n)
        self.link_slides()
        grid = self.d.slide_grid()
        groups = self.rows() or [[]]
        row_nodes = [self.row]
        for _ in groups[1:]:
            r = copy.deepcopy(self.row)
            r['guid'] = self.new_guid()
            self.add(r)
            row_nodes.append(r)
        widest = 1
        for ri, (row, group, rpos) in enumerate(zip(row_nodes, groups, figdeck.positions(len(groups)))):
            row['parentIndex'] = {'guid': copy.deepcopy(grid['guid']), 'position': rpos}
            row.setdefault('transform', {}).update({'m00': 1.0, 'm01': 0.0, 'm10': 0.0, 'm11': 1.0, 'm02': float(SLIDE_GAP),
                                                    'm12': float(SLIDE_GAP + ri * (SLIDE_H + SLIDE_GAP))})
            n = max(1, len(group))
            row['size'] = {'x': float(n * SLIDE_W + (n - 1) * SLIDE_GAP), 'y': float(SLIDE_H)}
            widest = max(widest, n)
            for j, (s, pos) in enumerate(zip(group, figdeck.positions(len(group)))):
                s['parentIndex'] = {'guid': copy.deepcopy(row['guid']), 'position': pos}
                s.setdefault('transform', {}).update({'m00': 1.0, 'm01': 0.0, 'm10': 0.0, 'm11': 1.0,
                                                      'm02': float(j * (SLIDE_W + SLIDE_GAP)), 'm12': 0.0})
        grid['size'] = {'x': float(widest * SLIDE_W + (widest - 1) * SLIDE_GAP + 2 * SLIDE_GAP),
                        'y': float(len(groups) * SLIDE_H + (len(groups) + 1) * SLIDE_GAP)}
        if self.d.message.get('nodeChangeOrder') == 'GUID':  # Figma stores layers sorted by id
            self.d.message['nodeChanges'].sort(key=lambda n: (n['guid']['sessionID'], n['guid']['localID']))
        self.d.reindex()

    # ------------------------------------------------------------------ text
    def set_text(self, node, value, list_type=None, keep_line_styles=True, highlight=None, link_paint=None):
        """Write spec text into a text layer. `highlight` / `link_paint`: paints for ==x== and [x](url) runs."""
        paras = paragraphs(value, list_type)
        if not paras:
            paras = [{'runs': [('', {})], 'list': None}]
        td = node.setdefault('textData', {})
        orig = td.get('characters', '')
        ids = td.get('characterStyleIDs') or []
        table = {o['styleID']: o for o in td.get('styleOverrideTable') or []}
        old_lines = td.get('lines') or [{}]
        starts = [0] + [i + 1 for i, ch in enumerate(orig) if ch == '\n']
        line_sid = [ids[s] if s < len(ids) else 0 for s in starts] if keep_line_styles else [0]
        next_sid = [max(list(table) + [0]) + 1]
        variants = {}

        def variant(base_sid, fmt):
            key = (base_sid, bool(fmt.get('bold')), fmt.get('url'), bool(fmt.get('hl')))
            if key in variants:
                return variants[key]
            o = copy.deepcopy(table.get(base_sid, {})) if base_sid else {}
            o.pop('styleID', None)
            if fmt.get('bold'):
                f = o.get('fontName') or self.effective_font(node)
                o['fontName'] = font(f['family'], bolder(f['family'], f.get('style', 'Regular')))
                if node.get('styleIdForText') and 'styleIdForText' not in o:
                    o['isOverrideOverTextStyle'] = True
                    o['styleIdForText'] = copy.deepcopy(node['styleIdForText'])
            if fmt.get('hl'):
                o['fillPaints'] = [copy.deepcopy(highlight or solid('green'))]
            if fmt.get('url'):
                o['hyperlink'] = {'url': fmt['url'], 'openInNewTab': True}
                o['textDecoration'] = 'UNDERLINE'
                if link_paint:
                    o['fillPaints'] = [copy.deepcopy(link_paint)]
            sid = next_sid[0]
            next_sid[0] += 1
            o['styleID'] = sid
            table[sid] = o
            variants[key] = sid
            return sid

        chars, cids, lines = [], [], []
        prev_list = None
        for pi, p in enumerate(paras):
            base = line_sid[min(pi, len(line_sid) - 1)]
            for text, fmt in p['runs']:
                sid = variant(base, fmt) if fmt else base
                chars.append(text)
                cids += [sid] * len(text)
            if pi < len(paras) - 1:
                chars.append('\n')
                cids.append(base)
            tmpl = dict(old_lines[min(pi, len(old_lines) - 1)]) if old_lines else {}
            lt = {'bullet': 'UNORDERED_LIST', 'number': 'ORDERED_LIST'}.get(p.get('list'), 'PLAIN')
            tmpl.update({'lineType': lt, 'styleId': 0, 'indentationLevel': 1 if lt != 'PLAIN' else 0,
                         'sourceDirectionality': tmpl.get('sourceDirectionality', 'AUTO'),
                         'listStartOffset': 0, 'isFirstLineOfList': lt != 'PLAIN' and prev_list != lt})
            lines.append(tmpl)
            prev_list = lt if lt != 'PLAIN' else None
        td['characters'] = ''.join(chars)
        used = set(cids)
        td['characterStyleIDs'] = cids
        td['styleOverrideTable'] = [table[k] for k in sorted(table) if k in used and k != 0]
        if not td['styleOverrideTable']:
            td.pop('styleOverrideTable', None)
            if not any(cids):
                td.pop('characterStyleIDs', None)
        td['lines'] = lines
        node.pop('derivedTextData', None)
        if node not in self.touched_text:
            self.touched_text.append(node)
        return node

    def effective_font(self, node):
        st = self.style_node(node.get('styleIdForText'))
        return (st or node).get('fontName') or node.get('fontName')

    def style_node(self, ref):
        if not ref:
            return None
        g = ref.get('guid')
        if g and g.get('sessionID') != 4294967295:
            return self.tpl.get(figdeck.gid(g))
        key = (ref.get('assetRef') or {}).get('key')
        if key:
            for n in self.tpl.values():
                if n.get('key') == key and n.get('styleType'):
                    return n
        return None

    def restyle(self, node, style=None, size=None, family=None, weight=None, line_height=None, letter=None, fill=None):
        """Change type settings. Linking a template text style keeps the text editable as that style."""
        if style:
            st = self.tpl[STYLES[style]]
            node['styleIdForText'] = {'guid': copy.deepcopy(st['guid'])}
            for k in render_deck.TEXT_STYLE_KEYS:
                if k in st:
                    node[k] = copy.deepcopy(st[k])
        else:
            st = self.style_node(node.get('styleIdForText'))
            if st:  # take the style's values onto the layer before detaching
                for k in render_deck.TEXT_STYLE_KEYS:
                    if k in st:
                        node[k] = copy.deepcopy(st[k])
        if any(v is not None for v in (size, family, weight, line_height, letter)):
            node.pop('styleIdForText', None)
            f = node.get('fontName') or {'family': 'Lato', 'style': 'Regular'}
            if family or weight:
                node['fontName'] = font(family or f['family'], weight or f['style'])
            if size is not None:
                node['fontSize'] = float(size)
            if line_height is not None:
                node['lineHeight'] = ({'value': float(line_height), 'units': 'PIXELS'} if line_height > 4
                                      else {'value': float(line_height) * 100, 'units': 'PERCENT'})
            if letter is not None:
                node['letterSpacing'] = {'value': float(letter), 'units': 'PERCENT'}
            td = node.get('textData') or {}
            for o in td.get('styleOverrideTable') or []:  # keep run overrides consistent with the new size
                if size is not None and 'fontSize' in o:
                    o['fontSize'] = float(size)
        if fill is not None:
            node['fillPaints'] = [solid(fill)]
        return node

    # ------------------------------------------------------------------ images
    def image_paint(self, path, mode='FIT'):
        full = path if os.path.isabs(path) else os.path.join(self.base_dir, path)
        data = open(full, 'rb').read()
        if data[:3] == b'GIF' or full.lower().endswith(('.webp', '.heic', '.tif', '.tiff')):
            tmp = tempfile.mktemp(suffix='.png')
            subprocess.run(['sips', '-s', 'format', 'png', full, '--out', tmp], capture_output=True, check=True)
            data = open(tmp, 'rb').read()
            self.warnings.append(f'{os.path.basename(full)}: converted to a still PNG (add the animated GIF in Figma if you need motion)')
        w, h = image_size(data)
        hsh = self.d.add_image(data)
        return {'type': 'IMAGE', 'opacity': 1.0, 'visible': True, 'blendMode': 'NORMAL',
                'transform': {'m00': 1.0, 'm01': 0.0, 'm02': 0.0, 'm10': 0.0, 'm11': 1.0, 'm12': 0.0},
                'image': {'hash': bytes.fromhex(hsh), 'name': os.path.splitext(os.path.basename(full))[0]},
                'imageThumbnail': {'hash': bytes.fromhex(hsh), 'name': os.path.splitext(os.path.basename(full))[0]},
                'animationFrame': 0, 'imageScaleMode': mode, 'imageShouldColorManage': False, 'rotation': 0.0,
                'scale': 0.5, 'originalImageWidth': w, 'originalImageHeight': h, 'thumbHash': b'', 'altText': ''}, (w, h)

    # ------------------------------------------------------------------ measuring + auto layout
    def measure_and_layout(self):
        if not self.touched_text:
            return
        self.d.reindex()
        r = render_deck.Renderer(self.d)
        blocks = []
        for i, n in enumerate(self.touched_text):
            css = r.text_box_css(n).replace('justify-content', 'x-jc')
            mode = n.get('textAutoResize', 'NONE')
            width = 'max-content' if mode == 'WIDTH_AND_HEIGHT' else f"{n['size']['x']:.2f}px"
            blocks.append(f'<div class="m" data-i="{i}" style="position:absolute;left:0;top:{i * 4}px;width:{width}">'
                          f'<div class="in" style="{css}">{r.text_inner(n)}</div></div>')
        page = (f'<!doctype html><html><head><meta charset="utf-8">{render_deck.FONT_HEAD}<style>{render_deck.PAGE_CSS}</style></head>'
                f'<body>{"".join(blocks)}<script>document.fonts.ready.then(()=>{{const o={{}};'
                f'document.querySelectorAll(".m").forEach(m=>{{const r=m.firstChild.getBoundingClientRect();o[m.dataset.i]=[r.width,r.height]}});'
                f'const p=document.createElement("pre");p.id="out";p.textContent=JSON.stringify(o);document.body.appendChild(p)}});</script></body></html>')
        tmp = tempfile.mktemp(suffix='.html')
        open(tmp, 'w').write(page)
        res = render_deck.chrome(['--virtual-time-budget=15000', '--window-size=1920,1080', '--dump-dom', 'file://' + tmp])
        os.remove(tmp)
        m = re.search(r'<pre id="out">(.*?)</pre>', res.stdout, re.S)
        if not m:
            self.warnings.append('Text could not be measured (Chrome did not answer); sizes are estimates.')
            return
        sizes = json.loads(html.unescape(m.group(1)))
        for i, n in enumerate(self.touched_text):
            w, h = sizes.get(str(i), [n['size']['x'], n['size']['y']])
            mode = n.get('textAutoResize', 'NONE')
            old_w = n['size']['x']
            if mode == 'WIDTH_AND_HEIGHT':
                n['size'] = {'x': float(math.ceil(w) + 2), 'y': float(math.ceil(h))}
                align = n.get('textAlignHorizontal', 'LEFT')
                parent = self.d.nodes.get(figdeck.gid(n['parentIndex']['guid']))
                if not (parent and parent.get('stackMode') in ('VERTICAL', 'HORIZONTAL')):
                    shift = {'CENTER': 0.5, 'RIGHT': 1.0}.get(align, 0.0) * (old_w - n['size']['x'])
                    n['transform']['m02'] = n['transform'].get('m02', 0.0) + shift
            elif mode == 'HEIGHT':
                n['size'] = {'x': n['size']['x'], 'y': float(math.ceil(h))}
            n['_measured'] = (w, h)
        # re-run auto layout on every frame that holds touched text, innermost first
        frames = []
        for n in self.touched_text:
            p = self.d.nodes.get(figdeck.gid(n['parentIndex']['guid']))
            while p is not None and p.get('type') in ('FRAME', 'INSTANCE') and p.get('stackMode') in ('VERTICAL', 'HORIZONTAL'):
                if p not in frames:
                    frames.append(p)
                p = self.d.nodes.get(figdeck.gid(p['parentIndex']['guid'])) if p.get('parentIndex') else None
        for f in self.auto_frames:  # frames that hold only shapes or other frames
            if figdeck.gid(f) in self.d.nodes and f not in frames:
                frames.append(f)
        frames.sort(key=lambda f: -self.depth(f))
        for f in frames:
            self.stack(f)
        for n in self.touched_text:
            n.pop('_measured', None)

    def depth(self, n):
        k = 0
        while n.get('parentIndex'):
            n = self.d.nodes.get(figdeck.gid(n['parentIndex']['guid']))
            if n is None:
                break
            k += 1
        return k

    def stack(self, f):
        vertical = f.get('stackMode') == 'VERTICAL'
        kids = [c for c in self.d.children(f) if c.get('visible', True) and c.get('stackPositioning') != 'ABSOLUTE']
        gap = f.get('stackSpacing', 0.0) or 0.0
        pl = f.get('stackHorizontalPadding', 0.0) or 0.0
        pt = f.get('stackVerticalPadding', 0.0) or 0.0
        pr = f.get('stackPaddingRight', pl)
        pb = f.get('stackPaddingBottom', pt)
        main = sum((c['size']['y'] if vertical else c['size']['x']) for c in kids) + gap * max(0, len(kids) - 1)
        cross = max([(c['size']['x'] if vertical else c['size']['y']) for c in kids] or [0])
        # Figma leaves stackPrimarySizing unset for "hug contents" and writes FIXED for a fixed size.
        hug_main = f.get('stackPrimarySizing') != 'FIXED'
        hug_cross = f.get('stackCounterSizing') in ('RESIZE_TO_FIT', 'RESIZE_TO_FIT_WITH_IMPLICIT_SIZE')
        size = f['size']
        if hug_main:
            if vertical:
                size['y'] = main + pt + pb
            else:
                size['x'] = main + pl + pr
        if hug_cross:
            if vertical:
                size['x'] = max(size['x'] if not kids else 0, cross + pl + pr)
            else:
                size['y'] = cross + pt + pb
        avail = (size['y'] - pt - pb) if vertical else (size['x'] - pl - pr)
        growers = [c for c in kids if (c.get('stackChildPrimaryGrow') or 0) > 0]
        if growers and not hug_main and avail > main:  # "fill container" children share the free space
            extra = (avail - main) / len(growers)
            for c in growers:
                c['size']['y' if vertical else 'x'] += extra
            main = avail
        cross_size = (size['x'] - pl - pr) if vertical else (size['y'] - pt - pb)
        for c in kids:
            if c.get('stackChildAlignSelf') == 'STRETCH' and c.get('type') != 'TEXT':
                c['size']['x' if vertical else 'y'] = cross_size
        align = f.get('stackPrimaryAlignItems', 'MIN')
        start = 0.0
        g = gap
        if align == 'CENTER':
            start = (avail - main) / 2
        elif align == 'MAX':
            start = avail - main
        elif align == 'SPACE_BETWEEN' and len(kids) > 1:
            g = (avail - (main - gap * (len(kids) - 1))) / (len(kids) - 1)
        cal = f.get('stackCounterAlignItems', 'MIN')
        cross_avail = (size['x'] - pl - pr) if vertical else (size['y'] - pt - pb)
        cur = start
        for c in kids:
            cs = c['size']['x'] if vertical else c['size']['y']
            off = {'CENTER': (cross_avail - cs) / 2, 'MAX': cross_avail - cs}.get(cal, 0.0)
            t = c.setdefault('transform', {'m00': 1.0, 'm01': 0.0, 'm10': 0.0, 'm11': 1.0})
            if vertical:
                t['m02'], t['m12'] = pl + off, pt + cur
                cur += c['size']['y'] + g
            else:
                t['m02'], t['m12'] = pl + cur, pt + off
                cur += c['size']['x'] + g

    # ------------------------------------------------------------------ save
    def save(self, out, file_name):
        self.measure_and_layout()
        self.finish()
        self.d.save(out, file_name=file_name)
        return out


class S:
    """One slide being built: `n(template_id)` returns the copy of a template layer on this slide."""

    def __init__(self, b, slide, mapping):
        self.b, self.slide, self.m = b, slide, mapping

    def n(self, tid):
        node = self.m.get(tid)
        if node is None or figdeck.gid(node) not in self.b.d.nodes:
            return None
        return node

    def drop(self, *tids):
        for t in tids:
            self.b.delete(self.n(t))

    def keep_only(self, *tids):
        keep = set(figdeck.gid(self.m[t]) for t in tids if self.m.get(t))
        for c in list(self.b.d.children(self.slide)):
            if figdeck.gid(c) not in keep:
                self.b.delete(c)

    def text(self, tid, value, **kw):
        node = self.n(tid) if isinstance(tid, str) else tid
        if node is None:
            return None
        return self.b.set_text(node, value, **kw)

    def place(self, node, x=None, y=None, w=None, h=None):
        if node is None:
            return None
        t = node.setdefault('transform', {'m00': 1.0, 'm01': 0.0, 'm10': 0.0, 'm11': 1.0, 'm02': 0.0, 'm12': 0.0})
        if x is not None:
            t['m02'] = float(x)
        if y is not None:
            t['m12'] = float(y)
        if w is not None or h is not None:
            s = node.setdefault('size', {'x': 0.0, 'y': 0.0})
            changed = (w is not None and abs(s.get('x', 0) - w) > 0.01) or (h is not None and abs(s.get('y', 0) - h) > 0.01)
            if w is not None:
                s['x'] = float(w)
            if h is not None:
                s['y'] = float(h)
            if changed and node.get('type') not in ('VECTOR', 'TEXT'):
                node.pop('fillGeometry', None)  # cached outlines of the old size; Figma redraws them
                node.pop('strokeGeometry', None)
        return node

    def add(self, proto_tid, parent=None, x=None, y=None, w=None, h=None):
        """Copy any template layer (from any template slide) onto this slide."""
        parent = parent or self.slide
        m = self.b.clone(proto_tid, parent)
        node = m[proto_tid]
        self.place(node, x, y, w, h)
        for k, v in m.items():
            self.m.setdefault('+' + k + ':' + figdeck.gid(v), v)
        return node

    def add_text(self, proto_tid, value, x, y, w, h=None, resize='HEIGHT', align=None, valign=None, parent=None,
                 list_type=None, name=None, **style):
        node = self.add(proto_tid, parent, x, y, w, h if h is not None else self.b.tpl[proto_tid]['size']['y'])
        node['textAutoResize'] = resize
        if align:
            node['textAlignHorizontal'] = align
        if valign:
            node['textAlignVertical'] = valign
        if style:
            self.b.restyle(node, **style)
        self.b.set_text(node, value, list_type=list_type, keep_line_styles=False)
        node['name'] = name or node.get('name')
        return node

    def reorder(self, parent, first=(), last=()):
        """Re-number the children of `parent` so `first` sit at the bottom and `last` on top."""
        kids = list(self.b.d.children(parent))
        f = [k for k in first if k in kids]
        l_ = [k for k in last if k in kids]
        mid = [k for k in kids if k not in f and k not in l_]
        order = f + mid + l_
        for k, pos in zip(order, figdeck.positions(len(order))):
            k['parentIndex']['position'] = pos
        self.b.d.kids[figdeck.gid(parent)] = order

    def panel(self, x, w=None):
        """The light-blue panel used on the right of content slides (Accent 6 at 20%)."""
        node = self.rect(x, 0, w if w is not None else 1920 - x, 1080, fill='sky', opacity=0.2)
        node['name'] = 'Panel'
        return node

    def fill(self, node, value, opacity=1.0):
        if node is not None:
            node['fillPaints'] = [solid(value, opacity)]
        return node

    def image(self, node, path, mode='FIT', keep_fills=False):
        if node is None or not path:
            return None
        full = path if os.path.isabs(path) else os.path.join(self.b.base_dir, path)
        if not os.path.exists(full):
            self.b.warnings.append(f'Slide {len(self.b.new_slides)}: image "{path}" not found, a placeholder was left.')
            node['fillPaints'] = (node.get('fillPaints') or []) if keep_fills else [solid('mist')]
            node['name'] = f'Image placeholder: {os.path.basename(path)}'
            return None
        paint, size = self.b.image_paint(path, mode)
        node['fillPaints'] = (node.get('fillPaints') or []) + [paint] if keep_fills else [paint]
        return size

    def rect(self, x, y, w, h, fill='white', radius=0.0, stroke=None, stroke_w=0.0, opacity=1.0, shadow=False, parent=None):
        node = self.add('2038:240', parent, x, y, w, h)  # template rectangle (has a stroke slot)
        node['name'] = 'Rectangle'
        fill, stroke = self.tc(fill) if fill else fill, self.tc(stroke) if stroke else stroke
        node['fillPaints'] = [solid(fill, opacity)] if fill else []
        for k in ('rectangleTopLeftCornerRadius', 'rectangleTopRightCornerRadius', 'rectangleBottomLeftCornerRadius',
                  'rectangleBottomRightCornerRadius'):
            node[k] = float(radius)
        node['cornerRadius'] = float(radius)
        node['rectangleCornerRadiiIndependent'] = False
        if stroke:
            node['strokePaints'] = [solid(stroke)]
            node['strokeWeight'] = float(stroke_w or 2.0)
            node['strokeAlign'] = 'INSIDE'
        else:
            node.pop('strokePaints', None)
            node['strokeWeight'] = 0.0
        node.pop('fillGeometry', None)
        node.pop('strokeGeometry', None)
        if shadow:
            node['effects'] = [{'type': 'DROP_SHADOW', 'offset': {'x': 0.0, 'y': 8.0}, 'radius': 32.0, 'visible': True,
                                'blendMode': 'NORMAL', 'spread': 0.0, 'showShadowBehindNode': False,
                                'color': {'r': 0.09, 'g': 0.13, 'b': 0.34, 'a': 0.12}}]
        return node

    def ellipse(self, x, y, d, fill='twilight'):
        node = self.add('1:63', None, x, y, d, d)  # the ellipse inside the template circle component
        node['name'] = 'Circle'
        node['fillPaints'] = [solid(fill)]
        node.pop('fillGeometry', None)
        node.pop('overrideKey', None)
        return node

    def logo(self, x, y, white=False):
        node = self.add('2013:277' if white else '2038:246', None, x, y)
        return node

    def icon_white(self, inst):
        """Template icons default to a grey colour variable; force them white on blue buttons."""
        if inst is None:
            return
        sd = inst.get('symbolData') or {}
        sym = self.b.tpl.get(figdeck.gid(sd.get('symbolID'))) if sd.get('symbolID') else None
        if not sym:
            return
        vec = [c for c in self.b.tpl_children_cached(figdeck.gid(sym)) if c.get('type') == 'VECTOR']
        if not vec or not vec[0].get('overrideKey'):
            return
        key = vec[0]['overrideKey']
        ovs = [o for o in sd.get('symbolOverrides') or [] if not (len(o['guidPath']['guids']) == 1 and figdeck.gid(o['guidPath']['guids'][0]) == figdeck.gid(key))]
        ovs.append({'guidPath': {'guids': [copy.deepcopy(key)]}, 'fillPaints': [solid('white')]})
        sd['symbolOverrides'] = ovs

    # ------------------------------------------------------------------ Day & Night primitives
    def theme(self, name):
        """Pick the day, night or blue theme: every colour role below resolves through it."""
        name = name if name in TOKENS['themes'] else 'night'
        self.th = dict(TOKENS['themes'][name], name=name)
        return self.th

    def tc(self, role):
        """A theme role ('title', 'muted', 'highlight'...) or a brand colour name -> colour spec."""
        th = getattr(self, 'th', None) or self.theme('night')
        return th.get(role, role) if isinstance(role, str) else role

    def background(self, name=None):
        """Token background (solid, gradient stack) as the slide fill plus a locked full-bleed layer."""
        name = name or self.tc('background')
        layers = TOKENS['backgrounds'].get(name)
        if layers is None:
            self.slide['fillPaints'] = [solid(self.tc(name))]
            return None
        base = layers[0] if layers[0]['type'] == 'solid' else None
        self.slide['fillPaints'] = [solid(base['color'])] if base else [solid(layers[0]['stops'][0][0])]
        if base and len(layers) == 1:
            return None
        node = self.rect(0, 0, SLIDE_W, SLIDE_H, fill=None)
        node['fillPaints'] = paints(layers, SLIDE_W, SLIDE_H)
        node['name'] = f'Background ({name})'
        node['locked'] = True
        return node

    def t(self, value, kind='body', x=0, y=0, w=800, color='text', align='LEFT', resize='HEIGHT', h=None, parent=None,
          name=None, list_type=None, valign=None, highlight='highlight', size=None, link='highlight', line=None):
        """A text layer set in a brand type token (presentation-brand assets/tokens.json, "type")."""
        ty = TOKENS['type'][kind]
        fam, style = TOKENS['fonts'][ty['font']]
        fs = float(size or ty['size'])
        lh = float(line or round(fs * ty['line']))
        node = self.b.new_node(TEXT_PROTO, parent or self.slide)
        self.place(node, x, y, w, h or lh)
        for k in ('styleIdForText', 'fontVariations', 'textTracks', 'derivedTextData', 'hyperlink'):
            node.pop(k, None)
        node['textAutoResize'] = resize
        node['textAlignHorizontal'] = align
        node['textAlignVertical'] = valign or 'TOP'
        node['fontName'] = font(fam, style)
        node['fontSize'] = fs
        node['lineHeight'] = {'value': lh, 'units': 'PIXELS'}
        node['letterSpacing'] = {'value': float(ty.get('tracking', 0)), 'units': 'PERCENT'}
        node['textCase'] = 'UPPER' if ty.get('case') == 'upper' else 'ORIGINAL'
        node['textDecoration'] = 'NONE'
        node['paragraphSpacing'] = float(ty.get('paragraph', round(fs * 0.45) if ty['font'].startswith('sans') else 0))
        node['fillPaints'] = [solid(self.tc(color))]
        node['strokePaints'] = []
        node['effects'] = []
        self.b.set_text(node, value, list_type=list_type, keep_line_styles=False,
                        highlight=solid(self.tc(highlight)) if highlight else None,
                        link_paint=solid(self.tc(link)) if link else None)
        node['name'] = name or kind.replace('-', ' ').title()
        return node

    def frame(self, x=0, y=0, w=100, h=100, mode='VERTICAL', gap=0, pad=0, parent=None, fill=None, radius=0,
              hug_main=True, hug_cross=False, align='MIN', cross='MIN', name='Frame', stroke=None, stroke_w=1.5,
              clip=False):
        """An auto-layout frame (mode VERTICAL / HORIZONTAL) or a plain frame (mode NONE)."""
        node = self.b.new_node(FRAME_PROTO, parent or self.slide)
        self.place(node, x, y, w, h)
        if isinstance(pad, (int, float)):
            pad = (pad, pad, pad, pad)
        elif len(pad) == 2:
            pad = (pad[0], pad[1], pad[0], pad[1])
        top, right, bottom, left = (float(v) for v in pad)
        node['stackMode'] = mode
        for k in ('stackPrimarySizing', 'stackCounterSizing', 'stackChildAlignSelf', 'stackChildPrimaryGrow'):
            node.pop(k, None)
        if mode != 'NONE':
            node['stackSpacing'] = float(gap)
            node['stackHorizontalPadding'], node['stackVerticalPadding'] = left, top
            node['stackPaddingRight'], node['stackPaddingBottom'] = right, bottom
            if not hug_main:
                node['stackPrimarySizing'] = 'FIXED'
            node['stackCounterSizing'] = 'RESIZE_TO_FIT_WITH_IMPLICIT_SIZE' if hug_cross else 'FIXED'
            node['stackPrimaryAlignItems'] = align
            node['stackCounterAlignItems'] = cross
            self.b.auto_frames.append(node)
        node['fillPaints'] = [solid(self.tc(fill))] if fill else []
        self.corners(node, radius)
        if stroke:
            node['strokePaints'] = [solid(self.tc(stroke))]
            node['strokeWeight'] = float(stroke_w)
            node['strokeAlign'] = 'INSIDE'
        else:
            node['strokePaints'] = []
            node['strokeWeight'] = 0.0
        node['frameMaskDisabled'] = not clip
        node['name'] = name
        return node

    def corners(self, node, radius):
        for k in ('rectangleTopLeftCornerRadius', 'rectangleTopRightCornerRadius', 'rectangleBottomLeftCornerRadius',
                  'rectangleBottomRightCornerRadius', 'cornerRadius'):
            node[k] = float(radius)
        node['rectangleCornerRadiiIndependent'] = False

    def dot(self, x, y, d, fill, parent=None, name='Dot', stroke=None, stroke_w=2.0):
        node = self.b.new_node('1:63', parent or self.slide)  # the ellipse of the template circle component
        self.place(node, x, y, d, d)
        for k in ('fillGeometry', 'strokeGeometry', 'overrideKey', 'componentPropRefs'):
            node.pop(k, None)
        node['fillPaints'] = [solid(self.tc(fill))] if fill else []
        if stroke:
            node['strokePaints'] = [solid(self.tc(stroke))]
            node['strokeWeight'] = float(stroke_w)
            node['strokeAlign'] = 'INSIDE'
        else:
            node['strokePaints'] = []
            node['strokeWeight'] = 0.0
        node['name'] = name
        return node

    def equal_heights(self, row):
        """After layout, give every card in `row` the height of the tallest one."""
        self.slide.setdefault('_equal', []).append(figdeck.gid(row))
        return row

    def vplace(self, node, top, bottom, mode='center'):
        """After text is measured, put `node` at the top, centre or bottom of the band top..bottom."""
        self.slide.setdefault('_vplace', []).append((figdeck.gid(node), float(top), float(bottom), mode))
        return node

    def heading(self, sp, w, parent, title_kind='title', align='LEFT', gap=20, title=None, kicker=None,
                subtitle=None, title_size=None):
        """Kicker (mono label), title and subtitle as one auto-layout group."""
        title = sp.get('title', '') if title is None else title
        kicker = sp.get('kicker') if kicker is None else kicker
        subtitle = sp.get('subtitle') if subtitle is None else subtitle
        g = self.frame(0, 0, w, 10, 'VERTICAL', gap=gap, parent=parent, name='Heading',
                       cross={'LEFT': 'MIN', 'CENTER': 'CENTER', 'RIGHT': 'MAX'}[align])
        if kicker:
            self.t(kicker, 'kicker', w=w, color='kicker', align=align, parent=g, name='Kicker')
        if title:
            self.t(title, title_kind, w=w, color='title', align=align, parent=g, name='Title', size=title_size)
            if sp.get('title_light'):
                self.t(sp['title_light'], title_kind, w=w, color='muted', align=align, parent=g, name='Title (light)',
                       size=title_size)
        if subtitle:
            self.t(subtitle, 'subtitle', w=w, color='muted', align=align, parent=g, name='Subtitle')
        return g

    def bullets(self, items, w, parent, kind='body', marker='dot', color='text', gap=None, name='Bullets'):
        """A list as auto-layout rows: marker + text. marker: dot, number, letter, check or none."""
        ty = TOKENS['type'][kind]
        lh = round(ty['size'] * ty['line'])
        box = self.frame(0, 0, w, 10, 'VERTICAL', gap=gap if gap is not None else round(ty['size'] * 0.75),
                         parent=parent, name=name)
        letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        for i, it in enumerate(items or []):
            text = it.get('text', '') if isinstance(it, dict) else it
            row = self.frame(0, 0, w, lh, 'HORIZONTAL', gap=24 if marker != 'none' else 0, parent=box,
                             hug_main=False, hug_cross=True, name=f'Item {i + 1}')
            mw = 0
            if marker == 'dot':
                d = max(10, round(ty['size'] * 0.42))
                holder = self.frame(0, 0, d, lh, 'NONE', parent=row, name='Marker')
                self.dot(0, (lh - d) / 2, d, 'dot', parent=holder)
                mw = d
            elif marker in ('number', 'letter', 'check'):
                label = {'number': f'{i + 1:02d}', 'letter': letters[i % 26], 'check': '✓'}[marker]
                mw = 56 if marker == 'number' else 44
                holder = self.frame(0, 0, mw, lh, 'NONE', parent=row, name='Marker')
                ky = TOKENS['type']['kicker']
                self.t(label, 'kicker', 0, (lh - round(ky['size'] * ky['line'])) / 2, mw, color='dot', parent=holder,
                       name='Marker label')
            tx = self.t(text, kind, 0, 0, w - mw - (24 if marker != 'none' else 0), color=color, parent=row, name='Text')
            tx['stackChildPrimaryGrow'] = 1.0
        return box

    def pill(self, label, parent=None, x=0, y=0, fill='button', color='button_text', kind='button', pad=(16, 32),
             stroke=None, url=None, name='Button'):
        """Rounded-full button or chip that hugs its text (CTA = pill)."""
        f = self.frame(x, y, 10, 10, 'HORIZONTAL', gap=12, pad=pad, parent=parent, fill=fill, radius=999,
                       hug_main=True, hug_cross=True, cross='CENTER', name=name, stroke=stroke)
        value = f'[{label}]({url})' if url else label
        tx = self.t(value, kind, 0, 0, 10, color=color, resize='WIDTH_AND_HEIGHT', parent=f, name='Label', link=color)
        if url:
            for o in (tx.get('textData') or {}).get('styleOverrideTable') or []:
                o['textDecoration'] = 'NONE'  # the whole pill is the link: no underline
        return f

    def chip(self, label, parent=None, x=0, y=0, variant='default'):
        """Small mono label: default (theme chip), new (Energetic Green), current (outline)."""
        if variant == 'new':
            return self.pill(label, parent, x, y, fill='green', color='midnight', kind='label', pad=(8, 18), name='Chip')
        if variant == 'current':
            return self.pill(label, parent, x, y, fill=None, color='muted', kind='label', pad=(8, 18), stroke='border', name='Chip')
        return self.pill(label, parent, x, y, fill='chip', color='chip_text', kind='label', pad=(8, 18), name='Chip')

    def image_file(self, path):
        if not path:
            return None
        full = path if os.path.isabs(path) else os.path.join(self.b.base_dir, path)
        return full if os.path.exists(full) else None

    def shot(self, path, x, y, w, h, fit='contain', radius=None, frame=True, drop=True, halign='center',
             valign='center', name='Screenshot', parent=None, placeholder='Screenshot'):
        """A picture inside the box x, y, w, h. contain: the whole picture at its own ratio (rounded,
        with a hairline frame and a soft shadow); cover: fills the box and crops."""
        radius = TOKENS['radius']['image'] if radius is None else radius
        full = self.image_file(path)
        if not full:
            if path:
                self.b.warnings.append(f'Slide {len(self.b.new_slides)}: image "{path}" not found, a placeholder was left.')
            box = self.rect(x, y, w, h, fill='stage', radius=radius, stroke='border', stroke_w=2, parent=parent)
            box['name'] = f'Placeholder: {os.path.basename(path) if path else placeholder}'
            self.t(placeholder if not path else f'{placeholder}: {os.path.basename(path)}', 'label', x, y + h / 2 - 12, w,
                   color='muted', align='CENTER', parent=parent, name='Placeholder label')
            return box
        paint, (iw, ih) = self.b.image_paint(full, 'FILL')
        if fit == 'contain':
            sc = min(w / iw, h / ih)
            rw, rh = iw * sc, ih * sc
            rx = x + {'left': 0, 'center': (w - rw) / 2, 'right': w - rw}[halign]
            ry = y + {'top': 0, 'center': (h - rh) / 2, 'bottom': h - rh}[valign]
        else:
            rx, ry, rw, rh = x, y, w, h
        node = self.rect(rx, ry, rw, rh, fill=None, radius=radius, stroke='frame' if frame else None, stroke_w=1.5,
                         parent=parent)
        node['fillPaints'] = [paint]
        if drop:
            node['effects'] = [shadow(self.tc('shadow'))]
        node['name'] = name
        return node

    def icon(self, name, x, y, d=72, fill='reviewpro', parent=None):
        """A template icon (question, settings, integrations, space) in white, centred on a round button.
        The icon is a copy of the template's own instance of that icon, scaled the way Figma scales
        instances (never swapped to another component, never resized by its box alone)."""
        circle = self.frame(x, y, d, d, 'NONE', parent=parent, fill=fill, radius=d / 2, name='Icon')
        key = str(name or 'question').lower()
        if key not in ICON_INSTANCES:
            self.b.warnings.append(f'Unknown icon "{name}". Use one of: {", ".join(ICON_INSTANCES)}')
            key = 'question'
        inst = self.add(ICON_INSTANCES[key], circle)
        size = round(d * 0.62)
        self.b.scale_instance(inst, size)
        self.place(inst, (d - size) / 2, (d - size) / 2)
        self.icon_white(inst)
        inst['name'] = f'Icon / {key}'
        return circle

    def brand_logo(self, x, y, color=None):
        return self.logo(x, y, white=(self.tc(color or 'logo') == 'white'))

    def footer(self, sp, note=None, logo=True):
        """Logo bottom right, a footnote or source bottom left."""
        sx = TOKENS['space']
        if logo and sp.get('logo', True) is not False:
            self.brand_logo(SLIDE_W - sx['margin_x'] - LOGO_W, sx['footer_y'])
        src = note
        if src is None and sp.get('source'):
            so = sp['source']
            src = f"Source: [{so.get('text', so.get('url'))}]({so['url']})" if isinstance(so, dict) and so.get('url') else \
                f"Source: {so.get('text') if isinstance(so, dict) else so}"
        if src:
            self.t(src, 'footnote', sx['margin_x'], sx['footer_y'] + 12, 1200, color='muted', name='Footnote')


# --------------------------------------------------------------------------- layouts
LAYOUTS = {}


def layout(name, theme, fields, about):
    """Register a layout. `theme` is its default (day, night or blue); a slide can set "theme" to switch."""
    def deco(fn):
        LAYOUTS[name] = {'fn': fn, 'theme': theme, 'fields': fields, 'about': about}
        return fn
    return deco


def lines_count(value):
    return len(paragraphs(value))


# --------------------------------------------------------------------------- post-layout pass
def finalize_slide(b, s, index):
    """Equalise card rows, place measured blocks in their vertical bands, flag blocks taller than their band."""
    b.d.reindex()
    for gid_ in s.slide.pop('_equal', []):
        row = b.d.nodes.get(gid_)
        kids = [c for c in b.d.children(row)] if row else []
        if kids:
            hmax = max(c['size']['y'] for c in kids)
            for c in kids:
                c['size']['y'] = hmax
                c['stackPrimarySizing'] = 'FIXED'
            b.stack(row)
            parent = b.d.nodes.get(figdeck.gid(row['parentIndex']['guid']))
            while parent is not None and parent.get('stackMode') in ('VERTICAL', 'HORIZONTAL'):
                b.stack(parent)
                parent = b.d.nodes.get(figdeck.gid(parent['parentIndex']['guid'])) if parent.get('parentIndex') else None
    for gid_, top, bottom, mode in s.slide.pop('_vplace', []):
        n = b.d.nodes.get(gid_)
        if n is None:
            continue
        hgt = n['size']['y']
        if hgt > bottom - top + 1:
            b.warnings.append(f'Slide {index}: the text block "{n.get("name")}" is {round(hgt - (bottom - top))}px taller '
                              f'than its space. Cut words or split the slide.')
        y = top if mode == 'top' else bottom - hgt if mode == 'bottom' else top + (bottom - top - hgt) / 2
        n['transform']['m12'] = float(max(0.0, round(y)))


def build(spec_path, out, template=TEMPLATE):
    spec = json.load(open(spec_path, encoding='utf-8'))
    b = Builder(template, base_dir=os.path.dirname(os.path.abspath(spec_path)))
    b.deck_spec = {k: v for k, v in spec.items() if k != 'slides'}
    built = []
    for i, sp in enumerate(spec.get('slides') or [], 1):
        name = sp.get('layout')
        if name not in LAYOUTS:
            raise SystemExit(f'Slide {i}: unknown layout "{name}". Run build_deck.py --layouts to see them.')
        L = LAYOUTS[name]
        s = b.start_slide(BASE_SLIDE, sp)
        s.keep_only()
        s.theme(sp.get('theme') or L['theme'])
        L['fn'](s, sp)
        built.append(s)
    b.measure_and_layout()
    for i, s in enumerate(built, 1):
        finalize_slide(b, s, i)
    b.finish()
    file_name = spec.get('file_name') or spec.get('title') or os.path.splitext(os.path.basename(out))[0]
    b.d.save(out, file_name=file_name)
    return b


def template_ids_in_code():
    src = ''.join(open(os.path.join(HERE, f), encoding='utf-8').read() for f in ('build_deck.py', 'layouts.py'))
    return sorted(set(re.findall(r"'(\d+:\d+)'", src)))


def check_template(path=TEMPLATE):
    """Every template layer id this script uses must exist in the template file."""
    d = figdeck.Deck(path)
    missing = [g for g in template_ids_in_code() if g not in d.nodes and not g.startswith('13:')]
    return {'template': os.path.abspath(path), 'ids_used': len(template_ids_in_code()), 'missing': missing}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('spec', nargs='?')
    ap.add_argument('--out')
    ap.add_argument('--preview', help='folder for the HTML/PNG preview and fit report')
    ap.add_argument('--pptx', help='also write a PowerPoint file')
    ap.add_argument('--template', default=TEMPLATE)
    ap.add_argument('--layouts', action='store_true', help='list layouts and their fields')
    ap.add_argument('--layouts-md', action='store_true', help='the layouts as the Markdown table of references/layouts.md')
    ap.add_argument('--check-template', action='store_true', help='confirm the template still has every layer this script uses')
    a = ap.parse_args()
    if a.check_template:
        r = check_template(a.template)
        print(json.dumps(r, indent=1))
        sys.exit(1 if r['missing'] else 0)
    if a.layouts_md:
        print('| Layout | Default theme | What it is | Fields |\n|---|---|---|---|')
        for k, v in LAYOUTS.items():
            print(f"| `{k}` | {v['theme']} | {v['about']} | {v['fields']} |")
        return
    if a.layouts:
        for k, v in LAYOUTS.items():
            print(f"{k:13} {v['theme']:5} | {v['about']}\n{'':13}       fields: {v['fields']}")
        return
    if a.out and a.out.lower().endswith('.deck'):
        print('Note: Figma\'s file browser refuses the .deck extension. Use .fig for files you drag into Figma.',
              file=sys.stderr)
    if not a.spec or not a.out:
        ap.error('spec and --out are required')
    b = build(a.spec, a.out, a.template)
    result = {'deck': os.path.abspath(a.out), 'slides': len(b.new_slides), 'warnings': b.warnings}
    if a.preview:
        report = render_deck.render(a.out, a.preview)
        result['preview'] = os.path.abspath(a.preview)
        result['fit_issues'] = report
    if a.pptx:
        import deck_to_pptx
        deck_to_pptx.convert(a.out, a.pptx)
        result['pptx'] = os.path.abspath(a.pptx)
    print(json.dumps(result, indent=1, ensure_ascii=False))


import layouts  # noqa: E402,F401  (registers the Day & Night layouts in LAYOUTS)

if __name__ == '__main__':
    main()
