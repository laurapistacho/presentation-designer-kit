#!/usr/bin/env python3
"""Read and write Figma Slides files (.fig or .deck) and Figma design files with the Python standard library.

A Slides file, whatever its extension, is a zip archive:
    canvas.fig      binary "fig-kiwi" document: magic + version + compressed chunks
    meta.json       file name, export date, background colour
    thumbnail.png   small preview
    images/<sha1>   every image used by an image fill, named by the SHA-1 of its bytes

`canvas.fig` holds two chunks: the kiwi schema (raw deflate) and the document message
(zstd in current Figma exports, raw deflate in older ones). The schema travels inside the
file, so this module decodes and re-encodes with the exact schema Figma wrote. Re-encoding an
unmodified document reproduces the original bytes; `python3 figdeck.py selftest <file>` checks it.

The zstd chunk is read and written with the `zstd` command line tool when it is installed
(Homebrew: `brew install zstd`). Without the tool:
  - writing stores the chunk in a valid zstd frame made of raw (uncompressed) blocks, so the
    file keeps the compression format Figma's own exports use;
  - reading works for frames made of raw blocks (files this module wrote without the tool) and
    for the kit template, whose decoded chunk is kept in `template/decoded/`
    (`python3 figdeck.py save-decoded <file.deck>` refreshes it; that step needs the tool);
  - reading any other zstd file (a deck saved by Figma) stops with a message to install the tool.
"""
import copy
import hashlib
import io
import json
import os
import shutil
import struct
import subprocess
import sys
import zipfile
import zlib

PRIMITIVES = ['bool', 'byte', 'int', 'uint', 'float', 'string', 'int64', 'uint64']
KINDS = ['ENUM', 'STRUCT', 'MESSAGE']
ZSTD_MAGIC = b'\x28\xb5\x2f\xfd'
KIT_ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', '..'))
DECODED_DIR = os.path.join(KIT_ROOT, 'template', 'decoded')


# --------------------------------------------------------------------------- byte buffers
class Reader:
    __slots__ = ('d', 'i')

    def __init__(self, data):
        self.d = data
        self.i = 0

    def byte(self):
        b = self.d[self.i]
        self.i += 1
        return b

    def varuint(self):
        shift = 0
        value = 0
        while True:
            b = self.d[self.i]
            self.i += 1
            value |= (b & 127) << shift
            shift += 7
            if not (b & 128) or shift >= 35:
                return value & 0xFFFFFFFF

    def varint(self):
        v = self.varuint()
        return ~(v >> 1) if v & 1 else v >> 1

    def varfloat(self):
        if self.d[self.i] == 0:
            self.i += 1
            return 0.0
        bits = int.from_bytes(self.d[self.i:self.i + 4], 'little')
        self.i += 4
        bits = ((bits << 23) | (bits >> 9)) & 0xFFFFFFFF
        return struct.unpack('<f', struct.pack('<I', bits))[0]

    def string(self):
        end = self.d.index(0, self.i)
        s = self.d[self.i:end].decode('utf-8')
        self.i = end + 1
        return s

    def varuint64(self):
        value = 0
        shift = 0
        while True:
            b = self.byte()
            if (b & 128) and shift < 56:
                value |= (b & 127) << shift
                shift += 7
            else:
                return value | (b << shift)

    def varint64(self):
        v = self.varuint64()
        return -(v >> 1) - 1 if v & 1 else v >> 1

    def bytes_(self):
        n = self.varuint()
        b = bytes(self.d[self.i:self.i + n])
        self.i += n
        return b


class Writer:
    __slots__ = ('b',)

    def __init__(self):
        self.b = bytearray()

    def byte(self, v):
        self.b.append(v & 255)

    def varuint(self, v):
        v &= 0xFFFFFFFF
        while True:
            byte = v & 127
            v >>= 7
            if v:
                self.b.append(byte | 128)
            else:
                self.b.append(byte)
                return

    def varint(self, v):
        v = int(v)
        self.varuint(((v << 1) ^ (v >> 31)) & 0xFFFFFFFF)

    def varfloat(self, v):
        bits = struct.unpack('<I', struct.pack('<f', float(v)))[0]
        bits = ((bits >> 23) | (bits << 9)) & 0xFFFFFFFF
        if bits & 255 == 0:
            self.b.append(0)
            return
        self.b += bits.to_bytes(4, 'little')

    def string(self, s):
        self.b += s.encode('utf-8')
        self.b.append(0)

    def varuint64(self, v):
        i = 0
        while v > 127 and i < 8:
            self.b.append((v & 127) | 128)
            v >>= 7
            i += 1
        self.b.append(v & 255)

    def varint64(self, v):
        self.varuint64((v << 1) if v >= 0 else (((-v - 1) << 1) | 1))

    def bytes_(self, data):
        self.varuint(len(data))
        self.b += data


# --------------------------------------------------------------------------- kiwi schema + codec
def decode_schema(data):
    r = Reader(data)
    defs = []
    for _ in range(r.varuint()):
        name = r.string()
        kind = KINDS[r.byte()]
        fields = []
        for _ in range(r.varuint()):
            fname = r.string()
            ftype = r.varint()
            is_array = bool(r.byte() & 1)
            value = r.varuint()
            fields.append([fname, ftype, is_array, value])
        defs.append((name, kind, fields))
    schema = {}
    for name, kind, fields in defs:
        if kind != 'ENUM':
            for f in fields:
                f[1] = PRIMITIVES[~f[1]] if f[1] < 0 else defs[f[1]][0]
        schema[name] = {'kind': kind, 'fields': fields}
    return schema


class Codec:
    def __init__(self, schema):
        self.schema = schema
        self.enum_by_value = {}
        self.enum_by_name = {}
        self.msg_by_id = {}
        for name, d in schema.items():
            if d['kind'] == 'ENUM':
                self.enum_by_value[name] = {f[3]: f[0] for f in d['fields']}
                self.enum_by_name[name] = {f[0]: f[3] for f in d['fields']}
            elif d['kind'] == 'MESSAGE':
                self.msg_by_id[name] = {f[3]: f for f in d['fields']}

    # -- decode
    def decode(self, data, root='Message'):
        return self._read(Reader(data), root, False)

    def _read(self, r, t, is_array):
        if is_array:
            if t == 'byte':
                return r.bytes_()
            return [self._read(r, t, False) for _ in range(r.varuint())]
        if t == 'bool':
            return r.byte() != 0
        if t == 'byte':
            return r.byte()
        if t == 'int':
            return r.varint()
        if t == 'uint':
            return r.varuint()
        if t == 'float':
            return r.varfloat()
        if t == 'string':
            return r.string()
        if t == 'int64':
            return r.varint64()
        if t == 'uint64':
            return r.varuint64()
        d = self.schema[t]
        kind = d['kind']
        if kind == 'ENUM':
            v = r.varuint()
            return self.enum_by_value[t].get(v, v)
        if kind == 'STRUCT':
            return {f[0]: self._read(r, f[1], f[2]) for f in d['fields']}
        out = {}
        fmap = self.msg_by_id[t]
        while True:
            fid = r.varuint()
            if fid == 0:
                return out
            f = fmap[fid]
            out[f[0]] = self._read(r, f[1], f[2])

    # -- encode
    def encode(self, value, root='Message'):
        w = Writer()
        self._write(w, root, False, value)
        return bytes(w.b)

    def _write(self, w, t, is_array, v):
        if is_array:
            if t == 'byte':
                w.bytes_(bytes.fromhex(v) if isinstance(v, str) else bytes(v))
                return
            w.varuint(len(v))
            for x in v:
                self._write(w, t, False, x)
            return
        if t == 'bool':
            w.byte(1 if v else 0)
        elif t == 'byte':
            w.byte(v)
        elif t == 'int':
            w.varint(v)
        elif t == 'uint':
            w.varuint(v)
        elif t == 'float':
            w.varfloat(v)
        elif t == 'string':
            w.string(v)
        elif t == 'int64':
            w.varint64(v)
        elif t == 'uint64':
            w.varuint64(v)
        else:
            d = self.schema[t]
            kind = d['kind']
            if kind == 'ENUM':
                w.varuint(self.enum_by_name[t][v] if isinstance(v, str) else v)
            elif kind == 'STRUCT':
                for f in d['fields']:
                    self._write(w, f[1], f[2], v[f[0]])
            else:
                # Fields are written in the order the dict holds them. Decoded messages keep
                # Figma's own field order, so an unmodified document re-encodes byte for byte.
                fields = self.msg_by_name(t)
                for name, val in v.items():
                    if val is None:
                        continue
                    f = fields.get(name)
                    if f is None:
                        raise KeyError(f'{t} has no field {name!r}')
                    w.varuint(f[3])
                    self._write(w, f[1], f[2], val)
                w.varuint(0)

    def msg_by_name(self, t):
        cache = self.__dict__.setdefault('_by_name', {})
        if t not in cache:
            cache[t] = {f[0]: f for f in self.schema[t]['fields']}
        return cache[t]


# --------------------------------------------------------------------------- compression
def have_zstd():
    return shutil.which('zstd') is not None


def zstd_store(data):
    """A valid zstd frame holding `data` in raw blocks (no compression). Any zstd reader decodes it."""
    out = bytearray(ZSTD_MAGIC)
    out.append(0xA0)  # frame header: 4-byte content size, single segment, no checksum, no dictionary
    out += struct.pack('<I', len(data))
    step, pos = 128 * 1024, 0  # 128 KB is the largest block zstd allows
    while True:
        block = data[pos:pos + step]
        pos += len(block)
        last = pos >= len(data)
        out += struct.pack('<I', (len(block) << 3) | int(last))[:3]  # block type 0 = raw
        out += block
        if last:
            return bytes(out)


def zstd_unstore(chunk):
    """Decode zstd frames made only of raw and RLE blocks; None when a frame holds compressed blocks."""
    out, i = bytearray(), 0
    while i < len(chunk):
        if chunk[i:i + 4] != ZSTD_MAGIC:
            return None
        fhd = chunk[i + 4]
        single = (fhd >> 5) & 1
        i += 5 + (0 if single else 1) + [0, 1, 2, 4][fhd & 3] + [single, 2, 4, 8][fhd >> 6]
        while True:
            h = int.from_bytes(chunk[i:i + 3], 'little')
            i += 3
            last, kind, size = h & 1, (h >> 1) & 3, h >> 3
            if kind == 0:
                out += chunk[i:i + size]
                i += size
            elif kind == 1:
                out += chunk[i:i + 1] * size
                i += 1
            else:
                return None
            if last:
                break
        if (fhd >> 2) & 1:
            i += 4  # content checksum
    return bytes(out)


def decoded_copy_path(chunk):
    return os.path.join(DECODED_DIR, hashlib.sha1(chunk).hexdigest() + '.zlib')


def decompress(chunk):
    if chunk[:4] == ZSTD_MAGIC:
        if have_zstd():
            return subprocess.run(['zstd', '-d', '-c', '-q'], input=chunk, capture_output=True, check=True).stdout
        data = zstd_unstore(chunk)
        if data is not None:
            return data
        copy_path = decoded_copy_path(chunk)
        if os.path.exists(copy_path):
            with open(copy_path, 'rb') as f:
                return zlib.decompress(f.read())
        raise RuntimeError('This file was saved by Figma with zstd compression. Install the zstd tool to read it '
                           '(Mac: brew install zstd) and retry. Building decks from the kit template does not need it.')
    try:
        return zlib.decompress(chunk, -15)
    except zlib.error:
        return zlib.decompress(chunk)


def compress(data, like):
    if like[:4] == ZSTD_MAGIC:
        # Match Figma's own frames: content size in the header, one segment, no checksum (header byte 0xA0).
        # Data piped to the zstd tool has no known size, so the tool leaves the size out unless told; files
        # written that way failed Figma's import ("Internal error during import"). zstd_store writes the same
        # header as Figma when the tool is missing or too old for these options.
        if have_zstd():
            res = subprocess.run(['zstd', '-c', '-q', '-3', '--no-check', f'--stream-size={len(data)}'], input=data,
                                 capture_output=True)
            out = res.stdout
            if res.returncode == 0 and len(out) > 5 and (out[4] & 0x20) and not (out[4] & 0x04):
                return out
        return zstd_store(data)
    c = zlib.compressobj(9, zlib.DEFLATED, -15)
    return c.compress(data) + c.flush()


def _canvas_chunks(path):
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            canvas = z.read('canvas.fig')
    else:
        with open(path, 'rb') as f:
            canvas = f.read()
    i, chunks = 12, []
    while i < len(canvas):
        n = int.from_bytes(canvas[i:i + 4], 'little')
        chunks.append(canvas[i + 4:i + 4 + n])
        i += 4 + n
    return chunks


def _needs_decoded_copy(chunk):
    return chunk[:4] == ZSTD_MAGIC and zstd_unstore(chunk) is None


def has_decoded_copy(path):
    """True when `path` reads without the zstd tool (its compressed zstd chunks are in template/decoded/)."""
    return all(os.path.exists(decoded_copy_path(c)) for c in _canvas_chunks(path) if _needs_decoded_copy(c))


def save_decoded(path, prune=False):
    """Keep the decoded zstd chunks of `path` in template/decoded/ so it reads without the zstd tool.
    Needs the tool. `prune` removes copies that belong to no chunk of `path` (an older template).
    Returns {'written': [...], 'removed': [...]}."""
    if not have_zstd():
        raise RuntimeError('Saving the decoded copy needs the zstd tool (Mac: brew install zstd).')
    written, keep = [], set()
    for chunk in _canvas_chunks(path):
        if not _needs_decoded_copy(chunk):
            continue
        target = decoded_copy_path(chunk)
        keep.add(os.path.basename(target))
        decoded = decompress(chunk)
        try:
            with open(target, 'rb') as f:
                current = zlib.decompress(f.read()) == decoded
        except (OSError, zlib.error):
            current = False
        if not current:
            os.makedirs(DECODED_DIR, exist_ok=True)
            with open(target, 'wb') as f:
                f.write(zlib.compress(decoded, 9))
            written.append(target)
    removed = []
    if prune and os.path.isdir(DECODED_DIR):
        for name in sorted(os.listdir(DECODED_DIR)):
            if name.endswith('.zlib') and name not in keep:
                os.remove(os.path.join(DECODED_DIR, name))
                removed.append(name)
    return {'written': written, 'removed': removed}


# --------------------------------------------------------------------------- guid helpers
def gid(g):
    """'sessionID:localID' for a guid dict (or for a node that carries a 'guid')."""
    if 'guid' in g and isinstance(g['guid'], dict):
        g = g['guid']
    return f"{g['sessionID']}:{g['localID']}"


def guid(text):
    s, l = text.split(':')
    return {'sessionID': int(s), 'localID': int(l)}


POS_DIGITS = ''.join(chr(c) for c in range(0x21, 0x7E))  # '!'..'}'


def positions(n):
    """n strictly increasing fractional-index keys for sibling ordering (Figma compares them as strings)."""
    base = len(POS_DIGITS)
    width = 1
    while (base - 2) ** width < n + 1:
        width += 1
    span = (base - 2) ** width
    step = span // (n + 1)
    out = []
    for i in range(1, n + 1):
        v = i * step
        digits = []
        for _ in range(width):
            digits.append(POS_DIGITS[1 + v % (base - 2)])
            v //= (base - 2)
        out.append(''.join(reversed(digits)))
    return out


# --------------------------------------------------------------------------- the deck
class Deck:
    def __init__(self, path=None):
        self.path = path
        self.magic = b'fig-deck'
        self.version = 106
        self.raw_chunks = []
        self.codec = None
        self.message = None
        self.images = {}
        self.meta = {}
        self.thumbnail = None
        self.extra_files = {}
        if path:
            self.load(path)

    # -- io
    def load(self, path):
        if zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as z:
                canvas = z.read('canvas.fig')
                for name in z.namelist():
                    if name.startswith('images/') and not name.endswith('/'):
                        self.images[name.split('/', 1)[1]] = z.read(name)
                    elif name == 'meta.json':
                        self.meta = json.loads(z.read(name))
                    elif name == 'thumbnail.png':
                        self.thumbnail = z.read(name)
                    elif name not in ('canvas.fig',) and not name.endswith('/'):
                        self.extra_files[name] = z.read(name)
        else:
            canvas = open(path, 'rb').read()
        self.magic = canvas[:8]
        self.version = int.from_bytes(canvas[8:12], 'little')
        i = 12
        self.raw_chunks = []
        while i < len(canvas):
            n = int.from_bytes(canvas[i:i + 4], 'little')
            self.raw_chunks.append(canvas[i + 4:i + 4 + n])
            i += 4 + n
        self.codec = Codec(decode_schema(decompress(self.raw_chunks[0])))
        self.message_bytes = decompress(self.raw_chunks[1])
        self.message = self.codec.decode(self.message_bytes)
        self.reindex()
        return self

    def canvas_bytes(self):
        data = self.codec.encode(self.message)
        chunk1 = compress(data, self.raw_chunks[1])
        out = bytearray(self.magic)
        out += self.version.to_bytes(4, 'little')
        for chunk in [self.raw_chunks[0], chunk1] + self.raw_chunks[2:]:
            out += len(chunk).to_bytes(4, 'little')
            out += chunk
        return bytes(out)

    def save(self, path, file_name=None, prune_images=True):
        canvas = self.canvas_bytes()
        meta = copy.deepcopy(self.meta) or {}
        if file_name:
            meta['file_name'] = file_name
        used = self.used_image_hashes() if prune_images else set(self.images)
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_STORED) as z:
            z.writestr('canvas.fig', canvas)
            if self.thumbnail:
                z.writestr('thumbnail.png', self.thumbnail)
            z.writestr('meta.json', json.dumps(meta, separators=(',', ':')), compress_type=zipfile.ZIP_DEFLATED)  # as Figma does
            z.writestr(zipfile.ZipInfo('images/'), b'')
            for h, data in self.images.items():
                if h in used:
                    z.writestr('images/' + h, data)
            videos = self.used_video_hashes() if prune_images else None
            for name, data in self.extra_files.items():
                if videos is not None and name.startswith('videos/') and name.split('/', 1)[1] not in videos:
                    continue  # a video no layer plays any more (the template's own, for example)
                z.writestr(name, data)
        return path

    def used_video_hashes(self):
        used = set()

        def scan(o):
            if isinstance(o, dict):
                v = o.get('video')
                if o.get('type') == 'VIDEO' and isinstance(v, dict) and 'hash' in v:
                    h = v['hash']
                    used.add(h.hex() if isinstance(h, (bytes, bytearray)) else h)
                for x in o.values():
                    scan(x)
            elif isinstance(o, list):
                for x in o:
                    scan(x)
        scan(self.message['nodeChanges'])
        return used

    # -- index
    def reindex(self):
        self.nodes = {}
        self.kids = {}
        for n in self.message['nodeChanges']:
            self.nodes[gid(n['guid'])] = n
        for n in self.message['nodeChanges']:
            p = n.get('parentIndex')
            if p:
                self.kids.setdefault(gid(p['guid']), []).append(n)
        for k in self.kids:
            self.kids[k].sort(key=lambda n: n['parentIndex'].get('position', ''))

    def children(self, node_or_id):
        key = node_or_id if isinstance(node_or_id, str) else gid(node_or_id['guid'])
        return self.kids.get(key, [])

    def parent(self, node):
        p = node.get('parentIndex')
        return self.nodes.get(gid(p['guid'])) if p else None

    def walk(self, node, depth=0):
        yield node, depth
        for c in self.children(node):
            yield from self.walk(c, depth + 1)

    def subtree(self, node):
        return [n for n, _ in self.walk(node)]

    def of_type(self, t):
        return [n for n in self.message['nodeChanges'] if n.get('type') == t]

    def slide_grid(self):
        return self.of_type('SLIDE_GRID')[0]

    def slide_rows(self):
        return self.children(self.slide_grid())

    def slides(self):
        """SLIDE nodes in presentation order (rows top to bottom, slides left to right)."""
        out = []
        for row in self.slide_rows():
            for c in self.children(row):
                if c['type'] == 'SLIDE':
                    out.append(c)
                else:  # slide templates are wrapped in a MODULE
                    out += [k for k in self.children(c) if k['type'] == 'SLIDE']
        return out

    def used_image_hashes(self):
        used = set()

        def scan(o):
            if isinstance(o, dict):
                for k, v in o.items():
                    if k in ('image', 'imageThumbnail', 'animatedImage') and isinstance(v, dict) and 'hash' in v:
                        h = v['hash']
                        used.add(h.hex() if isinstance(h, (bytes, bytearray)) else h)
                    else:
                        scan(v)
            elif isinstance(o, list):
                for v in o:
                    scan(v)
        scan(self.message['nodeChanges'])
        return used

    def add_image(self, data):
        h = hashlib.sha1(data).hexdigest()
        self.images[h] = data
        return h

    def max_session(self):
        return max(n['guid']['sessionID'] for n in self.message['nodeChanges'])


def image_hash_hex(paint_image):
    h = paint_image.get('hash')
    return h.hex() if isinstance(h, (bytes, bytearray)) else h


def selftest(path):
    d = Deck(path)
    again = d.codec.encode(d.message)
    same = again == d.message_bytes
    print(json.dumps({
        'file': path,
        'version': d.version,
        'nodes': len(d.message['nodeChanges']),
        'slides': len(d.slides()),
        'images': len(d.images),
        'roundtrip_identical': same,
        'zstd_available': have_zstd(),
    }, indent=1))
    return 0 if same else 1


if __name__ == '__main__':
    if len(sys.argv) >= 3 and sys.argv[1] == 'selftest':
        sys.exit(selftest(sys.argv[2]))
    if len(sys.argv) >= 3 and sys.argv[1] == 'save-decoded':
        print(json.dumps(save_decoded(sys.argv[2], prune=True), indent=1))
        sys.exit(0)
    print('usage: figdeck.py selftest <file.fig>\n'
          '       figdeck.py save-decoded <template.deck>   (keeps template/decoded/ current; needs the zstd tool)')
    sys.exit(2)
