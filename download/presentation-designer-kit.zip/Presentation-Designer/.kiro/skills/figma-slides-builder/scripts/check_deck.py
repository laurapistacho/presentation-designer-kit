#!/usr/bin/env python3
"""Structural check of a Figma Slides file (.fig or .deck) before it goes to Figma. Exit code 0 = no errors.

    python3 check_deck.py out.fig

Checks: the file decodes and re-encodes identically, every layer has a living parent and a unique
id, every component instance points at an existing component, text runs and lines match the text,
every colour variable and text style a layer points at exists, every image fill has its image in
the archive, and slides are 1920x1080 inside the slide grid.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figdeck  # noqa: E402

SENTINEL = 4294967295


def refs(o, path=''):
    """Yield (path, guid) for every {'sessionID','localID'} dict inside o."""
    if isinstance(o, dict):
        if set(o) == {'sessionID', 'localID'}:
            yield path, o
            return
        for k, v in o.items():
            yield from refs(v, f'{path}.{k}' if path else k)
    elif isinstance(o, list):
        for v in o:
            yield from refs(v, path + '[]')


def check(path):
    errors, warnings = [], []
    d = figdeck.Deck(path)
    again = d.codec.encode(d.message)
    if again != d.message_bytes:
        errors.append('document does not re-encode to the same bytes')
    if d.message.get('nodeChangeOrder') == 'GUID':
        keys = [(n['guid']['sessionID'], n['guid']['localID']) for n in d.message['nodeChanges']]
        if keys != sorted(keys):
            errors.append('layers are not stored in id order, but the file says they are')
    seen = set()
    for n in d.message['nodeChanges']:
        g = figdeck.gid(n)
        if g in seen:
            errors.append(f'duplicate id {g}')
        seen.add(g)
    for n in d.message['nodeChanges']:
        g = figdeck.gid(n)
        p = n.get('parentIndex')
        if n.get('type') != 'DOCUMENT' and not p:
            errors.append(f'{g} {n.get("type")} has no parent')
        if p and figdeck.gid(p['guid']) not in d.nodes:
            errors.append(f'{g} {n.get("type")} {n.get("name")!r}: parent {figdeck.gid(p["guid"])} is missing')
        if n.get('type') == 'INSTANCE':
            sid = (n.get('symbolData') or {}).get('symbolID')
            if not sid or figdeck.gid(sid) not in d.nodes:
                errors.append(f'{g} instance {n.get("name")!r}: component {figdeck.gid(sid) if sid else None} is missing')
        for where, ref in refs({k: v for k, v in n.items() if k in ('fillPaints', 'strokePaints', 'styleIdForText', 'styleIdForFill', 'textData')}):
            if ref['sessionID'] == SENTINEL:
                continue
            if where.endswith('alias.guid') or where.endswith('styleIdForText.guid') or where.endswith('styleIdForFill.guid'):
                if figdeck.gid(ref) not in d.nodes:
                    errors.append(f'{g} {n.get("name")!r}: {where} points at missing {figdeck.gid(ref)}')
        if n.get('type') == 'TEXT':
            td = n.get('textData') or {}
            chars = td.get('characters', '')
            ids = td.get('characterStyleIDs') or []
            if len(ids) > len(chars):
                errors.append(f'{g} text {n.get("name")!r}: more style ids ({len(ids)}) than characters ({len(chars)})')
            table = {o['styleID'] for o in td.get('styleOverrideTable') or []}
            missing = set(ids) - table - {0}
            if missing:
                errors.append(f'{g} text {n.get("name")!r}: style runs {sorted(missing)} have no definition')
            paras = chars.count('\n') + 1
            if td.get('lines') is not None and len(td['lines']) != paras:
                errors.append(f'{g} text {n.get("name")!r}: {len(td["lines"])} line entries for {paras} paragraphs')
            if not chars.strip():
                warnings.append(f'{g} text {n.get("name")!r} is empty')
        for p_ in (n.get('fillPaints') or []):
            if p_.get('type') == 'IMAGE':
                h = figdeck.image_hash_hex(p_.get('image') or {})
                if h and h not in d.images:
                    errors.append(f'{g} {n.get("name")!r}: image {h} is not in the file')
    slides = d.slides()
    slide_ids = {figdeck.gid(s) for s in slides}
    for s in slides:
        for pi in s.get('prototypeInteractions') or []:
            for a in pi.get('actions') or []:
                t = a.get('transitionNodeID')
                if t and figdeck.gid(t) not in d.nodes:
                    errors.append(f'slide {s.get("name")!r}: its click-through goes to a missing layer {figdeck.gid(t)}')
                elif t and figdeck.gid(t) not in slide_ids:
                    warnings.append(f'slide {s.get("name")!r}: its click-through goes to a layer that is not a slide')
    for row in d.slide_rows():
        if row.get('type') != 'SLIDE_ROW':
            errors.append(f'{figdeck.gid(row)} sits in the slide grid but is a {row.get("type")}, not a slide row')
    for s in slides:
        sz = s.get('size', {})
        if round(sz.get('x', 0)) != 1920 or round(sz.get('y', 0)) != 1080:
            errors.append(f'slide {s.get("name")!r} is {sz} instead of 1920x1080')
    return {'file': os.path.abspath(path), 'slides': len(slides), 'rows': len(d.slide_rows()), 'layers': len(d.message['nodeChanges']),
            'images': len(d.images), 'errors': errors, 'warnings': warnings[:20]}


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    r = check(sys.argv[1])
    print(json.dumps(r, indent=1, ensure_ascii=False))
    sys.exit(1 if r['errors'] else 0)
