#!/usr/bin/env python3
"""Preview a Figma Slides file (.fig or .deck): HTML deck, PNG per slide, contact sheet and a fit report.

    python3 render_deck.py deck.fig --out preview/          # all slides
    python3 render_deck.py deck.fig --out preview/ --slides 3-5

Output in --out:
    index.html          full-size slides, arrow keys / click to move, F for fullscreen
    slides/NN.png       one PNG per slide (960x540 by default, --scale 1 for 1920x1080)
    contact-sheet.png   every slide on one image, numbered
    report.json         text that runs past the slide edge or past its own box

This is an approximation built with headless Chrome. Figma is the source of truth: fonts,
line breaks and blur strength can differ slightly. Fonts come from the fonts installed on this
computer first (Shiji Day Sans Aeonik, Shiji Night Serif Reckless Neue, Noto Sans), then
from the Shiji website and Google Fonts. Videos show their poster frame.
"""
import argparse
import html
import json
import math
import os
import re
import shutil
import struct
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figdeck  # noqa: E402

SLIDE_W, SLIDE_H = 1920, 1080

WEIGHTS = [('extralight', 200), ('ultralight', 200), ('semibold', 600), ('demibold', 600), ('extrabold', 800),
           ('ultrabold', 800), ('hairline', 100), ('thin', 100), ('air', 200), ('light', 300), ('regular', 400),
           ('normal', 400), ('book', 400), ('medium', 500), ('bold', 700), ('black', 900), ('heavy', 900)]

FONT_STACKS = {
    'Shiji Day Sans Aeonik': "'Shiji Day Sans Aeonik','ShijiDaySansCDN',system-ui,sans-serif",
    'Shiji Night Serif Reckless Neue': "'Shiji Night Serif Reckless Neue','ShijiNightSerifCDN',Georgia,serif",
    'Lato': "'Lato',sans-serif",
    'Noto Sans': "'Noto Sans',sans-serif",
    'Noto Sans Mono': "'Noto Sans Mono',ui-monospace,Menlo,monospace",
    'Inter': "'Inter',sans-serif",
}

FONT_HEAD = """<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&family=Lato:wght@300;400;700;900&family=Noto+Sans:wght@400;500;700&family=Noto+Sans+Mono:wght@400;500;700&display=swap" rel="stylesheet">
<style>
@font-face{font-family:'ShijiDaySansCDN';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9c_ShijiDaySansAeonik-Regular.woff2') format('woff2');font-weight:400;}
@font-face{font-family:'ShijiDaySansCDN';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8f_ShijiDaySansAeonik-Medium.woff2') format('woff2');font-weight:500;}
@font-face{font-family:'ShijiDaySansCDN';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9d_ShijiDaySansAeonik-Bold.woff2') format('woff2');font-weight:700 900;}
@font-face{font-family:'ShijiNightSerifCDN';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8e_ShijiNightSerifRecklessNeue-Regular.woff2') format('woff2');font-weight:100 500;}
@font-face{font-family:'ShijiNightSerifCDN';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67dac539ac844f1933bcafb0_ShijiNightSerifRecklessNeue-Heavy.woff2') format('woff2');font-weight:600 900;}
</style>"""


# --------------------------------------------------------------------------- small math
def mat(t):
    t = t or {}
    return [t.get('m00', 1.0), t.get('m01', 0.0), t.get('m02', 0.0), t.get('m10', 0.0), t.get('m11', 1.0), t.get('m12', 0.0)]


def mul(a, b):
    """a after b (both 2x3 as [m00,m01,m02,m10,m11,m12])."""
    return [a[0] * b[0] + a[1] * b[3], a[0] * b[1] + a[1] * b[4], a[0] * b[2] + a[1] * b[5] + a[2],
            a[3] * b[0] + a[4] * b[3], a[3] * b[1] + a[4] * b[4], a[3] * b[2] + a[4] * b[5] + a[5]]


def inv(m):
    a, b, c, d, e, f = m
    det = a * e - b * d
    if abs(det) < 1e-12:
        return [1, 0, 0, 0, 1, 0]
    return [e / det, -b / det, (b * f - c * e) / det, -d / det, a / det, (c * d - a * f) / det]


def apply(m, x, y):
    return m[0] * x + m[1] * y + m[2], m[3] * x + m[4] * y + m[5]


def css_matrix(m):
    return 'matrix({:.6f},{:.6f},{:.6f},{:.6f},{:.3f},{:.3f})'.format(m[0], m[3], m[1], m[4], m[2], m[5])


def rgba(c, opacity=1.0):
    if not c:
        return 'transparent'
    return 'rgba({},{},{},{:.4f})'.format(round(c.get('r', 0) * 255), round(c.get('g', 0) * 255),
                                           round(c.get('b', 0) * 255), c.get('a', 1.0) * opacity)


def hex_color(c):
    return '#%02X%02X%02X' % tuple(round(c.get(k, 0) * 255) for k in 'rgb')


TEXT_STYLE_KEYS = ('fontName', 'fontSize', 'lineHeight', 'letterSpacing', 'textCase', 'textDecoration',
                   'paragraphSpacing', 'paragraphIndent', 'fontVariations', 'listSpacing')


# Line height of each family as Figma measures it (ascender + descender + gap, per 1px of font size).
# Figma's "100%" line height means 100% of this value, not 100% of the font size.
FONT_LINE_HEIGHT = {'Lato': 1.2, 'Shiji Day Sans Aeonik': 1.14, 'Shiji Night Serif Reckless Neue': 1.121,
                    'Noto Sans': 1.362, 'Noto Sans Mono': 1.362, 'Inter': 1.21, 'Helvetica Neue': 1.193, 'Aeonik TRIAL': 1.2}


def figma_line_height(lh, size, font_name=None):
    lh = lh or {}
    u, v = lh.get('units'), lh.get('value')
    if u == 'PIXELS':
        return v
    if u == 'PERCENT':
        return v / 100.0 * size * FONT_LINE_HEIGHT.get((font_name or {}).get('family'), 1.2)
    if u == 'RAW':
        return v * size
    return size * FONT_LINE_HEIGHT.get((font_name or {}).get('family'), 1.2)


def font_css(font_name):
    family = (font_name or {}).get('family', 'Lato')
    style = ((font_name or {}).get('style') or 'Regular').lower().replace(' ', '').replace('-', '')
    weight = 400
    for key, w in WEIGHTS:
        if key in style:
            weight = w
            break
    italic = 'italic' in style or 'oblique' in style
    stack = FONT_STACKS.get(family, "'{}',sans-serif".format(family.replace("'", '')))
    return stack, weight, italic


def esc(s):
    return html.escape(s, quote=False)


# --------------------------------------------------------------------------- geometry blobs
def path_from_blob(blob):
    b = blob['bytes'] if isinstance(blob, dict) else blob
    i, out = 0, []
    n = len(b)
    while i < n:
        cmd = b[i]
        i += 1
        if cmd == 0:
            out.append('Z')
            continue
        count = {1: 2, 2: 2, 3: 4, 4: 6}.get(cmd)
        if count is None or i + 4 * count > n:
            break
        vals = struct.unpack_from('<%df' % count, b, i)
        i += 4 * count
        out.append({1: 'M', 2: 'L', 3: 'Q', 4: 'C'}[cmd] + ' '.join('%.2f' % v for v in vals))
    return ' '.join(out)


class Renderer:
    def __init__(self, deck, image_dir=None, image_url_prefix='images/'):
        self.d = deck
        self.blobs = deck.message.get('blobs', [])
        self.image_dir = image_dir
        self.image_url_prefix = image_url_prefix
        self.image_ext = {}
        self.text_ids = []

    # ------------------------------------------------------------------ styles
    def d_style(self, ref):
        """Local style node for a styleIdFor* reference (by guid or by library key), else None."""
        if not ref:
            return None
        g = ref.get('guid')
        if g:
            if g.get('sessionID') == 4294967295:
                return None
            return self.d.nodes.get(figdeck.gid(g))
        key = (ref.get('assetRef') or {}).get('key')
        if key:
            if not hasattr(self, '_style_by_key'):
                self._style_by_key = {x['key']: x for x in self.d.message['nodeChanges'] if x.get('styleType') and x.get('key')}
            return self._style_by_key.get(key)
        return None

    def fills_of(self, n, field='fillPaints', style_field='styleIdForFill'):
        st = self.d_style(n.get(style_field))
        if st and st.get('fillPaints') is not None:
            return st['fillPaints']
        return n.get(field)

    # ------------------------------------------------------------------ images
    def image_url(self, h):
        if h not in self.d.images:
            return None
        if h not in self.image_ext:
            data = self.d.images[h]
            ext = 'png' if data[:4] == b'\x89PNG' else 'gif' if data[:3] == b'GIF' else 'jpg'
            self.image_ext[h] = ext
            if self.image_dir:
                os.makedirs(self.image_dir, exist_ok=True)
                p = os.path.join(self.image_dir, f'{h}.{ext}')
                if not os.path.exists(p):
                    open(p, 'wb').write(data)
        return f'{self.image_url_prefix}{h}.{self.image_ext[h]}'

    # ------------------------------------------------------------------ paints
    def paint_layers(self, paints, w, h, uid):
        """HTML for paint layers, bottom to top. Each layer fills its (already clipped) parent."""
        out = []
        for k, p in enumerate(paints or []):
            if not p.get('visible', True):
                continue
            op = p.get('opacity', 1.0)
            blend = p.get('blendMode', 'NORMAL')
            style = 'position:absolute;inset:0;'
            if blend not in ('NORMAL', 'PASS_THROUGH'):
                style += 'mix-blend-mode:{};'.format(blend.lower().replace('_', '-'))
            t = p.get('type')
            if t == 'SOLID':
                out.append(f'<div style="{style}background:{rgba(p.get("color"), op)}"></div>')
            elif t in ('GRADIENT_LINEAR', 'GRADIENT_RADIAL', 'GRADIENT_DIAMOND'):
                gi = inv(mat(p.get('transform')))
                stops = ''.join('<stop offset="{:.4f}" stop-color="{}" stop-opacity="{:.4f}"/>'.format(
                    s['position'], hex_color(s['color']), s['color'].get('a', 1)) for s in p.get('stops', []))
                gid_ = f'g{uid}_{k}'
                if t == 'GRADIENT_LINEAR':
                    x1, y1 = apply(gi, 0, 0.5)
                    x2, y2 = apply(gi, 1, 0.5)
                    grad = (f'<linearGradient id="{gid_}" gradientUnits="userSpaceOnUse" x1="{x1 * w:.2f}" y1="{y1 * h:.2f}" '
                            f'x2="{x2 * w:.2f}" y2="{y2 * h:.2f}">{stops}</linearGradient>')
                else:
                    gm = mul([w, 0, 0, 0, h, 0], gi)
                    grad = (f'<radialGradient id="{gid_}" gradientUnits="userSpaceOnUse" cx="0.5" cy="0.5" r="0.5" '
                            f'gradientTransform="matrix({gm[0]:.6f},{gm[3]:.6f},{gm[1]:.6f},{gm[4]:.6f},{gm[2]:.3f},{gm[5]:.3f})">{stops}</radialGradient>')
                out.append(f'<svg style="{style}opacity:{op}" width="{w:.2f}" height="{h:.2f}" viewBox="0 0 {w:.2f} {h:.2f}" preserveAspectRatio="none">'
                           f'<defs>{grad}</defs><rect width="100%" height="100%" fill="url(#{gid_})"/></svg>')
            elif t == 'GRADIENT_ANGULAR':
                # Paint the conic gradient in gradient space (unit square, centre 0.5/0.5, start pointing right,
                # clockwise) and map it into the node with the inverse paint transform.
                gi = inv(mat(p.get('transform')))
                stops = p.get('stops', [])
                parts = ['{} {:.3f}%'.format(rgba(s['color']), s['position'] * 100) for s in stops]
                if stops and stops[0]['position'] > 0:
                    parts.insert(0, '{} 0%'.format(rgba(stops[-1]['color'])))
                span = 5.0  # gradient-space square from -2 to 3 so the node is always covered
                px = 500.0
                m = mul([w, 0, 0, 0, h, 0], mul(gi, [span / px, 0, -2, 0, span / px, -2]))
                out.append(f'<div style="{style}overflow:hidden;opacity:{op}"><div style="position:absolute;left:0;top:0;width:{px}px;height:{px}px;'
                           f'transform-origin:0 0;transform:{css_matrix(m)};background:conic-gradient(from 90deg at 50% 50%,{",".join(parts)})"></div></div>')
            elif t in ('IMAGE', 'VIDEO'):  # a video shows its poster frame, as Figma does until it plays
                img = p.get('image') or {}
                url = self.image_url(figdeck.image_hash_hex(img)) if img.get('hash') else None
                if not url:
                    out.append(f'<div style="{style}background:repeating-linear-gradient(45deg,#ccd,#ccd 10px,#eef 10px,#eef 20px);opacity:{op}"></div>')
                    continue
                mode = p.get('imageScaleMode', 'FILL')
                if mode == 'FIT':
                    bg = f"background:url('{url}') center/contain no-repeat"
                elif mode == 'TILE':
                    sc = p.get('scale', 1.0) or 1.0
                    bg = f"background:url('{url}') 0 0/{p.get('originalImageWidth', 100) * sc}px auto repeat"
                elif mode in ('STRETCH', 'CROP') and p.get('transform'):
                    gi = inv(mat(p.get('transform')))
                    m = mul([w, 0, 0, 0, h, 0], mul(gi, [1 / 1000, 0, 0, 0, 1 / 1000, 0]))
                    out.append(f'<div style="{style}overflow:hidden;opacity:{op}"><img src="{url}" style="position:absolute;left:0;top:0;width:1000px;height:1000px;'
                               f'transform-origin:0 0;transform:{css_matrix(m)}"></div>')
                    continue
                else:
                    bg = f"background:url('{url}') center/cover no-repeat"
                out.append(f'<div style="{style}{bg};opacity:{op}"></div>')
        return ''.join(out)

    # ------------------------------------------------------------------ effects
    def effect_css(self, n, is_text=False):
        shadows, filters = [], []
        for e in n.get('effects') or []:
            if not e.get('visible', True):
                continue
            t = e.get('type')
            if t == 'DROP_SHADOW':
                o = e.get('offset', {})
                if is_text:
                    shadows.append('{:.1f}px {:.1f}px {:.1f}px {}'.format(o.get('x', 0), o.get('y', 0), e.get('radius', 0), rgba(e.get('color'))))
                else:
                    shadows.append('{:.1f}px {:.1f}px {:.1f}px {:.1f}px {}'.format(o.get('x', 0), o.get('y', 0), e.get('radius', 0), e.get('spread', 0), rgba(e.get('color'))))
            elif t == 'INNER_SHADOW' and not is_text:
                o = e.get('offset', {})
                shadows.append('inset {:.1f}px {:.1f}px {:.1f}px {:.1f}px {}'.format(o.get('x', 0), o.get('y', 0), e.get('radius', 0), e.get('spread', 0), rgba(e.get('color'))))
            elif t == 'FOREGROUND_BLUR':
                filters.append('blur({:.1f}px)'.format(e.get('radius', 0) / 2.0))
        css = ''
        if shadows:
            css += ('text-shadow:' if is_text else 'box-shadow:') + ','.join(shadows) + ';'
        if filters:
            css += 'filter:' + ' '.join(filters) + ';'
        return css

    # ------------------------------------------------------------------ text
    def text_inner(self, n):
        td = n.get('textData') or {}
        chars = td.get('characters', '')
        ids = td.get('characterStyleIDs') or []
        table = {o['styleID']: o for o in td.get('styleOverrideTable') or []}
        lines = td.get('lines') or []
        # A linked local text style wins over the layer's own (possibly stale) type settings.
        base = dict(n)
        st = self.d_style(n.get('styleIdForText'))
        if st:
            base.update({k: st[k] for k in TEXT_STYLE_KEYS if k in st})
        merged = {}
        for sid, o in table.items():
            props = {}
            st = self.d_style(o.get('styleIdForText'))
            if st:
                props.update({k: st[k] for k in TEXT_STYLE_KEYS if k in st})
            props.update({k: v for k, v in o.items() if k not in ('styleID', 'styleIdForText')})
            merged[sid] = props

        def style_of(sid):
            o = merged.get(sid) if sid else None
            get = (lambda k, dflt=None: (o.get(k) if o and k in o else base.get(k, dflt)))
            return get

        def run_css(sid):
            get = style_of(sid)
            stack, weight, italic = font_css(get('fontName'))
            size = get('fontSize', 12.0)
            css = f'font-family:{stack};font-weight:{weight};font-size:{size:.2f}px;'
            if italic:
                css += 'font-style:italic;'
            ls = get('letterSpacing') or {}
            if ls.get('value'):
                v = ls['value'] * size / 100.0 if ls.get('units') == 'PERCENT' else ls['value']
                css += f'letter-spacing:{v:.3f}px;'
            fills = [p for p in (get('fillPaints') or []) if p.get('visible', True)]
            if fills:
                p = fills[-1]
                if p.get('type') == 'SOLID':
                    css += f'color:{rgba(p.get("color"), p.get("opacity", 1.0))};'
                elif p.get('stops'):
                    css += f'color:{rgba(p["stops"][0]["color"])};'
            deco = get('textDecoration', 'NONE')
            if deco == 'UNDERLINE':
                css += 'text-decoration:underline;'
            elif deco == 'STRIKETHROUGH':
                css += 'text-decoration:line-through;'
            else:
                css += 'text-decoration:none;'  # links without an underline stay plain, as in Figma
            case = get('textCase', 'ORIGINAL')
            if case == 'UPPER':
                css += 'text-transform:uppercase;'
            elif case == 'LOWER':
                css += 'text-transform:lowercase;'
            elif case == 'TITLE':
                css += 'text-transform:capitalize;'
            return css, size, get

        def line_height(get, size):
            return figma_line_height(get('lineHeight'), size, get('fontName'))

        # split into paragraphs on '\n'
        paras = []
        start = 0
        for i, ch in enumerate(chars + '\n'):
            if ch == '\n':
                paras.append((start, i))
                start = i + 1
        if chars.endswith('\n'):
            paras = paras[:-1] if len(paras) > 1 else paras
        out = []
        counters = {}
        para_spacing = base.get('paragraphSpacing', 0.0) or 0.0
        for pi, (a, b) in enumerate(paras):
            info = lines[pi] if pi < len(lines) else {}
            ltype = info.get('lineType', 'PLAIN')
            level = info.get('indentationLevel', 0) or 0
            spans = []
            first_css, first_size, first_get = run_css(ids[a] if a < len(ids) else 0)
            lh_px = line_height(first_get, first_size)
            k = a
            while k < b:
                sid = ids[k] if k < len(ids) else 0
                j = k
                while j < b and (ids[j] if j < len(ids) else 0) == sid:
                    j += 1
                css, size, get = run_css(sid)
                lhr = line_height(get, size)
                if lhr:
                    css += f'line-height:{lhr:.2f}px;'
                text = esc(chars[k:j]).replace('\u2028', '<br>')
                link = (table.get(sid) or {}).get('hyperlink') or (n.get('hyperlink') if sid == 0 else None)
                if link and link.get('url'):
                    spans.append(f'<a href="{html.escape(link["url"])}" target="_blank" style="{css}">{text}</a>')
                else:
                    spans.append(f'<span style="{css}">{text}</span>')
                k = j
            body = ''.join(spans) or '&#8203;'
            pstyle = first_css + (f'line-height:{lh_px:.2f}px;' if lh_px else '')
            if pi < len(paras) - 1 and para_spacing:
                pstyle += f'margin-bottom:{para_spacing:.1f}px;'
            if ltype in ('ORDERED_LIST', 'UNORDERED_LIST') and level > 0:
                indent = first_size * 1.25 * level
                if ltype == 'ORDERED_LIST':
                    if level not in counters:
                        counters[level] = info.get('listStartOffset', 0) or 0
                    counters[level] += 1
                    marker = f'{counters[level]}.'
                else:
                    marker = '•'
                for lv in list(counters):
                    if lv > level:
                        del counters[lv]
                out.append(f'<div class="p" style="{pstyle}padding-left:{indent:.1f}px;position:relative">'
                           f'<span style="position:absolute;left:{indent - first_size * 1.1:.1f}px;width:{first_size * 0.9:.1f}px;text-align:right">{marker}</span>{body}</div>')
            else:
                counters = {}
                out.append(f'<div class="p" style="{pstyle}">{body}</div>')
        return ''.join(out)

    def text_box_css(self, n):
        align = {'LEFT': 'left', 'CENTER': 'center', 'RIGHT': 'right', 'JUSTIFIED': 'justify'}.get(n.get('textAlignHorizontal', 'LEFT'), 'left')
        valign = {'TOP': 'flex-start', 'CENTER': 'center', 'BOTTOM': 'flex-end'}.get(n.get('textAlignVertical', 'TOP'), 'flex-start')
        wrap = 'pre' if n.get('textAutoResize') == 'WIDTH_AND_HEIGHT' else 'pre-wrap'
        return f'display:flex;flex-direction:column;justify-content:{valign};text-align:{align};white-space:{wrap};overflow-wrap:normal;'

    # ------------------------------------------------------------------ nodes
    def node_html(self, n, ctx=None, uid='n', size_override=None, transform_override=None):
        """ctx: (overrides, derived, path) when rendering inside an instance."""
        if not n.get('visible', True):
            return ''
        t = n.get('type')
        if t in ('VARIABLE', 'VARIABLE_SET', 'DOCUMENT'):
            return ''
        size = size_override or n.get('size') or {'x': 0, 'y': 0}
        w, h = size.get('x', 0), size.get('y', 0)
        m = transform_override or mat(n.get('transform'))
        style = f'position:absolute;left:0;top:0;width:{w:.2f}px;height:{h:.2f}px;transform-origin:0 0;transform:{css_matrix(m)};'
        op = n.get('opacity', 1.0)
        if op < 0.999:
            style += f'opacity:{op:.3f};'
        blend = n.get('blendMode', 'PASS_THROUGH')
        if blend not in ('NORMAL', 'PASS_THROUGH'):
            style += 'mix-blend-mode:{};'.format(blend.lower().replace('_', '-'))
        my_id = figdeck.gid(n['guid']) if n.get('guid') else uid
        attrs = f' data-id="{my_id}" data-type="{t}" data-name="{html.escape(n.get("name", ""))}"'
        if t == 'TEXT':
            style += self.text_box_css(n) + self.effect_css(n, is_text=True)
            self.text_ids.append(my_id)
            return f'<div class="tx"{attrs} data-resize="{n.get("textAutoResize", "NONE")}" style="{style}">{self.text_inner(n)}</div>'

        effects = self.effect_css(n)
        radius = self.radius_css(n, w, h)
        geo = self.geometry(n, ctx)
        inner = ''
        fills = self.fills_of(n)
        strokes = self.fills_of(n, 'strokePaints', 'styleIdForStrokeFill')
        if t == 'SHAPE_WITH_TEXT':
            # A Slides shape keeps its look in generation data: fills, strokes, stroke weight and corner
            # radius on the first entry, the drawn outlines in the derived frame data.
            gen = (n.get('nodeGenerationData') or {}).get('overrides') or []
            fills = gen[0].get('fillPaints') if gen else None
            strokes = gen[0].get('strokePaints') if gen else None
            dif = (n.get('derivedImmutableFrameData') or {}).get('overrides') or []
            if dif and dif[0].get('fillGeometry'):
                geo = dif[0]['fillGeometry']
            if gen:
                n = dict(n)
                for k in ('strokeWeight', 'strokeAlign', 'cornerRadius'):
                    if gen[0].get(k) is not None:
                        n[k] = gen[0][k]
                radius = self.radius_css(n, w, h)
                if dif and dif[0].get('strokeGeometry'):
                    ctx = dict(ctx or {}, derived_stroke=dif[0]['strokeGeometry'])
        network = t == 'VECTOR' and n.get('vectorData') and not n.get('fillGeometry') and not n.get('strokeGeometry')
        if network:  # a path written by the kit (infographics): drawn from its vector network
            inner += self.network_svg(n, w, h, fills, strokes)
            fills, strokes = None, None
        if t == 'ELLIPSE' and n.get('dashPattern') and strokes and (n.get('strokeWeight') or 0) > 0:
            inner += self.dashed_ellipse(n, w, h, strokes)
            strokes = None
        if fills:
            layers = self.paint_layers(fills, w, h, uid)
            if layers:
                if geo is not None and t not in ('FRAME', 'SLIDE', 'SYMBOL', 'INSTANCE', 'MODULE', 'RECTANGLE', 'ROUNDED_RECTANGLE'):
                    d_attr, bw, bh = self.geo_path(geo)
                    cw, chh = max(w, bw), max(h, bh)
                    layers = self.paint_layers(fills, w, h, uid) if (cw, chh) == (w, h) else self.paint_layers(fills, cw, chh, uid)
                    inner += f'<div style="position:absolute;left:0;top:0;width:{cw:.2f}px;height:{chh:.2f}px;clip-path:path(\'{d_attr}\')">{layers}</div>'
                elif t == 'ELLIPSE':
                    inner += f'<div style="position:absolute;inset:0;border-radius:50%;overflow:hidden">{layers}</div>'
                else:
                    inner += f'<div style="position:absolute;inset:0;{radius}overflow:hidden">{layers}</div>'
        if strokes and (n.get('strokeWeight') or 0) > 0:
            inner += self.stroke_html(n, strokes, w, h, radius, ctx, uid)
        if t == 'SHAPE_WITH_TEXT':
            inner += self.shape_text(n)

        # children (frames, groups, instances)
        kids_html = ''
        clip = t in ('FRAME', 'SLIDE', 'SYMBOL', 'INSTANCE', 'MODULE') and not n.get('frameMaskDisabled', False)
        src = ctx.get('symbol_src') if ctx else None
        if t == 'INSTANCE':
            kids_html = self.instance_children(n, ctx if src else None, uid, src)
        elif src is not None:
            child_ctx = {'overrides': ctx['overrides'], 'derived': ctx['derived'], 'path': ctx['path']}
            for i, c in enumerate(self.d.children(src)):
                kids_html += self.symbol_child_html(c, child_ctx, f'{uid}_{i}')
        else:
            for i, c in enumerate(self.d.children(n) if n.get('guid') else []):
                kids_html += self.node_html(c, None, f'{uid}_{i}')
        if kids_html and clip:
            kids_html = f'<div style="position:absolute;inset:0;{radius}overflow:hidden">{kids_html}</div>'
        if effects:
            style += effects
            if 'box-shadow' in effects:
                style += radius
        return f'<div{attrs} style="{style}">{inner}{kids_html}</div>'

    @staticmethod
    def stroke_colour(strokes):
        for p in strokes or []:
            if not p.get('visible', True):
                continue
            if p.get('type') == 'SOLID':
                return rgba(p.get('color'), p.get('opacity', 1.0))
            if p.get('stops'):
                return rgba(p['stops'][len(p['stops']) // 2]['color'], p.get('opacity', 1.0))
        return 'transparent'

    @staticmethod
    def dash_attrs(n):
        dash = n.get('dashPattern')
        cap = {'ROUND': 'round', 'SQUARE': 'square'}.get(n.get('strokeCap'), 'butt')
        out = f' stroke-linecap="{cap}" stroke-linejoin="round"'
        if dash:
            out += ' stroke-dasharray="' + ' '.join('%g' % v for v in dash) + '"'
        return out

    def network_svg(self, n, w, h, fills, strokes):
        """A vector layer drawn from its network: segments as lines and cubic curves, Figma's arrow ends on the
        vertices that ask for one (styleOverrideTable)."""
        vd = n.get('vectorData') or {}
        i = vd.get('vectorNetworkBlob')
        if i is None or i >= len(self.blobs):
            return ''
        b = bytes(self.blobs[i]['bytes'])
        nv, ns_, nr = struct.unpack_from('<3I', b, 0)
        off, verts, segs = 12, [], []
        for _ in range(nv):
            verts.append(struct.unpack_from('<Iff', b, off))
            off += 12
        for _ in range(ns_):
            segs.append(struct.unpack_from('<IIffIff', b, off))
            off += 28
        size = vd.get('normalizedSize') or {}
        kx = w / size['x'] if size.get('x') else 1.0
        ky = h / size['y'] if size.get('y') else 1.0
        pt = [(x * kx, y * ky) for _, x, y in verts]
        d_attr, last = [], None
        heads = {}
        for _, a, ax, ay, c, cx, cy in segs:
            (x0, y0), (x1, y1) = pt[a], pt[c]
            if last != a:
                d_attr.append('M%.2f %.2f' % (x0, y0))
            if ax == ay == cx == cy == 0:
                d_attr.append('L%.2f %.2f' % (x1, y1))
                heads.setdefault(c, (x1 - x0, y1 - y0))
                heads.setdefault(('s', a), (x0 - x1, y0 - y1))
            else:
                d_attr.append('C%.2f %.2f %.2f %.2f %.2f %.2f' % (x0 + ax * kx, y0 + ay * ky, x1 + cx * kx, y1 + cy * ky, x1, y1))
                heads.setdefault(c, (-cx, -cy))
                heads.setdefault(('s', a), (-ax, -ay))
            last = c
        if nr:
            d_attr.append('Z')
        sw = float(n.get('strokeWeight') or 0)
        col = self.stroke_colour(strokes) if strokes and sw > 0 else 'none'
        fill = 'none'
        if nr and fills:
            fill = self.stroke_colour(fills)
        svg = [f'<path d="{" ".join(d_attr)}" fill="{fill}" stroke="{col}" stroke-width="{sw:g}"{self.dash_attrs(n)}/>']
        table = {o.get('styleID'): o for o in vd.get('styleOverrideTable') or []}
        for vi, (st, _, _) in enumerate(verts):
            cap = (table.get(st) or {}).get('strokeCap') if st else None
            if cap not in ('ARROW_LINES', 'ARROW_EQUILATERAL', 'TRIANGLE_FILLED') or col == 'none':
                continue
            dx, dy = heads.get(vi) or heads.get(('s', vi)) or (1.0, 0.0)
            L = math.hypot(dx, dy) or 1.0
            dx, dy = dx / L, dy / L
            k = max(8.0, sw * 4.5)
            (px, py) = pt[vi]
            bx, by = px - dx * k, py - dy * k
            nx, ny = -dy * k * 0.62, dx * k * 0.62
            if cap == 'ARROW_LINES':
                svg.append(f'<path d="M{bx + nx:.2f} {by + ny:.2f} L{px:.2f} {py:.2f} L{bx - nx:.2f} {by - ny:.2f}" fill="none" '
                           f'stroke="{col}" stroke-width="{sw:g}" stroke-linecap="round" stroke-linejoin="round"/>')
            else:
                svg.append(f'<path d="M{px:.2f} {py:.2f} L{bx + nx:.2f} {by + ny:.2f} L{bx - nx:.2f} {by - ny:.2f} Z" fill="{col}"/>')
        return (f'<svg style="position:absolute;left:0;top:0;overflow:visible" width="{max(w, 1):.2f}" '
                f'height="{max(h, 1):.2f}">{"".join(svg)}</svg>')

    def dashed_ellipse(self, n, w, h, strokes):
        sw = float(n.get('strokeWeight') or 1)
        grow = {'INSIDE': -sw / 2, 'CENTER': 0.0, 'OUTSIDE': sw / 2}.get(n.get('strokeAlign', 'INSIDE'), 0.0)
        return (f'<svg style="position:absolute;left:0;top:0;overflow:visible" width="{max(w, 1):.2f}" height="{max(h, 1):.2f}">'
                f'<ellipse cx="{w / 2:.2f}" cy="{h / 2:.2f}" rx="{max(0.1, w / 2 + grow):.2f}" ry="{max(0.1, h / 2 + grow):.2f}" '
                f'fill="none" stroke="{self.stroke_colour(strokes)}" stroke-width="{sw:g}"{self.dash_attrs(n)}/></svg>')

    def radius_css(self, n, w, h):
        if n.get('type') == 'ELLIPSE':
            return 'border-radius:50%;'
        if n.get('rectangleCornerRadiiIndependent'):
            r = [n.get('rectangleTopLeftCornerRadius', 0), n.get('rectangleTopRightCornerRadius', 0),
                 n.get('rectangleBottomRightCornerRadius', 0), n.get('rectangleBottomLeftCornerRadius', 0)]
            if any(r):
                return 'border-radius:{:.1f}px {:.1f}px {:.1f}px {:.1f}px;'.format(*r)
            return ''
        r = n.get('cornerRadius', 0) or 0
        return f'border-radius:{r:.1f}px;' if r else ''

    def geo_path(self, geo):
        parts, mx, my = [], 0.0, 0.0
        for g in geo:
            i = g.get('commandsBlob')
            if i is None or i >= len(self.blobs):
                continue
            d_attr = path_from_blob(self.blobs[i])
            parts.append(d_attr)
            nums = [float(v) for v in re.findall(r'-?\d+(?:\.\d+)?', d_attr)]
            mx = max([mx] + nums[0::2])
            my = max([my] + nums[1::2])
        return ' '.join(parts), mx, my

    def geometry(self, n, ctx):
        if ctx and ctx.get('derived_geo'):
            return ctx['derived_geo']
        return n.get('fillGeometry')

    def stroke_html(self, n, strokes, w, h, radius, ctx, uid):
        sw = n.get('strokeWeight', 1.0)
        geo = n.get('strokeGeometry')
        if ctx and ctx.get('derived_stroke'):
            geo = ctx['derived_stroke']
        layers = self.paint_layers(strokes, w + 2 * sw, h + 2 * sw, uid + 's')
        if not layers:
            return ''
        if geo:
            # The stroke outline is a filled shape that can reach outside the box (centre and outside
            # strokes, lines with no height), so draw it as an SVG path that may overflow.
            d_attr = ' '.join(path_from_blob(self.blobs[g['commandsBlob']]) for g in geo if g.get('commandsBlob') is not None and g['commandsBlob'] < len(self.blobs))
            col = 'transparent'
            for p in strokes:
                if not p.get('visible', True):
                    continue
                if p.get('type') == 'SOLID':
                    col = rgba(p.get('color'), p.get('opacity', 1.0))
                elif p.get('stops'):
                    col = rgba(p['stops'][0]['color'], p.get('opacity', 1.0))
            return (f'<svg style="position:absolute;left:0;top:0;overflow:visible" width="{max(w, 1):.2f}" height="{max(h, 1):.2f}">'
                    f'<path d="{d_attr}" fill="{col}"/></svg>')
        align = n.get('strokeAlign', 'INSIDE')
        off = {'INSIDE': 0, 'CENTER': -sw / 2, 'OUTSIDE': -sw}.get(align, 0)
        col = 'transparent'
        for p in strokes:
            if p.get('visible', True) and p.get('type') == 'SOLID':
                col = rgba(p.get('color'), p.get('opacity', 1.0))
        return f'<div style="position:absolute;inset:{off:.1f}px;border:{sw:.1f}px solid {col};{radius}box-sizing:border-box"></div>'

    def shape_text(self, n):
        gen = (n.get('nodeGenerationData') or {}).get('overrides') or []
        dif = (n.get('derivedImmutableFrameData') or {}).get('overrides') or []
        txt = None
        for o in gen[1:]:
            if o.get('textData', {}).get('characters'):
                txt = o
        if not txt:
            return ''
        node = dict(gen[0])
        node.update(txt)
        node['type'] = 'TEXT'
        size = n.get('size')
        for o in dif:
            if o.get('derivedTextData') and o.get('size'):
                size = o['size']
        node['size'] = size
        node['transform'] = None
        node['textAlignVertical'] = node.get('textAlignVertical', 'CENTER')
        node['textAlignHorizontal'] = node.get('textAlignHorizontal', 'CENTER')
        node['guid'] = None
        sw, sh = n['size']['x'], n['size']['y']
        inner = self.text_inner(node)
        return f'<div style="position:absolute;inset:16px;{self.text_box_css(node)}">{inner}</div>' if inner else ''

    # ------------------------------------------------------------------ instances
    def instance_children(self, inst, parent_ctx, uid, src=None):
        """Children of an instance: the symbol's layers with overrides and derived layout applied.

        Override and derived-data keys are paths of overrideKeys, one entry per instance level."""
        sd = inst.get('symbolData') or {}
        sym = self.d.nodes.get(figdeck.gid(sd['symbolID'])) if sd.get('symbolID') else None
        if not sym:
            return ''
        if parent_ctx:
            here = parent_ctx['path'] + [figdeck.gid((src or inst).get('overrideKey') or (src or inst)['guid'])]
        else:
            here = []
        overrides, derived = {}, {}
        for o in sd.get('symbolOverrides') or []:
            key = '/'.join(here + [figdeck.gid(g) for g in o['guidPath']['guids']])
            overrides.setdefault(key, {}).update({k: v for k, v in o.items() if k != 'guidPath'})
        for o in inst.get('derivedSymbolData') or []:
            derived['/'.join(here + [figdeck.gid(g) for g in o['guidPath']['guids']])] = o
        if parent_ctx:  # the outer instance wins over the nested one
            for k, v in parent_ctx['overrides'].items():
                overrides.setdefault(k, {}).update(v)
            derived.update(parent_ctx['derived'])
        ctx = {'overrides': overrides, 'derived': derived, 'path': here}
        sw, sh = sym['size']['x'], sym['size']['y']
        iw, ih = inst['size']['x'], inst['size']['y']
        scale = None
        has_derived = any(k.startswith('/'.join(here)) for k in derived) if derived else False
        if not has_derived and sw and sh and (abs(iw - sw) > 0.5 or abs(ih - sh) > 0.5):
            scale = (iw / sw, ih / sh)
        return ''.join(self.symbol_child_html(c, ctx, f'{uid}_{i}', scale) for i, c in enumerate(self.d.children(sym)))

    def symbol_child_html(self, c, ctx, uid, scale=None):
        key = '/'.join(ctx['path'] + [figdeck.gid(c.get('overrideKey') or c['guid'])])
        node = dict(c)
        ov = ctx['overrides'].get(key)
        if ov:
            node.update(ov)
        der = ctx['derived'].get(key) or {}
        size = der.get('size') or node.get('size')
        tr = mat(der['transform']) if der.get('transform') else mat(node.get('transform'))
        if scale:
            tr = mul([scale[0], 0, 0, 0, scale[1], 0], tr)
        sub = {'overrides': ctx['overrides'], 'derived': ctx['derived'], 'path': ctx['path'],
               'derived_geo': der.get('fillGeometry'), 'derived_stroke': der.get('strokeGeometry'), 'symbol_src': c}
        return self.node_html(node, sub, uid, size_override=size, transform_override=tr)

    # ------------------------------------------------------------------ slides
    def slide_html(self, slide, number):
        bg = self.paint_layers(slide.get('fillPaints'), SLIDE_W, SLIDE_H, f's{number}')
        kids = ''.join(self.node_html(c, None, f's{number}_{i}') for i, c in enumerate(self.d.children(slide)))
        name = html.escape(slide.get('name', ''))
        return (f'<section class="slide" data-n="{number}" data-name="{name}" data-id="{figdeck.gid(slide["guid"])}">'
                f'{bg}{kids}</section>')


def notes_text(slide):
    raw = slide.get('slideSpeakerNotes')
    if not raw:
        return ''
    try:
        j = json.loads(raw)
    except ValueError:
        return raw
    out = []

    def walk(o):
        if isinstance(o, dict):
            if o.get('type') == 'text':
                out.append(o.get('text', ''))
            for c in o.get('children') or []:
                walk(c)
            if o.get('type') in ('paragraph', 'listitem', 'heading'):
                out.append('\n')
    walk(j.get('root', {}))
    return ''.join(out).strip()


PAGE_CSS = """
*{margin:0;padding:0;box-sizing:border-box}
html,body{background:#1e1e1e}
.slide{position:relative;width:1920px;height:1080px;overflow:hidden;background:#fff;}
.tx a{color:inherit}
.p{min-height:1px;flex-shrink:0}
"""

VIEWER_JS = """
<script>
const S=[...document.querySelectorAll('.slide')];let i=0;
function fit(){const k=Math.min(innerWidth/1920,innerHeight/1080);S.forEach(s=>{s.style.transform='scale('+k+')';s.style.transformOrigin='0 0';s.style.position='absolute';s.style.left=((innerWidth-1920*k)/2)+'px';s.style.top=((innerHeight-1080*k)/2)+'px';});}
function show(n){i=(n+S.length)%S.length;S.forEach((s,x)=>s.style.display=x===i?'block':'none');document.getElementById('ctr').textContent=(i+1)+' / '+S.length;}
addEventListener('resize',fit);
addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key===' '){e.preventDefault();show(i+1)}else if(e.key==='ArrowLeft'){show(i-1)}else if(e.key==='f'||e.key==='F'){document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()}});
addEventListener('click',e=>{if(e.target.closest('a'))return;show(e.clientX>innerWidth/2?i+1:i-1)});
document.body.style.overflow='hidden';fit();show(0);
</script><div id="ctr" style="position:fixed;bottom:10px;right:14px;color:#999;font:12px system-ui;z-index:9"></div>
"""

REPORT_JS = """
<script>
document.fonts.ready.then(()=>{
 const out=[];
 const box=el=>{const r=el.getBoundingClientRect();return {l:r.left,t:r.top,r:r.right,b:r.bottom}};
 const inter=(a,b)=>Math.max(0,Math.min(a.r,b.r)-Math.max(a.l,b.l))*Math.max(0,Math.min(a.b,b.b)-Math.max(a.t,b.t));
 document.querySelectorAll('.slide').forEach(s=>{
  const S=box(s);
  const texts=[...s.querySelectorAll('.tx')].map(t=>{
   let c=null;[...t.children].forEach(p=>{const b=box(p);if(b.r-b.l<1)return;
     const range=document.createRange();range.selectNodeContents(p);const rr=range.getBoundingClientRect();
     const bb={l:rr.left,t:rr.top,r:rr.right,b:rr.bottom};
     c=c?{l:Math.min(c.l,bb.l),t:Math.min(c.t,bb.t),r:Math.max(c.r,bb.r),b:Math.max(c.b,bb.b)}:bb});
   return {el:t,box:box(t),content:c||box(t),name:t.dataset.name,resize:t.dataset.resize,faded:parseFloat(getComputedStyle(t).opacity)<0.5};
  });
  const logos=[...s.querySelectorAll(':scope>[data-type="INSTANCE"]')].filter(e=>/^Shiji$|Shiji logo/i.test(e.dataset.name)).map(box);
  texts.forEach((T,i)=>{
   const issues=[];const C=T.content;
   if(C.l<S.l-2||C.r>S.r+2||C.t<S.t-2||C.b>S.b+2)issues.push('runs past the slide edge');
   else if(C.b>S.b-36&&!T.el.dataset.name.match(/^(Note|Source|Credit|Footer|Prototype link)$/))issues.push('sits in the bottom margin (keep the last 36px clear)');
   if(T.resize!=='WIDTH_AND_HEIGHT'&&T.el.innerText.trim().length>2&&(C.b>T.box.b+4||C.t<T.box.t-4))issues.push('text is taller than its box ('+Math.round(C.b-C.t)+'px of text in '+Math.round(T.box.b-T.box.t)+'px)');
   if(logos.some(L=>inter(C,L)>40))issues.push('touches the Shiji logo');
   texts.forEach((U,j)=>{if(j<=i||T.faded||U.faded)return;const a=inter(C,U.content);if(a>200)issues.push('overlaps "'+U.name+'"')});
   if(issues.length)out.push({slide:+s.dataset.n,layer:T.name,id:T.el.dataset.id,issues,text:T.el.innerText.replace(/\\s+/g,' ').slice(0,80)});
  });
 });
 const pre=document.createElement('pre');pre.id='report';pre.textContent=JSON.stringify(out);document.body.appendChild(pre);
});
</script>
"""


def find_chrome():
    cands = [os.environ.get('CHROME'), '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
             '/Applications/Chromium.app/Contents/MacOS/Chromium', shutil.which('google-chrome'), shutil.which('chromium'),
             shutil.which('chromium-browser'), shutil.which('chrome')]
    for c in cands:
        if c and os.path.exists(c):
            return c
    return None


def chrome(args, timeout=180):
    exe = find_chrome()
    if not exe:
        raise RuntimeError('Google Chrome was not found. Install it or set CHROME=/path/to/chrome.')
    base = [exe, '--headless=new', '--disable-gpu', '--hide-scrollbars', '--allow-file-access-from-files',
            '--force-device-scale-factor=1', '--no-first-run', '--no-default-browser-check']
    return subprocess.run(base + args, capture_output=True, text=True, timeout=timeout)


def parse_slides(spec, total):
    if not spec:
        return list(range(1, total + 1))
    out = []
    for part in spec.split(','):
        if '-' in part:
            a, b = part.split('-')
            out += list(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return [n for n in out if 1 <= n <= total]


def build_page(deck, numbers, out_dir, mode='viewer', scale=1.0, cols=1):
    r = Renderer(deck, image_dir=os.path.join(out_dir, 'images'))
    slides = deck.slides()
    parts = [r.slide_html(slides[n - 1], n) for n in numbers]
    css = PAGE_CSS
    if mode == 'shots':
        # Lay slides out at full size and scale the pixels, so line breaks match the 1920px layout.
        cw, ch = round(SLIDE_W * scale), round(SLIDE_H * scale)
        # 1px margin: sips ignores some crops that start at x=0 and end on the bottom edge.
        css += ('.grid{display:grid;margin:0 0 1px 1px;grid-template-columns:repeat(%d,%dpx);grid-auto-rows:%dpx}'
                '.cell{width:%dpx;height:%dpx;overflow:hidden;position:relative}'
                '.cell>.slide{transform:scale(%s);transform-origin:0 0}') % (cols, cw, ch, cw, ch, scale)
        body = '<div class="grid">' + ''.join(f'<div class="cell">{x}</div>' for x in parts) + '</div>'
        tail = ''
    elif mode == 'report':
        body = ''.join(parts)
        tail = REPORT_JS
    else:
        body = ''.join(parts)
        tail = VIEWER_JS
    title = html.escape(deck.meta.get('file_name', 'Deck preview'))
    return (f'<!doctype html><html><head><meta charset="utf-8"><title>{title}</title>{FONT_HEAD}'
            f'<style>{css}</style></head><body>{body}{tail}</body></html>')


def crop(src, dst, x, y, w, h):
    subprocess.run(['sips', '--cropToHeightWidth', str(h), str(w), '--cropOffset', str(y), str(x), src, '--out', dst],
                   capture_output=True, check=True)


def render(deck_path, out_dir, slides_spec=None, scale=0.5, shots=True, sheet=True):
    deck = figdeck.Deck(deck_path)
    total = len(deck.slides())
    numbers = parse_slides(slides_spec, total)
    os.makedirs(out_dir, exist_ok=True)
    open(os.path.join(out_dir, 'index.html'), 'w').write(build_page(deck, numbers, out_dir, 'viewer'))
    rep_path = os.path.join(out_dir, '.report.html')
    open(rep_path, 'w').write(build_page(deck, numbers, out_dir, 'report'))
    res = chrome(['--virtual-time-budget=15000', '--window-size=1920,1080', '--dump-dom', 'file://' + os.path.abspath(rep_path)])
    m = re.search(r'<pre id="report">(.*?)</pre>', res.stdout, re.S)
    report = json.loads(html.unescape(m.group(1))) if m else [{'error': 'fit check did not run', 'stderr': res.stderr[-400:]}]
    os.remove(rep_path)
    json.dump({'deck': os.path.abspath(deck_path), 'slides': len(numbers), 'issues': report}, open(os.path.join(out_dir, 'report.json'), 'w'), indent=1)
    pngs = []
    if shots:
        sd = os.path.join(out_dir, 'slides')
        os.makedirs(sd, exist_ok=True)
        sw, sh = round(SLIDE_W * scale), round(SLIDE_H * scale)
        # Chrome screenshots larger than about one screen come back corrupted, so stay at 1920x1080.
        cols = max(1, 1920 // sw)
        rows = max(1, 1080 // sh)
        per = cols * rows
        for k in range(0, len(numbers), per):
            chunk = numbers[k:k + per]
            used_rows = math.ceil(len(chunk) / cols)
            page = os.path.join(out_dir, f'.shots{k}.html')
            open(page, 'w').write(build_page(deck, chunk, out_dir, 'shots', scale, cols))
            big = os.path.join(out_dir, f'.shots{k}.png')
            chrome(['--virtual-time-budget=15000', f'--window-size={sw * cols + 1},{sh * used_rows + 1}', f'--screenshot={big}', 'file://' + os.path.abspath(page)])
            for j, n in enumerate(chunk):
                dst = os.path.join(sd, f'{n:02d}.png')
                crop(big, dst, 1 + (j % cols) * sw, (j // cols) * sh, sw, sh)
                pngs.append(dst)
            os.remove(page)
            os.remove(big)
    if sheet and pngs:
        for old in [f for f in os.listdir(out_dir) if f.startswith('contact-sheet')]:
            os.remove(os.path.join(out_dir, old))
        pages = [pngs[i:i + 16] for i in range(0, len(pngs), 16)]
        for k, page_pngs in enumerate(pages, 1):
            name = 'contact-sheet.png' if len(pages) == 1 else f'contact-sheet-{k}.png'
            contact_sheet(page_pngs, os.path.join(out_dir, name))
    return report


def contact_sheet(pngs, dst, cols=4, cell_w=480):
    cell_h = round(cell_w * 9 / 16)
    cells = ''.join(f'<div class="c"><img src="file://{os.path.abspath(p)}"><span>{os.path.basename(p)[:-4]}</span></div>' for p in pngs)
    page = dst + '.html'
    open(page, 'w').write(f'<!doctype html><html><head><style>body{{margin:0;background:#1e1e1e}}.g{{display:grid;grid-template-columns:repeat({cols},{cell_w}px);grid-auto-rows:{cell_h}px;gap:0}}'
                          f'.c{{position:relative}}.c img{{width:{cell_w}px;height:{cell_h}px;display:block}}.c span{{position:absolute;top:6px;left:6px;background:#FFE14D;color:#000;font:bold 14px system-ui;padding:1px 6px;border-radius:3px}}</style></head>'
                          f'<body><div class="g">{cells}</div></body></html>')
    rows = math.ceil(len(pngs) / cols)
    chrome([f'--window-size={cols * cell_w},{rows * cell_h}', f'--screenshot={dst}', 'file://' + os.path.abspath(page)])
    os.remove(page)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('deck')
    ap.add_argument('--out', required=True)
    ap.add_argument('--slides', help='e.g. 1-5,8')
    ap.add_argument('--scale', type=float, default=0.5, help='PNG scale, 0.5 = 960x540 (default), 1 = 1920x1080')
    ap.add_argument('--no-shots', action='store_true', help='only index.html and report.json')
    a = ap.parse_args()
    report = render(a.deck, a.out, a.slides, a.scale, shots=not a.no_shots)
    print(json.dumps({'out': os.path.abspath(a.out), 'issues': len(report),
                      'first_issues': report[:8]}, indent=1, ensure_ascii=False))


if __name__ == '__main__':
    main()
