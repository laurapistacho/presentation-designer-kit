#!/usr/bin/env python3
"""Dump the words of a deck, slide by slide, as Markdown: for reviews, rewrites and tone checks.

    python3 deck_text.py deck.fig            # Figma Slides file (File > Save local copy)
    python3 deck_text.py deck.pptx            # PowerPoint file
    python3 deck_text.py deck.json            # deck spec used by build_deck.py
    python3 deck_text.py deck.fig --out words.md

Each slide lists its text from top to bottom, marks the biggest text as the headline, counts the
words, and shows the speaker notes. The presentation-writer skill reads this output.
"""
import argparse
import html
import json
import os
import re
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def from_deck(path):
    import figdeck
    import render_deck as R
    d = figdeck.Deck(path)
    r = R.Renderer(d)
    out = []
    for i, s in enumerate(d.slides(), 1):
        texts = []

        def walk(n, m):
            if not n.get('visible', True):
                return
            m2 = R.mul(m, R.mat(n.get('transform')))
            if n['type'] == 'TEXT':
                chars = (n.get('textData') or {}).get('characters', '').replace('\u2028', ' ').strip()
                if chars:
                    st = r.d_style(n.get('styleIdForText'))
                    size = (st or n).get('fontSize', n.get('fontSize', 0))
                    op = n.get('opacity', 1.0)
                    texts.append({'y': m2[5], 'x': m2[2], 'size': size, 'text': chars, 'faded': op < 0.5})
            if n['type'] == 'INSTANCE':
                return
            for c in d.children(n):
                walk(c, m2)
        for c in d.children(s):
            walk(c, [1, 0, 0, 0, 1, 0])
        out.append({'n': i, 'name': s.get('name', ''), 'texts': texts, 'notes': R.notes_text(s),
                    'skipped': bool(s.get('isSkippedSlide'))})
    return d.meta.get('file_name', os.path.basename(path)), out


def from_pptx(path):
    z = zipfile.ZipFile(path)
    names = sorted((n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)), key=lambda n: int(re.findall(r'\d+', n)[-1]))
    out = []
    for i, n in enumerate(names, 1):
        x = z.read(n).decode('utf-8', 'replace')
        texts = []
        for sp in re.findall(r'<p:sp>.*?</p:sp>', x, re.S):
            off = re.search(r'<a:off x="(-?\d+)" y="(-?\d+)"', sp)
            sizes = [int(v) / 100 * 2 for v in re.findall(r' sz="(\d+)"', sp)]  # back to 1920px-wide pixels
            paras = []
            for p in re.findall(r'<a:p>.*?</a:p>', sp, re.S):
                t = html.unescape(''.join(re.findall(r'<a:t>([^<]*)</a:t>', p)))
                if t.strip():
                    paras.append(t)
            if paras:
                texts.append({'y': int(off.group(2)) if off else 0, 'x': int(off.group(1)) if off else 0,
                              'size': max(sizes) if sizes else 0, 'text': '\n'.join(paras), 'faded': False})
        notes = ''
        rel = n.replace('slides/', 'slides/_rels/') + '.rels'
        if rel in z.namelist():
            m = re.search(r'Target="\.\./notesSlides/(notesSlide\d+\.xml)"', z.read(rel).decode())
            if m:
                nx = z.read('ppt/notesSlides/' + m.group(1)).decode('utf-8', 'replace')
                body = re.search(r'type="body".*', nx, re.S)
                notes = '\n'.join(html.unescape(''.join(re.findall(r'<a:t>([^<]*)</a:t>', p))) for p in re.findall(r'<a:p>.*?</a:p>', body.group(0) if body else '', re.S)).strip()
        out.append({'n': i, 'name': str(i), 'texts': texts, 'notes': notes, 'skipped': 'show="0"' in x[:300]})
    return os.path.basename(path), out


def from_spec(path):
    spec = json.load(open(path))
    out = []
    for i, sp in enumerate(spec.get('slides') or [], 1):
        texts = []
        for k, v in sp.items():
            if k in ('layout', 'notes', 'image', 'left_image', 'right_image', 'skip', 'split', 'image_style', 'image_fit',
                     'background', 'side', 'markers', 'icon', 'serif', 'circle', 'title_size', 'name'):
                continue
            flat = json.dumps(v, ensure_ascii=False) if isinstance(v, (list, dict)) else str(v)
            texts.append({'y': 0, 'x': 0, 'size': 100 if k == 'title' else 30, 'text': f'{k}: {flat}', 'faded': False})
        out.append({'n': i, 'name': sp.get('layout', ''), 'texts': texts, 'notes': sp.get('notes', ''), 'skipped': bool(sp.get('skip'))})
    return spec.get('file_name', os.path.basename(path)), out


def to_markdown(title, slides):
    lines = [f'# {title}', '', f'{len(slides)} slides', '']
    total = 0
    for s in slides:
        ts = sorted(s['texts'], key=lambda t: (round(t['y'] / 40), t['x']))
        words = sum(len(re.findall(r"\w[\w'’-]*", t['text'])) for t in ts if not t['faded'])
        total += words
        head = max((t for t in ts if not t['faded']), key=lambda t: t['size'], default=None)
        flag = ' (skipped)' if s['skipped'] else ''
        lines.append(f"## Slide {s['n']}{flag} · {words} words")
        for t in ts:
            mark = '**Headline:** ' if t is head else ('*(faded)* ' if t['faded'] else '')
            body = t['text'].replace('\n', ' / ')
            lines.append(f'- {mark}{body}')
        if s['notes']:
            lines.append(f"- *Notes:* {s['notes'].replace(chr(10), ' / ')}")
        lines.append('')
    lines.insert(3, f'{total} words on slides, {round(total / max(1, len(slides)))} per slide on average')
    return '\n'.join(lines)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('file')
    ap.add_argument('--out')
    a = ap.parse_args()
    ext = os.path.splitext(a.file)[1].lower()
    if ext == '.pptx':
        title, slides = from_pptx(a.file)
    elif ext == '.json':
        title, slides = from_spec(a.file)
    else:
        title, slides = from_deck(a.file)
    md = to_markdown(title, slides)
    if a.out:
        open(a.out, 'w').write(md)
        print(os.path.abspath(a.out))
    else:
        print(md)


if __name__ == '__main__':
    main()
