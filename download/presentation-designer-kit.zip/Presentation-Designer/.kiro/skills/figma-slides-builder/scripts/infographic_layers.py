"""Infographic layouts (registered in build_deck.LAYOUTS on import): wheel, rings, cycle, process, userflow,
timeline, hierarchy and matrix.

The presentation-infographics skill's engine (scripts/infographics.py) lays the diagram out as a scene of
shapes; this file draws that scene as editable Figma layers on the slide:

- chips and cards: auto-layout frames, their text linked to the template's text styles;
- circles: ellipses (dashed or dotted strokes where the diagram has them);
- lines, arcs and arrows: vector paths, with Figma's own arrow ends;
- decisions: a square turned 45 degrees;
- every colour a brand token, bound to the template's theme variables.

One frame per diagram ("Infographic · Wheel"), one frame inside it per part (Centre, Items, Spokes...).
"""
import copy
import math
import os
import struct
import sys

import build_deck
from build_deck import SLIDE_W, TOKENS, gradient, layout, solid
import figdeck

ENGINE = os.path.join(build_deck.KIT_ROOT, '.kiro', 'skills', 'presentation-infographics', 'scripts')
if ENGINE not in sys.path:
    sys.path.insert(0, ENGINE)
import infographics as ig  # noqa: E402

SPACE = TOKENS['space']
M, TOP = SPACE['margin_x'], SPACE['margin_top']
LIMIT = SPACE['footer_y'] - 48
TEXT_W = 560.0
SPLIT_BOX = (760.0, float(TOP), float(SLIDE_W - M - 760), float(LIMIT - TOP))
RECT_KEYS = ('cornerRadius', 'rectangleTopLeftCornerRadius', 'rectangleTopRightCornerRadius',
             'rectangleBottomLeftCornerRadius', 'rectangleBottomRightCornerRadius', 'rectangleCornerRadiiIndependent',
             'fillGeometry', 'strokeGeometry', 'vectorData', 'arcData', 'borderLeftWeight', 'borderStrokeWeightsIndependent')
CAP = {'round': 'ROUND', 'butt': 'NONE', 'none': 'NONE', 'square': 'SQUARE'}


# --------------------------------------------------------------------------- where the diagram goes
def arrangement(sp):
    return sp.get('arrange') == 'split' or (sp.get('arrange') is None and sp.get('layout') in ig.ROUND)


def diagram_box(sp):
    """The diagram's area on the slide: the right of a text column, or under the heading."""
    if arrangement(sp):
        return SPLIT_BOX
    kick = ig.type_of('kicker')[1] + 20 if sp.get('kicker') else 0
    sub = ig.type_of('subtitle')[1] + 20 if (sp.get('subtitle') or sp.get('lead')) else 0
    top = TOP + kick + ig.type_of('title')[1] + sub + 56
    return (float(M), float(top), float(SLIDE_W - 2 * M), float(LIMIT - top))


def check(sp, theme=None):
    """(errors, warnings) the engine reports for a spec slide: for the copy check, before anything is built."""
    try:
        sc = ig.scene(sp, diagram_box(sp), theme or sp.get('theme') or 'night')
    except ig.InfographicError as e:
        return [str(e)], []
    except (KeyError, TypeError, ValueError) as e:
        return [f'The diagram could not be laid out: {e}'], []
    return [], list(sc.warnings)


# --------------------------------------------------------------------------- layer helpers
def blank(s, kind, parent, x, y, w, h, name):
    """A new layer of `kind` from the template's plain rectangle, with nothing of the rectangle left."""
    n = s.b.new_node(build_deck.RECT_PROTO, parent)
    for k in RECT_KEYS:
        n.pop(k, None)
    n['type'] = kind
    n['name'] = name
    n['transform'] = {'m00': 1.0, 'm01': 0.0, 'm02': float(x), 'm10': 0.0, 'm11': 1.0, 'm12': float(y)}
    n['size'] = {'x': float(w), 'y': float(h)}
    n['fillPaints'], n['strokePaints'], n['effects'] = [], [], []
    n['strokeWeight'] = 0.0
    return n


def paint_of(s, c):
    if isinstance(c, str) and c.startswith('#'):
        return solid(c)
    return solid(s.tc(c))


def cycle_paint(s):
    """The template's own day-night cycle (the angular gradient of its swatch \"DAY-NIGHT CYCLE\")."""
    src = next((n for n in s.b.tpl.values() if n.get('name') == 'DAY-NIGHT CYCLE'), None)
    p = next((p for p in (src or {}).get('fillPaints') or [] if p.get('type') == 'GRADIENT_ANGULAR'), None)
    return copy.deepcopy(p) if p else paint_of(s, 'meridian')


def stroke(s, n, color, weight, cap='round', dash=None, align='CENTER'):
    n['strokePaints'] = [paint_of(s, color)]
    n['strokeWeight'] = float(weight)
    n['strokeAlign'] = align
    n['strokeCap'] = CAP.get(cap, 'ROUND')
    n['strokeJoin'] = 'ROUND'
    if dash:
        n['dashPattern'] = [float(v) for v in dash]
    return n


def network(verts, segs, regions=()):
    """Figma's vector network: verts [(x, y, style)], segs [(a, (dx, dy), b, (dx, dy))], regions [[segment ids]]."""
    out = bytearray(struct.pack('<3I', len(verts), len(segs), len(regions)))
    for x, y, st in verts:
        out += struct.pack('<Iff', st, x, y)
    for a, ta, b, tb in segs:
        out += struct.pack('<IIffIff', 0, a, ta[0], ta[1], b, tb[0], tb[1])
    for loop in regions:
        out += struct.pack('<II', 1, 1) + struct.pack('<I', len(loop)) + struct.pack('<%dI' % len(loop), *loop)
    return bytes(out)


def vector(s, parent, ox, oy, verts, segs, samples, name, arrow=None, regions=()):
    """A vector path: verts in slide pixels; the layer's box is the path's own bounds (from `samples`)."""
    xs, ys = [p[0] for p in samples], [p[1] for p in samples]
    x0, y0 = min(xs), min(ys)
    w, h = max(xs) - x0, max(ys) - y0
    local = [(x - x0, y - y0, 0) for x, y in verts]
    table = None
    if arrow in ('end', 'both'):
        local[-1] = (local[-1][0], local[-1][1], 1)
        table = [{'styleID': 1, 'strokeCap': 'ARROW_LINES'}]
    if arrow in ('start', 'both'):
        local[0] = (local[0][0], local[0][1], 1)
        table = [{'styleID': 1, 'strokeCap': 'ARROW_LINES'}]
    n = blank(s, 'VECTOR', parent, x0 - ox, y0 - oy, w, h, name)
    blobs = s.b.d.message.setdefault('blobs', [])
    blobs.append({'bytes': network(local, segs, regions)})
    n['vectorData'] = {'vectorNetworkBlob': len(blobs) - 1, 'normalizedSize': {'x': float(w), 'y': float(h)}}
    if table:
        n['vectorData']['styleOverrideTable'] = table
    return n


def arc_path(cx, cy, r, a0, a1):
    """Vertices, cubic segments and sample points of an arc (degrees clockwise from 12 o'clock)."""
    t0, t1 = math.radians(a0 - 90.0), math.radians(a1 - 90.0)
    parts = max(1, int(math.ceil(abs(t1 - t0) / (math.pi / 2))))
    step = (t1 - t0) / parts
    k = 4.0 / 3.0 * math.tan(step / 4) * r
    verts = [(cx + r * math.cos(t0 + i * step), cy + r * math.sin(t0 + i * step)) for i in range(parts + 1)]
    segs = []
    for i in range(parts):
        a, b = t0 + i * step, t0 + (i + 1) * step
        segs.append((i, (-math.sin(a) * k, math.cos(a) * k), i + 1, (math.sin(b) * k, -math.cos(b) * k)))
    samples = [(cx + r * math.cos(t0 + (t1 - t0) * j / 64.0), cy + r * math.sin(t0 + (t1 - t0) * j / 64.0)) for j in range(65)]
    return verts, segs, samples


def text_kind(kind):
    base, _, at = kind.partition('@')
    return base, (float(at) if at else None)


def text(s, parent, value, kind, x, y, w, color, align='LEFT', resize='HEIGHT', name='Text'):
    base, size = text_kind(kind)
    return s.t(value, base, x, y, w, color=color, align=align, resize=resize, parent=parent, name=name, size=size,
               highlight=None, link=None)


# --------------------------------------------------------------------------- the scene as layers
def bounds(it):
    k = it['kind']
    if k in ('circle', 'arc'):
        r = it['r'] + (it.get('sw') or 0) / 2
        return it['cx'] - r, it['cy'] - r, it['cx'] + r, it['cy'] + r
    if k == 'line':
        xs, ys = [p[0] for p in it['pts']], [p[1] for p in it['pts']]
        pad = (it.get('sw') or 0) / 2 + (8 if it.get('arrow') else 0)
        return min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad
    h = it.get('h') or ig.type_of(it['type'])[1]
    if k == 'text' and it.get('rotate'):
        cx, cy = it['x'] + it['w'] / 2, it['y'] + h / 2
        return cx - h / 2, cy - it['w'] / 2, cx + h / 2, cy + it['w'] / 2
    return it['x'], it['y'], it['x'] + it['w'], it['y'] + h


def draw_circle(s, parent, it, ox, oy):
    r = it['r']
    n = s.dot(it['cx'] - r - ox, it['cy'] - r - oy, 2 * r, None, parent=parent, name=it.get('name', 'Circle'))
    if it.get('fill'):
        n['fillPaints'] = [paint_of(s, it['fill'])]
    if it.get('stroke') and it.get('sw'):
        dotted = bool(it.get('dash')) and it['dash'][0] < 1
        stroke(s, n, it['stroke'], it['sw'], cap='round' if dotted else 'butt', dash=it.get('dash'))
    return n


def draw_arc(s, parent, it, ox, oy):
    verts, segs, samples = arc_path(it['cx'], it['cy'], it['r'], it['a0'], it['a1'])
    n = vector(s, parent, ox, oy, verts, segs, samples, it.get('name', 'Arc'), arrow=it.get('arrow'))
    if it.get('gradient'):
        n['strokePaints'] = [cycle_paint(s)]
        n['strokeWeight'], n['strokeAlign'], n['strokeCap'] = float(it['sw']), 'CENTER', CAP.get(it.get('cap'), 'NONE')
    else:
        stroke(s, n, it['stroke'], it['sw'], cap=it.get('cap', 'round'), dash=it.get('dash'))
    return n


def draw_line(s, parent, it, ox, oy):
    pts = it['pts']
    segs = [(i, (0.0, 0.0), i + 1, (0.0, 0.0)) for i in range(len(pts) - 1)]
    n = vector(s, parent, ox, oy, pts, segs, pts, it.get('name', 'Line'), arrow=it.get('arrow'))
    dotted = bool(it.get('dash')) and it['dash'][0] < 1
    stroke(s, n, it['stroke'], it['sw'], cap='round' if dotted else it.get('cap', 'round'), dash=it.get('dash'))
    return n


def draw_box(s, parent, it, ox, oy):
    x, y, w, h = it['x'] - ox, it['y'] - oy, it['w'], it['h']
    pv, ph = it.get('pad') or (14.0, 20.0)
    texts = []
    if it.get('shape') == 'diamond':  # a square turned 45 degrees, the label on top of it
        side = w / math.sqrt(2.0)
        q = s.rect(0, 0, side, side, fill=None, radius=10, parent=parent)
        q['fillPaints'] = [paint_of(s, it['fill'])] if it.get('fill') else []
        if it.get('stroke'):
            q['strokePaints'] = [paint_of(s, it['stroke'])]
            q['strokeWeight'] = float(it.get('sw') or 1.5)
            q['strokeAlign'] = 'INSIDE'
        c = math.sqrt(0.5)
        q['transform'] = {'m00': c, 'm01': -c, 'm10': c, 'm11': c, 'm02': x + w / 2, 'm12': y + h / 2 - side * c}
        q['name'] = 'Decision'
        holder = s.frame(x + w * 0.18, y + h * 0.18, w * 0.64, h * 0.64, 'VERTICAL', parent=parent, hug_main=False,
                         align='CENTER', cross='CENTER', name=it.get('name', 'Decision'))
        texts.append(text(s, holder, it['text'], it['type'], 0, 0, w * 0.64, it['color'], align='CENTER', name='Label'))
        s.slide.setdefault('_fit', []).append((figdeck.gid(holder), [figdeck.gid(t) for t in texts], it.get('name')))
        return holder
    dot = it.get('dot')
    align = 'LEFT' if (dot and h > 60) else it.get('align', 'CENTER')
    mode = 'HORIZONTAL' if dot else 'VERTICAL'
    f = s.frame(x, y, w, h, mode, gap=10 if dot else 2, pad=(pv, ph, pv, ph), parent=parent, hug_main=False,
                align='CENTER', cross='CENTER' if (mode == 'HORIZONTAL' or align == 'CENTER') else 'MIN',
                name=it.get('name', 'Box'), stroke=it.get('stroke'), stroke_w=it.get('sw') or 1.5,
                radius=w / 2 if it.get('shape') == 'circle' else min(it.get('radius') or 0, h / 2))
    if it.get('gradient'):
        f['fillPaints'] = [gradient(it['gradient'], w, h)]
    elif it.get('fill'):
        f['fillPaints'] = [paint_of(s, it['fill'])]
    inner = w - 2 * ph
    if dot:
        d = s.dot(0, 0, ig.DOT, None, parent=f, name='Colour')
        d['fillPaints'] = [paint_of(s, dot)]
        if it.get('dot_ring'):
            stroke(s, d, it['dot_ring'], 1.5, align='INSIDE')
        inner -= ig.DOT + ig.DOT_GAP
    one_line = h <= ig.type_of(it['type'])[1] + 2 * pv + 2
    for key, nm in (('top', 'Label'), ('text', 'Text'), ('sub', 'Text below')):
        value = it.get(key)
        if not value:
            continue
        kind = it[key + '_type'] if key != 'text' else it['type']
        color = it[key + '_color'] if key != 'text' else it['color']
        resize = 'WIDTH_AND_HEIGHT' if (it.get('chip') and one_line) else 'HEIGHT'
        texts.append(text(s, f, value, kind, 0, 0, inner, color, align=align, resize=resize, name=nm))
    s.slide.setdefault('_fit', []).append((figdeck.gid(f), [figdeck.gid(t) for t in texts], it.get('name')))
    return f


def draw_text(s, parent, it, ox, oy):
    x, y = it['x'] - ox, it['y'] - oy
    n = text(s, parent, it['text'], it['type'], x, y, it['w'], it['color'], align=it.get('align', 'LEFT'),
             name=it.get('name', 'Text'))
    if it.get('rotate'):
        h = ig.type_of(it['type'])[1]
        cx, cy = x + it['w'] / 2, y + h / 2
        a = math.radians(float(it['rotate']))
        c, sn = math.cos(a), math.sin(a)
        # turn about the box centre: local (w/2, h/2) lands on (cx, cy)
        n['transform'] = {'m00': c, 'm01': -sn, 'm10': sn, 'm11': c,
                          'm02': cx - (c * it['w'] / 2 - sn * h / 2), 'm12': cy - (sn * it['w'] / 2 + c * h / 2)}
    return n


DRAW = {'circle': draw_circle, 'arc': draw_arc, 'line': draw_line, 'box': draw_box, 'text': draw_text}


def render(s, sc, title):
    """Draw scene `sc` on slide `s`: one frame for the diagram, one inside it for each part."""
    bx, by, bw, bh = sc.area
    groups, order = {}, []
    for it in sc.items:
        g = it.get('group') or 'Diagram'
        if g not in groups:
            groups[g] = []
            order.append(g)
        groups[g].append(it)
    allb = [bounds(it) for it in sc.items]
    fx0, fy0 = min(b[0] for b in allb), min(b[1] for b in allb)
    fx1, fy1 = max(b[2] for b in allb), max(b[3] for b in allb)
    top = s.frame(fx0, fy0, fx1 - fx0, fy1 - fy0, 'NONE', name=f'Infographic · {title}')
    for g in order:
        gb = [bounds(it) for it in groups[g]]
        gx0, gy0 = min(b[0] for b in gb), min(b[1] for b in gb)
        gx1, gy1 = max(b[2] for b in gb), max(b[3] for b in gb)
        holder = s.frame(gx0 - fx0, gy0 - fy0, max(1.0, gx1 - gx0), max(1.0, gy1 - gy0), 'NONE', parent=top, name=g)
        for it in groups[g]:
            DRAW[it['kind']](s, holder, it, gx0, gy0)
    return top


# --------------------------------------------------------------------------- the slide
TITLES = {'wheel': 'Wheel', 'rings': 'Rings', 'cycle': 'Cycle', 'process': 'Process', 'userflow': 'User flow',
          'timeline': 'Timeline', 'hierarchy': 'Hierarchy', 'matrix': 'Matrix'}


def infographic_slide(s, sp):
    kind = sp['layout']
    bg = sp.get('background') or {'night': 'night', 'day': None, 'blue': 'blue'}.get(s.th['name'])
    s.background(bg)
    if arrangement(sp):
        col = s.frame(M, 0, TEXT_W, 10, 'VERTICAL', gap=28, name='Text')
        head = s.heading(sp, TEXT_W, col, subtitle=sp.get('subtitle') or '')
        head['name'] = 'Heading'
        if sp.get('lead'):
            s.t(sp['lead'], 'lead', w=TEXT_W, color='muted', parent=col, name='Lead')
        s.vplace(col, TOP, LIMIT)
    else:
        head = s.heading(sp, SLIDE_W - 2 * M, None, subtitle=sp.get('subtitle') or sp.get('lead') or '')
        s.place(head, M, TOP)
    n = len(s.b.new_slides)
    try:
        sc = ig.scene(sp, diagram_box(sp), s.th['name'])
    except ig.InfographicError as e:
        raise SystemExit(f'Slide {n}: {e}')
    for w in sc.warnings:
        s.b.warnings.append(f'Slide {n}: {w}')
    render(s, sc, TITLES.get(kind, kind.title()))
    s.footer(sp)


FIELDS = {
    'wheel': 'kicker, title, lead, center, items[] (3-10: text, color, highlight), palette (products)',
    'rings': 'kicker, title, lead, rings[] inner to outer (2-4: label, items[] up to 4: text, color, highlight, outline)',
    'cycle': 'kicker, title, lead, center, steps[] (3-8: text, highlight)',
    'process': 'kicker, title, subtitle, steps[] (2-6: text, sub, highlight)',
    'userflow': 'kicker, title, subtitle, nodes[] (id, text, kind: start | screen | decision | end, label), links[] (from, to, label)',
    'timeline': 'kicker, title, subtitle, events[] (2-8: date, text, sub, highlight), phases[] (title, from, to), today',
    'hierarchy': 'kicker, title, subtitle, root (text, sub, children[] up to 6, each with children[] up to 5)',
    'matrix': 'kicker, title, lead, quadrants[4] (title, items[] up to 4, highlight), x_axis, y_axis (label, low, high)',
}
ABOUT = {
    'wheel': 'Infographic: one thing in the centre (Night Serif) and its parts around it as chips, joined by dotted spokes.',
    'rings': 'Infographic: layers or scopes inside each other, the inner one stacked in the middle, the others on their ring.',
    'cycle': 'Infographic: a loop of numbered cards around the gradient circle, joined by arrows.',
    'process': 'Infographic: steps in order, left to right: a numbered circle, a title and a line of text each.',
    'userflow': 'Infographic: screens, decisions and their paths, left to right; a branch starts a row below.',
    'timeline': 'Infographic: dated moments on a line, phases above it, a Today chip; years and versions in Night Serif.',
    'hierarchy': 'Infographic: a tree from one item down: cards under it, each with its own chips.',
    'matrix': 'Infographic: two axes and four quadrant cards with up to four chips in each.',
}


def _register(kind):
    @layout(kind, 'night', FIELDS[kind], ABOUT[kind], template='Infographic · ' + TITLES[kind] + ' (kit)')
    def _fn(s, sp):
        infographic_slide(s, sp)
    return _fn


for _kind in ig.TYPES:
    _register(_kind)
