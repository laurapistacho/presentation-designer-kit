#!/usr/bin/env python3
"""Print the layer tree of a Figma Slides file (.fig or .deck): ids, names, positions, sizes, fonts and text.

    python3 inspect_deck.py deck.fig              # every slide
    python3 inspect_deck.py deck.fig --slides 3,5 # some slides
    python3 inspect_deck.py deck.fig --styles     # text styles and colour variables

Use it when the template changes: the layout table in build_deck.py points at template layers by id.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import figdeck  # noqa: E402


def hexc(c):
    return '#%02X%02X%02X' % tuple(round(c.get(k, 0) * 255) for k in 'rgb') if c else ''


def describe(d, n):
    t = n.get('transform') or {}
    s = n.get('size') or {}
    bits = [n['type'], figdeck.gid(n), repr(n.get('name', ''))]
    if s:
        bits.append(f"{round(t.get('m02', 0))},{round(t.get('m12', 0))} {round(s.get('x', 0))}x{round(s.get('y', 0))}")
    if not n.get('visible', True):
        bits.append('hidden')
    fills = [hexc(p.get('color')) or p.get('type') for p in n.get('fillPaints') or [] if p.get('visible', True)]
    if fills:
        bits.append('fill=' + ','.join(fills))
    if n['type'] == 'TEXT':
        f = n.get('fontName', {})
        st = n.get('styleIdForText', {}).get('guid')
        sn = d.nodes.get(figdeck.gid(st), {}).get('name') if st else None
        bits.append(f"{f.get('family')} {f.get('style')} {n.get('fontSize')} style={sn} align={n.get('textAlignHorizontal', 'LEFT')} resize={n.get('textAutoResize', 'NONE')}")
        bits.append(repr(n.get('textData', {}).get('characters', '')[:70]))
    if n['type'] == 'INSTANCE':
        sym = d.nodes.get(figdeck.gid(n['symbolData']['symbolID']))
        bits.append('-> ' + (sym.get('name') if sym else '?'))
    if n.get('stackMode'):
        bits.append(f"autolayout={n['stackMode']} gap={n.get('stackSpacing', 0)}")
    return ' '.join(bits)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('deck')
    ap.add_argument('--slides')
    ap.add_argument('--styles', action='store_true')
    a = ap.parse_args()
    d = figdeck.Deck(a.deck)
    if a.styles:
        for n in d.message['nodeChanges']:
            if n.get('styleType') == 'TEXT':
                f = n.get('fontName', {})
                lh = n.get('lineHeight', {})
                print('TEXT STYLE', figdeck.gid(n), repr(n.get('name')), f.get('family'), f.get('style'), n.get('fontSize'), f"lh={lh.get('value')} {lh.get('units')}")
        for n in d.message['nodeChanges']:
            if n['type'] == 'VARIABLE' and n.get('variableResolvedType') == 'COLOR':
                vals = [hexc(e['variableData']['value'].get('colorValue')) for e in (n.get('variableDataValues') or {}).get('entries', []) if e['variableData']['value'].get('colorValue')]
                print('COLOR VAR', figdeck.gid(n), repr(n.get('name')), vals)
        return
    slides = d.slides()
    wanted = None
    if a.slides:
        wanted = set()
        for part in a.slides.split(','):
            if '-' in part:
                x, y = part.split('-')
                wanted |= set(range(int(x), int(y) + 1))
            else:
                wanted.add(int(part))
    for i, s in enumerate(slides, 1):
        if wanted and i not in wanted:
            continue
        print(f'===== slide {i}')
        for n, depth in d.walk(s):
            print('  ' * depth + describe(d, n))


if __name__ == '__main__':
    main()
