#!/usr/bin/env python3
"""Cut a Figma Slides grid render into one PNG per slide, plus contact sheets.

Figma's REST API cannot read the layers of a Slides file, but it can render it. The slide grid is
node 0:3 in every Slides file. Render it twice with the Figma MCP tool `download_figma_images`:

  1. small, for finding the slides:   nodeId "0:3", pngScale 0.1   -> grid-small.png
  2. large, for the pictures:         nodeId "0:3", pngScale 0.3-0.5 (Figma caps renders at about
                                      32 megapixels, so long decks come back smaller; that is fine)

Then:
    python3 figma_grid_slices.py grid-small.png grid-large.png --out slides/ --prefix A

Output: slides/A01.png ... (one per slide, presentation order), contact-1.png ... (16 per sheet),
manifest.json (row and column of each slide in the grid).
"""
import argparse
import json
import os
import struct
import subprocess
import sys
import zlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def decode_png(path):
    data = open(path, 'rb').read()
    i, idat = 8, b''
    while i < len(data):
        n = struct.unpack('>I', data[i:i + 4])[0]
        typ, body = data[i + 4:i + 8], data[i + 8:i + 8 + n]
        if typ == b'IHDR':
            w, h, depth, ctype = struct.unpack('>IIBB', body[:10])
        elif typ == b'IDAT':
            idat += body
        i += 12 + n
    if depth != 8:
        raise SystemExit('Expected an 8-bit PNG from Figma')
    bpp = {2: 3, 6: 4, 0: 1, 4: 2}[ctype]
    raw = zlib.decompress(idat)
    stride = w * bpp
    rows, prev, p = [], bytearray(stride), 0
    for _ in range(h):
        f = raw[p]
        line = bytearray(raw[p + 1:p + 1 + stride])
        p += 1 + stride
        if f == 1:
            for x in range(bpp, stride):
                line[x] = (line[x] + line[x - bpp]) & 255
        elif f == 2:
            for x in range(stride):
                line[x] = (line[x] + prev[x]) & 255
        elif f == 3:
            for x in range(stride):
                a = line[x - bpp] if x >= bpp else 0
                line[x] = (line[x] + ((a + prev[x]) >> 1)) & 255
        elif f == 4:
            for x in range(stride):
                a = line[x - bpp] if x >= bpp else 0
                b, c = prev[x], prev[x - bpp] if x >= bpp else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                line[x] = (line[x] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        rows.append(line)
        prev = line
    return w, h, bpp, rows


def find_slides(small_png, scale):
    w, h, bpp, rows = decode_png(small_png)
    bg = bytes(rows[0][:bpp])

    def filled(line, x):
        px = line[x * bpp:(x + 1) * bpp]
        return not (bpp == 4 and px[3] < 16) and bytes(px) != bg

    occupied = [any(filled(rows[y], x) for x in range(0, w, 2)) for y in range(h)]
    bands, y = [], 0
    while y < h:
        if occupied[y]:
            y0 = y
            while y < h and occupied[y]:
                y += 1
            bands.append((y0, y))
        y += 1
    boxes = []
    for y0, y1 in bands:
        probes = [y0 + (y1 - y0) // 4, (y0 + y1) // 2]
        cols = [any(filled(rows[py], x) for py in probes) for x in range(w)]
        x = 0
        while x < w:
            if cols[x]:
                x0 = x
                while x < w and cols[x]:
                    x += 1
                if x - x0 > 20:
                    boxes.append({'x': round(x0 / scale), 'y': round(y0 / scale), 'w': round((x - x0) / scale), 'h': round((y1 - y0) / scale)})
            x += 1
    return w / scale, boxes


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('small')
    ap.add_argument('large')
    ap.add_argument('--small-scale', type=float, default=0.1)
    ap.add_argument('--out', required=True)
    ap.add_argument('--prefix', default='')
    a = ap.parse_args()
    grid_w, boxes = find_slides(a.small, a.small_scale)
    boxes.sort(key=lambda b: (b['y'], b['x']))
    lw = int(subprocess.run(['sips', '-g', 'pixelWidth', a.large], capture_output=True, text=True).stdout.split()[-1])
    s = lw / grid_w
    os.makedirs(a.out, exist_ok=True)
    rows_y = sorted(set(b['y'] for b in boxes))
    manifest, files = [], []
    for i, b in enumerate(boxes, 1):
        x, y = max(1, round(b['x'] * s)), round(b['y'] * s)
        w, h = round(1920 * s), round(1080 * s)
        dst = os.path.join(a.out, f'{a.prefix}{i:02d}.png')
        subprocess.run(['sips', '--cropToHeightWidth', str(h), str(w), '--cropOffset', str(y), str(x), a.large, '--out', dst],
                       capture_output=True, check=True)
        files.append(dst)
        row = rows_y.index(b['y']) + 1
        manifest.append({'slide': i, 'file': os.path.basename(dst), 'row': row,
                         'column': [bb for bb in boxes if bb['y'] == b['y']].index(b) + 1})
    json.dump({'scale': s, 'slides': manifest}, open(os.path.join(a.out, 'manifest.json'), 'w'), indent=1)
    import render_deck as R
    for k in range(0, len(files), 16):
        R.contact_sheet(files[k:k + 16], os.path.join(a.out, f'contact-{k // 16 + 1}.png'))
    print(json.dumps({'slides': len(files), 'rows': len(rows_y), 'scale': round(s, 4), 'out': os.path.abspath(a.out)}, indent=1))


if __name__ == '__main__':
    main()
