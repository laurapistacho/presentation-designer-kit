---
inclusion: auto
name: "shiji-presentation"
description: >
  Builds shareable, self-contained HTML presentations in the official Shiji / Daylight brand.
  Modular development: separate slide files assembled by build.sh into one index.html.
  Real Shiji brand webfonts from CDN + Noto Sans Mono from Google Fonts,
  real Shiji Brand Kit colors, Day & Night design philosophy, keyboard + click navigation, inline Shiji logo.
  Triggers on: presentation, slides, deck, prezentacja, branded slides, shiji presentation, build a deck.
---
# Daylight / Shiji Presentation Builder

Build a single self-contained HTML presentation that looks on-brand for Shiji / Daylight and can be
shared as **one file** — no external assets, no local font files, opens in any browser.

Core rules:

- **Modular development, single-file output.** During development, slides live in separate files. `build.sh` assembles them into one `index.html` for sharing. Always run `./build.sh` after editing slides.
- **Real Shiji brand fonts.** Use the official Shiji webfonts (Reckless Neue + Aeonik) hosted on the Webflow CDN. Only Noto Sans Mono comes from Google Fonts.
- **Real brand values.** Colors, gradients and philosophy below come from the official Shiji Brand Kit - use them exactly.
- **16:9, viewport-relative units** (`vw`/`vh`) so slides scale to any screen.

---

## Step 1 - Fonts (real Shiji brand webfonts from CDN)

The official Shiji brand fonts are hosted as `.woff2` webfonts on the Webflow CDN (shiji.com website).
Use `@font-face` declarations in `<style>` and a Google Fonts link only for Noto Sans Mono.

Put this in `<head>` (only for Noto Sans Mono):

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Mono:wght@400;500;700&display=swap" rel="stylesheet">
```

Put these `@font-face` declarations at the top of your `<style>` block (before `:root`):

```css
/* Shiji Night Serif - Reckless Neue */
@font-face{
  font-family:'Shiji Night Serif';
  src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8e_ShijiNightSerifRecklessNeue-Regular.woff2') format('woff2');
  font-weight:400;font-style:normal;font-display:swap;
}
@font-face{
  font-family:'Shiji Night Serif';
  src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67dac539ac844f1933bcafb0_ShijiNightSerifRecklessNeue-Heavy.woff2') format('woff2');
  font-weight:900;font-style:normal;font-display:swap;
}
/* Shiji Day Sans - Aeonik */
@font-face{
  font-family:'Shiji Day Sans';
  src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9c_ShijiDaySansAeonik-Regular.woff2') format('woff2');
  font-weight:400;font-style:normal;font-display:swap;
}
@font-face{
  font-family:'Shiji Day Sans';
  src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8f_ShijiDaySansAeonik-Medium.woff2') format('woff2');
  font-weight:500;font-style:normal;font-display:swap;
}
@font-face{
  font-family:'Shiji Day Sans';
  src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9d_ShijiDaySansAeonik-Bold.woff2') format('woff2');
  font-weight:700;font-style:normal;font-display:swap;
}
```

| Font                                        | Role                           | Weights available                       | Used for                               |
| ------------------------------------------- | ------------------------------ | --------------------------------------- | -------------------------------------- |
| **Shiji Night Serif** (Reckless Neue) | emotional / headlines / quotes | 400 (Regular), 900 (Heavy)              | big titles, stat numbers, pull quotes  |
| **Shiji Day Sans** (Aeonik)           | corporate body                 | 400 (Regular), 500 (Medium), 700 (Bold) | body text, bullets, labels             |
| **Noto Sans Mono** (Google Fonts)     | technical                      | 400, 500, 700                           | captions, tags, small technical labels |

CSS families:

```css
body{font-family:'Shiji Day Sans',system-ui,sans-serif;}
.serif{font-family:'Shiji Night Serif',Georgia,serif;}
.mono{font-family:'Noto Sans Mono',monospace;}
```

---

## Step 2 — Brand colors (exact Shiji Brand Kit values)

Paste this `:root` block. Avoid pure black for text — use Blue 0 (`#172554`).

```css
:root{
  /* Shiji Blue palette */
  --blue-0:#172554;   /* Midnight — primary text color (use instead of black) */
  --blue-1:#1E3A8A;   /* Twilight (Data + AI) */
  --blue-2:#0030FF;   /* Reviewpro — main highlight / CTA / buttons */
  --blue-3:#3B82F6;
  --blue-4:#60A5FA;   /* Meridian */
  --blue-5:#D5ECFF;
  --blue-6:#E8F5FF;   /* Daylight Blue */
  --blue-6-60:#F1F9FF;
  --blue-6-30:#F8FCFF;
  /* Shiji Active — highlight + action */
  --green:#0AFFAB;    /* Energetic Green — main active / highlight / CTA */
  --white:#FFFFFF;
  --black:#000000;    /* avoid — use --blue-0 for text */
  /* Alerts */
  --alert-light:#DC2626;  /* on light bg */
  --alert-dark:#F87171;   /* on dark bg */
  /* Day-Night product solid colors */
  --sunrise-red:#8D3791;   /* Daylight PMS */
  --sunset-yellow:#FFB851; /* Iceportal */
  --sunset-orange:#FF8056; /* Horizon */
  --sunset-purple:#7443A7; /* Infrasys */
}
```

Gradients (linear):

```css
/* Daylight PMS */    background:linear-gradient(90deg,#8D3791 0%,#1D4ED8 100%);
/* Shiji Brand 2 */   background:linear-gradient(90deg,#172554 0%,#1E3A8A 50%,#0AFFAB 100%);
/* Shiji Platform */  background:linear-gradient(90deg,#0030FF,#0AFFAB);
```

---

## Step 3 — Design philosophy: "Day & Night"

Shiji's rebrand (ITB Berlin 2025) theme is **Day and Night** — hospitality runs 24/7. Apply it:

- **Dark decks by default:** deep navy background (`--blue-0` / `#0c1024`), white text, **Energetic Green** (`#0AFFAB`) and **Blue 2** (`#0030FF`) as accents.
- **Horizon split** where it fits: lighter "day" tone at the top fading into dark "night" at the bottom (use the aurora / radial-gradient backgrounds below).
- **Green = active/highlight.** Reserve `--green` for the single most important word, number or CTA on a slide. Do not flood a slide with green.
- **CTA = pill.** Rounded-full buttons filled with Energetic Green (text in `--blue-0`) or Blue 2 (white text).
- **Tagline voice:** "The best hotels run on Shiji — day and night."

Accent backgrounds (optional, for title / divider slides):

```css
.bg-aurora{
  background:
    radial-gradient(120% 90% at 62% 42%, rgba(255,150,90,.55) 0%, rgba(255,150,90,0) 42%),
    radial-gradient(90% 70% at 40% 20%, rgba(70,120,255,.85) 0%, rgba(70,120,255,0) 55%),
    radial-gradient(120% 120% at 75% 80%, rgba(200,80,160,.55) 0%, rgba(200,80,160,0) 55%),
    linear-gradient(135deg,#20308a 0%,#2a2f7a 45%,#3a2f6a 100%);
}
.bg-night{background:#0c1024;}
.bg-blue{background:var(--blue-2);}
```

---

## Step 4 — Slide layouts

Use these four archetypes. All slides are `.slide` (hidden) and `.slide.active` (shown).

1. **Title** — `.slide.center`, `bg-aurora`, big `h1.title.serif`, brand-green highlight span, `.subtitle` below, logo top-center.
2. **Divider / section** — `.slide.center`, `bg-night`, big part number (`.part-num.serif`), green `.part-label`.
3. **Content (bullets)** — left-aligned `h2` + `ul.points` (green dots, green `<b>` for emphasis).
4. **Stats** — `.stats` row of `.stat` blocks; `.stat .num.serif` big, `.stat.mintnum .num` colored green. Keep to one row (max 4 across).

Two-column content uses `.cols` > `.col` (green `h3` heading per column).

Keep bottom text (`.footnote`) clear of the footer — sit it around `bottom:8vh`, never lower.

---

## Step 5 — Structure, navigation & logo

Full skeleton — copy and fill slides:

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PRESENTATION TITLE</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Mono:wght@400;500;700&display=swap" rel="stylesheet">
<style>
  /* Shiji Night Serif - Reckless Neue */
  @font-face{font-family:'Shiji Night Serif';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8e_ShijiNightSerifRecklessNeue-Regular.woff2') format('woff2');font-weight:400;font-style:normal;font-display:swap;}
  @font-face{font-family:'Shiji Night Serif';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67dac539ac844f1933bcafb0_ShijiNightSerifRecklessNeue-Heavy.woff2') format('woff2');font-weight:900;font-style:normal;font-display:swap;}
  /* Shiji Day Sans - Aeonik */
  @font-face{font-family:'Shiji Day Sans';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9c_ShijiDaySansAeonik-Regular.woff2') format('woff2');font-weight:400;font-style:normal;font-display:swap;}
  @font-face{font-family:'Shiji Day Sans';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8f_ShijiDaySansAeonik-Medium.woff2') format('woff2');font-weight:500;font-style:normal;font-display:swap;}
  @font-face{font-family:'Shiji Day Sans';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9d_ShijiDaySansAeonik-Bold.woff2') format('woff2');font-weight:700;font-style:normal;font-display:swap;}
  :root{ /* paste brand color block from Step 2 */ }
  *{margin:0;padding:0;box-sizing:border-box;}
  html,body{height:100%;background:#0c1024;font-family:'Shiji Day Sans',system-ui,sans-serif;overflow:hidden;}
  .serif{font-family:'Shiji Night Serif',Georgia,serif;}
  .mono{font-family:'Noto Sans Mono',monospace;}
  #deck{position:fixed;inset:0;}
  .slide{position:absolute;inset:0;display:none;padding:6.2vh 7vw;flex-direction:column;justify-content:center;background:var(--blue-0);color:var(--white);}
  .slide.active{display:flex;}
  .slide.center{align-items:center;text-align:center;justify-content:center;}
  h1.title{font-size:4.85vw;line-height:1.14;font-weight:700;}
  .subtitle{font-size:1.2vw;color:var(--blue-5);margin-top:5vh;line-height:1.65;}
  h2{font-size:3.4vw;font-weight:700;line-height:1.14;margin-bottom:5vh;}
  .kicker{color:var(--green);font-weight:700;font-size:1.15vw;letter-spacing:.5px;margin-bottom:2.4vh;}
  .hl{color:var(--green);}
  ul.points{list-style:none;display:flex;flex-direction:column;gap:3.2vh;max-width:80vw;}
  ul.points li{font-size:1.45vw;line-height:1.5;position:relative;padding-left:2.4vw;color:#eef1ff;}
  ul.points li::before{content:"";position:absolute;left:0;top:.66em;width:.72vw;height:.72vw;border-radius:50%;background:var(--green);}
  ul.points li b{color:var(--green);font-weight:700;}
  .stats{display:flex;gap:4vw;flex-wrap:wrap;}
  .stat .num{font-family:'Shiji Night Serif',Georgia,serif;font-size:3.8vw;font-weight:700;line-height:1.05;color:#fff;}
  .stat.mintnum .num{color:var(--green);}
  .stat .lbl{font-size:.98vw;color:var(--blue-5);margin-top:1.2vh;max-width:16vw;line-height:1.5;}
  .cta{display:inline-block;background:var(--green);color:var(--blue-0);font-weight:700;border-radius:999px;padding:1.6vh 2.6vw;font-size:1.1vw;}
  .logo{position:absolute;top:6vh;left:50%;transform:translateX(-50%);}
  .logo svg{height:9vh;width:auto;display:block;}
  .footnote{position:absolute;bottom:8vh;left:7vw;right:7vw;font-size:.95vw;color:var(--blue-5);opacity:.8;line-height:1.4;}
  #counter{position:fixed;bottom:2.4vh;right:2.4vw;font-size:.7vw;color:rgba(255,255,255,.55);z-index:20;}
  #hint{position:fixed;bottom:2.4vh;left:2.4vw;font-size:.7vw;color:rgba(255,255,255,.35);z-index:20;}
  #hint button{font:inherit;color:inherit;background:none;border:none;padding:0;cursor:pointer;transition:color .15s;}
  #hint button:hover{color:rgba(255,255,255,.85);}
  .navzone{position:fixed;top:0;bottom:0;width:14vw;z-index:15;cursor:pointer;}
  #prevz{left:0;} #nextz{right:0;}
</style>
</head>
<body>
<div id="deck">
  <!-- TITLE -->
  <section class="slide center bg-aurora active">
    <div class="logo">__SHIJI_LOGO_SVG__</div>
    <h1 class="title serif">Presentation title<br><span class="hl">highlight line</span></h1>
    <p class="subtitle">Subtitle / context line</p>
  </section>
  <!-- CONTENT -->
  <section class="slide">
    <div class="kicker mono">SECTION</div>
    <h2>Slide heading in one clear line</h2>
    <ul class="points">
      <li><b>Key point</b> — supporting detail.</li>
      <li>Another point.</li>
    </ul>
  </section>
  <!-- STATS -->
  <section class="slide">
    <h2>The numbers</h2>
    <div class="stats">
      <div class="stat mintnum"><div class="num serif">70%</div><div class="lbl">less time on repetitive tasks</div></div>
      <div class="stat"><div class="num serif">8<small> mo</small></div><div class="lbl">since adoption started</div></div>
    </div>
  </section>
</div>
<div id="counter"></div>
<div id="hint"><button id="prevBtn">←</button> <button id="nextBtn">→</button> Space · <button id="fsBtn">Fullscreen</button> (F) · <button id="restart">Restart</button> (R)</div>
<div class="navzone" id="prevz"></div>
<div class="navzone" id="nextz"></div>
<script>
  const slides=[...document.querySelectorAll('.slide')];
  let i=0;
  const counter=document.getElementById('counter');
  function show(n){
    i=(n+slides.length)%slides.length;
    slides.forEach((s,x)=>s.classList.toggle('active',x===i));
    counter.textContent=(i+1)+' / '+slides.length;
  }
  function next(){show(i+1);} function prev(){show(i-1);}
  function toggleFs(){
    if(!document.fullscreenElement)document.documentElement.requestFullscreen();
    else document.exitFullscreen();
  }
  document.addEventListener('keydown',e=>{
    if(e.key==='ArrowRight'||e.key===' '){e.preventDefault();next();}
    else if(e.key==='ArrowLeft'){prev();}
    else if(e.key==='f'||e.key==='F'){toggleFs();}
    else if(e.key==='r'||e.key==='R'){show(0);}
  });
  document.getElementById('nextz').onclick=next;
  document.getElementById('prevz').onclick=prev;
  document.getElementById('prevBtn').onclick=e=>{e.stopPropagation();prev();};
  document.getElementById('nextBtn').onclick=e=>{e.stopPropagation();next();};
  document.getElementById('fsBtn').onclick=e=>{e.stopPropagation();toggleFs();};
  document.getElementById('restart').onclick=e=>{e.stopPropagation();show(0);};
  show(0);
</script>
</body>
</html>
```

### Shiji logo (inline SVG)

Replace `__SHIJI_LOGO_SVG__` with a white inline SVG of the Shiji wordmark so the deck stays a single
file. If a real Shiji logo SVG is available in the project (e.g. `brand/Shiji-Logo.svg`), inline its
markup and set `fill:#fff`. Otherwise use a clean text wordmark as a fallback:

```html
<svg viewBox="0 0 220 60" role="img" aria-label="Shiji"><text x="0" y="46" font-family="'Shiji Night Serif',serif" font-size="52" font-weight="700" fill="#fff">Shiji</text></svg>
```

Keep the logo simple — one clean wordmark, no decorative dots unless using the official brand SVG.

---

## Links & navigation

**Inline links:** when a slide references something linkable, wrap the meaningful word(s) inside the
existing bullet rather than adding a separate "click here" bullet or showing a raw URL. Style them in
Energetic Green, underlined, opening in a new tab:

```html
<a href="https://example.com" target="_blank" rel="noopener" style="color:var(--green);text-decoration:underline;">meaningful phrase</a>
```

**Footer navigation** (already in the skeleton): the arrows, Fullscreen and Restart in `#hint` are all
clickable buttons, and the deck also responds to keys — `←` `→` `Space` to move, `F` for fullscreen,
`R` to restart. `show()` loops, so advancing past the last slide returns to the first and vice-versa.

Keep footer button hover clean (color change only, no underline).

---

## Image galleries & lightbox

When the user provides images (local folder, URLs, or any other source), add **gallery slides** with a built-in lightbox viewer.

### Gallery slide layout

Use `.slide.gallery-slide` with a `.gallery` container. Each image is clickable and opens in a fullscreen lightbox.

```html
<section class="slide gallery-slide">
  <div class="gallery-label mono">SECTION LABEL</div>
  <p style="position:absolute;top:9vh;left:7vw;font-size:1.1vw;color:var(--blue-5);max-width:80vw;">
    Description of what these images show.
  </p>
  <div class="gallery" style="margin-top:2vh;">
    <img src="slides-img/screenshot-1.png" alt="Description">
    <img src="slides-img/screenshot-2.png" alt="Description">
  </div>
</section>
```

### Required CSS (add to `<style>`)

```css
.gallery{display:flex;flex-wrap:wrap;gap:1.2vw;justify-content:center;align-items:center;padding:1vh 2vw;overflow:hidden;max-height:78vh;}
.gallery img{height:28vh;width:auto;border-radius:12px;border:1px solid rgba(255,255,255,.1);object-fit:contain;cursor:pointer;transition:transform .2s,box-shadow .2s;box-shadow:0 2px 12px rgba(0,0,0,.3);}
.gallery img:hover{transform:scale(1.1);box-shadow:0 8px 32px rgba(0,0,0,.5);}
.gallery-label{position:absolute;top:5vh;left:7vw;font-size:1vw;color:var(--green);font-weight:700;letter-spacing:.5px;}
.slide.gallery-slide{padding:6vh 3vw 4vh;justify-content:center;align-items:center;}

/* Lightbox */
#lightbox{position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:100;display:none;align-items:center;justify-content:center;flex-direction:column;}
#lightbox.open{display:flex;}
#lightbox img{max-height:88vh;max-width:92vw;object-fit:contain;border-radius:8px;box-shadow:0 0 60px rgba(0,0,0,.5);}
#lb-counter{position:absolute;top:2.5vh;right:3vw;font-size:.9vw;color:rgba(255,255,255,.5);}
#lb-close{position:absolute;top:2.5vh;left:3vw;font-size:1.4vw;color:rgba(255,255,255,.6);cursor:pointer;background:none;border:none;font-family:inherit;transition:color .15s;}
#lb-close:hover{color:#fff;}
.lb-nav{position:absolute;top:0;bottom:0;width:20vw;cursor:pointer;display:flex;align-items:center;z-index:101;}
.lb-nav span{font-size:2.5vw;color:rgba(255,255,255,.35);transition:color .15s;}
.lb-nav:hover span{color:#fff;}
#lb-prev{left:0;justify-content:flex-start;padding-left:2vw;}
#lb-next{right:0;justify-content:flex-end;padding-right:2vw;}
```

### Required HTML (add before `<div id="counter">`)

```html
<div id="lightbox">
  <button id="lb-close">✕ ESC</button>
  <div id="lb-counter"></div>
  <img id="lb-img" src="" alt="">
  <div class="lb-nav" id="lb-prev"><span>‹</span></div>
  <div class="lb-nav" id="lb-next"><span>›</span></div>
</div>
```

### Required JS (replace the standard `<script>` block)

The lightbox JS extends the standard slide navigation. Key additions:

- Click on gallery image → opens fullscreen lightbox at that image
- `←` `→` `Space` navigate within lightbox when open, slides when closed
- `ESC` or click on ✕ or background → closes lightbox
- Lightbox blocks slide navigation while open

```js
const lb=document.getElementById('lightbox');
const lbImg=document.getElementById('lb-img');
const lbCounter=document.getElementById('lb-counter');
let lbImages=[], lbIdx=0, lbOpen=false;

function openLightbox(galleryEl, imgIdx){
  lbImages=[...galleryEl.querySelectorAll('img')].map(im=>im.src);
  lbIdx=imgIdx||0;
  lbOpen=true;
  lb.classList.add('open');
  showLbImg();
}
function closeLightbox(){
  lbOpen=false;
  lb.classList.remove('open');
}
function showLbImg(){
  lbImg.src=lbImages[lbIdx];
  lbCounter.textContent=(lbIdx+1)+' / '+lbImages.length;
}
function lbNext(){lbIdx=(lbIdx+1)%lbImages.length;showLbImg();}
function lbPrev(){lbIdx=(lbIdx-1+lbImages.length)%lbImages.length;showLbImg();}

document.querySelectorAll('.gallery img').forEach(img=>{
  img.addEventListener('click',e=>{
    e.stopPropagation();
    const gallery=img.closest('.gallery');
    const imgs=[...gallery.querySelectorAll('img')];
    openLightbox(gallery, imgs.indexOf(img));
  });
});

document.getElementById('lb-close').onclick=e=>{e.stopPropagation();closeLightbox();};
document.getElementById('lb-prev').onclick=e=>{e.stopPropagation();lbPrev();};
document.getElementById('lb-next').onclick=e=>{e.stopPropagation();lbNext();};
lb.addEventListener('click',e=>{if(e.target===lb)closeLightbox();});

// In the keydown handler, add lightbox check BEFORE slide navigation:
// if(lbOpen){
//   if(e.key==='Escape'){closeLightbox();}
//   else if(e.key==='ArrowRight'||e.key===' '){e.preventDefault();lbNext();}
//   else if(e.key==='ArrowLeft'){lbPrev();}
//   return;
// }
```

### Divider slides with preview (optional)

If you want a representative image on a divider/title slide, add `.part-preview`:

```css
.part-preview{margin-top:4vh;height:30vh;width:30vh;border-radius:12px;object-fit:cover;border:1px solid rgba(255,255,255,.1);box-shadow:0 8px 40px rgba(0,0,0,.4);}
```

```html
<img class="part-preview" src="slides-img/representative-screenshot.png" alt="Example">
```

### GitLab Pages deployment

If user wants to share the presentation via URL:

1. Create a GitLab project
2. Put `index.html` + `slides-img/` folder inside `public/`
3. Add `.gitlab-ci.yml`:
   ```yaml
   pages:
     stage: deploy
     script:
       - echo "Deploying to GitLab Pages"
     artifacts:
       paths:
         - public
     only:
       - master
   ```
4. Push and trigger pipeline — Pages URL comes from the API response

---

---

## Modular File Structure

For presentations with many slides, use a modular file structure for easier editing:

```
presentation/
├── _head.html           # <html>, <head>, <style>, <body>, <div id="deck">
├── _foot.html           # </div>, lightbox, comparator, overlays, <script>, </body>
├── slides/
│   ├── 01-title.html    # Each slide is one <section class="slide ...">...</section>
│   ├── 02-overview.html
│   ├── 03-divider-topic.html
│   └── ...
├── slides-img/          # All images referenced by slides
├── build.sh             # Assembles _head + slides/*.html + _foot into index.html
└── index.html           # Generated output — DO NOT edit directly
```

### Rules

- **Edit slides individually** in `slides/` — each file contains exactly one `<section>` tag.
- **Run `./build.sh`** after any edit to regenerate `index.html`.
- **Never edit `index.html` directly** — it gets overwritten by the build.
- **Naming convention**: `NN-description.html` where NN is zero-padded order (01, 02...). Slides are concatenated in filename order.
- **To reorder slides**: rename the files to change their NN prefix.
- **To add a slide**: create a new file with the appropriate NN, shifting later numbers if needed.
- **To remove a slide**: delete the file and rebuild.
- `_head.html` contains all CSS, font declarations, and `:root` variables. Edit here for global style changes.
- `_foot.html` contains lightbox/comparator overlays, navigation JS, and `</body>`. Edit here for behavior changes.

### build.sh

```bash
#!/bin/zsh
DIR="$(cd "$(dirname "$0")" && pwd)"
OUT="$DIR/index.html"
{
  cat "$DIR/_head.html"
  echo ""
  for f in "$DIR"/slides/*.html; do
    echo ""
    cat "$f"
  done
  echo ""
  cat "$DIR/_foot.html"
} > "$OUT"
echo "✓ Built index.html — $(grep -c '<section' "$OUT") slides"
```

---

## Checklist before delivering

- [ ] Single `.html` output file — generated by `build.sh` from modular slides. No local font files (images in `slides-img/` subfolder are OK).
- [ ] `@font-face` declarations for Shiji Night Serif (Regular + Heavy) and Shiji Day Sans (Regular + Medium + Bold) from Webflow CDN present.
- [ ] Google Fonts link present for Noto Sans Mono only.
- [ ] Brand `:root` colors pasted exactly; text uses `--blue-0`, not black.
- [ ] Energetic Green used sparingly (one highlight per slide).
- [ ] Keyboard (← → Space · F fullscreen · R restart) + side click zones + clickable footer buttons + counter all work.
- [ ] Navigation loops (last → first, first → last).
- [ ] Linkable references use inline green links opening in a new tab (no raw URLs, no "click here" bullets).
- [ ] Footnote text sits at `bottom:8vh`, not overlapping the footer.
- [ ] Opens correctly by double-clicking the file (no server needed).
- [ ] If galleries present: lightbox HTML, CSS and JS are included.
- [ ] If galleries present: clicking image opens lightbox, ← → navigate within, ESC closes.
- [ ] If deploying to GitLab Pages: `public/` folder contains `index.html` + `slides-img/`, `.gitlab-ci.yml` present.
