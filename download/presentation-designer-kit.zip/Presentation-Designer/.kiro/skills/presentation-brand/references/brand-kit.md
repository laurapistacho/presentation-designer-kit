# Shiji Brand Kit (Day & Night)

Brand values from the Shiji rebrand presented at ITB Berlin 2025, as written in the original HTML presentation skill (`original-html-skill.md`). The decks this kit builds use exactly these values: `../assets/tokens.json` holds them for the build, and every file carries them as the local colour variables "Shiji Day & Night". Use the same values for other brand pieces: HTML pages, posters, documents, and the Modernised (V2) mockups of the Kiro Mockup Designer kit.

The old Product Presentation Template drifted from the brand kit: its navy was `#172256` (Midnight is `#172554`), its blue `#2463EB` (Reviewpro Blue is `#0030FF`) and its green `#0FFFAB` (Energetic Green is `#0AFFAB`). New decks use the brand kit.

## Fonts

| Font | Role | Weights | Use |
|---|---|---|---|
| Shiji Night Serif (Reckless Neue) | Emotional | 400 Regular, 900 Heavy | Big titles, quotes, stat numbers |
| Shiji Day Sans (Aeonik) | Corporate | 400, 500, 700 (the desktop files add Thin to Black) | Body, bullets, labels |
| Noto Sans Mono | Technical | 400, 500, 700 | Captions, tags, small technical labels |

Desktop font files come from the design lead (licensed, not shipped in the kit). Installed, they appear as "Shiji Day Sans Aeonik" (Thin to Black) and "Shiji Night Serif Reckless Neue" (variable font, weight 100 to 900).

Webfonts on the shiji.com CDN, for HTML:

```css
@font-face{font-family:'Shiji Night Serif';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8e_ShijiNightSerifRecklessNeue-Regular.woff2') format('woff2');font-weight:400;font-display:swap;}
@font-face{font-family:'Shiji Night Serif';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67dac539ac844f1933bcafb0_ShijiNightSerifRecklessNeue-Heavy.woff2') format('woff2');font-weight:900;font-display:swap;}
@font-face{font-family:'Shiji Day Sans';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9c_ShijiDaySansAeonik-Regular.woff2') format('woff2');font-weight:400;font-display:swap;}
@font-face{font-family:'Shiji Day Sans';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8f_ShijiDaySansAeonik-Medium.woff2') format('woff2');font-weight:500;font-display:swap;}
@font-face{font-family:'Shiji Day Sans';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9d_ShijiDaySansAeonik-Bold.woff2') format('woff2');font-weight:700;font-display:swap;}
```

Noto Sans Mono comes from Google Fonts (`https://fonts.googleapis.com/css2?family=Noto+Sans+Mono:wght@400;500;700&display=swap`), and Figma has it built in. The builder's preview (`figma-slides-builder/scripts/render_deck.py`) uses the same CDN files as a fallback when the fonts are not installed.

## Colours

```css
:root{
  /* Shiji Blue */
  --blue-0:#172554;   /* Midnight: primary text colour, use instead of black */
  --blue-1:#1E3A8A;   /* Twilight (Data + AI) */
  --blue-2:#0030FF;   /* ReviewPro: main highlight, CTA, buttons */
  --blue-3:#3B82F6;
  --blue-4:#60A5FA;   /* Meridian */
  --blue-5:#D5ECFF;
  --blue-6:#E8F5FF;   /* Daylight Blue */
  --blue-6-60:#F1F9FF;
  --blue-6-30:#F8FCFF;
  /* Shiji Active */
  --green:#0AFFAB;    /* Energetic Green: the one active highlight or CTA */
  --white:#FFFFFF;
  /* Alerts */
  --alert-light:#DC2626;  /* on light backgrounds */
  --alert-dark:#F87171;   /* on dark backgrounds */
  /* Day-Night product colours */
  --sunrise-red:#8D3791;   /* Daylight PMS */
  --sunset-yellow:#FFB851; /* Iceportal */
  --sunset-orange:#FF8056; /* Horizon */
  --sunset-purple:#7443A7; /* Infrasys */
}
```

Gradients:

```css
/* Daylight PMS   */ background:linear-gradient(90deg,#8D3791 0%,#1D4ED8 100%);
/* Shiji Brand 2  */ background:linear-gradient(90deg,#172554 0%,#1E3A8A 50%,#0AFFAB 100%);
/* Shiji Platform */ background:linear-gradient(90deg,#0030FF,#0AFFAB);
```

## Day & Night

Hospitality runs 24/7, and the rebrand's theme is Day and Night.

- Dark by default for brand pieces: deep navy, white text, Energetic Green and ReviewPro blue as accents.
- Horizon split where it fits: a lighter "day" tone fading into a dark "night".
- Green means active: one word, number or call to action per surface. Never a flood of green.
- Calls to action are pills: fully rounded, green with Midnight text, or ReviewPro blue with white text.
- Avoid pure black for text: Midnight (`#172554`).
- Tagline: "The best hotels run on Shiji — day and night."
