---
name: presentation-brand
description: The Shiji "Day & Night" look for presentations, taken from the original Shiji presentation skill - brand colours, the aurora and horizon gradients, Night Serif / Day Sans / Noto Sans Mono, the day, night and blue themes, layout rules and the visual check. The one source of the look - figma-slides-builder reads its tokens.json. Use when designing, theming or reviewing slides, when choosing the look of a layout, when a deck looks tacky, off-brand or cluttered, or when someone asks for Shiji brand colours, fonts or gradients.
---

# Presentation brand: Day & Night

Shiji's rebrand (ITB Berlin 2025) is about **Day and Night**: hotels run 24/7. In slides that means dark night slides with white type and one Energetic Green highlight, light day slides for the screenshots and the detail, and Reviewpro Blue as punctuation. The look comes from the original Shiji presentation skill (`references/original-html-skill.md`): simple slides, a strong serif title, a lot of space, one highlight.

This skill owns the look. The **presentation-writer** skill owns the words, the **figma-slides-builder** skill turns both into a Figma Slides file. When they disagree, the brand rules here win for anything visual.

| File | What |
|---|---|
| `assets/tokens.json` | The single source: colours, fonts, type scale, themes, backgrounds, gradients, radii, shadows. The builder reads it on every build. |
| `references/brand-kit.md` | The Shiji Brand Kit values with the web fonts on the shiji.com CDN, for brand pieces outside the kit. |
| `references/original-html-skill.md` | The original skill this look comes from, kept as it was written (it builds single-file HTML decks). |
| `library/index.html` (kit folder) | Every layout in this look, then the previous template and the team's decks, for comparison. |

## The rules

1. **Night by default.** Openers, dividers, statements, quotes and numbers are night slides. Screenshots and dense content are day slides. Blue (Reviewpro Blue background) is punctuation: a cover or a section, one or two per deck. Alternating night and day is the rhythm of the deck.
2. **One highlight per slide.** Mark it `==like this==` in the spec. It turns Energetic Green on night and blue slides and Reviewpro Blue on day slides. It is the word, number or line that matters most. Green text never goes on a light background (contrast is 1.3:1).
3. **Three typefaces, three jobs.**
   - Shiji Night Serif (Reckless Neue) for emotion: cover and divider titles, big numbers, statements, quotes. Heavy for titles and numbers, Regular for sentences and quotes.
   - Shiji Day Sans (Aeonik) for information: slide titles (Bold), body and bullets (Regular), buttons (Bold).
   - Noto Sans Mono for labels: the kicker above a title, chips, captions, dates, names under quotes. Uppercase, tracked.
4. **No black.** Text on day slides is Midnight `#172554`; secondary text is Midnight at 72%.
5. **Gradients come from the tokens, built as real Figma gradients**, never as blurred shapes or pictures:
   - `aurora` (orange, blue and pink glows on indigo): cover and closing slides only.
   - `horizon` (day light at the top fading into night): the left-aligned cover, scenario and brief slides.
   - `deep` (night with a twilight glow rising from the bottom): section dividers, hero quotes.
   - `night` (Midnight with a soft Blue 3 glow top right): night content slides.
   - `blue` (Reviewpro Blue with a lighter corner): blue covers and sections.
   - Accent bars only: `platform` (Reviewpro Blue to green), `brand-2`, `daylight-pms`.
6. **CTA = pill.** Fully rounded. Energetic Green with Midnight text on night, Reviewpro Blue with white text on day. Chips are small mono pills: green for "New", an outline for "Current".
7. **Screenshots sit on a stage.** On day slides the stage is Daylight Blue 60 (`#F1F9FF`); the screenshot keeps its own ratio, has 16 px corners, a hairline frame and a soft shadow. Never stretched; only photos are cropped to fill.
8. **Space.** 1920 x 1080, 128 px side margins, content between y 104 and 944, the logo bottom right at y 992, footnotes bottom left. The cover and closing slides carry the logo top centre.
9. **Kicker, title, subtitle.** The mono kicker names the topic in 1 to 4 words ("SETTINGS"), the title says the point, the subtitle adds one line. Skip what is not needed.
10. **One idea per slide.** If a slide needs two highlights, two screenshots that are not a comparison, or more than four bullets, it is two slides.

## Type scale

From `assets/tokens.json` ("type"). Sizes in px on a 1920 x 1080 slide.

| Token | Font | Size / line | Use |
|---|---|---|---|
| `display` | Night Serif Heavy | 112 / 121 | Cover and closing titles |
| `display-s` | Night Serif Heavy | 88 / 97 | Divider titles, questions, agenda title |
| `number` | Night Serif Heavy | 240 / 269 | Section numbers |
| `stat`, `stat-s` | Night Serif Heavy | 120, 88 | Big numbers |
| `statement` | Night Serif Regular | 80 / 92 | One-sentence slides |
| `quote`, `quote-s` | Night Serif Regular | 60, 36 | Hero quote, quotes in cards |
| `title`, `title-s` | Day Sans Bold | 64, 48 | Slide titles |
| `heading` | Day Sans Bold | 32 | Column and card headings |
| `subtitle`, `lead` | Day Sans Regular | 32 | The line under a title, the first sentence |
| `body`, `small` | Day Sans Regular | 28, 22 | Paragraphs and bullets, card text |
| `button` | Day Sans Bold | 22 | Pill buttons |
| `kicker`, `label` | Noto Sans Mono Bold, Medium | 22, 18 | Uppercase labels |
| `caption`, `footnote` | Noto Sans Mono, Day Sans | 18 | Captions, sources |

## Colours

| Token | Hex | Role |
|---|---|---|
| `midnight` | `#172554` | Night background; text on day slides |
| `night` | `#0C1024` | Deepest background: dividers, hero quotes |
| `twilight` | `#1E3A8A` | Circles, secondary dark surfaces |
| `reviewpro` | `#0030FF` | Highlight, link and button colour on day; blue slides |
| `blue-3` | `#3B82F6` | Glows, charts |
| `meridian` | `#60A5FA` | Glows, secondary numbers on night |
| `blue-5` | `#D5ECFF` | Secondary text on night; borders on day |
| `daylight` | `#E8F5FF` | Panels and chips on day |
| `daylight-60` | `#F1F9FF` | The stage behind screenshots |
| `daylight-30` | `#F8FCFF` | Quiet day background |
| `green` | `#0AFFAB` | The one highlight. Never text on light backgrounds |
| `moonlight` | `#EEF1FF` | Body text on night |
| `alert-light`, `alert-dark` | `#DC2626`, `#F87171` | Errors and risks on day, on night |
| `sunrise-red`, `sunset-yellow`, `sunset-orange`, `sunset-purple` | `#8D3791`, `#FFB851`, `#FF8056`, `#7443A7` | Product colours: Daylight PMS, Iceportal, Horizon, Infrasys |

Every built file carries these as local colour variables in the collection **Shiji Day & Night**, so designers pick them from the colour picker in Figma.

## Themes

A theme maps roles to colours; layouts only ask for roles. Spec: `"theme": "day" | "night" | "blue"` on any slide.

| Role | Night | Day | Blue |
|---|---|---|---|
| Background | Midnight | White | Reviewpro Blue |
| Title | White | Midnight | White |
| Text | Moonlight | Midnight | White |
| Muted | Blue 5 | Midnight 72% | Blue 5 |
| Highlight, kicker, dots | Energetic Green | Reviewpro Blue | Energetic Green |
| Surface (cards) | White 6% + White 14% border | Daylight Blue 60 + Blue 5 border | White 10% |
| Button | Green, Midnight text | Reviewpro Blue, white text | Green, Midnight text |
| Logo | White | Midnight | White |

## What made the old template look tacky

Keep these out of new decks and out of any change to the tokens:

- Huge blurred gradient blobs (angular gradients with a 266 to 300 px layer blur): muddy colour, heavy files, and they turn into pictures in PowerPoint. The aurora does the same job with flat, sharp radial gradients.
- Too many typefaces: Lato, Noto Sans, Inter and Aeonik mixed on one slide. Now three, each with one job.
- Off-brand values (`#172256`, `#2463EB`, `#0FFFAB`) next to brand ones.
- Faded giant numbers at 10% opacity and decorative circles on every slide.
- Two highlights fighting on one slide; green on white.

## Visual check before handing over

Look at every slide in the preview contact sheets, then:

- [ ] One highlight per slide, and it is the thing that matters.
- [ ] Night and day alternate; no more than about eight day slides in a row.
- [ ] No black text, no green text on day slides, no text over a busy picture without a dark caption pill.
- [ ] Only the three typefaces; serif for emotion, sans for information, mono for labels.
- [ ] Screenshots at their own ratio on a stage, nothing stretched or blurry (screenshots at 2x).
- [ ] Titles say the point; kickers are 1 to 4 words; at most four bullets.
- [ ] Nothing in the bottom 36 px except the footer; the logo bottom right (top centre on cover and closing).
- [ ] Cover and closing on the aurora, dividers on deep night, at most two blue slides.

## Changing the look (kit maintainers)

Edit `assets/tokens.json`, never colours or sizes inside the layouts. Then `python3 setup/build_showcase.py` rebuilds the Day & Night template (one slide per layout) and `library/index.html`; look at it before sharing the kit. New colours become new variables in every file automatically.
