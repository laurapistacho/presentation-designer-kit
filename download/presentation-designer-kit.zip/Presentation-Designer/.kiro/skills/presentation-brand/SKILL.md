---
name: presentation-brand
description: The Shiji "Day & Night" look for presentations, as the official Figma Slides template "00 Day & Night template" defines it - brand colours and the template's theme colours, the aurora and horizon gradients, Night Serif / Day Sans / Noto Sans and the template's text styles, the day, night and blue themes, the legacy accents, layout rules and the visual check. The one source of the look - figma-slides-builder reads its tokens.json. Use when designing, theming or reviewing slides, when choosing the look of a layout, when a deck looks tacky, off-brand or cluttered, or when someone asks for Shiji brand colours, fonts or gradients.
---

# Presentation brand: Day & Night

Shiji's rebrand (ITB Berlin 2025) is about **Day and Night**: hotels run 24/7. In slides that means dark night slides with white type and one Energetic Green highlight, light day slides for the screenshots and the detail, and Reviewpro Blue as punctuation. The look comes from the original Shiji presentation skill (`references/original-html-skill.md`): simple slides, a strong serif title, a lot of space, one highlight. The design team fine-tuned it in the **official Figma Slides template, "00 Day & Night template"** (https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4): that file is the reference, and `assets/tokens.json` matches its text styles and theme colours value for value.

This skill owns the look. The **presentation-writer** skill owns the words, the **figma-slides-builder** skill turns both into a Figma Slides file. When they disagree, the brand rules here win for anything visual.

| File | What |
|---|---|
| `assets/tokens.json` | The single source in numbers: colours, fonts, type scale, themes, backgrounds, gradients, radii, shadows, and which text style and theme colour of the official template each token is (`text_styles`, `theme_variables`). The builder reads it on every build. |
| `references/brand-kit.md` | The Shiji Brand Kit values with the web fonts on the shiji.com CDN, for brand pieces outside the kit. |
| `references/original-html-skill.md` | The original skill this look comes from, kept as it was written (it builds single-file HTML decks). |
| `library/index.html` (kit folder) | Every layout in this look, then the previous template and the team's decks, for comparison. |

## The rules

1. **Night by default.** Openers, dividers, statements, quotes and numbers are night slides. Screenshots and dense content are day slides. Blue (Reviewpro Blue background) is punctuation: a cover or a section, one or two per deck. Alternating night and day is the rhythm of the deck.
2. **One highlight per slide.** Mark it `==like this==` in the spec. It turns Energetic Green on night and blue slides and Reviewpro Blue on day slides. It is the word, number or line that matters most. Green text never goes on a light background (contrast is 1.3:1).
3. **Three typefaces, three jobs.**
   - Shiji Night Serif (Reckless Neue) for emotion: cover and divider titles, big numbers, statements, quotes. Heavy for titles and numbers, Regular for sentences and quotes.
   - Shiji Day Sans (Aeonik) for information: slide titles (Bold), body and bullets (Regular), buttons (Bold).
   - Noto Sans for labels: the kicker above a title, chips, dates, names under quotes (uppercase, tracked), and captions under pictures.
4. **No black.** Text on day slides is Midnight `#172554`; secondary text is Midnight at 72%.
5. **Gradients come from the tokens, built as real Figma gradients**, never as pictures (the legacy accents below are the one exception, copied from the template):
   - `aurora` (orange, blue and pink glows on indigo): cover and closing slides only.
   - `horizon` (day light at the top fading into night): the left-aligned cover, scenario and brief slides.
   - `deep` (night with a twilight glow rising from the bottom): section dividers, hero quotes.
   - `night` (Midnight with a soft Blue 3 glow top right): night content slides.
   - `blue` (Reviewpro Blue with a lighter corner): blue covers and sections.
   - Accent bars only: `platform` (Reviewpro Blue to green), `brand-2`, `daylight-pms`.
6. **CTA = pill.** Fully rounded. Energetic Green with Midnight text on night, Reviewpro Blue with white text on day. Chips are small label pills: green for "New", an outline for "Current", Midnight for a variant name, Blue 5 for its tags.
7. **Screenshots sit on a stage.** On day slides the stage is Daylight Blue 60 (`#F1F9FF`); the screenshot keeps its own ratio, has 16 px corners, a hairline frame and a soft shadow. Never stretched; only photos are cropped to fill.
8. **Space.** 1920 x 1080, 128 px side margins, content between y 104 and 944, the logo bottom right at y 992 on every content slide (the template's shared footer position), footnotes bottom left. The cover and closing slides carry the logo top centre (top left on the horizon cover). A text column in a white panel next to a stage sits at 96 px.
9. **Kicker, title, subtitle.** The kicker names the topic in 1 to 4 words ("SETTINGS"), the title says the point, the subtitle adds one line. Skip what is not needed.
10. **One idea per slide.** If a slide needs two highlights, two screenshots that are not a comparison, or more than four bullets, it is two slides.

## Type scale

From `assets/tokens.json` ("type"). Sizes in px on a 1920 x 1080 slide.

| Token | Font | Size / line | Use |
|---|---|---|---|
| `display` | Night Serif Heavy | 112 / 121 | Cover and closing titles |
| `display-s` | Night Serif Heavy | 88 / 97 | Divider titles, questions, agenda title |
| `number` | Night Serif Heavy | 240 / 269 | Section numbers |
| `stat`, `stat-s` | Night Serif Heavy | 120, 88 | Big numbers |
| `statement` | Night Serif Regular | 80 / 92 | One-sentence slides |
| `quote`, `quote-s` | Night Serif Regular | 60, 36 | Hero quote, quotes in cards |
| `title`, `title-s` | Day Sans Bold | 64, 48 | Slide titles |
| `heading` | Day Sans Bold | 32 | Column and card headings |
| `subtitle`, `lead` | Day Sans Regular | 32 | The line under a title, the first sentence |
| `body`, `small` | Day Sans Regular | 28, 22 | Paragraphs and bullets, card text |
| `button` | Day Sans Bold | 22 | Pill buttons |
| `kicker`, `label` | Noto Sans Bold, Medium | 22, 18 | Uppercase labels |
| `caption`, `caption-l`, `footnote` | Noto Sans, Noto Sans, Day Sans | 18, 24, 18 | Captions, captions under devices, sources |
| `header`, `display-xl`, `title-l`, `metric` | Day Sans Black, Night Serif Heavy, Day Sans Bold, Day Sans | 112.5, 112.5, 80, 800 | The legacy titles and the faded divider number |
| `slogan` | Night Serif Regular | 64 | The design-team slogan |

Every token is a text style of the official template (tokens.json `text_styles`: `kicker` is `Shiji / Labels / Kicker`, `title` is `Shiji / Headings / Slide title`, `body` is `Shiji / Body / Body 28`...). Built text is linked to its style, so the team changes a style once in Figma and every slide follows.

## Colours

| Token | Hex | Role |
|---|---|---|
| `midnight` | `#172554` | Night background; text on day slides |
| `night` | `#0C1024` | Deepest background: dividers, hero quotes |
| `twilight` | `#1E3A8A` | Circles, secondary dark surfaces |
| `reviewpro` | `#0030FF` | Highlight, link and button colour on day; blue slides |
| `blue-3` | `#3B82F6` | Glows, charts |
| `meridian` | `#60A5FA` | Glows, secondary numbers on night |
| `blue-5` | `#D5ECFF` | Secondary text on night; borders on day |
| `daylight` | `#E8F5FF` | Panels and chips on day |
| `daylight-60` | `#F1F9FF` | The stage behind screenshots |
| `daylight-30` | `#F8FCFF` | Quiet day background |
| `green` | `#0AFFAB` | The one highlight. Never text on light backgrounds |
| `moonlight` | `#EEF1FF` | Body text on night |
| `alert-light`, `alert-dark` | `#DC2626`, `#F87171` | Errors and risks on day, on night |
| `sunrise-red`, `sunset-yellow`, `sunset-orange`, `sunset-purple` | `#8D3791`, `#FFB851`, `#FF8056`, `#7443A7` | Product colours: Daylight PMS, Iceportal, Horizon, Infrasys |
| `logo-blue` | `#1F3A8A` | The Shiji logo and the round icon button on day slides |
| `light-blue` | `#92C5FD` | Wireframe lines on night; the variants stage on day (at 20%) |
| `brand-navy`, `link-blue` | `#172256`, `#2463EB` | Legacy layouts only |
| `ink` | `#111111` | The design-team slogan only |

Every built file carries these as colour variables. The Slides theme of the template, **Shiji / Presentation theme**, holds the role names designers see first (`Background/Night` is Midnight, `Background/Deep` Night, `Accent/Mint` Energetic Green, `Accent/Electric-blue` Reviewpro Blue, `Surface/Ice` Daylight Blue 60, `Surface/Pale-blue` Blue 5, `Brand/White`, `Brand/Ink`, `Brand/Logo-blue`, `Accent/Light-blue`, `Background/Brand-navy`, `Accent/Link-blue`); fills bind to those. The collection **Shiji Day & Night** holds the whole palette for the other colours.

## Themes

A theme maps roles to colours; layouts only ask for roles. Spec: `"theme": "day" | "night" | "blue"` on any slide.

| Role | Night | Day | Blue |
|---|---|---|---|
| Background | Midnight | White | Reviewpro Blue |
| Title | White | Midnight | White |
| Text | Moonlight | Midnight | White |
| Muted | Blue 5 | Midnight 72% | Blue 5 |
| Highlight, kicker, dots | Energetic Green | Reviewpro Blue | Energetic Green |
| Surface (cards) | White 6% + White 14% border | Daylight Blue 60 + Blue 5 border | White 10% |
| Button | Green, Midnight text | Reviewpro Blue, white text | Green, Midnight text |
| Logo | White | Midnight | White |

## The legacy accents

The official template keeps four layouts from the earlier template on purpose: `cover-gradient` (the violet glow on Brand Navy), `section-number` (the giant faded number on Link Blue), `question-circle` (the brand circle) and `content-gradient` (the violet field fading to white). Their artwork, blurred angular gradients and the brand circle component, is copied from the template file as it is, not drawn from tokens.

- Use them as an accent: about one per deck, where the deck continues the look of the earlier quarterlies. The copy check warns at three.
- They turn into pictures in PowerPoint; that is expected.
- Their off-brand values (`brand-navy`, `link-blue`) stay inside these layouts. Never use them elsewhere.

And keep these out of every deck:

- Too many typefaces: Lato, Inter or Aeonik TRIAL next to the Shiji fonts. Three families, each with one job.
- `#0FFFAB` instead of Energetic Green `#0AFFAB`; black text.
- Faded numbers and decorative circles outside the legacy layouts.
- Two highlights fighting on one slide; green on white.

## Visual check before handing over

Look at every slide in the preview contact sheets, then:

- [ ] One highlight per slide, and it is the thing that matters.
- [ ] Night and day alternate; no more than about eight day slides in a row.
- [ ] No black text, no green text on day slides, no text over a busy picture without a dark caption pill.
- [ ] Only the three typefaces; serif for emotion, Day Sans for information, Noto Sans for labels.
- [ ] At most one or two legacy accents (gradient cover, oversized number, brand circle, gradient brief).
- [ ] Screenshots at their own ratio on a stage, nothing stretched or blurry (screenshots at 2x).
- [ ] Titles say the point; kickers are 1 to 4 words; at most four bullets.
- [ ] Nothing in the bottom 36 px except the footer; the logo bottom right (top centre on cover and closing).
- [ ] Cover and closing on the aurora (or one legacy gradient cover), dividers on deep night, at most two blue slides.

## Changing the look (kit maintainers)

The official Figma template leads. When the team changes a style or a colour there, save a new local copy into the kit (`kit-maintenance` steering file) and give `assets/tokens.json` the same value: the build writes the token values into the template's styles, so a token that differs from the style changes the style in every built deck. Never put colours or sizes inside the layouts. Then `python3 setup/build_showcase.py` rebuilds the Day & Night template (one slide per layout) and `library/index.html`; look at it before sharing the kit. New colours become new variables in every file automatically.
