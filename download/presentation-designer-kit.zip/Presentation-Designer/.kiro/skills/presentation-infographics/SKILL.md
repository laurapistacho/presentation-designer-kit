---
name: presentation-infographics
description: Infographics in the Shiji Day & Night look - wheel, rings, cycle, process, user flow, timeline, hierarchy and matrix - drawn as editable Figma layers from the official template's own chips, cards and gradient circle, with the Night Serif, Day Sans and Noto Sans pairings and a contrast check on every label. Kiro proposes a diagram whenever a slide explains a structure, without being asked. Also exports a diagram as a PNG or a one-slide Figma file. Triggers on infographic, diagram, flow, user flow, flowchart, hierarchy, org chart, sitemap, timeline, roadmap, milestones, cycle, loop, wheel, hub, layers, rings, matrix, quadrant, 2x2.
---
# Presentation infographics

This skill turns a structure into a diagram: a platform and its products, layers inside layers, a loop, steps, screens and decisions, dates, reporting lines, two criteria. The **presentation-writer** skill decides the words, the **presentation-brand** skill owns the look, the **figma-slides-builder** skill writes the file. This skill decides which diagram fits, lays it out, and gives every part of it its type, colour and shape.

| File | What |
|---|---|
| `scripts/infographics.py` | The layout engine: a spec slide in, the diagram's shapes out (positions, colours, type), with the contrast check |
| `scripts/render_html.py` | Draws the engine's shapes as a picture (the PNG export) |
| `scripts/build_infographic.py` | One diagram on its own: a PNG or a one-slide Figma file |
| `.kiro/skills/figma-slides-builder/scripts/infographic_layers.py` | The eight layouts: the engine's shapes as editable Figma layers |
| `examples/infographics/` (kit folder) | One slide per diagram with sample data: `deck.json` and `Shiji infographics.fig` to drag into Figma |
| `library/infographics/` (kit folder) | A picture of each example |

## Use one without being asked

When a slide explains a structure, propose the matching diagram in the outline instead of bullets. The user sees it there with every other slide and can say no. Do it when the content already has the shape; never invent a structure to fill a diagram.

| The content is | Diagram | Layout |
|---|---|---|
| One thing with its parts around it (a platform and its products) | Wheel | `wheel` |
| Scopes or layers inside each other (team, product, world) | Rings | `rings` |
| A loop that repeats (a design cycle, a release rhythm) | Cycle | `cycle` |
| Three to six steps in order | Process | `process` |
| Screens and decisions, with branches | User flow | `userflow` |
| Dates, versions or phases | Timeline | `timeline` |
| Reporting lines, a sitemap, a breakdown | Hierarchy | `hierarchy` |
| Two criteria and four groups (impact against effort) | Matrix | `matrix` |

Keep the text when there are fewer than three parts, when the point is one number (`stats`), or when the relationships are not real. Split the slide when a diagram goes over its limits below.

## The eight diagrams

Each one has a slide in `examples/infographics/deck.json` (copy it as a starting point) and a picture in `library/infographics/`.

| Layout | Fields | Fits | Ask like |
|---|---|---|---|
| `wheel` | `center`, `items[]` (text, `color`, `highlight`), `palette: "products"` | 3 to 10 items, 4 words each | "Show the Shiji Platform with its nine products as a wheel." |
| `rings` | `rings[]` inner to outer: `label`, `items[]` (text, `color`, `highlight`, `outline`) | 2 to 4 rings, up to 4 items each | "Draw our three AI layers as rings, from the hub to the outside." |
| `cycle` | `steps[]` (text, `highlight`), `center` | 3 to 8 steps, 4 words each | "Turn our design process into a cycle." |
| `process` | `steps[]` (text, `sub`, `highlight`) | 2 to 6 steps, 16 words under each | "Make the guest journey from booking to review a five-step process." |
| `userflow` | `nodes[]` (`id`, text, `kind`: start, screen, decision, end; `label`), `links[]` (`from`, `to`, `label`) | 2 to 12 steps | "Draw the online check-in flow: when the ID is on file, the guest skips the scan." |
| `timeline` | `events[]` (`date`, text, `sub`, `highlight`), `phases[]` (`title`, `from`, `to`), `today` | 2 to 8 moments | "Put this year's releases on a timeline and mark today." |
| `hierarchy` | `root` (text, `sub`, `children[]` up to 6, each with `children[]` up to 5) | 3 levels | "Show the front office team as an org chart." |
| `matrix` | `quadrants[4]` (`title`, `items[]`, `highlight`), `x_axis`, `y_axis` (`label`, `low`, `high`) | 4 items per quadrant | "Sort these ideas by impact and effort." |

Every infographic slide also takes `kicker`, `title`, `lead` (or `subtitle`), `theme` (night, day, blue), `source` and `notes`. Wheel, rings, cycle and matrix put the text on the left and the diagram on the right; the others put the heading on top and the diagram under it. `"arrange": "full"` or `"split"` switches. In a user flow the first path out of a step stays on its row and every other branch starts a row below; a link back to an earlier step runs under the flow. Timeline `from`, `to` and `today` count moments from 0.

```json
{"layout": "wheel", "kicker": "Platform", "title": "Nine products, one platform", "center": "Shiji Platform",
 "palette": "products", "items": ["Meridian Experiences", "Iceportal Content", "Horizon Distribution", "..."],
 "notes": "What the presenter says about it."}
```

## The shapes, as Figma layers

A diagram is one frame on the slide ("Infographic · Wheel") with a frame inside for each part (Centre, Items, Spokes, Track, Rings, Arrows, Steps, Paths, Axes), each layer named after its text. Everything is editable in Figma like anything a designer draws:

| Shape | In Figma | Used for |
|---|---|---|
| Chip | Auto-layout frame, Noto Sans label linked to "Shiji / Labels / Metadata 18"; default (White 12%), new (Energetic Green), light (Blue 5), dark (Midnight), current (outline) | Items of wheels, rings, hierarchies and matrices; start and end of a user flow; Today |
| Product dot | 10 px ellipse inside a chip, in the product's brand colour | `palette: "products"` and any item `color` |
| Card | Auto-layout frame: White 6% with a White 14% hairline (Daylight Blue 60 and Blue 5 on day), a green label, a Day Sans title, a line under it | Cycle steps, screens, hierarchy branches, quadrants |
| Gradient circle | Frame with the template's Twilight to Reviewpro Blue gradient and a hairline halo | The centre of a wheel or a cycle, the top of a hierarchy |
| Lines and arrows | Vector paths, 2 px, Blue 5 at 50%; Figma's "line arrow" end; dotted spokes as round dashes | Spokes, connectors, flow paths, axes |
| Rings and arcs | Vector arcs, dashed, stopping short of the labels and chips that sit on them | Rings, the wheel's track, cycle arrows |
| Decision | A square turned 45 degrees with its label on top | User flow decisions |

## Type pairings

The three Shiji typefaces keep their jobs inside a diagram: Night Serif for the one thing that carries the feeling, Day Sans (Aeonik) for what people read, Noto Sans for what they scan. Every size is a text style of the official template.

| Part of the diagram | Typeface | Token (template text style) |
|---|---|---|
| The anchor: the centre of a wheel or a cycle | Night Serif Regular, as large as fits | `quote@52` (Serif quote 52), then `quote-s` (Quote 36), then Day Sans Bold `heading` |
| Figures: years, versions, prices, percentages on a timeline or a process | Night Serif Heavy | `stat-s@64` (Serif display 64) |
| Titles people read: steps, cards, screens, branches | Day Sans Bold | `heading` (Subheading 32), `button` (Caption 22 Bold) where space is tight |
| The line under a title | Day Sans Regular | `small` (Caption 22) |
| The top of a hierarchy | Day Sans Bold, its role under it in Day Sans Regular | `heading`, `small` |
| Labels people scan: chips, ring names, dates, numbers in circles, axis names, path labels | Noto Sans, uppercase | `label` (Metadata 18), `kicker` (Kicker 22) for quadrant titles |

- One serif moment per diagram: the anchor or the figures, not both. Rings, user flows, hierarchies and matrices have none unless a figure needs it.
- Night Serif Heavy only at 64 px and above; in a small circle the Regular cut reads better.
- Never serif for chips or for a line of text, never Noto Sans for a title, never a fourth typeface.

## Colour

- One highlight per diagram (`"highlight": true` on one item): a green outline or a green chip on night and blue slides, Reviewpro Blue on day.
- Product colours only as the dot in the product's chip, never as a full chip fill. `"palette": "products"` picks them from the product names; `"color"` sets one.
- No gradient rings, glows or shapes that carry no meaning. The wheel's day-night line (`"ring": "cycle"`, the template's own gradient) is there for brand moments; it is off by default.

## Contrast (never skipped)

- Every label reaches 4.5:1 on what is under it (WCAG AA), whatever its size. White text on Sunset Yellow is 1.7:1, on Sunset Orange 2.5:1, on Meridian 2.5:1: none of them is allowed. The chips and cards above pass at 6:1 or more.
- Lines, arrows and outlines that carry the structure reach 3:1 against the slide (WCAG 1.4.11).
- The engine refuses a colour that misses either: the copy check and the build stop with the label and its ratio. Pick another colour; never work around it.
- Colour is never the only signal: a highlight also has an outline, a status also has a word.

## Outside slides

```
python3 .kiro/skills/presentation-infographics/scripts/build_infographic.py decks/<slug>/deck.json --slide 4 --png "decks/<slug>/Diagram.png"
python3 .kiro/skills/presentation-infographics/scripts/build_infographic.py decks/<slug>/deck.json --slide 4 --fig "decks/<slug>/Diagram.fig"
```

The PNG is the diagram alone at twice the slide size (`--theme day` for documents on white, `--transparent` for no background): for Confluence, documents and Teams. The `.fig` is the slide as editable layers: drag it onto the Figma file browser, then copy the diagram into any Figma file.

## Checks before handing over

- [ ] The diagram matches a real structure in the content; nothing was invented to fill it.
- [ ] The copy check passes: within the limits above, no engine warning (labels too long, a chip crossing a ring, a flow too wide).
- [ ] The build prints no "does not fit its shape" warning.
- [ ] One highlight, one serif moment, product colours only as dots.
- [ ] Looked at in the preview contact sheet: labels fit their chips, nothing overlaps, arrows point the right way.
