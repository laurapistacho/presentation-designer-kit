#!/usr/bin/env python3
"""One infographic on its own: a PNG for documents, Confluence and Teams, and a one-slide Figma Slides file.

    python3 .kiro/skills/presentation-infographics/scripts/build_infographic.py spec.json --png out.png
    python3 .kiro/skills/presentation-infographics/scripts/build_infographic.py spec.json --fig out.fig
    python3 .kiro/skills/presentation-infographics/scripts/build_infographic.py deck.json --slide 4 --png out.png --theme day

`spec.json` is one slide (a dict with "layout": "wheel", ...) or a whole deck.json (then --slide picks the
slide, by default the first infographic). The PNG is the diagram alone, at twice the slide size, on the
theme's background (--transparent for none). The .fig is the whole slide as editable Figma layers: drag
it onto the Figma file browser, then copy the diagram into any Figma file.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import infographics as ig  # noqa: E402
import render_html  # noqa: E402

BUILDER = os.path.join(ig.KIT, '.kiro', 'skills', 'figma-slides-builder', 'scripts')
sys.path.insert(0, BUILDER)


def pick(spec, number=None):
    if 'slides' not in spec:
        return spec
    slides = spec['slides']
    if number:
        return slides[number - 1]
    for sp in slides:
        if sp.get('layout') in ig.TYPES:
            return sp
    sys.exit('No infographic slide in this deck (wheel, rings, cycle, process, userflow, timeline, hierarchy, matrix).')


def png(sp, out, theme, transparent=False, pad=48):
    import infographic_layers
    sc = ig.scene(sp, infographic_layers.diagram_box(sp), theme)
    x, y, w, h = sc.bounds()
    W, H = int(w + 2 * pad), int(h + 2 * pad)
    bg = 'transparent' if transparent else render_html.BACKGROUND[theme]
    body = (f'<div style="position:relative;width:{W}px;height:{H}px;overflow:hidden;background:{bg}">'
            f'<div style="position:absolute;left:{pad - x:.2f}px;top:{pad - y:.2f}px;width:1920px;height:1080px">'
            f'{render_html.scene_html(sc)}</div></div>')
    page = render_html.page([body]).replace('body{background:#1e1e1e}', 'body{background:transparent}')
    tmp = tempfile.mkdtemp(prefix='infographic-')
    try:
        path = os.path.join(tmp, 'diagram.html')
        open(path, 'w', encoding='utf-8').write(page)
        chrome = os.environ.get('CHROME') or '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
        shot = os.path.join(tmp, 'diagram.png')
        args = [chrome, '--headless=new', '--disable-gpu', '--hide-scrollbars', '--force-device-scale-factor=2',
                '--virtual-time-budget=8000', f'--window-size={W},{H}', f'--screenshot={shot}', 'file://' + path]
        if transparent:
            args.insert(4, '--default-background-color=00000000')
        subprocess.run(args, capture_output=True, timeout=180)
        if not os.path.exists(shot):
            sys.exit('Chrome did not write the picture. Is Google Chrome installed? (setup/check_setup.py checks it)')
        shutil.copy(shot, out)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return {'png': os.path.abspath(out), 'size': [W * 2, H * 2], 'warnings': sc.warnings}


def fig(sp, out, theme):
    import build_deck
    tmp = tempfile.mkdtemp(prefix='infographic-')
    try:
        one = dict(sp, theme=theme)
        path = os.path.join(tmp, 'deck.json')
        json.dump({'title': sp.get('title') or 'Infographic', 'slides': [one]}, open(path, 'w', encoding='utf-8'))
        b = build_deck.build(path, out)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return {'fig': os.path.abspath(out), 'warnings': b.warnings}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('spec')
    ap.add_argument('--slide', type=int, help='the slide of a deck.json (1 = the first)')
    ap.add_argument('--png')
    ap.add_argument('--fig')
    ap.add_argument('--theme', choices=('night', 'day', 'blue'))
    ap.add_argument('--transparent', action='store_true', help='PNG without the slide background')
    a = ap.parse_args()
    if not a.png and not a.fig:
        ap.error('give --png, --fig or both')
    sp = pick(json.load(open(a.spec, encoding='utf-8')), a.slide)
    theme = a.theme or sp.get('theme') or 'night'
    result = {'layout': sp.get('layout')}
    try:
        if a.png:
            result.update(png(sp, a.png, theme, a.transparent))
        if a.fig:
            result.update(fig(sp, a.fig, theme))
    except ig.InfographicError as e:
        sys.exit(str(e))
    print(json.dumps(result, indent=1, ensure_ascii=False))


if __name__ == '__main__':
    main()
