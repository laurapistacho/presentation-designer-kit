#!/usr/bin/env python3
"""Infographics for the Presentation Designer kit: the layout engine of the presentation-infographics skill.

    import infographics
    scene = infographics.scene(spec, box=(x, y, w, h), theme='night')

`spec` is one slide of deck.json with an infographic layout: wheel, rings, cycle, process, userflow,
timeline, hierarchy or matrix. The engine places the diagram inside `box` (slide pixels) as plain
shapes: circles, arcs, lines, cards, chips and text. Renderers draw the scene: the builder as editable
Figma layers, render_html.py as an HTML or PNG picture.

The look is the official template's own parts: its chips (Noto Sans labels in small pills), its cards
(a translucent surface with a hairline border, as on the quote cards), its gradient circle (Twilight
to Reviewpro Blue) and thin lines. Colour is used sparingly: one highlight, product colours as a dot.

Colours are brand token names (presentation-brand/assets/tokens.json) or (name, opacity). Text takes
the colour its chip or card defines and must reach 4.5:1 (WCAG AA) on what is under it; lines, arrows
and outlines must reach 3:1 against the slide (WCAG 1.4.11). The engine refuses colours that miss.
Python 3.9+, standard library only.
"""
import json
import math
import os

HERE = os.path.dirname(os.path.abspath(__file__))
KIT = os.environ.get('PRESENTATION_KIT') or os.path.abspath(os.path.join(HERE, '..', '..', '..', '..'))  # <kit>/.kiro/skills/presentation-infographics/scripts
TOKENS = json.load(open(os.path.join(KIT, '.kiro', 'skills', 'presentation-brand', 'assets', 'tokens.json'), encoding='utf-8'))

MIN_TEXT = 4.5      # WCAG AA, normal text: every label, whatever its size
MIN_GRAPHIC = 3.0   # WCAG 1.4.11: lines, arrows and outlines that carry the structure
LINE = 2.0          # every connector, ring and axis
CHIP_PAD = (11.0, 20.0)
DOT, DOT_GAP = 10.0, 10.0

# The Shiji day-night cycle, as the official template's swatch "DAY-NIGHT CYCLE" holds it (angular,
# position 0 at 9 o'clock, clockwise): Reviewpro Blue rising to daylight, sunset, night, sunrise.
CYCLE = [(0.099, '#0030FF'), (0.15, '#194FFB'), (0.207, '#3673F7'), (0.319, '#D5ECFF'), (0.407, '#FFB851'),
         (0.494, '#FF8056'), (0.622, '#7443A7'), (0.705, '#172554'), (0.847, '#172554'), (0.989, '#8A2B82')]
CYCLE_START = 270.0

# Shiji products and their brand colours (presentation-brand: product colours), by the first word.
PRODUCTS = {'daylight': 'sunrise-red', 'reviewpro': 'reviewpro', 'meridian': 'meridian', 'iceportal': 'sunset-yellow',
            'horizon': 'sunset-orange', 'infrasys': 'sunset-purple', 'twilight': 'twilight', 'astral': 'night',
            'stellaris': 'night', 'shiji': 'green'}

STYLES = {
    'night': dict(bg='midnight', title='white', text='moonlight', muted='blue-5', accent='green',
                  surface=('white', 0.06), border=('white', 0.14), chip=('white', 0.12), chip_text='white',
                  line=('blue-5', 0.5), dots=('blue-5', 0.6), outline=('white', 0.42), disc=('white', 0.025),
                  track=('white', 0.1), hub={'type': 'linear', 'angle': 160, 'stops': [['twilight', 1, 0], ['reviewpro', 1, 1]]},
                  light='blue-5', light_text='midnight', new='green', new_text='midnight', dark='midnight'),
    'day': dict(bg='white', title='midnight', text='midnight', muted=('midnight', 0.72), accent='reviewpro',
                surface='daylight-60', border='blue-5', chip='daylight', chip_text='midnight',
                line=('midnight', 0.5), dots=('midnight', 0.55), outline=('midnight', 0.55), disc=('reviewpro', 0.03),
                track=('midnight', 0.1), hub={'type': 'linear', 'angle': 160, 'stops': [['reviewpro', 1, 0], ['twilight', 1, 1]]},
                light='blue-5', light_text='midnight', new='reviewpro', new_text='white', dark='midnight'),
    'blue': dict(bg='reviewpro', title='white', text='white', muted='blue-5', accent='green',
                 surface=('white', 0.1), border=('white', 0.22), chip=('white', 0.16), chip_text='white',
                 line=('white', 0.6), dots=('white', 0.7), outline=('white', 0.6), disc=('white', 0.04),
                 track=('white', 0.14), hub={'type': 'linear', 'angle': 160, 'stops': [['twilight', 1, 0], ['midnight', 1, 1]]},
                 light='blue-5', light_text='midnight', new='green', new_text='midnight', dark='midnight'),
}

LIMITS = {  # what fits; the copy check and the build hold specs to these
    'wheel': {'items': (3, 10), 'item_chars': 26, 'center_chars': 24},
    'rings': {'rings': (2, 4), 'items_per_ring': (0, 4), 'item_chars': 24, 'label_chars': 24},
    'cycle': {'steps': (3, 8), 'title_chars': 22},
    'process': {'steps': (2, 6), 'title_chars': 28, 'text_words': 16},
    'userflow': {'nodes': (2, 12), 'text_chars': 30, 'label_chars': 12},
    'timeline': {'events': (2, 8), 'title_chars': 28, 'text_words': 14},
    'hierarchy': {'children': (1, 6), 'grandchildren': (0, 5), 'text_chars': 28},
    'matrix': {'quadrants': (4, 4), 'items_per_quadrant': (0, 4), 'item_chars': 24},
}


class InfographicError(ValueError):
    pass


# --------------------------------------------------------------------------- colour
def paint(c):
    """A colour spec ('name', '#hex' or (name, opacity)) -> (name or hex, opacity)."""
    if isinstance(c, (list, tuple)):
        return c[0], float(c[1])
    return c, 1.0


def hexval(c):
    c = paint(c)[0]
    if c.startswith('#'):
        return c.upper()
    return TOKENS['colors'][c]['hex'].upper()


def rgb(c):
    h = hexval(c)
    return tuple(int(h[i:i + 2], 16) / 255.0 for i in (1, 3, 5))


def to_hex(t):
    return '#%02X%02X%02X' % tuple(max(0, min(255, int(round(v * 255)))) for v in t)


def over(c, bg):
    """The colour you see: spec c (with its opacity) over the solid colour bg."""
    name, a = paint(c)
    f, b = rgb(name), rgb(bg)
    return to_hex(tuple(a * x + (1 - a) * y for x, y in zip(f, b)))


def luminance(c):
    def lin(v):
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(v) for v in rgb(c))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = sorted((luminance(a), luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def cycle_color(angle):
    """The day-night cycle colour at `angle` (degrees clockwise from 12 o'clock)."""
    p = ((angle - CYCLE_START) % 360.0) / 360.0
    stops = [(CYCLE[-1][0] - 1.0, CYCLE[-1][1])] + CYCLE + [(CYCLE[0][0] + 1.0, CYCLE[0][1])]
    for (p0, c0), (p1, c1) in zip(stops, stops[1:]):
        if p0 <= p <= p1:
            k = 0.0 if p1 == p0 else (p - p0) / (p1 - p0)
            return to_hex(tuple(x + (y - x) * k for x, y in zip(rgb(c0), rgb(c1))))
    return CYCLE[0][1]


# --------------------------------------------------------------------------- type
def type_of(kind):
    """Size, line height, uppercase and tracking of a type token, or of 'token@size' (a template text style size)."""
    base, _, at_size = kind.partition('@')
    t = TOKENS['type'][base]
    size = float(at_size) if at_size else float(t['size'])
    if 'line_px' in t and not at_size:
        line = float(t['line_px'])
    else:
        line = round(size * float(t.get('line', 1.3)))
    return size, line, t.get('case') == 'upper', float(t.get('tracking', 0))


NOTO_UPPER = dict(zip('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 &+-./,?:·',
                      [639, 652, 632, 729, 556, 516, 727, 752, 312, 258, 621, 524, 925, 772, 779, 603, 779, 618, 549,
                       553, 728, 592, 940, 580, 556, 572] + [572] * 10 + [260, 705, 572, 322, 268, 372, 268, 434, 268, 268]))


def est_width(text, kind):
    """The width of one line of text, for sizing chips and gaps. Figma measures the real thing."""
    size, _, upper, tracking = type_of(kind)
    font = TOKENS['type'][kind.partition('@')[0]]['font']
    text = text or ''
    if upper and 'label' in font:
        weight = 1.06 if 'bold' in font else (1.03 if 'medium' in font else 1.0)
        em = sum(NOTO_UPPER.get(ch, 700) for ch in text.upper()) / 1000.0 * weight
        return size * (em + len(text) * tracking / 100.0) + 2
    if 'serif' in font:
        factor = 0.6 if 'heavy' in font else 0.5
    else:
        factor = 0.56 if 'bold' in font or 'black' in font else 0.52
    return len(text) * size * (factor + tracking / 100.0)


def est_lines(text, kind, width):
    words, lines, cur = (text or '').split(), 1, ''
    for w in words:
        test = (cur + ' ' + w).strip()
        if cur and est_width(test, kind) > width:
            lines, cur = lines + 1, w
        else:
            cur = test
    return lines


FIGURE = __import__('re').compile(r'^[\d][\d.,:%+/–-]*[%+kKmM]?$|^Q[1-4]( \d{4})?$')


def is_figure(text):
    """A year, a version, a price or a percentage: shown in the serif figure style."""
    return bool(FIGURE.match((text or '').strip()))


def anchor_type(text, width):
    """The type of a diagram's anchor (the text in its centre): Night Serif Regular, as large as fits, then Day Sans Bold."""
    words = (text or '').split()
    for kind in ('quote@52', 'quote-s'):
        if words and max(est_width(w, kind) for w in words) <= width and est_lines(text, kind, width) <= (2 if kind == 'quote@52' else 3):
            return kind
    return 'heading'


# --------------------------------------------------------------------------- geometry
def at(cx, cy, r, a):
    """The point at angle a (degrees clockwise from 12 o'clock) on the circle cx, cy, r."""
    t = math.radians(a)
    return cx + r * math.sin(t), cy - r * math.cos(t)


def inside_box(px, py, b, pad=0.0):
    x, y, w, h = b
    return x - pad <= px <= x + w + pad and y - pad <= py <= y + h + pad


def edge_toward(b, tx, ty, shape='rect'):
    """Where the line from the centre of box b toward (tx, ty) leaves the box."""
    x, y, w, h = b
    cx, cy = x + w / 2, y + h / 2
    dx, dy = tx - cx, ty - cy
    if dx == 0 and dy == 0:
        return cx, cy
    if shape == 'diamond':
        k = 1.0 / (abs(dx) / (w / 2) + abs(dy) / (h / 2))
    elif shape == 'circle':
        k = (w / 2) / math.hypot(dx, dy)
    else:
        k = min((w / 2) / abs(dx) if dx else 1e9, (h / 2) / abs(dy) if dy else 1e9)
    return cx + dx * k, cy + dy * k


def radial(w, h, a):
    """How far a w x h box centred on a circle reaches inward or outward at angle a."""
    t = math.radians(a)
    return (w / 2) * abs(math.sin(t)) + (h / 2) * abs(math.cos(t))


def near_far(r, a, w, h, rr=None):
    """The nearest and farthest points from the centre of a w x h chip (corner radius rr: a pill when it is
    half the height) centred on a circle of radius r at angle a."""
    rr = min(h / 2, 22.0) if rr is None else rr
    x, y = abs(r * math.sin(math.radians(a))), abs(r * math.cos(math.radians(a)))
    iw, ih = w / 2 - rr, h / 2 - rr
    near = max(0.0, math.hypot(max(x - iw, 0.0), max(y - ih, 0.0)) - rr)
    return near, math.hypot(x + iw, y + ih) + rr


def along(w, h, a):
    """How much of the circle a w x h box centred on it covers at angle a."""
    t = math.radians(a)
    return w * abs(math.cos(t)) + h * abs(math.sin(t))


def angular_layout(sizes, gap, uniform=False):
    """Angles (degrees, the first at 12 o'clock) and a radius giving each box of `sizes` room around
    a circle: boxes side by side near the top and bottom need more arc than boxes stacked at the sides."""
    n = len(sizes)
    angles = [360.0 * i / n for i in range(n)]
    if not uniform:
        for _ in range(8):
            need = [along(w, h, a) + gap for (w, h), a in zip(sizes, angles)]
            total, cur, out = sum(need), 0.0, []
            for i, nd in enumerate(need):
                if i:
                    cur += nd / 2
                out.append(360.0 * cur / total)
                cur += nd / 2
            angles = out
    need = [along(w, h, a) + gap for (w, h), a in zip(sizes, angles)]
    radius = sum(need) / (2 * math.pi)
    if uniform:  # every neighbour pair must clear in x or in y
        radius = 0.0
        for i in range(n):
            (w0, h0), (w1, h1) = sizes[i], sizes[(i + 1) % n]
            a, b = math.radians(angles[i]), math.radians(angles[(i + 1) % n])
            dxs, dys = abs(math.sin(a) - math.sin(b)), abs(math.cos(a) - math.cos(b))
            opts = [v for v in (((w0 + w1) / 2 + gap) / dxs if dxs > 1e-6 else None,
                                ((h0 + h1) / 2 + gap) / dys if dys > 1e-6 else None) if v]
            radius = max(radius, min(opts))
    return angles, radius


# --------------------------------------------------------------------------- scene
class Scene:
    """The shapes of one diagram, in slide pixels, back to front."""

    def __init__(self, kind, box, theme):
        self.kind, self.area = kind, box
        self.theme = theme if theme in STYLES else 'night'
        self.st = STYLES[self.theme]
        self.bg = hexval(self.st['bg'])
        self.items, self.warnings = [], []
        self.group = None

    def _add(self, item):
        if self.group:
            item['group'] = self.group
        self.items.append(item)
        return item

    def role(self, c):
        return self.st.get(c, c) if isinstance(c, str) else c

    def check_graphic(self, c, what):
        r = contrast(over(c, self.bg), self.bg)
        if r < MIN_GRAPHIC:
            raise InfographicError(f'{what}: {hexval(c)} on the slide is {r:.1f}:1, below {MIN_GRAPHIC}:1. Pick a stronger colour.')

    def text_on(self, under, color, label):
        """Contrast of text `color` on `under` (a colour spec or a gradient): refuse below 4.5:1."""
        if isinstance(under, dict):
            backs = [hexval(s[0]) for s in under['stops']]
        else:
            backs = [over(under, self.bg) if under else self.bg]
        seen = [over(color, b) for b in backs]
        r = min(contrast(s, b) for s, b in zip(seen, backs))
        if r < MIN_TEXT:
            raise InfographicError(f'"{label}": {r:.1f}:1 on {backs[0]}, below {MIN_TEXT}:1. '
                                   'Pick another colour for the shape or the text.')
        return r

    # -- primitives
    def circle(self, cx, cy, r, fill=None, stroke=None, sw=0.0, dash=None, name='Circle', check=True, gradient=None):
        fill, stroke = self.role(fill), self.role(stroke)
        if stroke and check:
            self.check_graphic(stroke, name)
        return self._add(dict(kind='circle', cx=cx, cy=cy, r=r, fill=fill, stroke=stroke, sw=sw, dash=dash, name=name,
                              gradient=gradient))

    def arc(self, cx, cy, r, a0, a1, sw, stroke=None, gradient=None, cap='round', dash=None, arrow=None, name='Arc'):
        stroke = self.role(stroke)
        if stroke and not gradient:
            self.check_graphic(stroke, name)
        return self._add(dict(kind='arc', cx=cx, cy=cy, r=r, a0=a0, a1=a1, sw=sw, stroke=stroke, gradient=gradient,
                              cap=cap, dash=dash, arrow=arrow, name=name))

    def line(self, pts, stroke='line', sw=LINE, dash=None, cap='round', arrow=None, name='Line', check=True):
        stroke = self.role(stroke)
        if check:
            self.check_graphic(stroke, name)
        return self._add(dict(kind='line', pts=[(float(x), float(y)) for x, y in pts], stroke=stroke, sw=sw, dash=dash,
                              cap=cap, arrow=arrow, name=name))

    def box(self, x, y, w, h, text='', fill=None, stroke=None, sw=0.0, radius=0.0, dash=None, shape='rect',
            kind='button', color='title', align='CENTER', sub=None, sub_kind='small', sub_color='muted', name='Box',
            pad=(14.0, 20.0), top=None, top_kind='label', top_color='accent', gradient=None, dot=None, dot_ring=None,
            chip=False):
        """A shape with text: an optional small line above (top), the text, an optional line below (sub)."""
        fill, stroke = self.role(fill), self.role(stroke)
        if stroke and not fill and not gradient:
            self.check_graphic(stroke, name)
        under = gradient or fill
        item = dict(kind='box', x=x, y=y, w=w, h=h, text=text, fill=fill, stroke=stroke, sw=sw, radius=radius,
                    dash=dash, shape=shape, type=kind, align=align, name=name, pad=pad, gradient=gradient, chip=chip)
        ratios = []
        for key, value, k_, c_ in (('', text, kind, color), ('sub_', sub, sub_kind, sub_color), ('top_', top, top_kind, top_color)):
            if not value:
                continue
            c_ = self.role(c_)
            ratios.append(self.text_on(under, c_, value))
            item[key[:-1] if key else 'text'] = value
            item[key + 'type'] = k_
            item[key + 'color'] = c_
        item['ratio'] = round(min(ratios), 1) if ratios else None
        if dot:
            item['dot'] = self.role(dot)
            item['dot_ring'] = self.role(dot_ring) if dot_ring else None
        return self._add(item)

    def text(self, x, y, w, text, kind='body', color='text', align='LEFT', h=None, valign='TOP', name='Text', rotate=0.0):
        c = self.role(color)
        r = contrast(over(c, self.bg), self.bg)
        if r < MIN_TEXT:
            raise InfographicError(f'"{text}": {r:.1f}:1 against the slide, below {MIN_TEXT}:1.')
        return self._add(dict(kind='text', x=x, y=y, w=w, h=h, text=text, type=kind, color=c, align=align,
                              valign=valign, name=name, rotate=rotate, ratio=round(r, 1)))

    # -- the template's parts
    def chip_size(self, text, dot=False, max_w=236.0):
        """Width, height and line count of a template chip (Noto Sans label in a pill) for `text`."""
        size, line, _, _ = type_of('label')
        pv, ph = CHIP_PAD
        extra = DOT + DOT_GAP if dot else 0.0
        one = est_width(text, 'label') + 2 * ph + extra + 6
        if one <= max_w or ' ' not in text.strip():
            return one, line + 2 * pv, 1
        words = text.split()
        best = min((max(est_width(' '.join(words[:i]), 'label'), est_width(' '.join(words[i:]), 'label')), i)
                   for i in range(1, len(words)))
        return best[0] + 2 * ph + extra + 8, 2 * line + 2 * pv, 2

    def chip(self, x, y, text, variant='default', dot=None, max_w=236.0, name=None, size=None):
        """A chip of the official template: default, new, light, dark or current (outline)."""
        w, h, lines = size or self.chip_size(text, bool(dot), max_w)
        st = self.st
        fill, color, stroke = {
            'default': (st['chip'], st['chip_text'], None),
            'new': (st['new'], st['new_text'], None),
            'light': (st['light'], st['light_text'], None),
            'dark': (st['dark'], 'white', st['border']),
            'current': (None, st['title'], st['outline']),
        }[variant]
        ring = None
        if dot:
            under = over(fill, self.bg) if fill else self.bg
            ring = st['outline'] if contrast(hexval(dot), under) < 2.0 else None
        return self.box(x, y, w, h, text=text, fill=fill, stroke=stroke, sw=1.5, radius=h / 2 if lines == 1 else 22.0,
                        kind='label', color=color, name=name or text, pad=CHIP_PAD, dot=dot, dot_ring=ring, chip=True)

    def card(self, x, y, w, h, text, top=None, sub=None, highlight=False, kind='button', align='CENTER', radius=20.0,
             name=None, pad=(14.0, 22.0)):
        """A card as on the template's quote cards: translucent surface, hairline border."""
        st = self.st
        return self.box(x, y, w, h, text=text, fill=st['surface'], stroke=st['accent'] if highlight else st['border'],
                        sw=2.0 if highlight else 1.5, radius=radius, kind=kind, color='title', align=align, top=top,
                        top_kind='label', top_color='accent', sub=sub, sub_kind='small', sub_color='muted',
                        name=name or text, pad=pad)

    def hub(self, cx, cy, r, text, kind=None):
        """The template's gradient circle (Twilight to Reviewpro Blue) with a hairline halo."""
        st = self.st
        self.circle(cx, cy, r + 16, stroke=st['track'], sw=1.5, name='Halo', check=False)
        kind = kind or anchor_type(text, 2 * r - 48)
        return self.box(cx - r, cy - r, 2 * r, 2 * r, text=text, gradient=st['hub'], shape='circle', radius=r,
                        kind=kind, color='white', name='Centre', pad=(24.0, 24.0))

    def bounds(self):
        xs, ys = [], []
        for it in self.items:
            k = it['kind']
            if k in ('circle', 'arc'):
                r = it['r'] + it.get('sw', 0) / 2
                xs += [it['cx'] - r, it['cx'] + r]
                ys += [it['cy'] - r, it['cy'] + r]
            elif k == 'line':
                xs += [p[0] for p in it['pts']]
                ys += [p[1] for p in it['pts']]
            else:
                xs += [it['x'], it['x'] + it['w']]
                ys += [it['y'], it['y'] + (it.get('h') or type_of(it['type'])[1])]
        return (min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)) if xs else self.area


# --------------------------------------------------------------------------- spec helpers
def norm_items(values):
    return [dict(v) if isinstance(v, dict) else {'text': str(v)} for v in values or []]


def item_dot(it, palette=None):
    if it.get('color'):
        return it['color']
    if palette == 'products':
        return PRODUCTS.get((it.get('text') or '').strip().split(' ')[0].lower())
    return None


def ring_arcs(sc, cx, cy, r, gaps, stroke, dash, name, check=True):
    """A circle drawn as arcs that stop short of each gap (centre angle, half-width in degrees)."""
    cut = []
    for a, half in gaps:
        a0, a1 = (a - half) % 360, (a + half) % 360
        if a0 < a1:
            cut.append((a0, a1))
        else:
            cut += [(a0, 360.0), (0.0, a1)]
    cut.sort()
    merged = []
    for a0, a1 in cut:
        if merged and a0 <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], a1))
        else:
            merged.append((a0, a1))
    if not merged:
        return [sc.circle(cx, cy, r, stroke=stroke, sw=LINE, dash=dash, name=name, check=check)]
    free, start = [], merged[-1][1] - 360.0
    for a0, a1 in merged:
        if a0 - start > 2:
            free.append((start, a0))
        start = a1
    out = []
    for a0, a1 in free:
        if check:
            sc.check_graphic(stroke, name)
        out.append(sc._add(dict(kind='arc', cx=cx, cy=cy, r=r, a0=a0, a1=a1, sw=LINE, stroke=sc.role(stroke), gradient=None,
                                cap='butt', dash=dash, arrow=None, name=name)))
    return out


# --------------------------------------------------------------------------- layouts
def wheel(sp, sc):
    """One thing in the centre, 3 to 10 items around it on a faint track, joined by dotted spokes."""
    bx, by, bw, bh = sc.area
    st = sc.st
    items = norm_items(sp.get('items'))
    n = len(items)
    lo, hi = LIMITS['wheel']['items']
    if not lo <= n <= hi:
        raise InfographicError(f'A wheel holds {lo} to {hi} items; this one has {n}.')
    cx, cy = bx + bw / 2, by + bh / 2
    dots = [item_dot(it, sp.get('palette')) for it in items]
    sizes = [sc.chip_size(it['text'], bool(d), 230.0) for it, d in zip(items, dots)]
    angles, ri = angular_layout([(w, h) for w, h, _ in sizes], 30.0)
    rh = 124.0
    reach = [radial(w, h, a) for (w, h, _), a in zip(sizes, angles)]
    ri = max(ri, rh + 16 + max(reach) + 44)
    outer = ri + max(reach)
    ring, orbit = sp.get('ring'), sp.get('orbit')
    rr = outer + 34
    if ring:
        outer = rr + 2
    ro = outer + 40
    if orbit:
        outer = ro + 22
    k = min(1.0, (min(bw, bh) / 2 - 2) / outer)
    if k < 0.94:
        sc.warnings.append('The wheel is tight: shorten the labels, drop the ring or the orbit, or use fewer items.')
    ri, rr, ro = ri * k, rr * k, ro * k
    if orbit:
        sc.group = 'Orbit'
        sc.circle(cx, cy, ro, stroke=st['line'], sw=1.5, dash=[3, 7], name='Orbit')
        for a, label in ((0, 'Day'), (180, 'Night')):
            px, py = at(cx, cy, ro, a)
            w, h, _ = sc.chip_size(label)
            sc.chip(px - w / 2, py - h / 2, label, 'dark', name=f'Orbit · {label}')
    if ring:
        sc.group = 'Day-night line'
        sc.arc(cx, cy, rr, 0, 359.9, 3.0, gradient='cycle', cap='butt', name='Day-night line')
    boxes = []
    for (w, h, _), a in zip(sizes, angles):
        px, py = at(cx, cy, ri, a)
        boxes.append((px - w / 2, py - h / 2, w, h))
    sc.group = 'Track'
    gaps = [(a, math.degrees((along(w, h, a) / 2 + 12) / ri)) for (w, h, _), a in zip(sizes, angles)]
    for arc_ in ring_arcs(sc, cx, cy, ri, gaps, st['track'], None, 'Track', check=False):
        arc_['sw'] = 1.5
    sc.group = 'Spokes'
    for b in boxes:
        bcx, bcy = b[0] + b[2] / 2, b[1] + b[3] / 2
        ang = math.degrees(math.atan2(bcx - cx, cy - bcy))
        end = edge_toward(b, cx, cy)
        dist = math.hypot(end[0] - cx, end[1] - cy) - 12
        if dist > rh + 40:
            sc.line([at(cx, cy, rh + 26, ang), at(cx, cy, dist, ang)], st['dots'], sw=3.0, dash=[0.01, 9],
                    cap='round', name='Spoke')
    sc.group = 'Items'
    for it, b, d in zip(items, boxes, dots):
        sc.chip(b[0], b[1], it['text'], 'new' if it.get('highlight') else 'default', dot=d,
                size=(b[2], b[3], 2 if b[3] > 60 else 1))
    sc.group = 'Centre'
    sc.hub(cx, cy, rh, sp.get('center', ''))
    sc.group = None
    return sc


def rings(sp, sc):
    """Nested scopes or layers, inner to outer: the inner ring's items stack in the middle, the others sit on their ring."""
    bx, by, bw, bh = sc.area
    st = sc.st
    rs = sp.get('rings') or []
    lo, hi = LIMITS['rings']['rings']
    if not lo <= len(rs) <= hi:
        raise InfographicError(f'Rings take {lo} to {hi} rings; this one has {len(rs)}.')
    n = len(rs)
    cx, cy = bx + bw / 2, by + bh / 2 + 10
    # the inner ring's chips, stacked
    inner = norm_items(rs[0].get('items'))
    isz = [sc.chip_size(it['text'], bool(item_dot(it)), 320.0) for it in inner]
    if isz:  # one width for the whole stack
        sw_ = max(w for w, _, _ in isz)
        isz = [(sw_, h, lines) for _, h, lines in isz]
    gap = 12.0
    stack_h = sum(h for _, h, _ in isz) + gap * max(0, len(isz) - 1)
    stack_w = max([w for w, _, _ in isz] or [0])
    r1 = max(130.0, math.hypot(stack_w / 2, stack_h / 2) + 30)
    # the other rings' chips and their angles
    placed, radii = [], [r1]
    for i, r_ in enumerate(rs[1:], 2):
        its = norm_items(r_.get('items'))
        m = len(its)
        start, span = 44.0, 272.0
        offset = (span / max(1, m)) * (0.25 if i % 2 else -0.25) if m > 1 else 0.0
        angs = [start + span * (j + 0.5) / max(1, m) + offset for j in range(m)]
        szs = [sc.chip_size(it['text'], bool(item_dot(it)), 214.0) for it in its]
        reach = max([radial(w, h, a) for (w, h, _), a in zip(szs, angs)] or [0.0])
        # chips sit on their own ring and must clear the rings either side of it, corner to line
        prev = placed[-1] if placed else None
        r = radii[-1] + 72
        while True:
            near = min([near_far(r, a, w, h)[0] for (w, h, _), a in zip(szs, angs)] or [r])
            far_prev = max([near_far(radii[-1], a, w, h)[1] for (w, h, _), a in zip(prev[2], prev[1])] or [0.0]) if prev else 0.0
            if near >= radii[-1] + 14 and far_prev <= r - 14:
                break
            r += 2.0
        radii.append(r)
        placed.append((its, angs, szs, reach))
    out_reach = placed[-1][3] if placed else 0.0
    side = max([w for _, _, szs, _ in placed[-1:] for w, _, _ in szs] or [0.0]) / 2
    avail = min(bh / 2 - 14, bw / 2 - 6 - max(side, out_reach))
    if radii[-1] > avail and n > 1:  # keep the centre stack inside its ring: tighten only the spacing outside it
        k = (avail - r1) / (radii[-1] - r1)
        radii = [r1 + (r - r1) * k for r in radii]
    for i, (its, angs, szs, reach) in enumerate(placed, 1):  # a chip may sit on its ring, never across the next one
        nf = [near_far(radii[i], a, w, h) for (w, h, _), a in zip(szs, angs)]
        inner_ok = not nf or min(x[0] for x in nf) > radii[i - 1]
        outer_ok = i + 1 >= len(radii) or not nf or max(x[1] for x in nf) < radii[i + 1]
        if not (inner_ok and outer_ok):
            sc.warnings.append(f'Ring {i + 1}: a chip crosses the next ring. Shorten its labels or move an item to another ring.')
    colours = [st['accent']] + [st['line']] * (n - 1)
    # translucent discs, outer first: the middle reads lighter
    sc.group = 'Discs'
    for rad in reversed(radii):
        sc.circle(cx, cy, rad, fill=st['disc'], name='Disc', check=False)
    size_l, line_l, _, _ = type_of('label')
    for i, (r_, rad) in enumerate(zip(rs, radii)):
        sc.group = f'Ring {i + 1} · {r_.get("label", "")}'
        gaps = []
        label = r_.get('label')
        if label:
            lw = est_width(label, 'label') + 28
            gaps.append((0.0, math.degrees(lw / 2 / rad)))
        if i:
            its, angs, szs, _ = placed[i - 1]
            for (w, h, _), a in zip(szs, angs):
                gaps.append((a, math.degrees((along(w, h, a) / 2 + 10) / rad)))
        ring_arcs(sc, cx, cy, rad, gaps, colours[i], [5, 7], 'Ring')
        if label:
            sc.text(cx - lw / 2, cy - rad - line_l / 2, lw, label, kind='label',
                    color='accent' if i == 0 else 'muted', align='CENTER', name='Ring label')
    if inner:
        sc.group = 'Ring 1 · items'
        y = cy - stack_h / 2
        for it, (w, h, lines) in zip(inner, isz):
            sc.chip(cx - w / 2, y, it['text'], 'new' if it.get('highlight') else 'light', dot=item_dot(it),
                    size=(w, h, lines))
            y += h + gap
    for i, ((its, angs, szs, _), rad) in enumerate(zip(placed, radii[1:]), 2):
        sc.group = f'Ring {i} · items'
        for it, a, (w, h, lines) in zip(its, angs, szs):
            px, py = at(cx, cy, rad, a)
            variant = 'current' if it.get('dashed') or it.get('outline') else ('new' if it.get('highlight') else 'default')
            sc.chip(px - w / 2, py - h / 2, it['text'], variant, dot=item_dot(it), size=(w, h, lines))
    sc.group = None
    return sc


def cycle(sp, sc):
    """3 to 8 steps that repeat, clockwise, around an optional gradient circle."""
    bx, by, bw, bh = sc.area
    st = sc.st
    steps = norm_items(sp.get('steps'))
    n = len(steps)
    lo, hi = LIMITS['cycle']['steps']
    if not lo <= n <= hi:
        raise InfographicError(f'A cycle takes {lo} to {hi} steps; this one has {n}.')
    D = min(bw, bh)
    cx, cy = bx + bw / 2, by + bh / 2
    w, h = 224.0, 92.0
    angles, R = angular_layout([(w, h)] * n, 60.0, uniform=True)
    R = max(R, 210.0)
    k = min(1.0, (D / 2) / (R + h / 2 + 4))
    R *= k
    boxes = [(at(cx, cy, R, a)[0] - w / 2, at(cx, cy, R, a)[1] - h / 2, w, h) for a in angles]
    sc.group = 'Arrows'
    for i in range(n):
        a0, a1 = angles[i], angles[(i + 1) % n] + (360.0 if i == n - 1 else 0.0)
        s0, e1 = a0, a1
        while inside_box(*at(cx, cy, R, s0), boxes[i], 16) and s0 < a1:
            s0 += 0.5
        while inside_box(*at(cx, cy, R, e1), boxes[(i + 1) % n], 20) and e1 > s0:
            e1 -= 0.5
        if e1 - s0 > 4:
            sc.arc(cx, cy, R, s0, e1, LINE, stroke=st['line'], cap='round', arrow='end', name=f'Arrow {i + 1}')
    if sp.get('center'):
        sc.group = 'Centre'
        rc = min(R - h / 2 - 56, 120.0)
        if rc > 70:
            sc.hub(cx, cy, rc, sp['center'])
    sc.group = 'Steps'
    for i, (it, b) in enumerate(zip(steps, boxes)):
        sc.card(*b, text=it['text'], top=f'{i + 1:02d}', highlight=it.get('highlight'), name=it['text'])
    sc.group = None
    return sc


def process(sp, sc):
    """2 to 6 steps in order, left to right: a numbered circle, a title and a line of text each."""
    bx, by, bw, bh = sc.area
    st = sc.st
    steps = norm_items(sp.get('steps'))
    n = len(steps)
    lo, hi = LIMITS['process']['steps']
    if not lo <= n <= hi:
        raise InfographicError(f'A process takes {lo} to {hi} steps; this one has {n}.')
    slot = bw / n
    d = 76.0
    tw = slot - 64
    title_kind = 'heading' if n <= 5 else 'button'
    tl = max(est_lines(it['text'], title_kind, tw) for it in steps)
    xl = max(est_lines(it.get('sub', ''), 'small', tw) if it.get('sub') else 0 for it in steps)
    block = d + 32 + tl * type_of(title_kind)[1] + (12 + xl * type_of('small')[1] if xl else 0)
    y0 = by + max(0.0, (bh - block) / 2) + d / 2
    xs = [bx + slot * (i + 0.5) for i in range(n)]
    sc.group = 'Arrows'
    for i in range(n - 1):
        sc.line([(xs[i] + d / 2 + 16, y0), (xs[i + 1] - d / 2 - 16, y0)], sw=LINE, arrow='end', name=f'Arrow {i + 1}')
    for i, (it, x) in enumerate(zip(steps, xs)):
        sc.group = f'Step {i + 1} · {it["text"]}'
        hl = it.get('highlight')
        sc.box(x - d / 2, y0 - d / 2, d, d, text=f'{i + 1:02d}', fill=st['accent'] if hl else st['surface'],
               stroke=None if hl else st['border'], sw=1.5, shape='circle', radius=d / 2, kind='kicker',
               color=st['new_text'] if hl else 'accent', name='Number', pad=(0.0, 0.0))
        sc.text(x - tw / 2, y0 + d / 2 + 32, tw, it['text'], kind=title_kind, color='title', align='CENTER', name='Title')
        if it.get('sub'):
            sc.text(x - tw / 2, y0 + d / 2 + 32 + tl * type_of(title_kind)[1] + 12, tw, it['sub'], kind='small',
                    color='muted', align='CENTER', name='Text')
    sc.group = None
    return sc


def userflow(sp, sc):
    """Screens, decisions and the paths between them, left to right; a branch starts a row below."""
    bx, by, bw, bh = sc.area
    st = sc.st
    nodes = [dict(n) for n in sp.get('nodes') or []]
    links = [dict(l) for l in sp.get('links') or []]
    lo, hi = LIMITS['userflow']['nodes']
    if not lo <= len(nodes) <= hi:
        raise InfographicError(f'A user flow takes {lo} to {hi} steps; this one has {len(nodes)}.')
    by_id = {n['id']: n for n in nodes}
    for l in links:
        if l['from'] not in by_id or l['to'] not in by_id:
            raise InfographicError(f'Link {l["from"]} -> {l["to"]}: no step with that id.')
    out = {n['id']: [] for n in nodes}
    for l in links:
        out[l['from']].append(l)
    incoming = {l['to'] for l in links}
    roots = [n['id'] for n in nodes if n.get('kind') == 'start'] or [n['id'] for n in nodes if n['id'] not in incoming]
    depth, back = {}, set()

    def walk(nid, d, path):
        if d <= depth.get(nid, -1):
            return
        depth[nid] = d
        for l in out[nid]:
            if l['to'] in path:
                back.add((l['from'], l['to']))
            else:
                walk(l['to'], d + 1, path | {l['to']})
    for r_ in roots:
        walk(r_, 0, {r_})
    for n in nodes:
        depth.setdefault(n['id'], 0)
    for n in nodes:
        kind = n.get('kind', 'screen')
        if kind in ('start', 'end'):
            w, h, lines = sc.chip_size(n['text'], False, 260.0)
            n['w'], n['h'], n['lines'] = w, h, lines
        elif kind == 'decision':
            n['w'], n['h'] = 164.0, 164.0
        else:
            n['w'], n['h'] = 224.0, 100.0
    cols = max(depth.values()) + 1
    colw = [max(n['w'] for n in nodes if depth[n['id']] == c) for c in range(cols)]
    gap = (bw - sum(colw)) / max(1, cols - 1) if cols > 1 else 0
    if cols > 1 and gap < 56:
        sc.warnings.append('The user flow is too wide for the slide: fewer steps in a row, or split it.')
    xs, x = [], bx
    for c in range(cols):
        xs.append(x)
        x += colw[c] + gap
    row, taken = {}, set()
    for n in sorted(nodes, key=lambda n: depth[n['id']]):
        nid = n['id']
        if nid not in row:
            row[nid] = max(row.values()) + 1 if row else 0
        while (depth[nid], row[nid]) in taken:
            row[nid] += 1
        taken.add((depth[nid], row[nid]))
        k = 0
        for l in out[nid]:
            if (l['from'], l['to']) in back or l['to'] in row:
                continue
            row[l['to']] = row[nid] + k
            k += 1
    used = sorted(set(row.values()))
    pitch = max(n['h'] for n in nodes) + 64
    mid = (used[0] + used[-1]) / 2.0
    for n in nodes:
        c = depth[n['id']]
        n['x'] = xs[c] + (colw[c] - n['w']) / 2
        n['y'] = by + bh / 2 + (row[n['id']] - mid) * pitch - n['h'] / 2
    lanes = 1 if back else 0
    top = min(n['y'] for n in nodes)
    bottom = max(n['y'] + n['h'] for n in nodes)
    dy = by + (bh - (bottom - top) - lanes * 64) / 2 - top
    for n in nodes:
        n['y'] += dy
    bottom += dy
    sc.group = 'Paths'
    lane = bottom + 44
    for l in links:
        a, b = by_id[l['from']], by_id[l['to']]
        ax, ay = a['x'] + a['w'], a['y'] + a['h'] / 2
        bxl, byc = b['x'], b['y'] + b['h'] / 2
        if (l['from'], l['to']) in back:
            sx, sy = a['x'] + a['w'] / 2, a['y'] + a['h']
            tx, ty = b['x'] + b['w'] / 2, b['y'] + b['h']
            pts = [(sx, sy + 2), (sx, lane), (tx, lane), (tx, ty + 6)]
            lane += 22
            lab = (sx + 12, sy + 10)
        elif a.get('kind') == 'decision' and abs(byc - ay) > 8:
            sx, sy = a['x'] + a['w'] / 2, a['y'] + (0 if byc < ay else a['h'])
            pts = [(sx, sy), (sx, byc), (bxl - 8, byc)]
            lab = (sx + 14, sy + (-30 if byc < ay else 10))
        elif abs(byc - ay) < 2:
            pts = [(ax + 2, ay), (bxl - 8, byc)]
            lab = (ax + 16, ay - 30)
        else:
            mx = (ax + bxl) / 2
            pts = [(ax + 2, ay), (mx, ay), (mx, byc), (bxl - 8, byc)]
            lab = (ax + 16, ay - 30)
        sc.line(pts, sw=LINE, arrow='end', name=f'{a["text"]} → {b["text"]}')
        if l.get('label'):
            sc.text(lab[0], lab[1], 120, l['label'], kind='label', color='accent', name='Path label')
    sc.group = 'Steps'
    for n in nodes:
        kind = n.get('kind', 'screen')
        if kind in ('start', 'end'):
            sc.chip(n['x'], n['y'], n['text'], 'new' if kind == 'start' else 'light', size=(n['w'], n['h'], n['lines']))
        elif kind == 'decision':
            sc.box(n['x'], n['y'], n['w'], n['h'], text=n['text'], fill=st['surface'], stroke=st['outline'], sw=1.5,
                   shape='diamond', kind='button', name=n['text'], pad=(34.0, 34.0))
        else:
            sc.card(n['x'], n['y'], n['w'], n['h'], n['text'], top=n.get('label') or 'Screen', highlight=n.get('highlight'),
                    radius=18.0)
    sc.group = None
    return sc


def timeline(sp, sc):
    """2 to 8 dated moments on a line, optional phases above it and a 'today' chip."""
    bx, by, bw, bh = sc.area
    st = sc.st
    ev = norm_items(sp.get('events'))
    n = len(ev)
    lo, hi = LIMITS['timeline']['events']
    if not lo <= n <= hi:
        raise InfographicError(f'A timeline takes {lo} to {hi} moments; this one has {n}.')
    phases = sp.get('phases') or []
    pad = 100.0
    xs = [bx + pad + i * (bw - 2 * pad) / max(1, n - 1) for i in range(n)] if n > 1 else [bx + bw / 2]
    spacing = (bw - 2 * pad) / max(1, n - 1)
    tw = min(320.0, spacing - 32)
    title_kind = 'heading' if n <= 5 else 'button'
    today = sp.get('today')
    above = 60 + (76 if phases else 0) + (70 if today is not None else 0)
    figures = all(is_figure(e['text']) for e in ev)
    below = 30 + (type_of('stat-s@64')[1] if figures else 2 * type_of(title_kind)[1]) + (8 + 2 * type_of('small')[1] if any(e.get('sub') for e in ev) else 0)
    y = by + max(0.0, (bh - above - below) / 2) + above
    band_y = y - 124
    sc.group = 'Line'
    sc.line([(bx, y), (bx + bw, y)], sw=LINE, arrow='end', name='Time line')
    if phases:
        sc.group = 'Phases'
        for p in phases:
            x0, x1 = xs[int(p.get('from', 0))] - 40, xs[int(p.get('to', n - 1))] + 40
            need = est_width(p.get('title', ''), 'label') + 56
            if x1 - x0 < need:
                x0, x1 = (x0 + x1) / 2 - need / 2, (x0 + x1) / 2 + need / 2
            sc.box(x0, band_y, x1 - x0, 40, text=p.get('title', ''), fill=st['surface'], stroke=st['border'], sw=1.5,
                   radius=20, kind='label', color='muted', name=p.get('title', 'Phase'), pad=(0.0, 18.0))
    if today is not None:
        sc.group = 'Today'
        t = float(today)
        i0 = int(math.floor(t))
        tx = xs[min(n - 1, i0)] + (t - i0) * spacing if i0 < n - 1 else xs[-1]
        label = sp.get('today_label', 'Today')
        w, h, _ = sc.chip_size(label)
        top = (band_y if phases else y - 70) - 30 - h
        sc.line([(tx, top + h), (tx, y - 64)], 'accent', sw=LINE, dash=[4, 6], cap='round', name='Today line')
        sc.chip(tx - w / 2, top, label, 'new', name='Today')
    for i, (it, x) in enumerate(zip(ev, xs)):
        sc.group = f'Moment {i + 1}'
        done = today is not None and i <= float(today)
        hl = it.get('highlight')
        if hl:
            sc.circle(x, y, 20, stroke=('green', 0.45) if sc.theme != 'day' else ('reviewpro', 0.45), sw=1.5, name='Halo',
                      check=False)
        d = 18.0 if hl else 14.0
        sc.circle(x, y, d / 2, fill=st['accent'] if (done or hl) else st['bg'], stroke=st['accent'], sw=2.0, name='Dot')
        sc.text(x - tw / 2, y - 50, tw, it.get('date', ''), kind='label', color='accent' if (done or hl) else 'muted',
                align='CENTER', name='Date')
        tk = 'stat-s@64' if is_figure(it['text']) else title_kind
        sc.text(x - tw / 2, y + 30, tw, it['text'], kind=tk, color='title', align='CENTER', name='Title')
        if it.get('sub'):
            tl = est_lines(it['text'], tk, tw)
            sc.text(x - tw / 2, y + 30 + tl * type_of(tk)[1] + 8, tw, it['sub'], kind='small', color='muted',
                    align='CENTER', name='Text')
    sc.group = None
    return sc


def hierarchy(sp, sc):
    """A tree from one item down: up to 6 cards under it, each with up to 5 chips of its own."""
    bx, by, bw, bh = sc.area
    st = sc.st
    root = sp.get('root') or {}
    kids = norm_items(root.get('children'))
    lo, hi = LIMITS['hierarchy']['children']
    if not lo <= len(kids) <= hi:
        raise InfographicError(f'A hierarchy takes {lo} to {hi} items under the top one; this one has {len(kids)}.')
    n = len(kids)
    gap = 32.0
    w2 = min(300.0, (bw - (n - 1) * gap) / n)
    h1, h2 = 104.0, 92.0
    chip_h = sc.chip_size('X')[1]
    rw = min(380.0, bw)
    deepest = max(len(norm_items(k.get('children'))) for k in kids)
    total = h1 + 72 + h2 + (26 + deepest * (chip_h + 12) - 12 if deepest else 0)
    y1 = by + max(0.0, (bh - total) / 2)
    rx = bx + bw / 2 - rw / 2
    y2 = y1 + h1 + 72
    row_w = n * w2 + (n - 1) * gap
    x2s = [bx + (bw - row_w) / 2 + i * (w2 + gap) for i in range(n)]
    sc.group = 'Lines'
    bus = y1 + h1 + 36
    sc.line([(bx + bw / 2, y1 + h1), (bx + bw / 2, bus)], sw=LINE, name='Line')
    if n > 1:
        sc.line([(x2s[0] + w2 / 2, bus), (x2s[-1] + w2 / 2, bus)], sw=LINE, name='Line')
    for x in x2s:
        sc.line([(x + w2 / 2, bus), (x + w2 / 2, y2)], sw=LINE, name='Line')
    for k_, x in zip(kids, x2s):
        gk = norm_items(k_.get('children'))
        if gk:
            lx = x + 22
            y3 = y2 + h2 + 26
            last = y3 + (len(gk) - 1) * (chip_h + 12) + chip_h / 2
            sc.line([(lx, y2 + h2), (lx, last)], sw=LINE, name='Line')
            for j in range(len(gk)):
                cyj = y3 + j * (chip_h + 12) + chip_h / 2
                sc.line([(lx, cyj), (x + 40, cyj)], sw=LINE, name='Line')
    sc.group = 'Top'
    sc.box(rx, y1, rw, h1, text=root.get('text', ''), sub=root.get('sub'), gradient=st['hub'], radius=22.0, kind='heading',
           color='white', sub_kind='small', sub_color='blue-5', name=root.get('text', 'Top'))
    for i, (k_, x) in enumerate(zip(kids, x2s)):
        sc.group = f'Branch {i + 1} · {k_["text"]}'
        sc.card(x, y2, w2, h2, k_['text'], sub=k_.get('sub'), highlight=k_.get('highlight'), radius=18.0)
        for j, g in enumerate(norm_items(k_.get('children'))):
            y3 = y2 + h2 + 26 + j * (chip_h + 12)
            w, h, lines = sc.chip_size(g['text'], bool(item_dot(g)), w2 - 40)
            sc.chip(x + 40, y3, g['text'], 'new' if g.get('highlight') else 'default', dot=item_dot(g),
                    size=(min(w, w2 - 40), chip_h, 1))
    sc.group = None
    return sc


def matrix(sp, sc):
    """Two axes, four quadrant cards, up to four chips in each."""
    bx, by, bw, bh = sc.area
    st = sc.st
    qs = sp.get('quadrants') or []
    if len(qs) != 4:
        raise InfographicError('A matrix takes exactly four quadrants (top left, top right, bottom left, bottom right).')
    S = min(bw - 96, bh - 84)
    x0 = bx + 96 + (bw - 96 - S) / 2
    y0 = by + (bh - 84 - S) / 2
    g = 16.0
    c = (S - g) / 2
    cells = [(x0, y0), (x0 + c + g, y0), (x0, y0 + c + g), (x0 + c + g, y0 + c + g)]
    for i, (q, (qx, qy)) in enumerate(zip(qs, cells)):
        q = q if isinstance(q, dict) else {'title': str(q)}
        sc.group = f'Quadrant {i + 1} · {q.get("title", "")}'
        sc.box(qx, qy, c, c, fill=st['surface'], stroke=st['accent'] if q.get('highlight') else st['border'],
               sw=2.0 if q.get('highlight') else 1.5, radius=24.0, name='Quadrant')
        sc.text(qx + 32, qy + 30, c - 64, q.get('title', ''), kind='kicker', color='accent', name='Quadrant title')
        yy = qy + 30 + type_of('kicker')[1] + 24
        for it in norm_items(q.get('items'))[:4]:
            w, h, lines = sc.chip_size(it['text'], bool(item_dot(it)), c - 64)
            sc.chip(qx + 32, yy, it['text'], 'new' if it.get('highlight') else 'default', dot=item_dot(it),
                    size=(w, h, lines))
            yy += h + 12
    xa, ya = sp.get('x_axis') or {}, sp.get('y_axis') or {}
    lh = type_of('label')[1]
    sc.group = 'Axes'
    ay = y0 + S + 30
    sc.line([(x0, ay), (x0 + S, ay)], sw=LINE, arrow='end', name='X axis')
    sc.text(x0, ay + 14, S, xa.get('label', ''), kind='label', color='muted', align='CENTER', name='X label')
    sc.text(x0, ay + 14, 200, xa.get('low', ''), kind='label', color='muted', name='X low')
    sc.text(x0 + S - 200, ay + 14, 200, xa.get('high', ''), kind='label', color='muted', align='RIGHT', name='X high')
    ax = x0 - 30
    sc.line([(ax, y0 + S), (ax, y0)], sw=LINE, arrow='end', name='Y axis')
    sc.text(ax - 14 - S / 2 - lh / 2, y0 + S / 2 - lh / 2, S, ya.get('label', ''), kind='label', color='muted',
            align='CENTER', name='Y label', rotate=-90)
    if ya.get('low'):
        sc.text(ax - 14 - 100 - lh / 2, y0 + S - 100 - lh / 2, 200, ya['low'], kind='label', color='muted', align='LEFT',
                name='Y low', rotate=-90)
    if ya.get('high'):
        sc.text(ax - 14 - 100 - lh / 2, y0 + 100 - lh / 2, 200, ya['high'], kind='label', color='muted', align='RIGHT',
                name='Y high', rotate=-90)
    sc.group = None
    return sc


TYPES = {'wheel': wheel, 'rings': rings, 'cycle': cycle, 'process': process, 'userflow': userflow,
         'timeline': timeline, 'hierarchy': hierarchy, 'matrix': matrix}
ROUND = ('wheel', 'rings', 'cycle', 'matrix')  # square diagrams: text column on the left by default


def scene(sp, box, theme='night'):
    kind = sp.get('layout')
    if kind not in TYPES:
        raise InfographicError(f'Unknown infographic "{kind}". Use one of: {", ".join(TYPES)}.')
    sc = Scene(kind, box, theme)
    return TYPES[kind](sp, sc)
