#!/usr/bin/env python3
"""Draw an infographic scene (infographics.py) as HTML: shapes in SVG, text in the brand fonts.

Used for the look check and, later, for PNG export and the slide preview. Python 3.9+, standard library.
"""
import html
import math
import os
import sys

import infographics as ig

KIT = ig.KIT
sys.path.insert(0, os.path.join(KIT, '.kiro', 'skills', 'figma-slides-builder', 'scripts'))
try:
    import render_deck  # the kit's preview: its font links (Shiji CDN, Google Noto Sans)
    FONT_HEAD = render_deck.FONT_HEAD
except Exception:  # noqa: BLE001
    FONT_HEAD = ''

FAMILY = {
    'serif': "'Shiji Night Serif Reckless Neue','ShijiNightSerifCDN',Georgia,serif",
    'sans': "'Shiji Day Sans Aeonik','ShijiDaySansCDN',system-ui,sans-serif",
    'label': "'Noto Sans',system-ui,sans-serif",
}
WEIGHT = {'Regular': 400, 'Medium': 500, 'Bold': 700, 'Black': 900, 'Heavy': 900}


def rgba(c):
    name, a = ig.paint(c)
    r, g, b = (round(v * 255) for v in ig.rgb(name))
    return f'rgba({r},{g},{b},{a:g})'


def type_css(kind):
    t = ig.TOKENS['type'][kind.partition('@')[0]]
    fam, style = ig.TOKENS['fonts'][t['font']]
    key = 'serif' if 'Serif' in fam else ('label' if 'Noto' in fam else 'sans')
    size, line, upper, tracking = ig.type_of(kind)
    css = (f"font-family:{FAMILY[key]};font-weight:{WEIGHT.get(style, 400)};font-size:{size:g}px;"
           f"line-height:{line:g}px;letter-spacing:{tracking / 100:g}em;")
    return css + ('text-transform:uppercase;' if upper else '')


def esc(s):
    return html.escape(str(s or ''))


# --------------------------------------------------------------------------- SVG shapes
def arc_path(cx, cy, r, a0, a1):
    x0, y0 = ig.at(cx, cy, r, a0)
    x1, y1 = ig.at(cx, cy, r, a1)
    large = 1 if (a1 - a0) % 360 > 180 else 0
    return f'M{x0:.2f} {y0:.2f} A{r:.2f} {r:.2f} 0 {large} 1 {x1:.2f} {y1:.2f}'


def stroke_attrs(it):
    dash = it.get('dash')
    cap = {'round': 'round', 'butt': 'butt', 'none': 'butt'}.get(it.get('cap', 'round'), 'round')
    out = f'fill="none" stroke="{rgba(it["stroke"])}" stroke-width="{it["sw"]:g}" stroke-linecap="{cap}" stroke-linejoin="round"'
    if dash:
        out += f' stroke-dasharray="{" ".join(f"{v:g}" for v in dash)}"'
    return out


def head(tip, direction, size, color, sw=2.0):
    """An open arrowhead (Figma's "line arrow" end) with its tip at `tip`, pointing along `direction`."""
    dx, dy = direction
    L = math.hypot(dx, dy) or 1.0
    dx, dy = dx / L, dy / L
    bx, by = tip[0] - dx * size, tip[1] - dy * size
    nx, ny = -dy * size * 0.62, dx * size * 0.62
    return (f'<path d="M{bx + nx:.2f} {by + ny:.2f} L{tip[0]:.2f} {tip[1]:.2f} L{bx - nx:.2f} {by - ny:.2f}" fill="none" '
            f'stroke="{rgba(color)}" stroke-width="{sw:g}" stroke-linecap="round" stroke-linejoin="round"/>')


def svg_item(it):
    k = it['kind']
    if k == 'circle':
        fill = rgba(it['fill']) if it.get('fill') else 'none'
        st = stroke_attrs(it).replace('fill="none" ', '') if it.get('stroke') else ''
        return f'<circle cx="{it["cx"]:.2f}" cy="{it["cy"]:.2f}" r="{it["r"]:.2f}" fill="{fill}" {st}/>'
    if k == 'arc':
        cx, cy, r, a0, a1, sw = it['cx'], it['cy'], it['r'], it['a0'], it['a1'], it['sw']
        out = []
        size = 11.0 if it.get('arrow') else 0.0
        if it.get('gradient'):  # the day-night cycle: short slices in the colour of their angle
            step, a = 2.0, a0
            while a < a1:
                b = min(a1, a + step)
                col = ig.cycle_color((a + b) / 2)
                out.append(f'<path d="{arc_path(cx, cy, r, a, min(a1, b + 0.4))}" fill="none" stroke="{col}" '
                           f'stroke-width="{sw:g}" stroke-linecap="butt"/>')
                a = b
            if it.get('cap') == 'round':
                for ang in (a0, a1):
                    px, py = ig.at(cx, cy, r, ang)
                    out.append(f'<circle cx="{px:.2f}" cy="{py:.2f}" r="{sw / 2:.2f}" fill="{ig.cycle_color(ang)}"/>')
        else:
            out.append(f'<path d="{arc_path(cx, cy, r, a0, a1)}" {stroke_attrs(it)}/>')
        if size:
            t = math.radians(a1)
            out.append(head(ig.at(cx, cy, r, a1), (math.cos(t), math.sin(t)), size, it['stroke'], it['sw']))
        return ''.join(out)
    if k == 'line':
        pts = list(it['pts'])
        out = []
        size = 11.0 if it.get('arrow') else 0.0
        tip = None
        if size and len(pts) >= 2:
            (x0, y0), (x1, y1) = pts[-2], pts[-1]
            tip, direction = (x1, y1), (x1 - x0, y1 - y0)
        d = 'M' + ' L'.join(f'{x:.2f} {y:.2f}' for x, y in pts)
        out.append(f'<path d="{d}" {stroke_attrs(it)}/>')
        if tip:
            out.append(head(tip, direction, size, it['stroke'], it['sw']))
        return ''.join(out)
    if k == 'box' and (it.get('shape') == 'diamond' or it.get('dash')):
        x, y, w, h = it['x'], it['y'], it['w'], it['h']
        fill = rgba(it['fill']) if it.get('fill') else 'none'
        st = stroke_attrs(it).replace('fill="none" ', '') if it.get('stroke') else ''
        if it.get('shape') == 'diamond':
            return (f'<polygon points="{x + w / 2:.2f},{y:.2f} {x + w:.2f},{y + h / 2:.2f} {x + w / 2:.2f},{y + h:.2f} '
                    f'{x:.2f},{y + h / 2:.2f}" fill="{fill}" {st} stroke-linejoin="round"/>')
        sw = it.get('sw') or 0
        return (f'<rect x="{x + sw / 2:.2f}" y="{y + sw / 2:.2f}" width="{w - sw:.2f}" height="{h - sw:.2f}" '
                f'rx="{min(it.get("radius", 0), h / 2) - sw / 2:.2f}" fill="{fill}" {st}/>')
    return ''


# --------------------------------------------------------------------------- boxes and text
def gradient_css(g):
    stops = ', '.join(f'{rgba((c, a))} {p * 100:g}%' for c, a, p in g['stops'])
    return f'linear-gradient({g.get("angle", 180):g}deg, {stops})'


def box_html(it):
    x, y, w, h = it['x'], it['y'], it['w'], it['h']
    svg_drawn = it.get('shape') == 'diamond' or it.get('dash')
    style = f'left:{x:.2f}px;top:{y:.2f}px;width:{w:.2f}px;height:{h:.2f}px;'
    if not svg_drawn:
        if it.get('gradient'):
            style += f'background:{gradient_css(it["gradient"])};'
        elif it.get('fill'):
            style += f'background:{rgba(it["fill"])};'
        if it.get('stroke') and it.get('sw'):
            style += f'box-shadow:inset 0 0 0 {it["sw"]:g}px {rgba(it["stroke"])};'
        r = '50%' if it.get('shape') == 'circle' else f'{min(it.get("radius", 0), h / 2):g}px'
        style += f'border-radius:{r};'
    pad = it.get('pad', (14, 20))
    pv, ph = pad if isinstance(pad, (list, tuple)) else (pad * 0.35, pad)
    align = 'LEFT' if it.get('dot') and h > 60 else it.get('align', 'CENTER')
    ta = {'LEFT': 'left', 'CENTER': 'center', 'RIGHT': 'right'}[align]
    items = 'flex-start' if align == 'LEFT' else 'center'
    parts = []
    if it.get('top'):
        parts.append(f'<div style="{type_css(it["top_type"])}color:{rgba(it["top_color"])}">{esc(it["top"])}</div>')
    if it.get('text'):
        parts.append(f'<div style="{type_css(it["type"])}color:{rgba(it["color"])}">{esc(it["text"])}</div>')
    if it.get('sub'):
        parts.append(f'<div style="{type_css(it["sub_type"])}color:{rgba(it["sub_color"])}">{esc(it["sub"])}</div>')
    body = ''.join(parts)
    if it.get('dot'):
        ring = f'box-shadow:inset 0 0 0 1.5px {rgba(it["dot_ring"])};' if it.get('dot_ring') else ''
        lift = (ig.type_of(it['type'])[1] - 10) / 2
        dot = (f'<span style="flex:none;width:10px;height:10px;border-radius:50%;background:{rgba(it["dot"])};{ring}'
               f'margin-top:{lift:g}px"></span>')
        body = (f'<div style="display:flex;align-items:flex-start;gap:10px;text-align:{ta}">{dot}'
                f'<div style="min-width:0">{body}</div></div>')
    return (f'<div class="bx" style="{style}"><div class="in" style="padding:{pv:g}px {ph:g}px;text-align:{ta};'
            f'align-items:{items}">{body}</div></div>')


def text_html(it):
    style = f'left:{it["x"]:.2f}px;top:{it["y"]:.2f}px;width:{it["w"]:.2f}px;'
    style += type_css(it['type']) + f'color:{rgba(it["color"])};text-align:{it["align"].lower()};'
    if it.get('rotate'):
        style += f'transform:rotate({it["rotate"]:g}deg);transform-origin:50% 50%;'
    return f'<div class="tx" style="{style}">{esc(it["text"])}</div>'


def scene_html(sc):
    svg, divs = [], []
    for it in sc.items:
        s = svg_item(it)
        if s:
            svg.append(s)
        if it['kind'] == 'box':
            divs.append(box_html(it))
        elif it['kind'] == 'text':
            divs.append(text_html(it))
    return (f'<svg class="shapes" width="1920" height="1080" viewBox="0 0 1920 1080">{"".join(svg)}</svg>'
            + ''.join(divs))


CSS = """
*{margin:0;padding:0;box-sizing:border-box}
body{background:#1e1e1e}
.slide{position:relative;width:1920px;height:1080px;overflow:hidden}
.shapes{position:absolute;left:0;top:0}
.bx{position:absolute;display:flex}
.bx .in{flex:1;display:flex;flex-direction:column;justify-content:center;gap:2px;min-width:0}
.tx{position:absolute}
.col{position:absolute;display:flex;flex-direction:column;gap:24px}
"""

BACKGROUND = {
    'night': 'radial-gradient(55% 75% at 92% 0%, rgba(59,130,246,.32) 0%, rgba(59,130,246,0) 100%), #172554',
    'day': '#FFFFFF',
    'blue': 'radial-gradient(60% 80% at 90% 0%, rgba(96,165,250,.45) 0%, rgba(96,165,250,0) 100%), #0030FF',
}


def heading_html(sp, x, y, w, theme, title_kind='title'):
    st = ig.STYLES[theme]
    parts = []
    if sp.get('kicker'):
        parts.append(f'<div style="{type_css("kicker")}color:{rgba(st["kicker"] if "kicker" in st else st["accent"])}">{esc(sp["kicker"])}</div>')
    if sp.get('title'):
        parts.append(f'<div style="{type_css(title_kind)}color:{rgba(st["title"])}">{esc(sp["title"])}</div>')
    if sp.get('lead'):
        parts.append(f'<div style="{type_css("lead")}color:{rgba(st["muted"])}">{esc(sp["lead"])}</div>')
    return f'<div class="col" style="left:{x}px;top:{y}px;width:{w}px">{"".join(parts)}</div>'


def slide(sp, theme=None):
    """A whole 1920 x 1080 slide: the text column (or heading) and the diagram, as the builder will lay it out."""
    theme = theme or sp.get('theme') or 'night'
    split = sp.get('arrange') == 'split' or (sp.get('arrange') is None and sp['layout'] in ig.ROUND)
    if split:
        box = (760.0, 104.0, 1032.0, 840.0)
        head = heading_html(sp, 128, 0, 560, theme)
        head = head.replace('top:0px', 'top:104px;height:840px;justify-content:center')
    else:
        lines = (1 if sp.get('kicker') else 0) + (1 if sp.get('lead') else 0)
        top = 104 + 74 + lines * 52 + 64
        box = (128.0, float(top), 1664.0, 944.0 - top)
        head = heading_html(sp, 128, 104, 1664, theme)
    sc = ig.scene(sp, box, theme)
    body = head + scene_html(sc)
    return f'<div class="slide" style="background:{BACKGROUND[theme]}">{body}</div>', sc


def page(slides_html):
    return (f'<!doctype html><html><head><meta charset="utf-8">{FONT_HEAD}<style>{CSS}</style></head>'
            f'<body>{"".join(slides_html)}</body></html>')
