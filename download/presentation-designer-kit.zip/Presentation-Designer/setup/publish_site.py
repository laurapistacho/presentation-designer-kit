#!/usr/bin/env python3
"""Publish public/ (the kit website) to GitHub Pages. This makes it public: ask the kit owner first.

    python3 setup/build_site.py      # build first
    python3 setup/publish_site.py    # then publish
    python3 setup/publish_site.py --repo someone/presentation-designer-kit

Clones the site repository's gh-pages branch into a temporary folder, replaces its files with public/,
commits and pushes. GitHub Pages serves the branch at https://<owner>.github.io/<repo>/ a minute later.
Needs git and a GitHub sign-in that can push to the repository (gh auth login).
"""
import argparse
import os
import shutil
import subprocess
import sys
import tempfile

KIT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
PUBLIC = os.path.join(KIT, 'public')
DEFAULT_REPO = 'laurapistacho/presentation-designer-kit'


def git(*args, cwd=None):
    return subprocess.run(['git'] + list(args), cwd=cwd, check=True, capture_output=True, text=True).stdout


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--repo', default=DEFAULT_REPO, help='GitHub owner/name of the site repository')
    a = ap.parse_args()
    if not os.path.exists(os.path.join(PUBLIC, 'index.html')):
        sys.exit('public/ is empty: run python3 setup/build_site.py first.')
    url = f'https://github.com/{a.repo}.git'
    tmp = tempfile.mkdtemp(prefix='kit-site-')
    try:
        git('clone', '--quiet', '--branch', 'gh-pages', '--depth', '1', url, tmp)
        for name in os.listdir(tmp):
            if name != '.git':
                p = os.path.join(tmp, name)
                shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
        for name in os.listdir(PUBLIC):
            src, dst = os.path.join(PUBLIC, name), os.path.join(tmp, name)
            shutil.copytree(src, dst) if os.path.isdir(src) else shutil.copy(src, dst)
        for root, _, files in os.walk(tmp):
            for f in files:
                if f == '.DS_Store':
                    os.remove(os.path.join(root, f))
        git('add', '-A', cwd=tmp)
        if not git('status', '--porcelain', cwd=tmp).strip():
            print('Nothing changed: the website is already up to date.')
            return
        git('commit', '--quiet', '-m', 'Website update', cwd=tmp)
        git('config', 'http.postBuffer', '524288000', cwd=tmp)  # large downloads fail with HTTP 400 otherwise
        git('push', '--quiet', 'origin', 'gh-pages', cwd=tmp)
        owner, name = a.repo.split('/')
        print(f'Published. https://{owner}.github.io/{name}/ updates in about a minute.')
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    main()
