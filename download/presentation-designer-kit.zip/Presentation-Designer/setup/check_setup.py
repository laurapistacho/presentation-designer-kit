#!/usr/bin/env python3
"""Check that this computer can use the Presentation Designer kit, then build the smoke-test deck.

    python3 setup/check_setup.py           # from the kit folder
    python3 setup/check_setup.py --quick   # skip the test build

Checks: Python 3.9+, Google Chrome, the zstd tool (optional), the template file and its decoded
copy in template/decoded/ (refreshed here when zstd is installed, so computers without zstd can
read the template), the template layers the layouts use, the Shiji fonts (for the preview only;
Figma has its own), then builds
examples/smoke-test into a .fig Slides file with a preview and runs the structural check.
"""
import glob
import json
import os
import platform
import shutil
import subprocess
import sys

KIT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
BUILDER = os.path.join(KIT, '.kiro', 'skills', 'figma-slides-builder', 'scripts')
WRITER = os.path.join(KIT, '.kiro', 'skills', 'presentation-writer', 'scripts')
TEMPLATE = os.path.join(KIT, 'template', 'Day & Night template.deck')  # the official Figma template, saved locally
sys.path.insert(0, BUILDER)

FONTS = {  # the three families of the Day & Night type scale (presentation-brand tokens)
    'Shiji Day Sans Aeonik': ['ShijiDaySansAeonik*'],
    'Shiji Night Serif Reckless Neue': ['ShijiNightSerif*', '*RecklessNeue*'],
    'Noto Sans': ['NotoSans-*', 'NotoSans[[]*'],
}


def font_dirs():
    home = os.path.expanduser('~')
    if platform.system() == 'Darwin':
        return [os.path.join(home, 'Library', 'Fonts'), '/Library/Fonts', '/System/Library/Fonts']
    if platform.system() == 'Windows':
        return [os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Fonts'),
                os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Fonts')]
    return [os.path.join(home, '.fonts'), os.path.join(home, '.local', 'share', 'fonts'), '/usr/share/fonts']


def has_font(patterns):
    for d in font_dirs():
        for p in patterns:
            if glob.glob(os.path.join(d, '**', p), recursive=True):
                return True
    return False


def main():
    quick = '--quick' in sys.argv
    rows, blockers = [], []

    def row(item, ok, note, blocking=True):
        rows.append(('ok' if ok else ('MISSING' if blocking else 'warning'), item, note))
        if not ok and blocking:
            blockers.append(item)

    v = sys.version_info
    row('Python 3.9 or newer', v >= (3, 9), f'{v.major}.{v.minor}.{v.micro}')
    import render_deck
    chrome = render_deck.find_chrome()
    row('Google Chrome', bool(chrome), chrome or 'install Chrome, or set CHROME=/path/to/chrome')
    row('zstd tool', bool(shutil.which('zstd')), shutil.which('zstd') or 'optional, only to read decks saved by Figma (reviews): brew install zstd', blocking=False)
    if platform.system() == 'Darwin':
        row('sips (macOS)', bool(shutil.which('sips')), 'built into macOS')
    else:
        row('sips (macOS)', False, 'previews and PowerPoint pictures use macOS sips; on other systems build the .fig only', blocking=False)
    row('Template file', os.path.exists(TEMPLATE), os.path.relpath(TEMPLATE, KIT) if os.path.exists(TEMPLATE) else
        'in Figma open the official template (https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4), File > Save local copy, save it as template/Day & Night template.deck')
    if os.path.exists(TEMPLATE):
        import figdeck
        if figdeck.have_zstd():  # keep the decoded copy current, so the kit works on computers without zstd
            try:
                r = figdeck.save_decoded(TEMPLATE, prune=True)
                row('Template readable without zstd', True, 'template/decoded/ ' + ('refreshed' if r['written'] or r['removed'] else 'is current'))
            except Exception as e:  # noqa: BLE001
                row('Template readable without zstd', False, f'could not save template/decoded/: {e}', blocking=False)
        else:
            ok = figdeck.has_decoded_copy(TEMPLATE)
            row('Template readable without zstd', ok, 'template/decoded/ matches the template' if ok else
                'template/decoded/ is missing or older than the template: get the kit again, or brew install zstd')
        import build_deck
        try:
            r = build_deck.check_template(TEMPLATE)
            row('Template layers used by the layouts', not r['missing'], f"{r['ids_used']} ids, missing: {', '.join(r['missing']) or 'none'}")
        except Exception as e:  # noqa: BLE001
            row('Template layers used by the layouts', False, f'could not read the template: {e}')
    for name, pats in FONTS.items():
        row(f'Font: {name}', has_font(pats), 'installed' if has_font(pats) else 'preview falls back to web fonts; Figma is not affected', blocking=False)

    built = None
    if not quick and not blockers:
        spec = os.path.join(KIT, 'examples', 'smoke-test', 'deck.json')
        out = os.path.join(KIT, 'examples', 'smoke-test', 'Smoke test.fig')
        res = subprocess.run([sys.executable, os.path.join(BUILDER, 'build_deck.py'), spec, '--out', out,
                              '--preview', os.path.join(KIT, 'examples', 'smoke-test', 'preview')],
                             capture_output=True, text=True, timeout=900)
        try:
            r = json.loads(res.stdout)
            chk = subprocess.run([sys.executable, os.path.join(BUILDER, 'check_deck.py'), out], capture_output=True, text=True, timeout=300)
            c = json.loads(chk.stdout)
            ok = not c['errors'] and not r['fit_issues']
            row('Test build (examples/smoke-test)', ok, f"{r['slides']} slides, {len(r['fit_issues'])} fit issues, {len(c['errors'])} file errors")
            lint = subprocess.run([sys.executable, os.path.join(WRITER, 'lint_copy.py'), spec, '--json'], capture_output=True, text=True, timeout=120)
            lr = json.loads(lint.stdout)
            row('Copy check (examples/smoke-test)', not any(i['level'] == 'error' for i in lr['issues']), f"{len(lr['issues'])} findings")
            built = out
        except Exception:  # noqa: BLE001
            row('Test build (examples/smoke-test)', False, (res.stderr or res.stdout)[-300:].strip())

    w = max(len(r[1]) for r in rows)
    print('\nPresentation Designer kit: setup check\n')
    for status, item, note in rows:
        print(f'  {status:8} {item:<{w}}  {note}')
    print()
    if blockers:
        print('Not ready: fix the MISSING items above and run this again.')
        sys.exit(1)
    if built:
        print('Ready. Drag this file into the Figma file browser to test the import:')
        print(f'  {built}')
    else:
        print('Ready (test build skipped).')


if __name__ == '__main__':
    main()
