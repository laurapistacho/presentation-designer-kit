#!/usr/bin/env python3
"""Build the Day & Night template: one slide per layout, with sample content.

    python3 setup/build_showcase.py

Writes examples/day-night-template/Shiji Day & Night template.fig (drag it into the Figma file
browser to see, copy and reuse every layout), its preview, the slide pictures in library/day-night/
and library/index.html. Stops with the message if the build or the file check reports an error.
"""
import glob
import json
import os
import shutil
import subprocess
import sys

KIT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
BUILDER = os.path.join(KIT, '.kiro', 'skills', 'figma-slides-builder', 'scripts')
FOLDER = os.path.join(KIT, 'examples', 'day-night-template')
SPEC = os.path.join(FOLDER, 'deck.json')
OUT = os.path.join(FOLDER, 'Shiji Day & Night template.fig')
PREVIEW = os.path.join(FOLDER, 'preview')
LIB = os.path.join(KIT, 'library', 'day-night')


def main():
    res = subprocess.run([sys.executable, os.path.join(BUILDER, 'build_deck.py'), SPEC, '--out', OUT, '--preview', PREVIEW],
                         capture_output=True, text=True, timeout=1200)
    try:
        r = json.loads(res.stdout)
    except ValueError:
        sys.exit('The build failed:\n' + (res.stderr or res.stdout)[-1500:])
    chk = subprocess.run([sys.executable, os.path.join(BUILDER, 'check_deck.py'), OUT], capture_output=True, text=True,
                         timeout=300)
    c = json.loads(chk.stdout)
    if c['errors']:
        sys.exit('The file check found errors:\n' + json.dumps(c['errors'], indent=1))
    layouts = [sl.get('layout') for sl in json.load(open(SPEC, encoding='utf-8'))['slides']]
    if os.path.isdir(LIB):
        shutil.rmtree(LIB)
    os.makedirs(LIB)
    pictures = sorted(glob.glob(os.path.join(PREVIEW, 'slides', '*.png')))
    index = []
    for i, (png, name) in enumerate(zip(pictures, layouts), 1):
        jpg = os.path.join(LIB, f'{i:02d}-{name}.jpg')
        if shutil.which('sips'):
            subprocess.run(['sips', '-s', 'format', 'jpeg', '-s', 'formatOptions', '80', png, '--out', jpg],
                           capture_output=True, check=True)
        else:
            jpg = jpg[:-4] + '.png'
            shutil.copy(png, jpg)
        index.append({'n': i, 'layout': name, 'file': os.path.basename(jpg)})
    with open(os.path.join(LIB, 'index.json'), 'w', encoding='utf-8') as f:
        json.dump(index, f, indent=1)
    subprocess.run([sys.executable, os.path.join(KIT, 'setup', 'build_library_page.py')], check=True,
                   capture_output=True)
    print(json.dumps({'file': OUT, 'slides': r['slides'], 'fit_issues': len(r.get('fit_issues') or []),
                      'warnings': r.get('warnings'), 'file_errors': len(c['errors']), 'pictures': len(index)},
                     indent=1, ensure_ascii=False))
    if r.get('fit_issues'):
        sys.exit('Some text does not fit: see the report in ' + os.path.join(PREVIEW, 'report.json'))


if __name__ == '__main__':
    main()
