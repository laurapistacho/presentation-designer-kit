#!/usr/bin/env python3
"""Build the Day & Night template: the official template's 40 layouts, rebuilt by the kit with sample content.
    python3 setup/build_showcase.py
Writes examples/day-night-template/Shiji Day & Night template.fig (drag it into the Figma file
browser to see, copy and reuse every layout), its preview, the slide pictures in library/day-night/
and library/index.html. Stops with the message if the build or the file check reports an error.
The slides follow the official Figma template (https://www.figma.com/slides/r03dbNAia3aYpzBjBab0c4),
in its order and with its slide-grid rows.
"""
import glob
import json
import os
import shutil
import subprocess
import sys
KIT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
BUILDER = os.path.join(KIT, '.kiro', 'skills', 'figma-slides-builder', 'scripts')
FOLDER = os.path.join(KIT, 'examples', 'day-night-template')
SPEC = os.path.join(FOLDER, 'deck.json')
OUT = os.path.join(FOLDER, 'Shiji Day & Night template.fig')
PREVIEW = os.path.join(FOLDER, 'preview')
LIB = os.path.join(KIT, 'library', 'day-night')


def build(spec=SPEC, out=OUT, preview=PREVIEW, lib=LIB, template=None):
    """Build the showcase, check the file, write one picture per slide into lib/ with index.json."""
    env = dict(os.environ)
    if template:
        env['PRESENTATION_TEMPLATE'] = template
    res = subprocess.run([sys.executable, os.path.join(BUILDER, 'build_deck.py'), spec, '--out', out, '--preview', preview],
                         capture_output=True, text=True, timeout=1800, env=env)
    try:
        r = json.loads(res.stdout)
    except ValueError:
        sys.exit('The build failed:\n' + (res.stderr or res.stdout)[-1500:])
    chk = subprocess.run([sys.executable, os.path.join(BUILDER, 'check_deck.py'), out], capture_output=True, text=True,
                         timeout=300, env=env)
    c = json.loads(chk.stdout)
    if c['errors']:
        sys.exit('The file check found errors:\n' + json.dumps(c['errors'][:20], indent=1))
    slides = json.load(open(spec, encoding='utf-8'))['slides']
    layouts = [sl.get('layout') for sl in slides]
    if os.path.isdir(lib):
        shutil.rmtree(lib)
    os.makedirs(lib)
    pictures = sorted(glob.glob(os.path.join(preview, 'slides', '*.png')))
    sys.path.insert(0, BUILDER)
    import build_deck
    index = []
    for i, (png, name) in enumerate(zip(pictures, layouts), 1):
        jpg = os.path.join(lib, f'{i:02d}-{name}.jpg')
        if shutil.which('sips'):
            subprocess.run(['sips', '-s', 'format', 'jpeg', '-s', 'formatOptions', '80', png, '--out', jpg],
                           capture_output=True, check=True)
        else:
            jpg = jpg[:-4] + '.png'
            shutil.copy(png, jpg)
        L = build_deck.LAYOUTS.get(name) or {}
        index.append({'n': i, 'layout': name, 'file': os.path.basename(jpg), 'template': L.get('template', ''),
                      'row': slides[i - 1].get('row', '')})
    with open(os.path.join(lib, 'index.json'), 'w', encoding='utf-8') as f:
        json.dump(index, f, indent=1, ensure_ascii=False)
    if r.get('fit_issues'):
        sys.exit('Some text does not fit: see the report in ' + os.path.join(preview, 'report.json'))
    return {'file': out, 'slides': r['slides'], 'fit_issues': len(r.get('fit_issues') or []), 'warnings': r.get('warnings'),
            'text_without_style': r.get('text_without_style'), 'file_errors': len(c['errors']), 'pictures': len(index)}


def main():
    r = build()
    subprocess.run([sys.executable, os.path.join(KIT, 'setup', 'build_library_page.py')], check=True,
                   capture_output=True)
    print(json.dumps(r, indent=1, ensure_ascii=False))


if __name__ == '__main__':
    main()
