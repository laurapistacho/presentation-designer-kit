#!/usr/bin/env python3
"""Build the kit website and its public download (maintainer script).

    python3 setup/build_site.py            # rebuild the Day & Night template, then the site
    python3 setup/build_site.py --serve    # build, then preview on http://localhost:8000

Writes public/, a static website like the Kiro Mockup Designer's: install steps and downloads, what the
kit is, the Day & Night look (drawn from presentation-brand tokens), every layout, the template deck
in a browser viewer, and how the words are written. Publish the folder on any static host (GitHub
Pages, GitLab Pages, an internal server).

public/download/ holds the public edition of the kit (without the pictures of the team's own decks,
library/decks and library/slides) and the Day & Night template as a .fig to drag into Figma.
The full kit for the team stays download/presentation-designer-kit.zip (setup/build_kit_zip.py).
Python 3.9+, standard library only.
"""
import html
import http.server
import json
import os
import shutil
import socketserver
import subprocess
import sys
import zipfile

KIT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
OUT = os.path.join(KIT, 'public')
BUILDER = os.path.join(KIT, '.kiro', 'skills', 'figma-slides-builder', 'scripts')
SHOW = os.path.join(KIT, 'examples', 'day-night-template')
ZIP_NAME = 'presentation-designer-kit.zip'
FIG_NAME = 'shiji-day-and-night-template.fig'
INTERNAL = ('library/decks/', 'library/slides/')  # the team's own decks: internal edition only
sys.path.insert(0, BUILDER)
sys.path.insert(0, os.path.join(KIT, 'setup'))

import build_deck  # noqa: E402
import build_kit_zip  # noqa: E402
import build_library_page  # noqa: E402
import figdeck  # noqa: E402
import render_deck  # noqa: E402

T = build_deck.TOKENS
C = {k: v['hex'] for k, v in T['colors'].items()}
esc = html.escape


# --------------------------------------------------------------------------- token helpers
def rgba(col, alpha=1.0):
    h = C.get(col, col).lstrip('#')
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f'rgba({r},{g},{b},{alpha:g})' if alpha < 1 else f'#{h.upper()}'


def spec_css(spec):
    if isinstance(spec, (list, tuple)):
        return rgba(spec[0], float(spec[1]))
    return rgba(spec)


def background_css(name):
    """A token background (bottom layer first) as one CSS background (top layer first)."""
    layers = []
    for layer in T['backgrounds'][name]:
        if layer['type'] == 'solid':
            c = rgba(layer['color'], float(layer.get('opacity', 1)))
            layers.append(f'linear-gradient({c},{c})')
            continue
        stops = ','.join(f'{rgba(col, float(a))} {float(p) * 100:g}%' for col, a, p in layer['stops'])
        if layer['type'] == 'linear':
            layers.append(f'linear-gradient({layer["angle"]}deg,{stops})')
        else:
            (x, y), (rx, ry) = layer['at'], layer['size']
            layers.append(f'radial-gradient({rx * 100:g}% {ry * 100:g}% at {x * 100:g}% {y * 100:g}%,{stops})')
    return 'background:' + ','.join(reversed(layers)) + ';'


def logo_html(white=True):
    d = figdeck.Deck(build_deck.TEMPLATE)
    r = render_deck.Renderer(d)
    inner = r.node_html(d.nodes['2013:277' if white else '2038:246'], transform_override=[1, 0, 0, 0, 1, 0])
    return f'<span class="logo"><span class="logo-in">{inner}</span></span>'


# --------------------------------------------------------------------------- panels
def panel_install():
    steps = [('Download', 'Unzip the kit anywhere. Keep the hidden <code>.kiro</code> folder: it holds the agent and the skills.'),
             ('Open in Kiro', 'File → Open Folder, pick <code>Presentation-Designer</code>, then Trust.'),
             ('Describe the deck', 'Pick the <b>presentation-designer</b> agent in the chat and say what the deck is for, who is in the room and where the facts are.')]
    return f'''
<h1>Presentation Designer</h1>
<p class="lead">Build the design team's presentations as native <b>Figma Slides</b> files with Kiro, in the Shiji <b>Day &amp; Night</b> look. Kiro writes the story and the copy, then builds a file you drag into Figma: real gradients, brand colours as variables, auto layout text, speaker notes and transitions.</p>
<div class="downloads">
  <a class="pill pill-blue" href="download/{ZIP_NAME}" download>Download kit</a>
  <a class="pill pill-line" href="download/{FIG_NAME}" download>Download the Figma template</a>
</div>
<p class="note">The kit is a ZIP with the agent, three skills, the template and examples. The template is one .fig file with every layout: drag it onto the Figma file browser to see the look and copy slides from it.</p>
<h2>Quick start</h2>
<div class="steps">{''.join(f'<div class="card step"><span class="num">{i}</span><b class="step-title">{t}</b><p>{d}</p></div>' for i, (t, d) in enumerate(steps, 1))}</div>
<h2>What to ask</h2>
<ul>
<li>"Design Updates Q4 2026 for product leadership, 40 minutes. Here are the Jira epics and the adoption numbers."</li>
<li>"A component update on the new Panel for developers and QA. Figma file: …, prototype: …"</li>
<li>"Turn these research notes into a readout for the product team. Humour is welcome."</li>
<li>"Review this deck for tone and consistency." (with a Figma link, or a copy saved from Figma)</li>
</ul>
<p>Kiro asks a few questions, proposes the story one line per slide and waits for your yes, writes the copy and speaker notes, builds the file, looks at every slide, runs its checks and tells you what is left to finish in Figma. Every deck lives in its own folder in <code>decks/</code>.</p>
<h2>Open it in Figma</h2>
<ul>
<li>Drag the <code>.fig</code> file onto the Figma <b>file browser</b> (Drafts or a project page), or use Import there. Not onto an open file: Figma then answers "Drop .fig or .jam files into the file browser".</li>
<li>It opens as a Figma Slides file. Finish there what a file cannot carry: prototype embeds, GIFs, polls.</li>
<li>Need PowerPoint? In Figma: File → Export → PowerPoint. Or ask Kiro for a .pptx.</li>
</ul>
<h2>What you need</h2>
<ul>
<li>macOS with Python 3.9 or newer: if <code>python3</code> is missing, macOS offers to install it the first time you type it in a terminal.</li>
<li>Google Chrome: Kiro uses it to measure text and draw previews.</li>
<li>The Shiji fonts (Day Sans Aeonik, Night Serif Reckless Neue) from the design lead, and Noto Sans Mono from Google Fonts. Figma has them already: the fonts only make the local preview exact.</li>
<li>Check a computer with <code>python3 setup/check_setup.py</code> in the kit folder: it builds a short test deck to drag into Figma.</li>
</ul>
<h2>For maintainers</h2>
<p>The kit is plain files. The look lives in <code>.kiro/skills/presentation-brand/assets/tokens.json</code>, the layouts in <code>.kiro/skills/figma-slides-builder/scripts/layouts.py</code>; ask Kiro for kit maintenance and it follows <code>.kiro/steering/kit-maintenance.md</code>. Rebuild this website and the downloads with <code>python3 setup/build_site.py</code>.</p>
<p>There is no auto-update: download the new zip and replace everything except your <code>decks/</code> folder.</p>
'''


def panel_about():
    return '''
<h1>What is this</h1>
<p class="lead">A Kiro kit that turns notes, Jira tickets, research and Figma links into Figma Slides decks for the Shiji design team, in one consistent look, without anyone pushing pixels for hours.</p>
<div class="two">
<div class="card"><h3>What it is</h3><ul>
<li>An agent, <b>presentation-designer</b>, that runs the whole flow: brief, story, copy, build, checks, hand-over.</li>
<li>Three skills that stay aligned: the <b>writer</b> (the words), the <b>brand</b> (the look) and the <b>builder</b> (the Figma file).</li>
<li>28 layouts in the Day &amp; Night look, from covers to customer quotes.</li>
<li>Native Figma Slides files: gradients, colour variables, auto layout, notes, transitions, one grid row per section.</li>
<li>Checks before you see anything: copy, fit of every text block, structure of the file.</li>
</ul></div>
<div class="card"><h3>What it is not</h3><ul>
<li>Not a replacement for designing in Figma: it gets the deck to 90%, you finish the details.</li>
<li>Not a source of facts: every number, quote and date comes from what you give it. Gaps stay marked as <code>[TBD]</code>.</li>
<li>Not a Figma plugin: it writes a file; Figma imports it.</li>
<li>Not live elements: polls, prototype embeds and GIFs are added in Figma (the slides say where).</li>
</ul></div>
</div>
<h2>How it works</h2>
<p>The <b>writer</b> skill interviews you, outlines the story and writes <code>deck.json</code>: every slide's copy, kicker, highlight and speaker notes, with live moments placed for the deck type. The <b>brand</b> skill holds the look in one file of tokens: colours, gradients, type, the day, night and blue themes. The <b>builder</b> draws each layout from those tokens into a Figma Slides file, measures every text block in Chrome, previews every slide and checks the file before you open it.</p>
<h2>When to use it</h2>
<ul>
<li>Quarterly design updates for stakeholders: outcomes first, numbers with sources.</li>
<li>Design and component updates: the detail builders need, screen by screen.</li>
<li>Research readouts: stories, quotes and findings, with room for humour.</li>
<li>Huddles, kickoffs and challenges: short decks with a clear ask.</li>
<li>Reviewing an existing deck for tone, consistency and words that do not fit.</li>
</ul>
'''


def panel_look():
    colors = ''.join(
        f'<div class="swatch"><span class="chip-color" style="background:{c["hex"]}"></span><b>{esc(c["name"])}</b>'
        f'<code>{c["hex"]}</code><small>{esc(c["role"])}</small></div>' for c in T['colors'].values())
    fonts = T['fonts']
    rows = []
    sample = {'display': 'Design Updates', 'display-s': 'Agenda', 'number': '01', 'stat': '~60%', 'stat-s': '12,480',
              'statement': 'Search to jump.', 'quote': 'Where are the alerts?', 'quote-s': 'Everything is where I expect it.',
              'title': 'Search that finds it', 'title-s': 'What we learned', 'heading': 'Layout improvements',
              'subtitle': 'UX & UI Design', 'lead': 'Find any setting without knowing where it lives.',
              'body': 'Live filtering across all sections', 'small': 'One scale replaces hardcoded values.',
              'button': 'Questions?', 'kicker': 'Settings', 'label': 'Front office', 'caption': 'Every review in one list',
              'footnote': 'Source: Rollout summary'}
    for key, ty in T['type'].items():
        fam, style = fonts[ty['font']]
        css_fam = {'Shiji Night Serif Reckless Neue': "'Night',Georgia,serif", 'Shiji Day Sans Aeonik': "'Day',system-ui,sans-serif",
                   'Noto Sans Mono': "'Noto Sans Mono',monospace"}[fam]
        weight = {'Heavy': 900, 'Bold': 700, 'Medium': 500}.get(style, 400)
        size = ty['size'] * 0.5
        case = 'text-transform:uppercase;' if ty.get('case') == 'upper' else ''
        rows.append(f'<tr><td><code>{key}</code></td><td>{esc(fam.replace("Shiji ", ""))} {style}<br><small>{ty["size"]} px · {esc(ty.get("use", ""))}</small></td>'
                    f'<td><span style="font-family:{css_fam};font-weight:{weight};font-size:{size:g}px;line-height:{ty["line"]};'
                    f'letter-spacing:{ty.get("tracking", 0) / 100:g}em;{case}">{esc(sample.get(key, key))}</span></td></tr>')
    th = T['themes']

    def mini(name, label):
        t = th[name]
        return (f'<div class="mini" style="{background_css(t["background"] if t["background"] != "day" else "day")}">'
                f'<span class="m-kicker" style="color:{spec_css(t["kicker"])}">{label}</span>'
                f'<span class="m-title" style="color:{spec_css(t["title"])}">One idea, <span style="color:{spec_css(t["highlight"])}">one highlight</span></span>'
                f'<span class="m-text" style="color:{spec_css(t["muted"])}">Night Serif for emotion, Day Sans for information.</span>'
                f'<span class="m-pill" style="background:{spec_css(t["button"])};color:{spec_css(t["button_text"])}">Questions?</span></div>')
    backgrounds = ''.join(f'<figure class="bg"><div style="{background_css(b)}"></div><figcaption><code>{b}</code> {esc(u)}</figcaption></figure>'
                          for b, u in (('aurora', 'cover and closing'), ('horizon', 'night opener, scenarios'),
                                       ('deep', 'dividers, hero quotes'), ('night', 'night content'), ('blue', 'punctuation')))
    rules = ['<b>Night by default</b> for openers, dividers, statements, quotes and numbers; <b>day</b> for screenshots and detail; <b>blue</b> for one or two punctuation slides.',
             '<b>One highlight per slide</b>, marked <code>==like this==</code>: Energetic Green on night, Reviewpro Blue on day. Never green text on a light background.',
             '<b>Three typefaces, three jobs:</b> Night Serif for emotion, Day Sans for information, Noto Sans Mono for labels.',
             '<b>No black:</b> text on day slides is Midnight.',
             '<b>Gradients from the tokens only</b>, built as real Figma gradients: never blurred shapes or pictures.',
             '<b>CTA = pill:</b> fully rounded, green on night, Reviewpro Blue on day.',
             '<b>Screenshots sit on a stage</b> at their own ratio, with 16 px corners, a hairline frame and a soft shadow.',
             '<b>Space:</b> 128 px side margins, content between 104 and 944 px, the logo bottom right.',
             '<b>Kicker, title, subtitle:</b> the kicker names the topic in 1 to 4 words, the title says the point.',
             '<b>One idea per slide:</b> two highlights or more than four bullets means two slides.']
    return f'''
<h1>The look: Day &amp; Night</h1>
<p class="lead">Shiji's rebrand is about Day and Night: hotels run 24/7. Night slides carry the big moments in Night Serif with one Energetic Green highlight; day slides carry the screenshots and the detail; Reviewpro Blue punctuates. Everything below is drawn from one file, <code>presentation-brand/assets/tokens.json</code>, the same file every build reads.</p>
<h2>Themes</h2>
<div class="minis">{mini('night', 'Night')}{mini('day', 'Day')}{mini('blue', 'Blue')}</div>
<h2>Backgrounds</h2>
<div class="bgs">{backgrounds}</div>
<h2>Rules</h2>
<ol class="rules">{''.join(f'<li>{r}</li>' for r in rules)}</ol>
<h2>Colours</h2>
<p>Every file carries these as colour variables in the collection <b>Shiji Day &amp; Night</b>, so designers pick them from Figma's colour picker.</p>
<div class="swatches">{colors}</div>
<h2>Type scale</h2>
<p class="note">Samples at half size. Sizes are for a 1920 × 1080 slide.</p>
<table class="type"><tbody>{''.join(rows)}</tbody></table>
'''


def panel_layouts():
    pics = {it['layout']: it['file'] for it in json.load(open(os.path.join(KIT, 'library', 'day-night', 'index.json'), encoding='utf-8'))}
    cards = []
    for name, L in build_deck.LAYOUTS.items():
        if name.startswith('_'):
            continue
        pic = pics.get(name)
        img = f'<img loading="lazy" src="layouts/{esc(pic)}" alt="{esc(name)} layout">' if pic else ''
        cards.append(f'<figure class="layout">{img}<figcaption><b><code>{esc(name)}</code></b> <span class="theme theme-{L["theme"]}">{L["theme"]}</span>'
                     f'<p>{esc(L["about"])}</p><small>{esc(L["fields"])}</small></figcaption></figure>')
    return f'''
<h1>Layouts</h1>
<p class="lead">28 layouts, each drawn from the brand tokens. Every slide can switch theme with <code>"theme": "day" | "night" | "blue"</code>; text takes <code>**bold**</code>, <code>==highlight==</code> and <code>[links](https://…)</code>. The pictures come from the Day &amp; Night template, built by the kit itself.</p>
<div class="layouts">{''.join(cards)}</div>
'''


def panel_examples():
    return f'''
<div class="viewer-bar"><b>Shiji Day &amp; Night template</b><span>28 slides · ← → to move · F for full screen</span>
<a class="pill pill-line small" href="examples/day-night-template/index.html" target="_blank" rel="noopener">Open full screen</a>
<a class="pill pill-blue small" href="download/{FIG_NAME}" download>Download .fig</a></div>
<iframe class="viewer" src="examples/day-night-template/index.html" title="The Day &amp; Night template deck"></iframe>
'''


def panel_writing():
    types = [('Quarterly', 'For stakeholders: outcomes first, one number per claim with its source, a few strong live moments.'),
             ('Design or component update', 'For builders: name, aspect, claim, at most four lines; current versus new, states, specs.'),
             ('Research readout', 'For the product team: stories, quotes and findings, a live moment every three to five slides.')]
    moments = [('Comedic relief', 'A meme or a funny picture that moves the argument forward', '<code>meme</code>, <code>split</code>, <code>picture</code>'),
               ('The quoter', 'Real words of real people, attributed by role and company', '<code>quotes</code>, <code>quote</code>, <code>quote-cards</code>'),
               ('A question to the room', 'Show of hands, a poll, a check-in', '<code>question</code>, <code>circle-list</code>'),
               ('The reveal', 'The answer, the twist, the punchline', '<code>statement</code>, <code>quote</code>'),
               ('A breather', 'A pause after a dense run', '<code>topic</code>, <code>statement</code>'),
               ('A principle', 'A line to remember', '<code>question</code> in serif')]
    return f'''
<h1>Writing</h1>
<p class="lead">The writer skill decides the words before anything is drawn: the story, the headlines, the speaker notes, and the live moments that keep the room awake.</p>
<h2>Deck types</h2>
<div class="steps">{''.join(f'<div class="card step"><b class="step-title">{t}</b><p>{d}</p></div>' for t, d in types)}</div>
<h2>Live moments</h2>
<table class="moments"><thead><tr><th>Moment</th><th>What</th><th>Layouts</th></tr></thead><tbody>
{''.join(f'<tr><td><b>{a}</b></td><td>{b}</td><td>{c}</td></tr>' for a, b, c in moments)}</tbody></table>
<h2>Ground rules</h2>
<ul>
<li><b>Nothing invented.</b> Missing facts become <code>[TBD — Requires Input]</code>, and the copy check refuses to pass them.</li>
<li><b>One slide, one point.</b> If a headline needs "and", it is two slides.</li>
<li><b>Speaker notes</b> on every content slide, written the way the presenter will say them.</li>
<li><b>The copy check</b> runs before every build: word limits per layout, placeholders, sources for numbers, AI vocabulary, one highlight per slide, pacing.</li>
</ul>
'''


# --------------------------------------------------------------------------- page
PANELS = [('install', 'Install', panel_install), ('about', 'What Is This', panel_about), ('look', 'The Look', panel_look),
          ('layouts', 'Layouts', panel_layouts), ('examples', 'Example Deck', panel_examples), ('writing', 'Writing', panel_writing)]


def page():
    font_css = '''
@font-face{font-family:'Night';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8e_ShijiNightSerifRecklessNeue-Regular.woff2') format('woff2');font-weight:400;font-display:swap}
@font-face{font-family:'Night';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67dac539ac844f1933bcafb0_ShijiNightSerifRecklessNeue-Heavy.woff2') format('woff2');font-weight:900;font-display:swap}
@font-face{font-family:'Day';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9c_ShijiDaySansAeonik-Regular.woff2') format('woff2');font-weight:400;font-display:swap}
@font-face{font-family:'Day';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b8f_ShijiDaySansAeonik-Medium.woff2') format('woff2');font-weight:500;font-display:swap}
@font-face{font-family:'Day';src:url('https://cdn.prod.website-files.com/67da8139199c44005d0f1427/67da8139199c44005d0f1b9d_ShijiDaySansAeonik-Bold.woff2') format('woff2');font-weight:700;font-display:swap}'''
    css = f'''{font_css}
*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{height:100%}}
body{{display:flex;font:16px/1.6 'Day',system-ui,sans-serif;color:{C['midnight']};background:{C['white']}}}
code{{font:13px 'Noto Sans Mono',monospace;background:{C['daylight']};padding:1px 6px;border-radius:6px}}
nav{{flex:none;width:260px;display:flex;flex-direction:column;padding:32px 20px;{background_css('night')}color:#fff}}
.logo{{display:block;position:relative;width:91px;height:48px;transform:scale(1.15);transform-origin:0 0;margin:0 0 12px 8px}}
.logo-in{{position:absolute;inset:0}}
.kitname{{font:500 12px 'Noto Sans Mono',monospace;letter-spacing:.12em;text-transform:uppercase;color:{C['blue-5']};margin:0 0 28px 8px}}
nav button{{display:block;width:100%;text-align:left;font:500 15px 'Day',sans-serif;color:{C['moonlight']};background:none;border:0;border-left:3px solid transparent;border-radius:0 10px 10px 0;padding:10px 14px;cursor:pointer}}
nav button:hover{{background:rgba(255,255,255,.06)}}
nav button.active{{background:rgba(255,255,255,.1);border-left-color:{C['green']};color:#fff}}
nav .foot{{margin-top:auto;font-size:12px;line-height:1.5;color:{C['blue-5']};padding:0 8px}}
nav .foot a{{color:{C['green']}}}
main{{flex:1;min-width:0;position:relative}}
section{{position:absolute;inset:0;display:none;overflow-y:auto}}
section.active{{display:block}}
section.frame.active{{display:flex;flex-direction:column}}
.content{{max-width:980px;padding:56px 56px 96px}}
h1{{font:900 52px/1.1 'Night',Georgia,serif;letter-spacing:-.01em;margin-bottom:16px}}
h2{{font:700 22px/1.3 'Day',sans-serif;margin:44px 0 14px}}
h3{{font:700 18px 'Day',sans-serif;margin-bottom:10px}}
p+p{{margin-top:12px}}
.lead{{font-size:19px;line-height:1.6;color:rgba(23,37,84,.78);max-width:780px}}
.note{{color:rgba(23,37,84,.72);font-size:14px;margin-top:10px}}
ul,ol{{padding-left:22px}}li+li{{margin-top:6px}}ul+p,ol+p,table+p{{margin-top:16px}}
.downloads{{display:flex;flex-wrap:wrap;gap:12px;margin:28px 0 4px}}
.pill{{display:inline-flex;align-items:center;font:700 15px 'Day',sans-serif;border-radius:999px;padding:12px 26px;text-decoration:none;white-space:nowrap}}
.pill.small{{padding:7px 16px;font-size:13px}}
.pill-blue{{background:{C['reviewpro']};color:#fff}}
.pill-line{{border:1.5px solid {C['blue-5']};color:{C['midnight']}}}
.steps{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}}
.two{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:28px}}
.card{{background:{C['daylight-60']};border:1px solid {C['blue-5']};border-radius:16px;padding:20px}}
.card p,.card li{{font-size:15px}}
.step .num{{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:50%;background:{C['midnight']};color:{C['green']};font:700 14px 'Noto Sans Mono',monospace;margin-bottom:10px}}
.step-title{{display:block;margin-bottom:4px}}
.minis{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}}
.mini{{aspect-ratio:16/9;border-radius:14px;padding:22px;display:flex;flex-direction:column;gap:8px;justify-content:center;box-shadow:0 8px 24px rgba(23,37,84,.12)}}
.mini:nth-child(2){{border:1px solid {C['blue-5']}}}
.m-kicker{{font:700 10px 'Noto Sans Mono',monospace;letter-spacing:.12em;text-transform:uppercase}}
.m-title{{font:900 20px/1.15 'Night',Georgia,serif}}
.m-text{{font-size:11px;line-height:1.4}}
.m-pill{{align-self:flex-start;font:700 10px 'Day',sans-serif;border-radius:999px;padding:5px 12px;margin-top:4px}}
.bgs{{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px}}
.bg{{margin:0}}.bg div{{aspect-ratio:16/9;border-radius:12px}}.bg figcaption{{font-size:13px;margin-top:6px;color:rgba(23,37,84,.72)}}
.rules li{{margin-top:8px}}
.swatches{{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px}}
.swatch{{display:grid;grid-template-columns:44px 1fr;column-gap:12px;align-items:center;font-size:14px}}
.swatch .chip-color{{grid-row:span 3;width:44px;height:44px;border-radius:12px;border:1px solid rgba(23,37,84,.12)}}
.swatch code{{justify-self:start;font-size:12px}}.swatch small{{font-size:12px;line-height:1.35;color:rgba(23,37,84,.72)}}
table{{border-collapse:collapse;width:100%}}td,th{{text-align:left;padding:10px 12px;border-bottom:1px solid {C['blue-5']};vertical-align:middle;font-size:14px}}
th{{font:700 12px 'Noto Sans Mono',monospace;letter-spacing:.08em;text-transform:uppercase;color:rgba(23,37,84,.72)}}
.type td:first-child{{width:110px}}.type td:nth-child(2){{width:260px}}.type small{{color:rgba(23,37,84,.72)}}
.layouts{{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;margin-top:28px}}
.layout{{margin:0;background:#fff;border:1px solid {C['blue-5']};border-radius:16px;overflow:hidden}}
.layout img{{display:block;width:100%;aspect-ratio:16/9;object-fit:cover;background:{C['daylight-60']}}}
.layout figcaption{{padding:14px 16px 16px}}.layout p{{font-size:14px;line-height:1.45;margin:6px 0}}
.layout small{{display:block;font:12px/1.5 'Noto Sans Mono',monospace;color:rgba(23,37,84,.72)}}
.theme{{font:700 10px 'Noto Sans Mono',monospace;letter-spacing:.1em;text-transform:uppercase;border-radius:999px;padding:2px 9px;margin-left:6px;vertical-align:2px}}
.theme-night{{background:{C['midnight']};color:{C['green']}}}.theme-day{{background:{C['daylight']};color:{C['reviewpro']}}}.theme-blue{{background:{C['reviewpro']};color:#fff}}
.viewer-bar{{display:flex;align-items:center;gap:16px;height:64px;padding:0 24px;border-bottom:1px solid {C['blue-5']};flex:none}}
.viewer-bar span{{flex:1;color:rgba(23,37,84,.72);font-size:14px}}
.viewer{{flex:1;width:100%;border:0;background:{C['night']}}}
@media (max-width:900px){{body{{flex-direction:column}}nav{{width:auto}}.steps,.two,.minis,.bgs{{grid-template-columns:1fr}}main{{min-height:80vh}}}}
'''
    nav = ''.join(f'<button type="button" data-panel="{k}">{label}</button>' for k, label, _ in PANELS)
    secs = ''.join(f'<section id="panel-{k}" class="{"frame" if k == "examples" else ""}">'
                   f'{fn() if k == "examples" else "<div class=content>" + fn() + "</div>"}</section>' for k, _, fn in PANELS)
    js = '''
const ids=[...document.querySelectorAll('nav button')].map(b=>b.dataset.panel);
function show(id){if(!ids.includes(id))id=ids[0];document.querySelectorAll('section').forEach(s=>s.classList.toggle('active',s.id==='panel-'+id));
document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.panel===id));}
document.querySelectorAll('nav button').forEach(b=>b.addEventListener('click',()=>{history.replaceState(null,'','#'+b.dataset.panel);show(b.dataset.panel);}));
addEventListener('hashchange',()=>show(location.hash.slice(1)));show(location.hash.slice(1));'''
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Presentation Designer · Figma Slides with Kiro</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Mono:wght@400;500;700&display=swap" rel="stylesheet">
<style>{css}</style></head><body>
<nav aria-label="Kit website">{logo_html()}<div class="kitname">Presentation designer</div>{nav}
<p class="foot">Figma Slides · Shiji Day &amp; Night<br><a href="download/{ZIP_NAME}" download>Download the kit</a></p></nav>
<main>{secs}</main>
<script>{js}</script></body></html>'''


# --------------------------------------------------------------------------- downloads
def public_zip(path):
    """The kit without the team's own decks; its library page without them either."""
    count = 0
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(KIT):
            dirs[:] = [d for d in dirs if d not in build_kit_zip.SKIP_DIRS and d != 'public']
            for f in files:
                full = os.path.join(root, f)
                rel = os.path.relpath(full, KIT)
                posix = rel.replace(os.sep, '/')
                if not build_kit_zip.keep(rel) or posix.startswith(INTERNAL):
                    continue
                arc = 'Presentation-Designer/' + posix
                if posix == 'library/index.html':
                    z.writestr(arc, build_library_page.page(public=True))
                else:
                    z.write(full, arc)
                count += 1
    return count


def build():
    show = subprocess.run([sys.executable, os.path.join(KIT, 'setup', 'build_showcase.py')], text=True)
    if show.returncode != 0:
        sys.exit('The Day & Night template did not build cleanly: fix it before publishing.')
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    os.makedirs(os.path.join(OUT, 'download'))
    shutil.copytree(os.path.join(KIT, 'library', 'day-night'), os.path.join(OUT, 'layouts'))
    viewer = os.path.join(OUT, 'examples', 'day-night-template')
    os.makedirs(viewer)
    shutil.copy(os.path.join(SHOW, 'preview', 'index.html'), viewer)
    shutil.copytree(os.path.join(SHOW, 'preview', 'images'), os.path.join(viewer, 'images'))
    shutil.copy(os.path.join(SHOW, 'Shiji Day & Night template.fig'), os.path.join(OUT, 'download', FIG_NAME))
    files = public_zip(os.path.join(OUT, 'download', ZIP_NAME))
    with open(os.path.join(OUT, 'index.html'), 'w', encoding='utf-8') as f:
        f.write(page())
    open(os.path.join(OUT, '.nojekyll'), 'w').close()
    size = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(OUT) for f in fs)
    print(json.dumps({'site': OUT, 'kit_zip_files': files, 'site_mb': round(size / 1e6, 1),
                      'downloads': sorted(os.listdir(os.path.join(OUT, 'download')))}, indent=1))


def serve():
    os.chdir(OUT)
    with socketserver.TCPServer(('127.0.0.1', 8000), http.server.SimpleHTTPRequestHandler) as httpd:
        print('Preview on http://localhost:8000 (Ctrl+C to stop)')
        httpd.serve_forever()


if __name__ == '__main__':
    build()
    if '--serve' in sys.argv:
        serve()
