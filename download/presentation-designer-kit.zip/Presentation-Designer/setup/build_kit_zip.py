#!/usr/bin/env python3
"""Package the kit for sharing: download/presentation-designer-kit.zip.

    python3 setup/build_kit_zip.py

Runs the setup check and rebuilds the Day & Night template (both must pass), then zips the kit
without personal work: decks/ (only its README stays), previews, caches, macOS files and earlier
downloads. The zip keeps the hidden .kiro/ folder (agent, skills, steering) and the built
"Shiji Day & Night template.fig", ready to drag into Figma.
"""
import os
import subprocess
import sys
import zipfile

KIT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
OUT = os.path.join(KIT, 'download', 'presentation-designer-kit.zip')
SKIP_DIRS = {'__pycache__', '.git', 'download', 'public', '.public-edition', 'preview', 'pptx-preview', '.agents',
             'node_modules'}
SKIP_FILES = {'.DS_Store', 'Thumbs.db'}


def keep(rel):
    parts = rel.split(os.sep)
    if any(p in SKIP_DIRS for p in parts):
        return False
    if parts[-1] in SKIP_FILES:
        return False
    if parts[0] == 'decks' and rel != os.path.join('decks', 'README.md'):
        return False
    if parts[:2] == ['examples', 'smoke-test'] and parts[-1].endswith(('.fig', '.deck', '.pptx')):
        return False  # rebuilt by the setup check on every computer
    return True


def main():
    check = subprocess.run([sys.executable, os.path.join(KIT, 'setup', 'check_setup.py')], text=True)
    if check.returncode != 0:
        print('The setup check failed: fix it before sharing the kit.')
        sys.exit(1)
    show = subprocess.run([sys.executable, os.path.join(KIT, 'setup', 'build_showcase.py')], text=True)
    if show.returncode != 0:
        print('The Day & Night template did not build cleanly: fix it before sharing the kit.')
        sys.exit(1)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    count = 0
    with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(KIT):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for f in files:
                full = os.path.join(root, f)
                rel = os.path.relpath(full, KIT)
                if keep(rel):
                    z.write(full, os.path.join('Presentation-Designer', rel))
                    count += 1
    print(f'{OUT}\n{count} files, {os.path.getsize(OUT) // 1024 // 1024} MB')


if __name__ == '__main__':
    main()
