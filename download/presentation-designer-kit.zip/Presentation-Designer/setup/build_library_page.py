#!/usr/bin/env python3
"""Write library/index.html: the Day & Night layouts, then the previous template and the team's decks.

    python3 setup/build_library_page.py

page(public=True) leaves out the team's decks (library/decks, library/slides): the public website and
its download use that version.
"""
import glob
import html
import json
import os
import re

KIT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
LIB = os.path.join(KIT, 'library')
EXAMPLES = os.path.join(KIT, '.kiro', 'skills', 'figma-slides-builder', 'references', 'examples.md')

DECKS = {
    'A': ('UX & UI Updates · Product Monthly', 'Design and component update', 'https://www.figma.com/slides/PmOV26l9XFQu9ndIz8igTa'),
    'B': ('UX Research & Mobile Initiative', 'Research readout', 'https://www.figma.com/slides/Zh3rYHndnzD76hBC0OaRXP'),
    'C': ('Design Updates · Q3 2026', 'Quarterly', 'https://www.figma.com/slides/tcIYHEBS1DGtWJnTQcmZ4Z'),
    'D': ('Design Updates · Q2 2026', 'Quarterly', 'https://www.figma.com/slides/uoOcpvKGl68lykWrWvOja3'),
}
TEMPLATE_URL = 'https://www.figma.com/slides/Q43PlPzdfGtoPMZOjttDxH'


def patterns():
    """Pattern rows from examples.md: (pattern, ids, layout)."""
    if not os.path.exists(EXAMPLES):
        return []
    rows = []
    for line in open(EXAMPLES, encoding='utf-8'):
        cells = [c.strip() for c in line.strip().strip('|').split('|')]
        if len(cells) >= 3 and re.search(r'\b[A-D]\d{2}\b', cells[1]) and '`' in cells[2]:
            rows.append((cells[0], re.findall(r'\b[A-D]\d{2}\b', cells[1]), re.sub(r'`', '', cells[2])))
    return rows


def page(public=False):
    rel = lambda p: os.path.relpath(p, LIB).replace(os.sep, '/')  # noqa: E731
    parts = []
    dn = os.path.join(LIB, 'day-night', 'index.json')
    if os.path.exists(dn):
        parts.append('<section><h2>Day &amp; Night layouts <span>what the kit builds now: one slide per layout, '
                     'from examples/day-night-template</span></h2><div class="grid">')
        for it in json.load(open(dn, encoding='utf-8')):
            parts.append(f'<figure><img loading="lazy" src="day-night/{html.escape(it["file"])}"><figcaption>'
                         f'{it["n"]:02d} · <code>{html.escape(it["layout"])}</code></figcaption></figure>')
        parts.append('</div></section>')
    t_imgs = sorted(glob.glob(os.path.join(LIB, 'template', 't[0-9][0-9].jpg')))
    parts.append(f'<section><h2>Previous template <span>Product Presentation Template, the look the kit replaced</span> '
                 f'<a href="{TEMPLATE_URL}">open in Figma</a></h2><div class="grid">')
    parts += [f'<figure><img loading="lazy" src="{rel(p)}"><figcaption>T{os.path.basename(p)[1:3]}</figcaption></figure>' for p in t_imgs]
    parts.append('</div></section>')
    singles = {os.path.basename(p)[:-4]: p for p in glob.glob(os.path.join(LIB, 'slides', '*.jpg'))}
    pats = [] if public else patterns()
    if pats:
        parts.append('<section><h2>Patterns from the team\'s decks <span>the original slides and the layout that '
                     'rebuilds each one in Day &amp; Night</span></h2><div class="grid">')
        for name, ids, lay in pats:
            pic = next((singles[i] for i in ids if i in singles), None)
            if pic:
                parts.append(f'<figure><img loading="lazy" src="{rel(pic)}"><figcaption><b>{html.escape(name)}</b><br>'
                             f'{html.escape(", ".join(ids))} · <code>{html.escape(lay)}</code></figcaption></figure>')
        parts.append('</div></section>')
    for letter, (title, kind, url) in ({} if public else DECKS).items():
        sheets = sorted(glob.glob(os.path.join(LIB, 'decks', f'deck{letter}-*.jpg')))
        if not sheets:
            continue
        parts.append(f'<section><h2>{letter} · {html.escape(title)} <span>{html.escape(kind)}</span> <a href="{url}">open in Figma</a></h2>')
        parts += [f'<img class="sheet" loading="lazy" src="{rel(p)}">' for p in sheets]
        parts.append('</section>')
    html_page = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Presentation library</title>
<style>
body{{margin:0;font:15px/1.5 -apple-system,system-ui,sans-serif;background:#F8FCFF;color:#172554}}
header{{background:#172554;color:#fff;padding:32px 48px}}header h1{{margin:0;font-size:28px}}header p{{margin:6px 0 0;color:#D5ECFF}}
section{{padding:24px 48px}}h2{{color:#172554;font-size:20px;margin:0 0 16px}}h2 span{{color:#1E3A8A;opacity:.75;font-weight:400;font-size:15px;margin-left:8px}}
h2 a{{font-size:13px;font-weight:400;margin-left:12px;color:#0030FF}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px}}
figure{{margin:0;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(23,34,86,.15)}}
figure img{{width:100%;display:block;aspect-ratio:16/9;object-fit:cover}}figcaption{{padding:8px 12px;font-size:13px}}
code{{background:#E8F5FF;padding:1px 5px;border-radius:4px}}.sheet{{width:100%;display:block;margin:0 0 12px;border-radius:8px}}
</style></head><body><header><h1>Presentation library</h1><p>The Day &amp; Night layouts, the previous template and the design team's reference decks. Built by setup/build_library_page.py.</p></header>
{"".join(parts)}</body></html>'''
    return html_page


def main():
    out = os.path.join(LIB, 'index.html')
    open(out, 'w', encoding='utf-8').write(page())
    print(out)


if __name__ == '__main__':
    main()
