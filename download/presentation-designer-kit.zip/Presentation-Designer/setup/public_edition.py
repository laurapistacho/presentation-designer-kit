#!/usr/bin/env python3
"""The public edition of the kit: what the website and its download may show (maintainer script).

    python3 setup/public_edition.py <folder>

The official template and the Day & Night showcase carry the team's own material: real product
screenshots, a screen recording, internal links and stale copies of pasted slides. The public edition
leaves all of that out:

- template/: a cleaned copy of the official template. It keeps the file skeleton the builder uses
  (the Slides theme, its colours and text styles, the components, the layers the layouts copy) and
  drops everything else on the template slides, so no picture, video or link of the team survives.
- examples/day-night-template/: the showcase spec without the pictures in img/internal/ (those slides
  show their image placeholders), its pictures, and the showcase built from the cleaned template.
- library/day-night/: the pictures of that public build, for the website and the library page.

build_site.py calls build(); the internal kit (build_kit_zip.py) keeps everything.
"""
import copy
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zlib

KIT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
BUILDER = os.path.join(KIT, '.kiro', 'skills', 'figma-slides-builder', 'scripts')
SHOW = os.path.join(KIT, 'examples', 'day-night-template')
INTERNAL_MEDIA = 'img/internal/'  # pictures of the team's own product work: internal edition only
sys.path.insert(0, BUILDER)
sys.path.insert(0, os.path.join(KIT, 'setup'))

import build_deck  # noqa: E402
import figdeck  # noqa: E402


# --------------------------------------------------------------------------- the template
def needed_ids(d):
    """Template layers the builder copies (every id in its code), with their subtrees and ancestors."""
    keep = set()
    for g in build_deck.template_ids_in_code():
        n = d.nodes.get(g)
        if n is None:
            continue
        keep.update(figdeck.gid(x) for x in d.subtree(n))
        p = d.parent(n)
        while p is not None:
            keep.add(figdeck.gid(p))
            p = d.parent(p)
    return keep


def sanitize_template(src, dst_dir):
    """A copy of the template without the team's material. Writes dst_dir/<name> and its decoded copy."""
    d = figdeck.Deck(src)
    keep = needed_ids(d)
    slides = d.of_type('SLIDE')
    doomed = set()
    for s in slides:
        sid = figdeck.gid(s)
        if sid not in keep:
            doomed.update(figdeck.gid(x) for x in d.subtree(s))  # a slide the builder never copies from
            continue
        for x in d.subtree(s):
            if figdeck.gid(x) not in keep:
                doomed.add(figdeck.gid(x))
    d.message['nodeChanges'] = [n for n in d.message['nodeChanges'] if figdeck.gid(n) not in doomed]
    d.reindex()
    placeholder = build_deck.solid('daylight-60')
    for n in d.message['nodeChanges']:
        fills = n.get('fillPaints') or []
        if any(p.get('type') == 'VIDEO' for p in fills):  # the video layer the builder copies: no recording
            n['fillPaints'] = [copy.deepcopy(placeholder)]
        for k in ('slideSpeakerNotes', 'hyperlink'):
            n.pop(k, None)
        td = n.get('textData') or {}
        for o in td.get('styleOverrideTable') or []:
            o.pop('hyperlink', None)
    for k in [k for k in d.extra_files if k.startswith('videos/')]:
        del d.extra_files[k]
    d.thumbnail = None
    os.makedirs(dst_dir, exist_ok=True)
    out = os.path.join(dst_dir, os.path.basename(src))
    d.save(out, file_name=d.meta.get('file_name'))
    # the decoded copy, so computers without the zstd tool read it (figdeck: template/decoded/)
    dec = os.path.join(dst_dir, 'decoded')
    os.makedirs(dec, exist_ok=True)
    for chunk in figdeck._canvas_chunks(out):
        if figdeck._needs_decoded_copy(chunk):
            with open(os.path.join(dec, hashlib.sha1(chunk).hexdigest() + '.zlib'), 'wb') as f:
                f.write(zlib.compress(figdeck.decompress(chunk), 9))
    left = figdeck.Deck(out)
    return {'file': out, 'layers': len(left.message['nodeChanges']), 'images': sorted(left.used_image_hashes()),
            'videos': sorted(left.used_video_hashes()), 'slides_kept': len(left.of_type('SLIDE'))}


# --------------------------------------------------------------------------- the showcase
def public_spec(spec):
    """The showcase spec with every internal picture taken out (the slide shows its placeholder)."""
    def clean(v):
        if isinstance(v, str):
            return None if v.startswith(INTERNAL_MEDIA) else v
        if isinstance(v, list):
            return [clean(x) for x in v]
        if isinstance(v, dict):
            return {k: clean(x) for k, x in v.items()}
        return v

    def unlink(v):  # links into the team's intranet become plain text
        if isinstance(v, dict):
            return {k: unlink(x) for k, x in v.items() if not (k == 'url' and is_internal_url(x))}
        if isinstance(v, list):
            return [unlink(x) for x in v]
        if isinstance(v, str):
            return INTERNAL_LINK.sub(lambda m: m.group(1), v)
        return v
    out = copy.deepcopy(spec)
    for i, sp in enumerate(out.get('slides') or []):
        for k in list(sp):
            if k in ('image', 'images', 'video', 'poster', 'columns', 'variants', 'people', 'left_image', 'right_image'):
                sp[k] = clean(sp[k])
        out['slides'][i] = unlink(sp)
    return out


INTERNAL_DOMAINS = ('shijidev' + '.com',)  # written in two parts so the public scan does not flag this line
INTERNAL_LINK = re.compile(r'\[([^\]]+)\]\((https?://[^)\s]*(?:' + '|'.join(re.escape(d) for d in INTERNAL_DOMAINS) + r')[^)\s]*)\)')


def is_internal_url(url):
    return isinstance(url, str) and any(d in url for d in INTERNAL_DOMAINS)


def build(folder):
    """Write the public edition into folder/: template/, examples/day-night-template/, library/day-night/."""
    if os.path.isdir(folder):
        shutil.rmtree(folder)
    tpl = sanitize_template(build_deck.TEMPLATE, os.path.join(folder, 'template'))
    show = os.path.join(folder, 'examples', 'day-night-template')
    os.makedirs(os.path.join(show, 'img'))
    for p in glob.glob(os.path.join(SHOW, 'img', '*')):
        if os.path.isfile(p):
            shutil.copy(p, os.path.join(show, 'img'))
    spec = public_spec(json.load(open(os.path.join(SHOW, 'deck.json'), encoding='utf-8')))
    with open(os.path.join(show, 'deck.json'), 'w', encoding='utf-8') as f:
        json.dump(spec, f, indent=1, ensure_ascii=False)
        f.write('\n')
    import build_showcase
    r = build_showcase.build(os.path.join(show, 'deck.json'), os.path.join(show, 'Shiji Day & Night template.fig'),
                             os.path.join(show, 'preview'), os.path.join(folder, 'library', 'day-night'),
                             template=tpl['file'])
    leaks = [h for h in figdeck.Deck(os.path.join(show, 'Shiji Day & Night template.fig')).used_image_hashes()
             if h in internal_hashes()]
    if leaks:
        sys.exit(f'The public showcase still holds {len(leaks)} internal pictures: {leaks[:3]}')
    return {'template': tpl, 'showcase': r, 'folder': folder}


def internal_hashes():
    """SHA-1 of every picture and video the public edition must not carry."""
    out = set()
    for p in glob.glob(os.path.join(SHOW, 'img', 'internal', '*')):
        out.add(hashlib.sha1(open(p, 'rb').read()).hexdigest())
    d = figdeck.Deck(build_deck.TEMPLATE)
    keep = needed_ids(d)
    kept_images = set()
    for g in keep:
        for p in (d.nodes[g].get('fillPaints') or []):
            if p.get('type') == 'IMAGE':  # the laptop picture and its thumbnail
                for k in ('image', 'imageThumbnail'):
                    if p.get(k):
                        kept_images.add(figdeck.image_hash_hex(p[k]))
    kit_samples = {hashlib.sha1(open(p, 'rb').read()).hexdigest() for p in glob.glob(os.path.join(SHOW, 'img', '*'))
                   if os.path.isfile(p)}
    out |= set(d.images) - kept_images - kit_samples
    out |= {k.split('/', 1)[1] for k in d.extra_files if k.startswith('videos/')}
    return out


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    print(json.dumps(build(os.path.abspath(sys.argv[1])), indent=1, default=str))
